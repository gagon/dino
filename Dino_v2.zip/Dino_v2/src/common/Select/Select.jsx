import React from 'react';
import Field from '../Form/Field';
import { Wrapper } from './SelectStyle';
import Typography from '@mui/material/Typography';
import { makeStyles } from '@mui/styles';
import FormControl from '@mui/material/FormControl';
import { Checkbox, ListItemText, Select as MuiSelect } from '@mui/material';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

const getChecked = (optionValue, value) =>
  value instanceof Array ? value.includes(optionValue) : value === optionValue;

const getOptionsValue = (options, value, placeholder, error) => {
  let result = [];
  if (!value && placeholder) {
    return (
      <Typography
        children={placeholder}
        variant={'body1'}
        color={error ? 'error' : 'textSecondary'}
      />
    );
  } else {
    options.forEach((option) => {
      getChecked(option.value, value) && result.push(option['name']);
    });
    return result.join(', ');
  }
};

const useStyles = makeStyles((theme) => ({
  helperTextRoot: {
    marginLeft: 14,
  },
  placeholder: { color: theme.palette.text.disabled },
  disabled: {
    color: '#979797 !important',
  },
}));

function SelectComponent(props) {
  const {
    name,
    options = [],
    value,
    onChange,
    multiple,
    disabled,
    label,
    placeholderValue = undefined,
    variant,
    outlineLabel,
    iconComponent,
    endIcon,
    helperText,
    height = 34,
    withoutEmptyOption,
    ...restProps
  } = props;
  const styles = useStyles();
  const isChanged = restProps.savedValue !== value && restProps.editedBg;

  return (
    <FormControl fullWidth disabled={disabled} error={!!props?.error}>
      {label && (
        <Typography
          style={{ marginBottom: 10 }}
          color={'textSecondary'}
          className=""
          children={label}
        />
      )}
      <MuiSelect
        fullWidth
        labelId="select"
        sx={{ background: isChanged ? 'rgb(248,161,105)' : undefined }}
        classes={{ disabled: styles.disabled }}
        name={name}
        multiple={multiple}
        onChange={onChange}
        variant={variant}
        displayEmpty
        MenuProps={{ style: { maxWidth: 650 }, ...props.MenuProps }}
        renderValue={(value) => getOptionsValue(options, value, props.placeholder, props?.error)}
        IconComponent={iconComponent ? iconComponent : KeyboardArrowDownIcon}
        {...restProps}
        value={multiple ? value || [] : value}
      >
        {!withoutEmptyOption && (
          <MenuItem key={'0'} value={placeholderValue} selected>
            <ListItemText primary={props.placeholder} className={styles.placeholder} />
          </MenuItem>
        )}
        {options.map((option) => (
          <MenuItem key={option.name} value={option.value}>
            {multiple && (
              <Checkbox
                color="primary"
                checked={getChecked(option.value, value)}
                style={{ marginRight: 5, width: 30 }}
              />
            )}
            <ListItemText primary={option['name']} />
            {endIcon && endIcon(option)}
          </MenuItem>
        ))}
      </MuiSelect>
      {helperText && (
        <FormHelperText classes={{ root: styles.helperTextRoot }} error={!!props?.error}>
          {helperText}
        </FormHelperText>
      )}
    </FormControl>
  );
}

const Select = (props) => {
  const {
    withoutForm,
    withoutEmptyOption,
    name,
    onChange,
    size,
    className,
    selectStyle,
    style,
    control,
    ...restProps
  } = props;
  return (
    <Wrapper size={size} selectStyle={selectStyle} style={style} className={className}>
      {withoutForm ? (
        <SelectComponent
          name={name}
          onChange={onChange}
          withoutEmptyOption={withoutEmptyOption}
          {...restProps}
        />
      ) : (
        <Field name={name} control={control}>
          {({ ref, ...fieldProps }) => {
            return (
              <SelectComponent
                name={name}
                inputRef={ref}
                withoutEmptyOption={withoutEmptyOption}
                {...restProps}
                {...fieldProps}
              />
            );
          }}
        </Field>
      )}
    </Wrapper>
  );
};

Select.defaultProps = {
  withoutForm: false,
  size: 'large',
};

export default Select;
