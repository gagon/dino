import styled from 'styled-components';

export const Wrapper = styled.div`
  width: 100%;

  .MuiSelect-select:focus {
    background-color: transparent;
  }

  .MuiFormControl-root {
    margin: 0;
  }

  .MuiOutlinedInput-root {
    padding: ${({ selectStyle }) => (selectStyle?.padding ? `${selectStyle.padding}px;` : '15px')};
    border-radius: ${({ selectStyle }) =>
      selectStyle?.borderRadius ? ` ${selectStyle.borderRadius}px;` : '8px'};
    height: ${({ selectStyle }) => (selectStyle?.height ? ` ${selectStyle.height}px;` : '34px')};
    margin: 0;
  }

  fieldset {
    display: ${(props) => (props?.selectStyle?.border === 'none' ? 'none' : 'inherit')};
  }
`;
