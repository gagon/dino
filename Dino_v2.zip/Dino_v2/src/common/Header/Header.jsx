import AccountCircleOutlinedIcon from '@mui/icons-material/AccountCircleOutlined';
import { Typography } from '@mui/material';
import AppBar from '@mui/material/AppBar';
import Button from '@mui/material/Button';
import Toolbar from '@mui/material/Toolbar';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loginModule, logout } from '../../pages/Login/LoginDucks';
import LogOutIcon from '../../_media/LogOutIcon';
import ScheduledCases from '../ScheduledCases/ScheduledCases';
import useSimpleModal from '../_hooks/useSimpleModal';
import LogOutDialog from './Dialog/LogOutDialog';
import { StyledHeader, useStyles } from './HeaderStyle';

export default function Header() {
  const logOutDialog = useSimpleModal();
  const classes = useStyles();
  const user = useSelector((state) => state[loginModule].user);
  const dispatch = useDispatch();

  return (
    <StyledHeader>
      <AppBar position="static" elevation={0} className="appbar">
        <div className="box ml0">
          <Toolbar disableGutters className={classes.toolbar}>
            <div className="dino-logo">
              <img src={'/dino-logo.png'} width={34} height={24} />
              <Typography children={'DINO'} />
            </div>
            <div className="flex justify-between items-center fullWidth">
              <div className="col-4 flex items-center fs-12">
                <img src={'/kpo-logo.svg'} width={46} height={29} />
                <span children={'Karachaganak'} className="fs-17 bold" />
              </div>
            </div>
            <div className="col-8  menu-item">
              <ScheduledCases />
              <Button
                color="inherit"
                sx={{ textTransform: 'none', borderRadius: 20, padding: '8px 20px' }}
                startIcon={<AccountCircleOutlinedIcon style={{ fontSize: 20 }} />}
                children={user?.user_name}
              />
              <Button
                color="inherit"
                sx={{ textTransform: 'none', borderRadius: 20, padding: '8px 20px' }}
                startIcon={<LogOutIcon style={{ fontSize: 20 }} />}
                children="Logout"
                onClick={() => dispatch(logout())}
              />
            </div>
          </Toolbar>
        </div>
      </AppBar>
      {logOutDialog.isOpen && <LogOutDialog {...logOutDialog} />}
    </StyledHeader>
  );
}
