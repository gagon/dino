import { addTranslation } from "../../../_helpers/translate";

addTranslation({
    ru: {
        log_out_warning: "Вы действительно хотите выйти?",
        log_out_cancel: "Нет",
        log_out_confirm: "Да",
    },
    kk: {},
});
