import styled from 'styled-components';
import { makeStyles } from '@mui/styles';

export const StyledHeader = styled.div`
  height: 76px;
  z-index: 3;

  .box {
    margin-right: 16px;
    height: 100%;
  }

  .appbar {
    height: 100%;
    background-color: ${({ theme }) => theme.palette.background.paper};
    color: ${({ theme }) => theme.palette.text.primary};
  }

  .dino-logo {
    padding: 14px 28px;
    margin-right: 16px;
    background: #fbfaff;
  }

  .menu-item {
    display: flex;
    align-items: center;
    justify-content: end;
    button {
      color: ${({ theme }) => theme.palette.action.disabled};
      font-size: 14px;
      span {
        color: ${({ theme }) => theme.palette.primary.main};
      }
    }
  }
`;

export const useStyles = makeStyles(({ palette }) => ({
  toolbar: {
    height: '100%',
  },
}));
