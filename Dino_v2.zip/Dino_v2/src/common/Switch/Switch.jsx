import React from 'react';
import { Switch as MuiSwitch } from '@mui/material';
import { styled } from '@mui/material/styles';

const AntSwitch = styled(MuiSwitch)(({ theme, size }) => ({
  width: size === 'small' ? 36 : 55,
  height: size === 'small' ? 18 : 25,
  padding: 0,
  alignItems: 'center',
  display: 'flex',
  '&:active': {
    '& .MuiSwitch-thumb': {
      width: size === 'small' ? 4 : 15,
    },
    '& .MuiSwitch-switchBase.Mui-checked': {
      transform: 'translateX(3px)',
    },
  },
  '& .MuiSwitch-switchBase': {
    padding: 2,
    '&.Mui-checked': {
      transform: size === 'small' ? 'translateX(19px)' : 'translateX(30px)',
      color: '#fff',
      '& + .MuiSwitch-track': {
        opacity: 1,
        backgroundColor: theme.palette.success.main,
      },
    },
  },
  '& .MuiSwitch-thumb': {
    boxShadow: '0 2px 4px 0 rgb(0 35 11 / 20%)',
    width: size === 'small' ? 12 : 19,
    height: size === 'small' ? 12 : 19,
    borderRadius: 50,
    marginTop: 1,

    transition: theme.transitions.create(['width'], {
      duration: 200,
    }),
  },
  '& .MuiSwitch-track': {
    borderRadius: 50,
    opacity: 1,
    backgroundColor: theme.palette.action.disabled,
    boxSizing: 'border-box',
  },
  '& .MuiSwitch-input': {
    width: '400% !important',
  },
}));

export default function Switch(props) {
  return (
    <>
      <AntSwitch {...props} inputProps={{ 'aria-label': 'ant design' }} />
    </>
  );
}
