import { ToggleButton, ToggleButtonGroup } from '@mui/material';
import { styled as muiStyled } from '@mui/material/styles';
import styled from 'styled-components';

export const HeaderMenuStyles = styled.div`
  background: #eef0f9;
  height: 38px;
  display: flex;
  align-items: center;
  z-index: 2;
  justify-content: space-between;
  padding-right: 28px;
  border-top: 1px solid #e3e3e3 !important;
  border-bottom: 1px solid #cfcfcf !important;

`;

export const StyledToggleButtonGroup = muiStyled(ToggleButtonGroup)(({ theme }) => ({
  '& .MuiToggleButtonGroup-grouped': {
    margin: theme.spacing(0.5),
    border: 0,
    borderRadius: 14,
    fontSize: 12,

    '&.Mui-disabled': {
      border: 0,
    },
    '&:not(:first-of-type)': {
      borderRadius: 14,
    },
    '&:first-of-type': {
      borderRadius: 14,
    },
  },

  '& .css-1mogbpw-MuiButtonBase-root-MuiToggleButton-root.Mui-selected': {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.common.white,
    '& .css-i4bv87-MuiSvgIcon-root': {
      stroke: `${theme.palette.common.white} !important`,
    },
  },
}));

export const StyledToggleButton = muiStyled(ToggleButton)(({ theme }) => ({
  borderRadius: 14,
  textTransform: 'none',
  color: theme.palette.text.primary,
  height: 25,
  whiteSpace: 'nowrap',
}));

export const HeaderColorKeyStyled = styled.div`
  display: flex;
  float: right;

  span {
    white-space: nowrap;
  }

  .indicator {
    width: 18px;
    height: 18px;
    background-color: white;
    border-radius: 50%;
    padding: 3px;
  }

  .indicator-key {
    width: 12px;
    height: 12px;
    border-radius: 50%;
  }
`;