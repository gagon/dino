import React, { Fragment } from 'react';

import { HeaderColorKeyStyled } from './HeaderMenuStyle';

const colorKeyItems = [
  { text: 'Unsaved Edit', backgroundColor: '#FE7F2E' },
  { text: 'Used In Optimization', backgroundColor: '#D4EEFF' },
  { text: 'Error', backgroundColor: '#D7153C' },
];

export default function HeaderColorKey() {
  return (
    <HeaderColorKeyStyled>
      <span className="text-secondary bold fs-12 mr2">Color Key :</span>
      {colorKeyItems.map(({ text, backgroundColor }) => (
        <Fragment key={text}>
          <div className="indicator">
            <div className="indicator-key" style={{ backgroundColor }} />
          </div>
          <span className="text-secondary fs-12 ml1 mr2">{text}</span>
        </Fragment>
      ))}
    </HeaderColorKeyStyled>
  );
}
