import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router';

import './HeaderMenuTranslate';
import HeaderColorKey from './HeaderColorKey';
import { headerMenuItems } from './HeaderMenuItems';
import { loginModule } from '../../pages/Login/LoginDucks';
import { LAST_VIEWED_CASE } from '../../_helpers/constants';

import { HeaderMenuStyles, StyledToggleButton, StyledToggleButtonGroup } from './HeaderMenuStyle';

export default function HeaderMenu() {
  const [page, setPage] = useState();
  const lastViewedCase = useSelector((state) => state[loginModule].userConfig[LAST_VIEWED_CASE]);
  const navigate = useNavigate();

  const handleChange = (e, path) => {
    setPage(path);
    navigate(path, { replace: true });
  };

  const handleMouseDown = (e) => {
    if (e.button === 1) {
      e.preventDefault();
    }
  };
  const handleMouseUp = (e, path) => {
    if (e.button === 1) {
      window.open(path, '_blank');
    }
  };

  return (
    <HeaderMenuStyles>
      <StyledToggleButtonGroup exclusive color="primary" value={page} onChange={handleChange}>
        {headerMenuItems(lastViewedCase).map(({ path, icon, label }) => (
          <StyledToggleButton
            key={path}
            value={path}
            onMouseDown={handleMouseDown}
            onMouseUp={(e) => handleMouseUp(e, path)}
          >
            {icon}
            {label}
          </StyledToggleButton>
        ))}
      </StyledToggleButtonGroup>
      <HeaderColorKey />
    </HeaderMenuStyles>
  );
}
