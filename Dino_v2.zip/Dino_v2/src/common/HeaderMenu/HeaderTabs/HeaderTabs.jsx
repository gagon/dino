import React from 'react';
import { MuiTabs, HeaderTabStyles } from './HeaderTabStyles';

export default function HeaderTabs({ value, ...props }) {
  return (
    <HeaderTabStyles>
      <MuiTabs TabIndicatorProps={{ style: { height: 4 } }} value={value} {...props} />
    </HeaderTabStyles>
  );
}
