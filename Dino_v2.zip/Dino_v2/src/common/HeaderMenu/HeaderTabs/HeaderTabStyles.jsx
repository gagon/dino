import styled from 'styled-components';
import { Tab, Tabs } from '@mui/material';
import { withStyles } from '@mui/styles';

export const HeaderTabStyles = styled.div`

;
  //position: sticky !important;
  //top: 55px;
  //z-index: 1101;
`;

export const MuiTabs = withStyles((theme) => ({
  root: {
    borderBottom: '1px solid #e8e8e8',
    backgroundColor: '#EEF0F9',
    color: theme.palette.text.primary,
    paddingLeft: 20,
  },
  indicator: {
    backgroundColor: theme.palette.text.primary,
  },
}))(Tabs);

export const MuiTab = withStyles((theme) => ({
  root: {
    // width: 240,
    fontSize: 14,
    color: '#FFFFFF',
    opacity: 0.38,

    '&$selected': {
      color: theme.palette.text.primary,
      backgroundColor: theme.palette.secondary.main,
    },
  },
  selected: {},
}))(Tab);
