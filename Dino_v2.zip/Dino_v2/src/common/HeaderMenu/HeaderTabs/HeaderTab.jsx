import React from 'react';
import { MuiTab } from './HeaderTabStyles';

export default function HeaderTab({ label, value, ...props }) {
  return <MuiTab label={label} value={value} {...props} />;
}
