import paths from '../../_helpers/paths';
import SettingIcon from '../../_media/SettingIcon';
import ThemeConfig from '../ThemeProvider/ThemeConfig';
import PageIcon from '../../_media/PageIcon';
import PagesIcon from '../../_media/PagesIcon';
import DoubleArrowIcon from '../../_media/DoubleArrowIcon';
import DownloadIcon from '../../_media/DownloadIcon';
import HelpIcon from '@mui/icons-material/ErrorOutlineOutlined';

const headerMenuItemStyle = {
  fontSize: 18,
  marginRight: 8,
  stroke: ThemeConfig().palette.action.disabled,
};

export const headerMenuItems = (lastViewedCase) => [
  {
    path: paths.config + '?tabName=configuredGapFiles',
    label: 'Config',
    icon: <SettingIcon style={headerMenuItemStyle} />,
  },
  {
    path: paths.case.replace(':caseId', lastViewedCase),
    label: 'Case',
    icon: <PageIcon style={headerMenuItemStyle} />,
  },
  {
    path: paths.compare,
    label: 'Case Compare',
    icon: <PagesIcon style={headerMenuItemStyle} />,
  },
  {
    path: paths.optimize,
    label: 'Optimize Routing (beta)',
    icon: <DoubleArrowIcon style={headerMenuItemStyle} />,
  },
  {
    path: paths.gatheringReport,
    label: 'Load Gathering Report',
    icon: <DownloadIcon style={headerMenuItemStyle} />,
  },
  {
    path: paths.help,
    label: 'Help',
    icon: <HelpIcon style={headerMenuItemStyle} />,
  },
];
