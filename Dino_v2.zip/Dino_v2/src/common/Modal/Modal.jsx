import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';

const styles = theme => ({
  root: {
    margin: 0,
    padding: theme.spacing(2)
  },
  closeButton: {
    position: 'absolute',
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});

const DialogTitle = withStyles(styles)(props => {
  const { classes, onClose, title, ...other } = props;
  return (
    <MuiDialogTitle disableTypography {...other}>
      <div className={'flex items-center'}>
        <Typography variant={'h6'} children={title} {...props.titleTypographyProps} />
        {other.secondTitle && (
          <div className={'ml2'} style={{ marginTop: 5 }}>
            {other.secondTitle}
          </div>
        )}
      </div>
      {onClose ? (
        <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

function Modal({
  title,
  titleColor,
  icon = <div />,
  children,
  titleDesc,
  withoutTitle = false,
  ...rest
}) {
  return (
    <Dialog fullWidth {...rest} scroll={'paper'}>
      {!withoutTitle && (
        <DialogTitle
          onClose={rest.onClose}
          title={title}
          secondTitle={rest.secondTitle}
          titleTypographyProps={rest.titleTypographyProps}
        />
      )}
      {children}
    </Dialog>
  );
}

export default Modal;
