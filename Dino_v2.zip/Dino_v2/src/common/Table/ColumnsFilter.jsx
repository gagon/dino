import React from 'react';
import LeftArrowIcon from '../../_media/LeftArrowIcon';
import IconButton from '@mui/material/IconButton';
import { Checkbox, FormControlLabel, FormGroup, Popover } from '@mui/material';

export default function ColumnsFilter({ columns, columnFilter, changeFilter }) {
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;

  return (
    <div>
      <IconButton
        aria-describedby={id}
        children={<LeftArrowIcon style={{ fontSize: 20 }} />}
        onClick={handleClick}
      />
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
      >
        <div style={{ padding: 20, borderRadius: 20 }}>
          {columns.map((item, index) => {
            return (
              <div key={index}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={!columnFilter.includes(item.field)}
                      style={{ padding: 2 }}
                      onChange={({ target: { checked } }) => changeFilter(item.field, checked)}
                    />
                  }
                  label={item.headerName}
                />
              </div>
            );
          })}
        </div>
      </Popover>
    </div>
  );
}
