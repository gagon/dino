import React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { styled as muiStyled } from '@mui/material/styles';
import { useTheme } from '@mui/styles';

const MuiDataGrid = muiStyled(DataGrid)(({ theme, overflow }) => ({
  '& .MuiDataGrid-columnHeaders': {
    position: 'sticky',
    background: '#EEF0F9',
    borderTopRightRadius: 8,
    borderTopLeftRadius: 8,
    overflow: overflow,
    zIndex: 1,
  },

  '& .MuiDataGrid-columnHeaderTitle': {
    fontSize: 12,
    fontWeight: 600,
    lineHeight: 1.2,
  },

  '& .MuiDataGrid-virtualScroller': {
    // Undo the margins that were added to push the rows below the previously fixed header
    marginTop: '0 !important',
  },
  '& .MuiDataGrid-main': {
    // Not sure why it is hidden by default, but it prevented the header from sticking
    overflow: 'visible',
  },
  '& .MuiDataGrid-renderingZone': {
    maxHeight: 'none !important',
  },
  '& .MuiDataGrid-row': {
    maxHeight: 'none !important',
  },
  '& .MuiDataGrid-cell': {
    borderBottom: '2px solid #EEF0F9',
    padding: '0 5px',
    lineHeight: 'unset !important',
    maxHeight: 'none !important',
  },
  '& .MuiDataGrid-overlay': {
    zIndex: 'auto',
  },
}));

export default function Table(props) {
  const { palette } = useTheme();

  return (
    <MuiDataGrid
      {...props}
      rowHeight={props?.rowHeight || 40}
      sx={{
        background: palette.background.paper,
        ...props.sx,
      }}
      overflow={props.overflow}
    />
  );
}
