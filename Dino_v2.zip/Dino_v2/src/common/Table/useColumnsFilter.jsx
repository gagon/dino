import React, { useState } from 'react';

export default function useColumnsFilter() {
  const [columnFilter, setColumnFilter] = useState([]);

  const changeFilter = (item, checked) => {
    if (!checked) {
      setColumnFilter([...columnFilter, item]);
    } else {
      setColumnFilter(columnFilter.filter((filterItem) => filterItem !== item));
    }
  };

  return { columnFilter, changeFilter };
}
