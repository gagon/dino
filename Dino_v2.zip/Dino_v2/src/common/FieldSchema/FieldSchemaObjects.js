import React from 'react';
import oilImg from '../../_media/svg/oilWhite.svg';
import GasIcon from '../../_media/GasIcon';
import unitSvg from '../../_media/svg/unit.svg';
import ParamsModel from './VisualizationBoard/Params/Model';
import Lines from './Lines';
import WellParams from './VisualizationBoard/UnitComponents/WellParams';
import UnitComponentsModel from './VisualizationBoard/UnitComponents/Model';
import ParamsByTypeModel from './VisualizationBoard/ParamsByType/Model';
import createEngine, { DiagramModel } from '@projectstorm/react-diagrams';
import UnitComponentsFactory from './VisualizationBoard/UnitComponents/Factory';
import ParamsByTypeFactory from './VisualizationBoard/ParamsByType/Factory';
import ParamsFactory from './VisualizationBoard/Params/Factory';
import styled from '@emotion/styled';
import { ShowHideBlock } from '../../pages/Case/Fields/FieldComponents/ShowHideField';

export const FieldWrappers = styled.div`
  background: #eef8ff;
  height: calc(100% - 23px);
  border-bottom-right-radius: 10px;
  border-bottom-left-radius: 10px;
  padding: 16px 7px 16px 7px;
`;

const Unit = () => (
  <>
    <WellParams title={'Gas from wells'}>
      <FieldWrappers />
    </WellParams>
    <WellParams title={'Oil from wells'}>
      <FieldWrappers />
    </WellParams>
    <WellParams title={'Water from wells'}>
      <FieldWrappers />
    </WellParams>
  </>
);

const FieldGroup = ({ type, height = 90, title, padding, width = 120 }) => (
  <ShowHideBlock type={type}>
    <div
      style={{ height, padding: title || padding ? 5 : 'inherit', width }}
      children={
        title && <div className="fs-12 flex justify-center mb1 center bold" children={title} />
      }
    />
  </ShowHideBlock>
);

export function getModel() {
  const engine = createEngine({
    registerDefaultDeleteItemsAction: false,
    registerDefaultPanAndZoomCanvasAction: false,
    registerDefaultZoomCanvasAction: false,
  });
  engine.getNodeFactories().registerFactory(new UnitComponentsFactory());
  engine.getNodeFactories().registerFactory(new ParamsByTypeFactory());
  engine.getNodeFactories().registerFactory(new ParamsFactory());

  const lines = new ParamsModel(engine, {
    children: <Lines />,
  });
  lines.setPosition(0, 0);
  lines.setLocked(true);

  const secondUnitNode = new UnitComponentsModel(engine, {
    title: 'U2',
    children: <Unit />,
  });
  secondUnitNode.setPosition(200, 400);
  secondUnitNode.setLocked(true);

  const thirdUnit = new UnitComponentsModel(engine, {
    title: 'U3',
    children: <Unit />,
  });
  thirdUnit.setPosition(700, 100);
  thirdUnit.setLocked(true);

  const KpcNode = new UnitComponentsModel(engine, {
    title: 'KPC',
    children: <Unit />,
  });
  KpcNode.setPosition(1200, 400);
  KpcNode.setLocked(true);

  const ogpOil = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <img src={oilImg} />
        <span children={'OGP oil'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={86} />,
  });
  ogpOil.setPosition(700, -40);
  ogpOil.setLocked(true);

  const ogpGas = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <GasIcon style={{ fontSize: 10 }} />
        <span children={'OGP gas'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={66} />,
    bgColor: '#5051F9',
  });
  ogpGas.setPosition(993, -20);
  ogpGas.setLocked(true);

  const mtuOil = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <img src={oilImg} />
        <span children={'MTU oil'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={130} />,
  });
  mtuOil.setPosition(1150, 110);
  mtuOil.setLocked(true);

  const cpcOil = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <img src={oilImg} />
        <span children={'CPC oil'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup />,
  });
  cpcOil.setPosition(1350, 650);
  cpcOil.setLocked(true);

  const fuelGas = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <GasIcon style={{ fontSize: 10 }} />
        <span children={'Fuel gas'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={64} />,
    bgColor: '#5051F9',
  });
  fuelGas.setPosition(1200, 650);
  fuelGas.setLocked(true);

  const gasInjection = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <img src={unitSvg} height={10} />
        <span children={'Gas injection'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={70} />,
    bgColor: '#5051F9',
  });
  gasInjection.setPosition(200, 650);
  gasInjection.setLocked(true);

  const U3GasTrain = new ParamsModel(engine, {
    children: <FieldGroup title="U3 gas Trains + Degasser" height={70} />,
    style: { border: '2px dashed #F3F5F9', background: 'white' },
  });
  U3GasTrain.setPosition(520, 50);
  U3GasTrain.setLocked(true);

  const unitPressures = new ParamsModel(engine, {
    children: (
      <FieldGroup
        title="Unit pressures"
        width={250}
        height={130}
        padding={20}
        type="unitPressure"
      />
    ),
    style: { border: '2px solid #d5d4d4' },
  });
  unitPressures.setPosition(230, 145);
  unitPressures.setLocked(true);

  const gasOpt = new ParamsModel(engine, {
    children: (
      <FieldGroup title="Gas optimisation" width={320} height={220} padding={20} type="gasopt" />
    ),
    style: { border: '2px solid #d5d4d4' },
  });
  gasOpt.setPosition(160, -95);
  gasOpt.setLocked(true);

  const labData = new ParamsModel(engine, {
    children: <FieldGroup title="Lab data" width={290} height={330} padding={20} type="lab" />,
    style: { border: '2px solid #d5d4d4' },
  });
  labData.setPosition(1310, 20);
  labData.setLocked(true);

  const u2DrizoGas = new ParamsModel(engine, {
    children: <FieldGroup title="U2 Drizo Gas" height={76} />,
    style: { border: '2px dashed #F3F5F9', background: 'white' },
  });
  u2DrizoGas.setPosition(60, 550);
  u2DrizoGas.setLocked(true);

  const kpcTotalGasTransfer = new ParamsModel(engine, {
    children: <FieldGroup title="KPC total gas transfer" height={156} />,
    style: { border: '2px dashed #F3F5F9', background: 'white' },
  });
  kpcTotalGasTransfer.setPosition(1650, 350);
  kpcTotalGasTransfer.setLocked(true);

  const secondUnitToThirdUnit = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  secondUnitToThirdUnit.setPosition(706, 350);
  secondUnitToThirdUnit.setLocked(true);

  const kpcToThirdUnit = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  kpcToThirdUnit.setPosition(856, 350);
  kpcToThirdUnit.setLocked(true);

  const thirdUnitToKpc = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  thirdUnitToKpc.setPosition(1000, 350);
  thirdUnitToKpc.setLocked(true);

  const secondUnitToKpc = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  secondUnitToKpc.setPosition(940, 480);
  secondUnitToKpc.setLocked(true);

  const kpcToSecondUnit = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  kpcToSecondUnit.setPosition(720, 600);
  kpcToSecondUnit.setLocked(true);

  const kpcToSecondUnitConstraint = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  kpcToSecondUnitConstraint.setPosition(790, 554);
  kpcToSecondUnitConstraint.setLocked(true);

  const thirdGasOilCalculate = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  thirdGasOilCalculate.setPosition(520, -60);
  thirdGasOilCalculate.setLocked(true);

  const qgasMPSep = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  qgasMPSep.setPosition(65, 300);
  qgasMPSep.setLocked(true);

  const model = new DiagramModel();
  model.setZoomLevel(window.innerWidth < 1600 ? 76 : 90);
  model.setOffsetY(80);
  model.setOffsetX(0);
  // model.setLocked();
  model.addAll(
    lines,
    secondUnitNode,
    thirdUnit,
    KpcNode,
    ogpOil,
    ogpGas,
    mtuOil,
    cpcOil,
    fuelGas,
    gasInjection,
    U3GasTrain,
    unitPressures,
    gasOpt,
    labData,
    u2DrizoGas,
    kpcTotalGasTransfer,
    secondUnitToThirdUnit,
    kpcToThirdUnit,
    thirdUnitToKpc,
    secondUnitToKpc,
    kpcToSecondUnit,
    kpcToSecondUnitConstraint,
    thirdGasOilCalculate,
    qgasMPSep
  );
  engine.setModel(model);

  return { model, engine };
}
