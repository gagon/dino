import { CanvasEngine } from '@projectstorm/react-canvas-core';
import { NodeModel, NodeModelGenerics } from '@projectstorm/react-diagrams';
import { ReactNode } from 'react';

export interface Params {
  title?: string | ReactNode;
  type: string;
  children: ReactNode;
  style: object;
}

export interface ParamsNodeModelGenerics {
  params: Params;
}

class ParamsModel extends NodeModel<NodeModelGenerics & ParamsNodeModelGenerics> {
  private params: Params;

  constructor(readonly engine: CanvasEngine, params: Params) {
    super({ type: 'params-node' });
    this.params = params;
  }

  getParams(): Params {
    return this.params;
  }

  setParams = (params: Params) => {
    this.params = params;
    this.engine.repaintCanvas();
  };

  serialize() {
    return {
      ...super.serialize(),
      params: this.params,
      locked: true,
    };
  }
}

export default ParamsModel;
