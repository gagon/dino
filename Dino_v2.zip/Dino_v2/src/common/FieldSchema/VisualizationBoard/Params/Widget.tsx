import React, { FC } from 'react';
import { DiagramEngine } from '@projectstorm/react-diagrams';
import ParamsModel from './Model';

export interface ParamsWidgetProps {
  node: ParamsModel;
  engine: DiagramEngine;
}

const ParamsWidget: FC<ParamsWidgetProps> = ({ node }) => {
  const params = node.getParams();

  return (
    <div
      style={{
        borderRadius: 10,
        ...params.style,
      }}
    >
      <div children={params?.children} />
    </div>
  );
};

export default ParamsWidget;
