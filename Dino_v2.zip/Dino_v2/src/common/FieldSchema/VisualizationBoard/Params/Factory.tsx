import * as React from 'react';
import { AbstractReactFactory } from '@projectstorm/react-canvas-core';
import { DiagramEngine } from '@projectstorm/react-diagrams-core';
import ParamsModel from './Model';
import ParamsWidget from './Widget';

class ParamsFactory extends AbstractReactFactory<ParamsModel, DiagramEngine> {
  constructor() {
    super('params-node');
  }

  generateReactWidget(event: any) {
    return <ParamsWidget engine={this.engine} node={event.model} />;
  }

  generateModel() {
    return new ParamsModel(this.engine, { title: '', children: <></>, style: {}, type: '' });
  }
}

export default ParamsFactory;
