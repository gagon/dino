import { CanvasEngine } from '@projectstorm/react-canvas-core';
import { NodeModel, NodeModelGenerics } from '@projectstorm/react-diagrams';
import {ReactNode} from "react";

export interface UnitParams {
  title?: string;
  children:ReactNode

}

export interface UnitNodeModelGenerics {
  unitParams: UnitParams;
}

class UnitComponentsModel extends NodeModel<NodeModelGenerics & UnitNodeModelGenerics> {
  private unitParams: UnitParams;

  constructor(readonly engine: CanvasEngine,unitParams:UnitParams) {
    super({ type: 'unit-components-node' });
    this.unitParams = unitParams;

  }

  getUnitParams(): UnitParams {
    return this.unitParams;
  }

  setUnitParams = (unitParams: UnitParams) => {
    this.unitParams = unitParams;
    this.engine.repaintCanvas();
  };

  serialize() {
    return {
      ...super.serialize(),
      unitParams: this.unitParams,
      locked: true,
    };
  }
}

export default UnitComponentsModel;
