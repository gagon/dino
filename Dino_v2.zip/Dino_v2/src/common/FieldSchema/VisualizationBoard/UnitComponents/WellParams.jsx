import React from 'react';
import styled from '@emotion/styled';

const Params = styled.div`
  width: ${(props) => (props.large ? 188 : 126)}px;
  height: ${(props) => (props.large ? 204 : 194)}px;
  border: 1px dashed #1ea7ff;
  border-radius: 10px;

  .fieldWrappers {
    background: #eef8ff;
    height: calc(100% - 23px);
    border-bottom-right-radius: 10px;
    border-bottom-left-radius: 10px;
    padding: 16px 7px 16px 7px;
  }
`;

export default function WellParams({ title, children, isHidden, large }) {
  return (
    <div style={{ visibility: isHidden ? 'hidden' : 'visible' }}>
      <Params large={large}>
        <div
          style={{ height: 23 }}
          className="fs-10 flex justify-center items-center bold"
          children={title}
        />
        {children}
      </Params>
    </div>
  );
}
