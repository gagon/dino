import React, { FC } from 'react';
import { DiagramEngine } from '@projectstorm/react-diagrams';
import UnitComponentsModel from './Model';
import styled from '@emotion/styled';

interface WidgetProps {
  large: any;
}

const Widget = styled.div<WidgetProps>`
  width: ${(props) => (props.large ? 603 : 430)}px;
  height: 230px;
  background: #d4eeff;
  border-radius: 10px;
  position: relative;
  padding: 8px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border: 1px solid #1ea7ff;

  .title {
    position: absolute;
    width: 80px;
    height: 28px;
    margin-top: -14px;
    top: 0;
    left: ${(props) => (props.large ? 250 : 175)}px;
    background: #1ea7ff;
    box-shadow: 0 8px 15px 0 #1ea7ff2e;
    border-radius: 6px;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
  }
`;

export interface UnitComponentsWidgetProps {
  node: UnitComponentsModel;
  engine: DiagramEngine;
  large: any;
}

const UnitComponentsWidget: FC<UnitComponentsWidgetProps> = ({ node, large }) => {
  const unitParams = node.getUnitParams();

  return (
    <Widget large={large}>
      <div className="title" children={unitParams?.title} />
      {unitParams?.children}
    </Widget>
  );
};
export default UnitComponentsWidget;
