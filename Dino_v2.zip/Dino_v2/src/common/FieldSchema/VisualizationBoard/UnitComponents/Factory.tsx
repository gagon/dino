import * as React from 'react';
import { AbstractReactFactory } from '@projectstorm/react-canvas-core';
import { DiagramEngine } from '@projectstorm/react-diagrams-core';
import UnitComponentsWidget from './Widget';
import UnitComponentsModel from './Model';

class UnitComponentsFactory extends AbstractReactFactory<UnitComponentsModel, DiagramEngine> {
  large = false;
  constructor(large: boolean) {
    super('unit-components-node');
    this.large = large;
  }

  generateReactWidget(event: any) {
    return <UnitComponentsWidget engine={this.engine} node={event.model} large={this.large} />;
  }

  generateModel() {
    return new UnitComponentsModel(this.engine, { title: '', children: <></> });
  }
}

export default UnitComponentsFactory;
