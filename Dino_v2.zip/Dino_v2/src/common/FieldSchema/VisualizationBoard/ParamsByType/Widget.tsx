import React, { FC } from 'react';
import { DiagramEngine } from '@projectstorm/react-diagrams';
import ParamsByTypeModel from './Model';

export interface ParamsByTypeWidgetProps {
  node: ParamsByTypeModel;
  engine: DiagramEngine;
}

const ParamsByTypeWidget: FC<ParamsByTypeWidgetProps> = ({ node }) => {
  const params = node.getParams();

  return (
    <div
      style={{
        minHeight: 84,
        background: 'white',
        borderRadius: 10,
        border: `1px solid ${params?.bgColor || '#0ACF83'}`,
        position: 'relative',
      }}
    >
      <span
        className="fs-10"
        style={{
          background: params?.bgColor || '#0ACF83',
          borderTopRightRadius: 5,
          borderBottomRightRadius: 5,
          padding: '2px 4px 2px 4px',
          color: 'white',
          position: 'absolute',
          marginTop: '-9px',
          marginLeft: '-1px',
        }}
        children={params?.title || ''}
      />

      <div style={{ padding: '15px 7px 10px 7px' }} children={params?.children} />
    </div>
  );
};

export default ParamsByTypeWidget;
