import { CanvasEngine } from '@projectstorm/react-canvas-core';
import { NodeModel, NodeModelGenerics } from '@projectstorm/react-diagrams';
import { ReactNode } from 'react';

interface Params {
  title?: string | ReactNode;
  children: ReactNode;
  type: string;
  bgColor: string;
}

export interface ParamsNodeModelGenerics {
  params: Params;
}

class ParamsByTypeModel extends NodeModel<NodeModelGenerics & ParamsNodeModelGenerics> {
  private params: Params;

  constructor(readonly engine: CanvasEngine, params: Params) {
    super({ type: 'params-by-type-node' });
    this.params = params;
  }

  getParams(): Params {
    return this.params;
  }

  setParams = (params: Params) => {
    this.params = params;
    this.engine.repaintCanvas();
  };

  serialize() {
    return {
      ...super.serialize(),
      params: this.params,
      locked: true,
    };
  }
}

export default ParamsByTypeModel;
