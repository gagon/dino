import * as React from 'react';
import { AbstractReactFactory } from '@projectstorm/react-canvas-core';
import { DiagramEngine } from '@projectstorm/react-diagrams-core';
import ParamsByTypeWidget from './Widget';
import ParamsByTypeModel from './Model';

class ParamsByTypeFactory extends AbstractReactFactory<ParamsByTypeModel, DiagramEngine> {
  constructor() {
    super('params-by-type-node');
  }

  generateReactWidget(event: any) {
    return <ParamsByTypeWidget engine={this.engine} node={event.model} />;
  }

  generateModel() {
    return new ParamsByTypeModel(this.engine, {
      title: '',
      children: <></>,
      bgColor: '#5051F9',
      type: '',
    });
  }
}

export default ParamsByTypeFactory;
