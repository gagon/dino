import React from 'react';
import ArrowIcon from '@mui/icons-material/PlayArrow';

const green = 'rgb(10, 207, 131)';
const blue = '#5051F9';

const ArrowRight = ({ color, width, top, left }) => (
  <div className="flex items-center absolute" style={{ top, left }}>
    <div style={{ backgroundColor: color, width: width, height: 2 }}></div>
    <div style={{ transform: 'rotate(0deg) translate(-9px, 2px) scale(0.7)' }}>
      <ArrowIcon style={{ color }} />
    </div>
  </div>
);

const ArrowLeft = ({ color, width, top, left }) => (
  <div className="flex items-center absolute" style={{ top, left }}>
    <div style={{ transform: 'rotate(180deg) translate(-9px, 2px) scale(0.7)' }}>
      <ArrowIcon style={{ color }} />
    </div>
    <div style={{ backgroundColor: color, width, height: 2 }}></div>
  </div>
);

const ArrowTop = ({ color, height, top, left }) => (
  <div className="absolute" style={{ top, left }}>
    <div style={{ transform: 'rotate(270deg) translate(-11px, -10px) scale(0.7)' }}>
      <ArrowIcon style={{ color }} />
    </div>
    <div style={{ backgroundColor: color, width: 2, height }}></div>
  </div>
);

const ArrowBottom = ({ color, height, top, left }) => (
  <div className="absolute" style={{ top, left }}>
    <div style={{ backgroundColor: color, width: 2, height }}></div>
    <div style={{ transform: 'rotate(90deg) translate(-11px, 12px) scale(0.7)' }}>
      <ArrowIcon style={{ color }} />
    </div>
  </div>
);

export default function Lines() {
  return (
    <div className="relative">
      <ArrowLeft color={blue} width={560} top={570} left={616} />
      <ArrowRight color={green} width={560} top={540} left={630} />
      <ArrowRight color={green} width={124} top={510} left={1066} />
      <ArrowTop color={green} height={214} top={312} left={916} />
      <ArrowTop color={blue} height={243} top={312} left={770} />
      <ArrowBottom color={green} height={50} top={591} left={1417} />
      <ArrowBottom color={blue} height={50} top={591} left={1287} />
      <ArrowBottom color={blue} height={50} top={591} left={300} />
      <ArrowTop color={green} height={50} top={54} left={770} />
      <ArrowTop color={blue} height={50} top={54} left={1063} />
      <ArrowRight color={green} width={50} top={120} left={1092} />
      <ArrowLeft color={blue} width={50} top={146} left={1116} />
      <div className="absolute" style={{ top: 325, left: 1066 }}>
        <div style={{ backgroundColor: green, width: 2, height: 198 }}></div>
      </div>
    </div>
  );
}
