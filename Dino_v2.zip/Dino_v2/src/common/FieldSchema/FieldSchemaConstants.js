export const GAS = 'gas';
export const CALCULATED = 'Calculated';
