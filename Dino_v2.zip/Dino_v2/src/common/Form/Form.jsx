import { useForm, FormProvider } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useEffect } from 'react';

//https://react-hook-form.com/api

/***
 * {[nameField]: yup.string().required()} пример параметра валидаций
 * render передаются все методы формы
 * ***/

/*
 * methods
 * watch - возвращает все поля с изменениями в режиме реального временя
 * register - для регистраций элемента к форме (<input register={name}/>)
 * formState: { errors } - ошибки валидаций и тд
 * setValue('name', 'value') -  ввод значений в поле в форме
 * getValue('name') -  ввод значений в поле в форме
 * useFormContext() - все методы можем получить в дочерних компонентах через контекст
 * */
let timeOut;
export default function Form({
  children,
  validationSchema = {},
  onSubmit,
  initialValues,
  render,
  className,
  style = {},
}) {
  const methods = useForm({
    resolver: yupResolver(yup.object().shape(validationSchema)),
    defaultValues: initialValues,
  });

  useEffect(() => {
    initialValues && methods.reset(initialValues);
  }, [initialValues]);

  const {
    formState: { errors },
  } = methods;
  const fieldsValue = methods.watch();

  return (
    <FormProvider {...methods}>
      <form
        className={className}
        style={{ width: '100%', ...style }}
        onSubmit={methods.handleSubmit((values, event) => {
          clearTimeout(timeOut);
          timeOut = setTimeout(() => {
            onSubmit(values, event);
          }, 10);
        })}
      >
        {render
          ? render({
              fieldsValue,
              errors,
              register: methods.register,
              ...methods,
            })
          : children}
      </form>
    </FormProvider>
  );
}
