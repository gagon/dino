import lodash from 'lodash';

export default function(defaultFormData, data = {}) {
  const defaultData = { ...defaultFormData };
  !lodash.isEmpty(data) &&
    Object.entries(data).forEach(([key, value]) => {
      if (value) {
        defaultData[key] = value;
      }
    });
  return defaultData;
}
