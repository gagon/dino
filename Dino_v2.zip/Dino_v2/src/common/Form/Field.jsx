import React from 'react';
import { Controller } from 'react-hook-form';

export default function Field({ name, control, children }) {
  return (
    <>
      <Controller
        control={control}
        name={name}
        render={({ field: { onChange, value, ref }, fieldState: { error } }) => {
          return (
            <>
              {children({
                ref,
                onChange,
                helperText: error?.message || '',
                error: error,
                value: value,
              })}
            </>
          );
        }}
      />
    </>
  );
}
