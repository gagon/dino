import React, { useCallback, useEffect } from 'react';

import DinoSocket from '../../_helpers/socket';

const useSocketMessage = (event, callback, deps = []) => {
  const socket = DinoSocket.socket;

  const handleSocketMessage = useCallback(
    (response) => {
      let parsedResponse = response;
      try {
        parsedResponse = JSON.parse(response);
      } catch {}
      callback(parsedResponse);
    },
    [event, callback]
  );

  useEffect(() => {
    if (socket) {
      socket.on(event, handleSocketMessage);
      return () => socket.off(event);
    }
  }, [event, handleSocketMessage, socket, ...deps]);
};

export default useSocketMessage;
