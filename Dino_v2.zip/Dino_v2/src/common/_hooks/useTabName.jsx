import { useEffect, useState } from 'react';
import {useLocation, useNavigate, useSearchParams} from 'react-router-dom';

export const DEFAULT_FILTER = { tabName: "" };

export default function useTabName(
  loadData,
  defaultFilter = DEFAULT_FILTER,
  name = ''
) {
  const tabName = `tab${name}`;
  const [tabFilter, setTabFilter] = useState(DEFAULT_FILTER);
  const { pathname, search } = useLocation();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const filterTab = JSON.parse(params.get(tabName))
  const changeTabName = (tab) => {
    const newFilter = { ...filterTab, tabName: tab };
    if (filterTab){
      params.set(tabName, JSON.stringify(newFilter));
    }else {
      params.append(tabName, JSON.stringify(newFilter));
    }
    navigate(`${pathname}?${params.toString()}`);
  };

  useEffect(() => {
    let requestFilter = { ...defaultFilter, ...filterTab };
    if (JSON.stringify(requestFilter) !== tabFilter) {
      if (tabFilter === null) {
        params.set(tabName, JSON.stringify(requestFilter));
        navigate(`${pathname}?${params.toString()}`, { replace: true });
      }
      if (loadData !== null){
        loadData(requestFilter);
      }
      setTabFilter(JSON.stringify(requestFilter));
    }
    // eslint-disable-next-line
  }, [search]);

  useEffect(
    () => () => {
      if (window.location.search) {
        if (pathname === window.location.pathname) {
          const params = new URLSearchParams(search);
          params.delete(tabName);
          navigate(`${pathname}?${params.toString()}`, { replace: true });
        }
      }
    },
    // eslint-disable-next-line
    []
  );

  return { filterTab,changeTabName,name };
}
