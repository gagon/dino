import { useForm as useHookForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useTranslation } from 'react-i18next';

export default function useForm(validationSchema, defaultValues) {
  const { t } = useTranslation();
  const form = useHookForm({
    resolver: yupResolver(validationSchema),
    defaultValues: defaultValues,
  });
  const regMui = (name) => {
    const register = form.register(name);
    const error = form.formState.errors[name] ?? {};
    return {
      ...register,
      error: !!error.message,
      helperText: error.message ? t(error.message) : undefined,
    };
  };
  return { regMui, ...form };
}
