import { useLocation, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';

export default function usePushNewPageWithFilter(index = '') {
  const filterName = `filter${index}`;
  const { pathname, search } = useLocation();
  const navigate = useNavigate();

  const params = new URLSearchParams(search);
  const [queryFilter, setQueryFilter] = useState({});
  const filter = params.get(filterName) ? JSON.parse(params.get(filterName)) : {};

  const push = (param = {}) => {
    let requestFilter = checkFilter(filter, param);
    params.set(filterName, JSON.stringify(requestFilter));
    navigate(`${pathname}?${params.toString()}`);
  };

  const pushWithPageReplace = (path, filterName = '', param = {}) => {
    const newFilterName = `filter${filterName}`;
    let requestFilter = checkFilter(filter, param);
    params.set(newFilterName, JSON.stringify(requestFilter));
    navigate(`${path}?${params.toString()}`);
  };

  useEffect(() => {
    if (JSON.stringify(filter) !== JSON.stringify(queryFilter)) {
      setQueryFilter(filter);
    }
  }, [search]);

  return { push, pushWithPageReplace, queryFilter };
}

const checkFilter = function (filter, newFilter) {
  let result = { ...filter, ...newFilter };
  for (let item of Object.entries(result)) {
    if (item[1] === null) {
      delete result[item[0]];
    }
  }
  return result;
};
