import { useLocation, useNavigate } from 'react-router-dom';

export default function useModal(name = 'modal') {
  const { pathname, search } = useLocation();
  const navigate = useNavigate();
  const sp = new URLSearchParams(search);
  let data = sp.get(name);
  try {
    if (data.indexOf('{') === 0 || data.indexOf('[') === 0) {
      data = JSON.parse(sp.get(name));
    }
  } catch (ignore) {}

  return {
    isOpen: !!sp.get(name),
    data: data,
    open: (data) => {
      typeof data === 'object' ? sp.set(name, JSON.stringify(data)) : sp.set(name, data);
      navigate(`${pathname}?${sp.toString()}`, { replace: true });
    },
    close: () => {
      sp.delete(name);
      navigate(`${pathname}?${sp.toString()}`, { replace: true });
    },
  };
}
