import React, { useEffect, useState } from 'react';

export default function TabPanel(props) {
  const { children, value, index, controlByStyle } = props;
  const [opened, setOpened] = useState(false);

  useEffect(() => {
    if (value === index && !opened) {
      setOpened(true);
    }
  }, [value, index]);

  return (
    <div hidden={value !== index} id={`simple-tabpanel-${index}`}>
      {!controlByStyle && value === index && <div>{children}</div>}
      {controlByStyle && opened && (
        <div style={{ display: value === index ? 'inherit' : 'none' }}>{children}</div>
      )}
    </div>
  );
}
