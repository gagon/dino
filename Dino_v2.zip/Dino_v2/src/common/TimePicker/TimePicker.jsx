import React, { useEffect, useState } from 'react';
import { range } from 'lodash';

import TimeUnitWheel from './TimeUnitWheel';

const hourRange = [...Array(24).keys()];
const minuteSecondRange = range(0, 60, 5);

const TimePicker = ({
  onChange,
  initialTime,
  disableSeconds,
  width = '320px',
  height = '358px',
}) => {
  const [selectedTime, setSelectedTime] = useState(null);

  const valueHandler = (unit, value) => {
    setSelectedTime((prev) => ({ ...prev, [unit]: value }));
  };

  useEffect(() => {
    if (selectedTime === null) setSelectedTime(initialTime);
  }, [initialTime, selectedTime]);

  useEffect(() => {
    onChange(selectedTime);
  }, [selectedTime]);

  return (
    <div
      style={{
        display: 'flex',
        width: width,
        height: height,
        gap: 16,
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <TimeUnitWheel
        minValue={0}
        maxValue={23}
        selectedValue={selectedTime?.hour || 0}
        valueHandler={(value) => valueHandler('hour', value)}
        horizontalOffset={103}
        valueRange={hourRange}
        type="hour"
      />
      <span>:</span>
      <TimeUnitWheel
        minValue={0}
        maxValue={59}
        selectedValue={selectedTime?.minute || 0}
        valueHandler={(value) => valueHandler('minute', value)}
        horizontalOffset={22}
        valueRange={minuteSecondRange}
      />
      {!disableSeconds && (
        <>
          <span>:</span>
          <TimeUnitWheel
            minValue={0}
            maxValue={59}
            selectedValue={selectedTime?.second || 0}
            valueHandler={(value) => valueHandler('second', value)}
            horizontalOffset={-58}
            valueRange={minuteSecondRange}
          />
        </>
      )}
    </div>
  );
};

export default TimePicker;
