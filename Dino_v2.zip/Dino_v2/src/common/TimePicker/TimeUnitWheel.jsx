import React, { useEffect, useState } from 'react';
import { IconButton, Typography, Box, Popover, Grid } from '@mui/material';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

const TimeUnitWheel = ({
  minValue,
  maxValue,
  valueHandler,
  selectedValue,
  horizontalOffset,
  valueRange,
  type,
}) => {
  const [value, setValue] = useState(0);
  const [anchorEl, setAnchorEl] = useState(null);

  const handleOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const isHour = type === 'hour';

  const onIncrementHandler = () => {
    setValue((prev) => (value >= maxValue ? minValue : prev + 1));
  };

  const onDecrementHandler = () => {
    setValue((prev) => (value <= minValue ? maxValue : prev - 1));
  };

  const onValueHandler = (value) => {
    setValue(value);
    setAnchorEl(null);
  };

  useEffect(() => {
    setValue(selectedValue);
  }, [selectedValue]);

  useEffect(() => {
    valueHandler(value);
  }, [value]);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <IconButton onClick={onIncrementHandler}>
        <KeyboardArrowUpIcon color="primary" fontSize="large" />
      </IconButton>
      <Typography
        sx={{ textAlign: 'center', fontSize: '24px', cursor: 'pointer' }}
        onClick={handleOpen}
      >
        {value < 10 ? `0${value}` : value}
      </Typography>
      <IconButton onClick={onDecrementHandler}>
        <KeyboardArrowDownIcon color="primary" fontSize="large" />
      </IconButton>

      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 20,
          horizontal: horizontalOffset,
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
      >
        <Box
          sx={{
            width: '320px',
            height: '364px',
            flexGrow: 1,
          }}
        >
          <Grid container sx={{ padding: '25px', height: '364px' }}>
            {valueRange.map((value) => (
              <Grid
                item
                key={value}
                xs={3}
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  fontWeight: 'bold',
                  fontSize: '16px',
                  height: isHour ? '40px' : '100px',
                }}
              >
                <Box
                  sx={{
                    padding: '8px',
                    cursor: 'pointer',
                    width: '37px',
                    textAlign: 'center',
                  }}
                  onClick={() => onValueHandler(value)}
                >
                  {value}
                </Box>
              </Grid>
            ))}
          </Grid>
        </Box>
      </Popover>
    </Box>
  );
};

export default TimeUnitWheel;
