import { addTranslation } from '../../../_helpers/translate';

addTranslation({
  ru: {
    columnsFilters_tableFilter_minSymbol: 'минимум 3 символа'
  },
  kk: {
    columnsFilters_tableFilter_minSymbol: 'кемінде 3 таңба'
  }
});
