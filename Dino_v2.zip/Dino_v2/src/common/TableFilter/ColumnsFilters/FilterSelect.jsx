import React from 'react';
import { Select, FormControl, IconButton, MenuItem } from '@mui/material';
import useDict from '../../_hooks/useDict';
import useColumnFilter from '../useColumnFilter';
import CloseIcon from '@mui/icons-material/Close';
import { useTranslation } from 'react-i18next';

export default function FilterSelect({
  name,
  dictCode,
  options,
  queryIndex = '',
  margin = 'none',
  style,
}) {
  const { i18n } = useTranslation();
  const { value, setFilter } = useColumnFilter(name, queryIndex);
  const dict = useDict(dictCode);

  const clearFiled = value && {
    IconComponent: () => (
      <IconButton
        onClick={() => setFilter(null)}
        size="small"
        style={{ marginRight: 5 }}
        children={<CloseIcon fontSize="small" />}
      />
    ),
  };

  return (
    <FormControl fullWidth margin={margin} className="left-align">
      <Select
        MenuProps={{ MenuListProps: { style: { maxWidth: 550, minWidth: 250 } } }}
        value={value || ''}
        onChange={(e) => setFilter(e.target.value)}
        {...clearFiled}
        style={style}
      >
        {(options || dict).map(
          (item) =>
            item && (
              <MenuItem key={item.code} value={item.code}>
                {item[`${i18n.language}_name`]}
              </MenuItem>
            )
        )}
      </Select>
    </FormControl>
  );
}
