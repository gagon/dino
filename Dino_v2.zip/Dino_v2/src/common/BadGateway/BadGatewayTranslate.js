import {addTranslation} from '../../_helpers/translate';

addTranslation({
	ru: {
		errors_BAD_GATEWAY:
			'В данный момент ведутся технические работы. Попробуйте войти позже',
	},
	kk: {
		errors_BAD_GATEWAY:
			'Қазіргі уақытта техникалық жұмыстар жүргізілуде. Кейінірек кіріп көріңіз',
	},
});
