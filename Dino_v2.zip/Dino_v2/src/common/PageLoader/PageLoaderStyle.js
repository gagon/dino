import styled from 'styled-components';

export const Div = styled.div`
  z-index: 1000;
  background-color: ${(props) =>
    props.opacity
      ? props.palette.background.default + props.opacity
      : props.palette.background.default};
  align-items: center;
  display: flex;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  position: ${(props) => props.position || 'fixed'};
  height: ${(props) => props.height || '100vh'};
`;

export const Loader = styled.div`
  height: 200px;
  margin: auto;

  .circle-bg {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    left: 0;
    margin: auto;
    width: 120px;
    height: 120px;
    background-color: ${(props) => props.theme.palette.background.paper};
    border-radius: 50%;
    box-shadow: 0 6px 10px 0 rgba(0, 0, 0, 0.14), 0 1px 18px 0 rgba(0, 0, 0, 0.12),
      0 3px 5px -1px rgba(0, 0, 0, 0.3);
  }

  .circular {
    animation: rotate 2s linear infinite;
    height: 90%;
    transform-origin: center center;
    width: 90%;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
  }

  .path {
    stroke-dasharray: 1, 200;
    stroke-dashoffset: 0;
    animation: dash 1.5s ease-in-out infinite;
    stroke-linecap: round;
    stroke: ${(props) => props.theme.palette.primary.main};
  }

  @keyframes rotate {
    100% {
      transform: rotate(360deg);
    }
  }

  @keyframes dash {
    0% {
      stroke-dasharray: 1, 200;
      stroke-dashoffset: 0;
    }
    50% {
      stroke-dasharray: 89, 200;
      stroke-dashoffset: -35px;
    }
    100% {
      stroke-dasharray: 89, 200;
      stroke-dashoffset: -124px;
    }
  }
`;
