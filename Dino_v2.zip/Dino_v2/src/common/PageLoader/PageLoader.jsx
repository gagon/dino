import React from 'react';
import { Div, Loader } from './PageLoaderStyle';
import { useTheme } from '@mui/material';

export default function PageLoader({ opacity, position, height }) {
  const { palette } = useTheme();
  return (
    <Div palette={palette} opacity={opacity} position={position} height={height}>
      <Loader>
        <div className="circle-bg">
          <svg className="circular" viewBox="25 25 50 50">
            <circle
              className="path"
              cx="50"
              cy="50"
              r="20"
              fill="none"
              strokeWidth="1.3"
              strokeMiterlimit="5"
            />
          </svg>
        </div>
      </Loader>
    </Div>
  );
}
