import React from 'react';
import { Loader } from './PageLoader/PageLoaderStyle';

export default function DataLoader() {
  return (
    <Loader>
      <div className="circle-bg">
        <svg className="circular" viewBox="25 25 50 50">
          <circle
            className="path"
            cx="50"
            cy="50"
            r="20"
            fill="none"
            strokeWidth="1.3"
            strokeMiterlimit="5"
          />
        </svg>
      </div>
    </Loader>
  );
}
