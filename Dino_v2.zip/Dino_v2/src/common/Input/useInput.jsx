import React, { useState } from 'react';
import EndAdornment from './EndAdornment';

export default function useInput({
  type,
  InputProps,
  withoutForm,
  onChange,
  height,
  multiline,
  ...props
}) {
  const [showPass, setShowPass] = useState(type !== 'password');

  const getInputProps = (value, onChange, error) => {
    const clearField = () => onChange({ target: { value: '' } });
    return {
      ...InputProps,
      style: { height: multiline ? 'auto' : height },
      endAdornment: (
        <EndAdornment
          value={value}
          error={error}
          onClear={clearField}
          type={type}
          showPass={showPass}
          setShowPass={setShowPass}
          {...props}
        />
      ),
    };
  };

  return { showPass, getInputProps };
}
