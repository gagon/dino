import styled from 'styled-components';

export const Wrapper = styled.div`
  width: ${({ fullWidth }) => (fullWidth ? '100%' : '')};

  .MuiFormControl-root {
    margin: 0;
  }

  .MuiOutlinedInput-root {
    background: ${({ inputStyle, isChanged }) =>
      inputStyle?.background
        ? `${inputStyle.background};`
        : isChanged
        ? 'rgb(248,161,105)'
        : 'transparent'};
    padding: ${({ inputStyle }) => (inputStyle?.padding ? `${inputStyle.padding}px;` : '15px')};
    border-radius: ${({ inputStyle }) =>
      inputStyle?.borderRadius ? ` ${inputStyle.borderRadius}px;` : '6px'};
    // height: ${({ inputStyle }) => (inputStyle?.height ? ` ${inputStyle.height}px;` : '34px')};
  }
`;
