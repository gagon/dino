import React, { useState } from 'react';
import Field from '../Form/Field';
import { Wrapper } from './InputStyle';
import { TextField, Typography } from '@mui/material';
import useInput from './useInput';

export default function Input({
  withoutForm,
  name,
  onChange,
  helperText,
  size,
  wrapperClassName,
  wrapperFullWidth = true,
  inputEndIcon,
  style,
  height = 34,
  label,
  inputStyle,
  value,
  control,
  savedValue,
  editedBg,
  ...restProps
}) {
  const { showPass, getInputProps } = useInput({
    ...restProps,
    height,
    inputEndIcon,
    withoutForm,
  });
  const type = restProps.type === 'password' && showPass ? 'text' : restProps.type;

  if (withoutForm) {
    return (
      <Wrapper inputStyle={inputStyle} className={wrapperClassName} fullWidth={wrapperFullWidth}>
        {label && (
          <Typography color={'textSecondary'} children={label} style={{ marginBottom: 5 }} />
        )}
        <TextField
          name={name}
          onChange={({ target }) => onChange(target.value)}
          InputProps={getInputProps(restProps.value, onChange)}
          helperText={helperText}
          {...restProps}
          value={value || ''}
          type={type}
        />
      </Wrapper>
    );
  } else {
    return (
      <Field name={name} control={control}>
        {({ ref, onClear, value, onChange, error, ...props }) => {
          const isChanged = savedValue !== value && editedBg;
          return (
            <Wrapper
              isChanged={isChanged}
              inputStyle={inputStyle}
              className={wrapperClassName}
              fullWidth={wrapperFullWidth}
            >
              {label && (
                <Typography color={'textSecondary'} children={label} style={{ marginBottom: 5 }} />
              )}
              <TextField
                onChange={onChange}
                InputProps={getInputProps(value, onChange, error)}
                error={error}
                helperText={props.helperText ? props.helperText : helperText}
                {...restProps}
                value={value || ''}
                type={type}
              />
            </Wrapper>
          );
        }}
      </Field>
    );
  }
}
