import React from 'react';
import IconButton from '@mui/material/IconButton';
import { Visibility, VisibilityOff } from '@mui/icons-material';

export default function EndAdornment({
  showPassViewButton,
  inputEndIcon,
  endAdornment,
  value,
  showPass,
  setShowPass,
}) {
  return (
    <>
      <div className="flex items-center  justify-end">
        {showPassViewButton && (
          <IconButton
            tooltip={showPass ? 'Скрыть' : 'Показать'}
            onClick={() => setShowPass(!showPass)}
            icon={showPass ? <VisibilityOff /> : <Visibility />}
            onMouseDown={(e) => e.preventDefault()}
            style={{ padding: 2 }}
          />
        )}
        {!value && inputEndIcon ? inputEndIcon : null}
        {endAdornment ? endAdornment : null}
      </div>
    </>
  );
}

function checkHideClearButton(isHideClearIcon, value, type) {
  if (isHideClearIcon) {
    return false;
  }
  // Кейс при 0, так как это falsy значение
  const ifValueZeroAndTypeNumber = value === 0 && type === 'number';
  if (value || ifValueZeroAndTypeNumber) {
    return true;
  }
}
