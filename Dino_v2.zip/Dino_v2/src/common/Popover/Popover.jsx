import React from 'react';
import { Popover } from '@mui/material';

const PopoverWindow = ({ open, anchorEl, onClose, children }) => {
  return (
    <Popover
      open={Boolean(anchorEl)}
      anchorEl={anchorEl}
      onClose={onClose}
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      transformOrigin={{
        vertical: 'bottom',
        horizontal: 'center',
      }}
    >
      {children}
    </Popover>
  );
};

export default PopoverWindow;
