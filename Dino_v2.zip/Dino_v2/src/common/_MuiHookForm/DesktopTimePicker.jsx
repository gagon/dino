import React, { useState } from 'react';
import { Box, TextField, Popover } from '@mui/material';
import CalendarIcon from '../../_media/CalendarIcon';
import TimePicker from '../TimePicker/TimePicker';

export default function DesktopTimePicker({
  value,
  background,
  onChange,
  sx,
  fontSize,
  fontWeight,
  disabled,
}) {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleOpen = (event) => {
    if (!disabled) {
      setAnchorEl(event.currentTarget);
    }
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <TextField
        value={value ?? ''}
        onClick={handleOpen}
        disabled={disabled}
        sx={sx}
        InputProps={{
          style: {
            padding: '6px 8px 6px 16px',
            fontSize: fontSize || '12px',
            fontWeight: fontWeight || 500,
            backgroundColor: background || 'transparent',
          },
          readOnly: true,
          endAdornment: <CalendarIcon style={{ cursor: 'pointer' }} />,
        }}
      />

      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
      >
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
          }}
          children={
            <TimePicker
              initialTime={{
                hour: value ? parseInt(value.substring(0, 2)) : 0,
                minute: value ? parseInt(value.substring(3, 5)) : 0,
              }}
              width="220px"
              height="220px"
              disableSeconds
              onChange={(value) =>
                onChange(
                  value
                    ? `${value.hour < 10 ? '0' + value.hour : value.hour}:${
                        value.minute < 10 ? '0' + value.minute : value.minute
                      }`
                    : ''
                )
              }
            />
          }
        />
      </Popover>
    </>
  );
}
