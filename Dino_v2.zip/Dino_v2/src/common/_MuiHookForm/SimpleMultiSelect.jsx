import * as React from 'react';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Controller } from 'react-hook-form';
import FormHelperText from '@mui/material/FormHelperText';
import { useTranslation } from 'react-i18next';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

export default function SimpleMultiSelect({
  label,
  name,
  control,
  defaultValue = [],
  children,
  size,
}) {
  const { t } = useTranslation();
  return (
    <Controller
      name={name}
      control={control}
      defaultValue={defaultValue}
      render={(params) => {
        const error = !!params.fieldState.error;
        const message = params.fieldState.error?.message;
        return (
          <FormControl fullWidth size={size}>
            <InputLabel error={error}>{label}</InputLabel>
            <Select
              multiple
              {...params.field}
              input={<OutlinedInput error={error} label="Name" />}
              MenuProps={MenuProps}
              children={children}
            />
            {error && <FormHelperText error>{t(message)}</FormHelperText>}
          </FormControl>
        );
      }}
    />
  );
}
