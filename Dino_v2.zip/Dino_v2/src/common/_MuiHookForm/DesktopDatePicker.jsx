import React, { useEffect, useState } from 'react';
import { Box, TextField, Popover, IconButton } from '@mui/material';
import { CalendarPicker } from '@mui/x-date-pickers/CalendarPicker';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import moment from 'moment';

import CalendarIcon from '../../_media/CalendarIcon';
import TimePicker from '../TimePicker/TimePicker';

export const DATE_FORMAT = 'DD-MM-YYYY HH:mm:ss';
const TABS = {
  DATE: 'DATE',
  TIME: 'TIME',
};
const initialPickedTime = { hour: 0, minute: 0, second: 0 };

export default function DateTimePicker({ value, background, onChange, sx, fontSize, fontWeight }) {
  const [currentTab, setCurrentTab] = useState(TABS.DATE);
  const [anchorEl, setAnchorEl] = useState(null);
  const [pickedDate, setPickedDate] = useState(null);
  const [pickedTime, setPickedTime] = useState(initialPickedTime);
  const open = Boolean(anchorEl);

  const handleOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  useEffect(() => {
    if (pickedDate === null && value !== null) {
      if (value === 'Invalid date') {
        const date = moment();
        const time = { hour: date.hour(), minute: date.minute(), second: date.second() };
        setPickedTime(time);
        setPickedDate(date);
      } else {
        const date = moment(value, DATE_FORMAT);
        const time = { hour: date.hour(), minute: date.minute(), second: date.second() };
        setPickedTime(time);
        setPickedDate(date);
      }
    }
  }, [value]);

  useEffect(() => {
    if (pickedDate !== null) {
      pickedDate.set(pickedTime);
      onChange(pickedDate.format(DATE_FORMAT));
    }
  }, [pickedDate, pickedTime]);

  return (
    <>
      <TextField
        id="date"
        value={value === 'Invalid date' ? '' : value ?? ''}
        onClick={handleOpen}
        sx={sx}
        InputProps={{
          style: {
            padding: '2px 4px 2px 16px',
            fontSize: fontSize || '12px',
            fontWeight: fontWeight || 500,
            backgroundColor: background || 'transparent',
          },
          readOnly: true,
          endAdornment: <CalendarIcon style={{ cursor: 'pointer' }} />,
        }}
      />

      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
      >
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          {currentTab === TABS.DATE && (
            <CalendarPicker date={pickedDate} onChange={(value) => setPickedDate(moment(value))} />
          )}
          {currentTab === TABS.TIME && (
            <TimePicker initialTime={pickedTime} onChange={(value) => setPickedTime(value)} />
          )}

          <Box sx={{ display: 'flex', gap: 11, marginTop: -4, marginBottom: 0.5 }}>
            <IconButton onClick={() => setCurrentTab(TABS.DATE)}>
              <CalendarMonthIcon color="primary" />
            </IconButton>
            <IconButton onClick={() => setCurrentTab(TABS.TIME)}>
              <AccessTimeIcon color="primary" />
            </IconButton>
          </Box>
        </Box>
      </Popover>
    </>
  );
}
