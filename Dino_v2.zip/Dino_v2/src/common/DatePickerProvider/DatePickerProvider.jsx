import React from 'react';
import { LocalizationProvider } from '@mui/x-date-pickers';
import MomentUtils from '@date-io/moment';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import { useTranslation } from 'react-i18next';

export default function DatePickerProvider({ children }) {
  const { i18n } = useTranslation();
  return (
    <LocalizationProvider
      dateAdapter={AdapterMoment}
      utils={MomentUtils}
      adapterLocale={i18n.language}
      children={children}
    />
  );
}
