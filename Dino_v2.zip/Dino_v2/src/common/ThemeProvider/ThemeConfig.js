export default function (isDark) {
  const primary = { main: isDark ? '#5051F9' : '#5051F9' };
  const secondary = { main: isDark ? '#6aa997' : '#6aa997' };

  return {
    isDark: isDark,
    palette: {
      mode: isDark ? 'dark' : 'light',
      primary: primary,
      secondary: secondary,
      success: { main: '#0ACF83', dark: '#029741' },
      background: {
        default: isDark ? '#191919' : '#E8E8F0',
        paper: isDark ? '#333333' : '#FFFFFF',
      },
      text: {
        secondary: '#79879C',
      },
      action: { disabled: '#9BA5B3', selected: '#F1F1F1', focus: '#E6E6E6', active: '#5F6388' },
    },
    typography: {
      fontFamily: 'Noto Sans, sans-serif',
    },
    shape: {
      borderRadius: 8,
    },
    components: {
      MuiButton: {
        styleOverrides: {
          root: {
            // height: 34,
            fontSize: 12,
          },
        },
      },
      MuiTypography: {
        defaultProps: {
          variant: 'body2',
        },
      },
      MuiDesktopDatePicker: {
        defaultProps: {
          inputFormat: 'DD.MM.yyyy',
          mask: '__.__.____',
        },
      },
      MuiFilledInput: {
        defaultProps: {
          margin: 'dense',
        },
      },
      MuiFormControl: {
        defaultProps: {
          margin: 'dense',
        },
      },
      MuiFormHelperText: {
        defaultProps: {
          margin: 'dense',
        },
      },
      MuiIconButton: {
        defaultProps: {
          size: 'small',
        },
      },
      MuiInputBase: {
        styleOverrides: {
          root: {
            padding: 2,
            border: '1px solid #F3F5F9',
          },
        },
        defaultProps: {
          margin: 'dense',
        },
      },
      MuiInputLabel: {
        defaultProps: {
          margin: 'dense',
        },
      },
      MuiOutlinedInput: {
        styleOverrides: {
          root: {
            // height: 34,
            padding: '15px 11px',
            fontSize: 12,
            border: '1px solid #F3F5F9',
          },
          input: {
            padding: 0,
          },
        },
        defaultProps: {
          margin: 'dense',
        },
      },
      MuiFab: {
        defaultProps: {
          size: 'small',
        },
      },
      MuiTable: {
        defaultProps: {
          size: 'small',
        },
      },
      MuiTextField: {
        defaultProps: {
          margin: 'dense',
          fullWidth: true,
        },
      },
      MuiToolbar: {
        defaultProps: {
          variant: 'dense',
        },
      },
      MuiDialog: {
        styleOverrides: {
          paper: {
            borderRadius: '20px',
          },
        },
      },
    },

    overrides: {
      MuiPaper: {
        root: {
          borderRadius: 20,
        },
      },
      MuiMenuItem: {
        root: {
          '&$selected': {
            backgroundColor: '#FF0000',
          },
        },
        selected: {
          backgroundColor: '#FF0000',
        },
      },
      MuiTextField: {
        outlined: {
          padding: 0,
        },
      },
      MuiTypography: {
        overline: {
          fontSize: '10px',
        },
        body1: { fontSize: '16px', lineHeight: 1.5, letterSpacing: '0.44px' },
        body2: { fontSize: '14px', lineHeight: '20px' },
        caption: { fontSize: '12px', lineHeight: '16px', letterSpacing: '0.4px' },
        subtitle2: { fontSize: '14px', LineHeight: '24px' },
        h1: { fontSize: '96px' },
        h2: { fontSize: '60px', LineHeight: '28px' },
        h3: { fontSize: '48px', LineHeight: '28px' },
        h6: { fontSize: '20px', LineHeight: '28px' },
        h5: { fontSize: '24px', LineHeight: '30,47px' },
        h4: { fontSize: '36px', LineHeight: '42,19px' },
      },
    },
  };
}
