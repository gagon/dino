import React, {useEffect, useMemo} from 'react';
import ThemeConfig from './ThemeConfig';
import {ThemeWrapper} from './ThemeStyle';
import {themeModule} from './ThemeDucks';
import {createTheme, ThemeProvider as MuiThemeProvider} from '@mui/material/styles';
import {ThemeProvider as StyledProvider} from 'styled-components';
import {useSelector} from 'react-redux';
import {useTranslation} from 'react-i18next';
import MuiLocalization from './MuiLocalization';

export default function ThemeProvider({children}) {
	const {i18n} = useTranslation();
	const {lang, locale} = MuiLocalization(i18n);
	const themeType = useSelector((state) => state[themeModule].themeType);

	const theme = useMemo(
		() => createTheme(ThemeConfig(themeType === 'dark'), locale),
		[themeType, lang]
	);

	useEffect(() => {
		try {
			document.getElementById('app').style.backgroundColor = theme.palette.background.default;
		} catch (e) {}
	}, [themeType]);

	return (
		<MuiThemeProvider theme={theme}>
			<ThemeWrapper theme={theme}>
				<StyledProvider theme={theme}>{children}</StyledProvider>
			</ThemeWrapper>
		</MuiThemeProvider>
	);
}
