import {createReducer} from '@reduxjs/toolkit';

/**
 * Constants
 */

export const themeModule = 'theme';
const CHANGE_THEME_TYPE = `${themeModule}/CHANGE_THEME_TYPE`;

/**
 * Reducer
 */

const themeType = window.localStorage.getItem('themeType');
const initialState = {
	themeType: ['light', 'dark'].includes(themeType) ? themeType : 'light',
};

export default createReducer(initialState, {
	[CHANGE_THEME_TYPE]: (state, action) => {
		window.localStorage.setItem('themeType', action.themeType);
		state.themeType = action.themeType;
	},
});

export const changeThemeType = (isDark) => ({
	type: CHANGE_THEME_TYPE,
	themeType: isDark ? 'dark' : 'light',
});
