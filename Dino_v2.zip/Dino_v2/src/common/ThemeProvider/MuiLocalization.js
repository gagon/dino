import { ruRU } from '@mui/material/locale';

export default function(i18n) {
    let lang = i18n.language;
    let locale = ruRU;
    if (lang === 'kk') {
        locale = JSON.parse(JSON.stringify(ruRU));
        locale.components.MuiTablePagination.backIconButtonText = 'Алдыңғы бет';
        locale.components.MuiTablePagination.labelRowsPerPage = 'Бір парақта жазба саны:';
        locale.components.MuiTablePagination.nextIconButtonText = 'Келесі бет';
    }
    return { lang, locale }
}
