import React from 'react';
import Button from '@mui/material/Button';

import { removeSchedule } from './ScheduledCasesDucks';

export const scheduledColumns = (userId, onlyMySchedules, dispatch) => {
  return [
    {
      field: 'case_id',
      headerName: 'Case id',
      width: 100,
      renderCell: ({ row }) => <div style={{ paddingLeft: 4 }}>{row.case_id}</div>,
    },
    { field: 'status', headerName: 'Status', width: 100 },
    {
      field: 'case_date',
      headerName: 'Case date',
      minWidth: 180,
      valueGetter: ({ row }) => row.case_date_formatted,
    },
    { field: 'user_name', headerName: 'User', minWidth: 130 },
    { field: 'case_name', headerName: 'Name', flex: 1 },
    {
      field: 'start_time',
      headerName: 'Start on',
      minWidth: 180,
      valueGetter: ({ row }) => row.start_time_formatted,
    },
    {
      field: 'completed_on',
      headerName: 'Completed on',
      minWidth: 180,
      valueGetter: ({ row }) => row.completed_on_formatted,
    },
    {
      field: 'id',
      headerName: 'Action',
      minWidth: 130,
      renderCell: ({ row }) => {
        return (
          row.user_id === userId && (
            <Button
              variant="outlined"
              color="primary"
              size="small"
              children={row.status === 'running' ? 'Stop' : 'Remove'}
              onClick={() => dispatch(removeSchedule(row.case_id, userId, onlyMySchedules))}
              style={{
                color: 'black',
                textTransform: 'none',
                padding: '4px 18px ',
                width: 85,
              }}
            />
          )
        );
      },
    },
  ];
};
