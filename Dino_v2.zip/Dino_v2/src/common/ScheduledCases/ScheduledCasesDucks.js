import { createReducer } from '@reduxjs/toolkit';
import moment from 'moment';

import { ScheduledApi } from '../../_helpers/service';
import Notice from '../utils/Notice';
import { changeActiveMenu } from '../../pages/Case/SideBar/CaseMenuDucks';
import { VIEW_RESULTS } from '../../pages/Case/SideBar/MenuItems';
import { caseModule, loadCase } from '../../pages/Case/CaseDucks/CaseDucks';

/**
 * Constants
 */
export const scheduledModule = 'scheduledCases';
const LOADING = `${scheduledModule}/LOADING`;
const CLEAR_STATE = `${scheduledModule}/CLEAR_STATE`;
const SET_SCHEDULED_DATA = `${scheduledModule}/SET_SCHEDULED_DATA`;
const SET_SCHEDULED_ITEM = `${scheduledModule}/SET_SCHEDULED_ITEM`;
const SET_SCHEDULED_LOG_MESSAGE = `${scheduledModule}/SET_SCHEDULED_LOG_MESSAGE`;
const SET_SCHEDULED_LOG_MESSAGES = `${scheduledModule}/SET_SCHEDULED_LOG_MESSAGES`;
const SET_COUNT = `${scheduledModule}/SET_COUNT`;
const SET_OPEN_MODAL = `${scheduledModule}/SET_OPEN_MODAL`;
const SET_SELECTED_CASE = `${scheduledModule}/SET_SELECTED_CASE`;
const LOADING_REMOVE_ID = `${scheduledModule}/LOADING_REMOVE_ID`;
const CLEAR = `${scheduledModule}/CLEAR`;

/**
 * Reducer
 */
const initialState = {
  scheduledData: [],
  count: 0,
  logMessages: {},
  loading: false,
  openModal: false,
  removeId: null,
  selectedCase: null,
};

export default createReducer(initialState, {
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [SET_COUNT]: (state, { payload }) => {
    state.count = payload;
  },
  [SET_SCHEDULED_DATA]: (state, { payload }) => {
    state.scheduledData = payload;
  },
  [SET_SCHEDULED_ITEM]: (state, { payload }) => {
    state.scheduledData.forEach((item) => {
      if (item.case_id === payload.case_id) {
        item.status = payload.status;
        item.completed_on = payload.completed_on;
        item.completed_on_formatted = payload.completed_on_formatted;
      }
    });
  },
  [SET_SCHEDULED_LOG_MESSAGE]: (state, { payload }) => {
    state.logMessages[payload.case_id].push(payload);
  },
  [SET_SCHEDULED_LOG_MESSAGES]: (state, { payload }) => {
    state.logMessages[payload.caseId] = payload.logMessages.map((msg) => ({
      ...msg,
      timestamp: moment.utc(msg.timestamp).format('DD.MM.YYYY HH:mm:ss'),
    }));
  },
  [SET_OPEN_MODAL]: (state, { payload }) => {
    state.openModal = payload;
  },
  [SET_SELECTED_CASE]: (state, { payload }) => {
    state.selectedCase = payload;
  },
  [LOADING_REMOVE_ID]: (state, { payload }) => {
    state.removeId = payload;
  },
  [CLEAR_STATE]: () => initialState,
});

/**
 * Actions
 */
export const clear = () => ({ type: CLEAR });

export const setSelectedCase = (caseId) => ({ type: SET_SELECTED_CASE, payload: caseId });

export const openScheduledModal = (open) => ({ type: SET_OPEN_MODAL, payload: open });

export const loadScheduled = (filter) => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING, payload: true });
    const { data } = await ScheduledApi.loadList(filter);
    const count = data.count;
    const scheduledData = data.data.map((i, index) => {
      const item = { ...i };
      item.id = item.case_id;
      item.start_time_formatted = item.start_time
        ? moment.utc(item.start_time).format('DD/MM/YYYY HH:mm:ss')
        : '';
      item.case_date_formatted = item.case_date
        ? moment(item.case_date).format('DD/MM/YYYY HH:mm:ss')
        : '';
      item.completed_on_formatted = item.completed_on
        ? moment.utc(item.completed_on).format('DD/MM/YYYY HH:mm:ss')
        : '';
      return item;
    });
    dispatch({ type: SET_SCHEDULED_DATA, payload: scheduledData });
    dispatch({ type: SET_COUNT, payload: count });
  } catch (e) {
    console.error(e);
    Notice.error('Filed to load scheduled cases data');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const loadScheduleMessage = (caseId) => async (dispatch, getState) => {
  try {
    if (caseId) {
      dispatch({ type: LOADING, payload: true });
      const { data } = await ScheduledApi.loadMessages(caseId);
      const logMessages = JSON.parse(data.messages);
      dispatch({ type: SET_SCHEDULED_LOG_MESSAGES, payload: { caseId, logMessages } });
    }
  } catch (e) {
    console.error(e);
    Notice.error('Filed to load scheduled case messages');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const setScheduleItem = (scheduleItem) => (dispatch, getState) => {
  const caseId = getState()[caseModule].caseData?.id;
  dispatch({ type: SET_SCHEDULED_ITEM, payload: scheduleItem });
  if (caseId === scheduleItem.case_id && scheduleItem.status === 'completed') {
    dispatch(loadCase(caseId));
    dispatch(changeActiveMenu(VIEW_RESULTS));
    dispatch(openScheduledModal(false));
  }
};

export const setScheduleMessage = (messageData) => async (dispatch, getState) => {
  try {
    const logMessages = getState()[scheduledModule].logMessages || {};
    if (logMessages.hasOwnProperty(messageData.case_id)) {
      dispatch({
        type: SET_SCHEDULED_LOG_MESSAGE,
        payload: {
          ...messageData,
          timestamp: moment(messageData.timestamp).local().format('DD.MM.YYYY HH:mm:ss'),
        },
      });
    }
  } catch (e) {
    console.error(e);
  }
};

export const removeSchedule = (caseId, userId, onlyMySchedules) => async (dispatch, getState) => {
  try {
    if (caseId) {
      dispatch({ type: LOADING_REMOVE_ID, payload: caseId });
      await ScheduledApi.remove(caseId);

      const filterObj = {
        userId: 0,
        limit: 25,
        offset: 0,
        sort: { param: 'start_time', asc: false },
      };
      if (onlyMySchedules) {
        filterObj.userId = userId;
      }
      dispatch(loadScheduled(filterObj));
    }
  } catch (e) {
    console.error(e);
    Notice.error(`Failed to remove case "${caseId}" scheduled`);
  } finally {
    dispatch({ type: LOADING_REMOVE_ID, payload: null });
  }
};
