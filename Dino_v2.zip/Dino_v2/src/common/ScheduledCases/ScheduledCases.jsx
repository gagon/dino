import React, { useEffect, useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import {
  Button,
  Dialog,
  Paper,
  useTheme,
  Pagination,
  PaginationItem,
  Select,
  MenuItem,
} from '@mui/material';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

import CalendarIcon from '../../_media/CalendarIcon';
import Switch from '../Switch/Switch';
import Table from '../Table/Table';
import ScheduledLogs from './ScheduledLogs';
import useModal from '../_hooks/useModal';
import useSocketMessage from '../_hooks/useSocketMessage';
import { scheduledColumns } from './ScheduledColumns';
import { loginModule } from '../../pages/Login/LoginDucks';
import {
  loadScheduled,
  loadScheduleMessage,
  openScheduledModal,
  scheduledModule,
  setScheduleItem,
  setScheduleMessage,
  setSelectedCase,
} from './ScheduledCasesDucks';

const containerStyle = {
  height: '486px',
  overflowY: 'auto',
  overflowX: 'hidden',
};

const options = [10, 25, 50, 100];
const defaultSortRule = { param: 'start_time', asc: false };

export default function ScheduledCases() {
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const userId = useSelector((state) => state[loginModule].userConfig.user_id);
  const loading = useSelector((state) => state[scheduledModule].loading);
  const scheduledData = useSelector((state) => state[scheduledModule].scheduledData);
  const count = useSelector((state) => state[scheduledModule].count);
  const openModal = useSelector((state) => state[scheduledModule].openModal);
  const selectedCase = useSelector((state) => state[scheduledModule].selectedCase);
  const [onlyMySchedules, setOnlyMySchedules] = useState(true);
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [filter, setFilter] = useState({
    userId: userId,
    offset: 0,
    sort: defaultSortRule,
  });

  const onSortHandler = useCallback((params) => {
    if (params.length < 1) {
      setFilter((prev) => ({ ...prev, sort: defaultSortRule }));
      return;
    }
    const field = params[0]?.field;
    const sortRule = params[0]?.sort === 'asc';
    setFilter((prev) => ({ ...prev, sort: { param: field, asc: sortRule } }));
  }, []);

  const handleChangePage = useCallback(
    (event, value) => {
      setPage(value);
      setFilter((prev) => ({ ...prev, offset: (value - 1) * rowsPerPage }));
    },
    [rowsPerPage]
  );

  const handleRowsPerPage = (e) => {
    setRowsPerPage(e.target.value);
    setPage(1);
  };

  const handleSwitchSchedules = useCallback(
    (e, checked) => {
      setOnlyMySchedules(checked);
      handleChangePage(e, 1);
    },
    [handleChangePage]
  );

  const handleCaseScheduleMsg = useCallback(
    (res) => {
      dispatch(setScheduleMessage(res));
    },
    [dispatch, setScheduleMessage]
  );

  const handleUpdateCaseSchedule = useCallback(
    (scheduleList) => {
      const scheduleItem = scheduleList[0];
      scheduleItem.completed_on_formatted = scheduleItem.completed_on
        ? moment(scheduleItem.completed_on).format('DD/MM/YYYY HH:mm:ss')
        : '';
      dispatch(setScheduleItem(scheduleItem));
    },
    [dispatch, setScheduleItem]
  );

  useSocketMessage('case_schedule_msg', handleCaseScheduleMsg);
  useSocketMessage('update_case_schedule_reply', handleUpdateCaseSchedule);

  useEffect(() => {
    dispatch(
      loadScheduled(
        onlyMySchedules
          ? { ...filter, limit: rowsPerPage }
          : { ...filter, limit: rowsPerPage, userId: 0 }
      )
    );
  }, [openModal, filter, onlyMySchedules, dispatch, rowsPerPage]);

  useEffect(() => {
    if (selectedCase) {
      dispatch(loadScheduleMessage(selectedCase));
    }
  }, [selectedCase, dispatch]);

  useEffect(() => {
    if (!selectedCase && scheduledData.length > 0) {
      dispatch(setSelectedCase(scheduledData[0].case_id));
    }
  }, [selectedCase, scheduledData, dispatch]);

  return (
    <>
      <Button
        color="inherit"
        sx={{ textTransform: 'none', borderRadius: 20, padding: '8px 20px' }}
        startIcon={<CalendarIcon color={palette.primary.main} style={{ fontSize: 20 }} />}
        onClick={() => dispatch(openScheduledModal(true))}
        children="Schedule"
      />

      {openModal && (
        <Dialog
          fullWidth
          maxWidth="xl"
          sx={{ background: '#5051F935', zIndex: 2 }}
          PaperProps={{ sx: { padding: '28px 36px' } }}
          onClose={() => dispatch(openScheduledModal(false))}
          open={openModal}
        >
          <div className="flex items-center mb2">
            <span
              children="Scheduled Cases"
              style={{ color: palette.action.active, fontSize: '20px' }}
            />
            <span className="ml3 fs-12 mr1" children={'Only my schedules'} />
            <Switch checked={onlyMySchedules} onChange={handleSwitchSchedules} />
          </div>

          <Paper variant="outlined" style={containerStyle}>
            <Table
              loading={loading}
              headerHeight={46}
              rows={scheduledData}
              columns={scheduledColumns(userId, onlyMySchedules, dispatch)}
              selectRow={({ row }) => row.case_id === selectedCase}
              onSelectionModelChange={(param) => dispatch(setSelectedCase(param[0]))}
              selectionModel={[selectedCase]}
              autoHeight
              hideFooterPagination
              hideFooter
              disableColumnMenu
              disableMultipleColumnsSorting
              disableExtendRowFullWidth={false}
              sx={{ border: 'none' }}
              sortingMode="server"
              onSortModelChange={onSortHandler}
            />
          </Paper>

          <div
            style={{
              display: 'flex',
              gap: 12,
              justifyContent: 'flex-end',
              alignItems: 'center',
              marginTop: 10,
            }}
          >
            <span style={{ color: palette.action.active, fontSize: 14 }}>Cases per page :</span>
            <Select
              value={rowsPerPage}
              onChange={handleRowsPerPage}
              sx={{ fontSize: 16, padding: '5px 8px' }}
            >
              {options.map((option) => (
                <MenuItem key={option} value={option} children={option} />
              ))}
            </Select>
            <Pagination
              color="primary"
              shape="rounded"
              count={Math.ceil(count / rowsPerPage)}
              page={page}
              onChange={handleChangePage}
              renderItem={(item) => (
                <PaginationItem
                  color="primary"
                  components={{ previous: ArrowBackIosNewIcon, next: ArrowForwardIosIcon }}
                  {...item}
                />
              )}
            />
          </div>

          <ScheduledLogs caseId={selectedCase} />
        </Dialog>
      )}
    </>
  );
}
