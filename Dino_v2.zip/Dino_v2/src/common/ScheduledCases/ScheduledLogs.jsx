import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import Typography from '@mui/material/Typography';
import { useTheme } from '@mui/styles';

import { scheduledModule } from './ScheduledCasesDucks';

const style = {
  border: '2px solid #F3F5F9',
  borderRadius: 6,
  marginTop: 12,
  padding: '11px 15px 9px 10px',
  height: '300px',
  overflowY: 'auto',
};

export default function ScheduledLogs({ caseId }) {
  const logMessages = useSelector((state) => state[scheduledModule].logMessages);
  const { palette } = useTheme();

  useEffect(() => {
    const elem = document.querySelector('#log-messages');
    if (elem) {
      elem.scrollTop = elem.scrollHeight;
    }
  });

  return (
    <div id="log-messages" style={style}>
      {caseId &&
        logMessages[caseId]?.map((item, index) => {
          const color = item.is_error ? palette.error.main : palette.text.secondary;
          const time = item?.timestamp || '';

          return (
            <div key={index} className="flex" style={{ color: color }}>
              <div style={{ width: 140, minWidth: 140 }}>{time}</div>
              <div className="ml2" dangerouslySetInnerHTML={{ __html: item.message }} />
            </div>
          );
        })}
    </div>
  );
}
