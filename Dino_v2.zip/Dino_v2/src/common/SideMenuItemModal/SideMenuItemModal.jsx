import React from 'react';
import Box from '@mui/material/Box';
import { Modal } from '@mui/material';

const style = {
  position: 'fixed',
  top: 310,
  left: 260,
  transform: 'translate(-50%, -50%)',
  bgcolor: 'background.paper',
  borderTopLeftRadius: 20,
  borderTopRightRadius: 20,
  borderBottomLeftRadius: 20,
  borderBottomRightRadius: 20,
  boxShadow: '0px 8px 15px 0px #5051F960',
  padding: '33px 33px 15px 33px ',
};

export default function SideMenuItemModal({ isOpen, close, children, boxStyle, left = style.left, top = style.top }) {
  return (
    <Modal open={isOpen} onClose={close} BackdropProps={{ sx: { background: 'transparent' } }}>
      <Box sx={{ ...style, ...boxStyle, left, top }} children={children} />
    </Modal>
  );
}
