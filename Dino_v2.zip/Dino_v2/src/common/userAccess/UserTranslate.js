import {addTranslation} from '../../_helpers/translate';

addTranslation({
	ru: {
		userAccess_errorLogout: 'Не удалось выйти из системы',
		userAccess_userNotFound: 'Пользователь не найден в системе',
		userAccess_incorrectUsernamePassword: 'Введен неверный логин или пароль',
		userAccess_authError: 'Не удалось авторизоваться',
		userAccess_signatureVerificationFail:
			'Ошибка ЭЦП, сертификат просрочен или некорректная подпись',
		userAccess_errorMultiSession:
			'Под учётной записью может работать только 1 пользователь',
		userAccess_error_token:
			'Уважаемый пользователь! Срок активной сессии Вашей учетной записи истек! Пожалуйста, обновите страницу и укажите повторно данные авторизации (логин/пароль)',
	},
	kk: {
		userAccess_errorLogout: 'Шығу сәтсіз аяқталды',
		userAccess_authError: 'Жүйеге кіру сәтсіз аяқталды',
		userAccess_incorrectUsernamePassword: 'Логин немесе құпия сөз қате енгізілді',
		userAccess_userNotFound: 'Пайдаланушы жүйеде табылмады',
		userAccess_signatureVerificationFail:
			'ЭЦҚ қатесі, сертификат мерзімі өткен немесе қол қате',
		userAccess_errorMultiSession:
			'Тіркеулік жазба бойынша тек 1 пайдаланушы жұмыс істей алады',
	},
});
