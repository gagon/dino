import {createReducer} from '@reduxjs/toolkit';
import {UserApi} from './UserApi';
import {handleError} from '../utils/handleError';
import i18next from 'i18next';
import routerProps from '../../_helpers/routerProps';
import Notice from '../utils/Notice';
import './UserTranslate';

/**
 * Constants
 */

export const userModule = 'user';
const SET_USER = `${userModule}/SET_USER`;
const LOADING = `${userModule}/LOADING`;
const CLEAR_STATE = `${userModule}/CLEAR_STATE`;

/**
 * Reducer
 */

const initialState = {
	loading: true,
	data: null,
	permissions: [],
};

export default createReducer(initialState, {
	[SET_USER]: (state, action) => {
		state.data = action.data;
		state.permissions = action.permissions;
		state.loading = false;
	},
	[LOADING]: (state, action) => {
		state.loading = !!action.payload;
	},
	[CLEAR_STATE]: () => initialState,
});

/**
 * Actions
 */

const setUser = (data) => async (dispatch) => {
	let permissions = [];
	let user = data;
	let startPage = "/";

	// collect permissions
	for (const permission of user.permissions || []) {
		permissions.push(permission.name);
	}

	dispatch({
		type: SET_USER,
		data: {...user, startPage},
		permissions,
	});
};

export const login = (values) => async (dispatch) => {
	try {
		dispatch({type: LOADING, payload: true});
		let {data} = await UserApi.login(values);
		localStorage.setItem('accessToken', data.result.accessToken);
		localStorage.setItem('refreshToken', data.result.refreshToken);
		dispatch(setUser(data.result));
	} catch (error) {
		if (error.response && error.response.data) {
			const errorStatus = error.response.data.status;
			if (errorStatus === 'INCORRECT_USERNAME_PASSWORD') {
				Notice.error(i18next.t('userAccess_incorrectUsernamePassword'));
			}
			if (errorStatus === 'MULTISESSION_NOT_ALLOWED') {
				Notice.error(i18next.t('userAccess_errorMultiSession'));
			}
		} else {
			handleError(error, i18next.t('userAccess_authError'));
		}
	} finally {
		dispatch({type: LOADING, payload: false});
	}
};

export const onetimePasswordByEmail = (formValues, history) => async (dispatch) => {
	try {
		dispatch({type: LOADING, payload: true});
		let nameParam = 'name';
		if (formValues.username.indexOf('@') !== -1) {
			nameParam = 'email';
		}
		let {data} = await UserApi.onetimePasswordByEmail(formValues, nameParam);
		if (data.status === 'SUCCESS') {
			Notice.success(i18next.t('reset_password_by_email_message'));
			history.push('/?login=true');
		}
	} catch (error) {
		handleError(error, i18next.t('userAccess_userNotFound'));
	} finally {
		dispatch({type: LOADING, payload: false});
	}
};

export const resetPassword = (formValues, history, oneTimePassword) => async (dispatch) => {
	try {
		dispatch({type: LOADING, payload: true});
		const dataValues = {...formValues, oneTimePassword};
		let {data} = await UserApi.resetPassword(dataValues);
		if (data.status === 'SUCCESS') {
			Notice.success(i18next.t('reset_success_message'));
			history.push('/?login=true');
		}
	} catch (error) {
		handleError(error, i18next.t('reset_error_message'));
	} finally {
		dispatch({type: LOADING, payload: false});
	}
};

export const logout = () => async (dispatch) => {
	try {
		dispatch({type: LOADING, payload: true});
		// await UserApi.logout();
	} catch (error) {
		console.error(error);
	} finally {
		localStorage.removeItem('accessToken');
		localStorage.removeItem('refreshToken');
		localStorage.removeItem('expiredAt');
		dispatch({type: SET_USER, data: null, permissions: []});
		dispatch({type: LOADING, payload: false});
	}
};

export const clearUser = () => async (dispatch) => {
	try {
		dispatch({type: LOADING, payload: true});
		localStorage.removeItem('accessToken');
		localStorage.removeItem('refreshToken');
		localStorage.removeItem('expiredAt');
		dispatch({type: SET_USER, data: null, permissions: []});
	} catch (error) {
		console.error(error);
		// handleError(error, i18next.t('userAccess_errorLogout'));
	} finally {
		dispatch({type: LOADING, payload: false});
	}
};

export const checkLogin = () => async (dispatch) => {
	try {
		dispatch({type: LOADING, payload: true});
		const {data} = await UserApi.getUser();
		dispatch(setUser(data.result));
	} catch (error) {
		let location = window.location;
		for (const route of Object.values(routerProps)) {
			if (route.path === location.pathname && !route.withoutAuth) {
				window.addressBarUrl = `${location.pathname}${location.search}`;
			}
		}
		dispatch({type: LOADING, payload: false});
	}
};

export const reUpdateUser = (handleUserData) => async (dispatch) => {
	try {
		const {data} = await UserApi.getUser();
		dispatch(setUser(data, handleUserData));
	} catch (error) {
		console.error(error);
	}
};
