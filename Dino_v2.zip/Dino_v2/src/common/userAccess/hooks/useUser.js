import {useSelector} from 'react-redux';
import {userModule} from '../UserDucks';

export default function useUser() {
	return useSelector((state) => state[userModule].data);
}
