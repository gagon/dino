import axios from 'axios';

export const UserApi = {
	login: (values) => axios.post('api/auth/login', values),
	onetimePasswordByEmail: (values, nameParam) =>
		axios.post(
			`api:services/nedb-entitlement/api/entlmnt/users/reset-password/${nameParam}/${values.username}`
		),
	resetPassword: (values) => axios.put('/api/auth/reset-password', values),
	getUser: () => axios.get('api/loginByToken'),
	logout: () => axios.get('api:runtime/logout'),
	refreshUser: (token) => axios.post('/token/refresh', null, {headers: {Authorization: `Bearer ${token}`}}),
};
