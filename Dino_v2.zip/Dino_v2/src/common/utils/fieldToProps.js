export function fieldToProps({ field, fieldState }) {
  return {
    ...field,
    inputRef: field.ref,
    error: !!fieldState.error,
    helperText: fieldState?.error?.message,
  }
}
