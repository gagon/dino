import moment from 'moment';

const TIMESTAMP_FMT = 'YYYY-MM-DDTHH:mm:ss';
const DATE_FMT = 'DD.MM.YYYY';
const DATE_MMM_FMT = 'DD MMM YYYY';
const TIME_FMT = 'HH:mm';
const TIME_SECONDS_FMT = 'HH:mm:ss';
const DATE_TIME_FMT = 'DD.MM.YYYY / HH:mm';

export const dateTimeFormat = (string) => string ? moment(string, TIMESTAMP_FMT).format(DATE_TIME_FMT) : string;
export const dateFormat = (string) => moment(string, TIMESTAMP_FMT).format(DATE_FMT);
export const timeFormat = (string) => string ? moment(string).format(TIME_FMT) : string;
export const dateMMMFormat = (string) => string ? moment(string).format(DATE_MMM_FMT) : string;

export const makeTimestamp = (date, time, withSeconds = false) =>
  moment(`${date} ${time}`, `${DATE_FMT} ${withSeconds ? TIME_SECONDS_FMT : TIME_FMT}`);

export const parseTimestamp = (string) => moment(string, TIMESTAMP_FMT);

export const formatTimestamp = (date) => date.format(TIMESTAMP_FMT);

export const formatCurrentTimestamp = () => formatTimestamp(moment());

export const parseDate = (string) => moment(string, DATE_FMT);

export const formatDate = (date) => date.format(DATE_FMT);

export const formatCurrentDate = () => formatDate(moment());

export const parseTime = (string, withSeconds = false) =>
  moment(string, withSeconds ? TIME_SECONDS_FMT : TIME_FMT);

export const formatTime = (date, withSeconds = false) =>
  date.format(withSeconds ? TIME_SECONDS_FMT : TIME_FMT);

export const formatCurrentTime = (withSeconds = false) =>
  formatTime(moment(), withSeconds);
