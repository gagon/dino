const addressToShort = (address_name) => {
    return address_name
        .replace('Улица', 'ул.')
        .replace('улица', 'ул.')
        .replace('проспект', 'пр.')
        .replace('Проспект', 'пр.')
        .replace('квартал', 'кв.')
        .replace('Квартал', 'кв.')
        .replace('микрорайон', 'мкр.')
        .replace('Микрорайон', 'мкр.')
        .replace('жилой комплекс', 'ЖК')
        .replace('Жилой комплекс', 'ЖК')
        .trim();
}
export function getAddress(address, getter){
    let street = '';
    let city = '';
    let full = '';

    full = addressToShort(address ?? '');

    let regexp = new RegExp('[0-9]');
    let hasHouseNumber = regexp.test(full);
    let items = full.split(',');

    if (items.length > 1) {
        if (hasHouseNumber && items.length >= 3) {
            city = items.slice(0, items.length - 2).join(', ').trim();
            street = items.slice(items.length - 2).join(', ').trim();
        } else {
            city = items.slice(0, items.length - 1).join(', ').trim();
            street = items.slice(items.length - 1).join(', ').trim();
        }
    } else {
        street = full;
        city = full;
    }
    switch (getter) {
        case 'city':
            return city;
        case 'street':
            return street;
        case 'full':
            return full;
        default:
            return full;
    }
}
