export function userFullName(data) {
  if (data.firstName) {
    return `${data.lastName || ''} ${data.firstName || ''}  ${data.middleName || ''}`;
  } else {
    return '';
  }
}
