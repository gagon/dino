import { useEffect, useState } from 'react';
import axios from 'axios';
import useUser from './userAccess/hooks/useUser';

async function downloadAvatar(photoUrl, setAvatar) {
    try {
        const photoResponse = await axios.get(photoUrl, { responseType: 'blob' });
        setAvatar(URL.createObjectURL(photoResponse.data));
    } catch (error) {
        console.error('Не удалось загрузить фото профиля', error);
    }
}

export function useAvatar() {
    const [avatar, setAvatar] = useState(null);
    const user = useUser();
    const photoUrl = user?.photoUrl;
    useEffect(() => {
        if (photoUrl) {
            downloadAvatar(photoUrl, setAvatar);
        }
        return () => setAvatar(null);
    }, [photoUrl]);

    return avatar;
}
