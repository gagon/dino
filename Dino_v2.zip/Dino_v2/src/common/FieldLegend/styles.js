export const gridWrapper = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: '4px',
  marginTop: '4px',
};

export const bgColors = {
  isExport: '#EDB901',
  isResult: '#1d9868',
  isMeasured: '#EDB901',
  isConstraint: '#EDB901',
};

export const spanWrapper = (colorKey) => ({
  display: 'flex',
  alignItems: 'center',
  height: 17,
  width: 76,
  margin: 0,
  padding: '2px 4px',
  borderRadius: '8px',
  fontSize: 8,
  color: colorKey === 'isExport' ? 'black' : 'white',
  border: colorKey === 'isConstraint' ? '2px solid #F12BA8' : 'none',
  backgroundColor: bgColors[colorKey],
});
