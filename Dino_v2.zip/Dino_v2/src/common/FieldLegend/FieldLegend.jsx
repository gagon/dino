import React from 'react';
import { gridWrapper, spanWrapper } from './styles';
import FieldArrowIcon from '../../_media/FieldArrowIcon';

const FieldLegend = () => {
  return (
    <div className="mr3">
      <span className="text-secondary bold fs-10">Color key :</span>
      <div style={gridWrapper}>
        <span style={spanWrapper('isExport')}>
          <FieldArrowIcon stroke={'black'} style={{ fontSize: 9, marginRight: 3, marginLeft: 3 }} />
          EXPORT
        </span>
        <span style={spanWrapper('isResult')}>
          <FieldArrowIcon stroke={'white'} style={{ fontSize: 9, marginRight: 3, marginLeft: 3 }} />
          RESULT
        </span>
        <span style={spanWrapper('isMeasured')}>
          <FieldArrowIcon stroke={'white'} style={{ fontSize: 9, marginRight: 3, marginLeft: 3 }} />
          MEASURED
        </span>
        <span style={spanWrapper('isConstraint')}>
          <FieldArrowIcon stroke={'white'} style={{ fontSize: 9, marginRight: 3, marginLeft: 3 }} />
          CONSTRAINT
        </span>
      </div>
    </div>
  );
};

export default FieldLegend;
