import React from 'react';
import { Helmet } from 'react-helmet';
import { useTranslation } from 'react-i18next';

export default function HeadTitle({ title }) {
  const { i18n } = useTranslation();
  const coreTitle = {
    ru: process.env.REACT_APP_HEAD_TITLE_RU || '',
    kk: process.env.REACT_APP_HEAD_TITLE_KK || '',
  };
  return (
    <Helmet>
      <title>
        {coreTitle[i18n.language] ? `${coreTitle[i18n.language]} | ` : ''}
        {title}
      </title>
    </Helmet>
  );
}
