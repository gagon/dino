import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

import AFTreeItem from './AFTreeItem';
import { PIDataApi } from '../../_helpers/service';
import { loginModule } from '../../pages/Login/LoginDucks';

const AFTree = ({ setSelectedAFItem }) => {
  const [initialAFTree, setInitialAFTree] = useState([]);
  const afServer = useSelector((state) => state[loginModule].appConfig['AF:AFServer']);

  useEffect(() => {
    const url = 'https://' + afServer + '/piwebapi/assetservers';
    PIDataApi.get(url).then((r) => {
      const data = r.data.Items.map((el) => ({ ...el, Type: 'AssetServers' }));
      setInitialAFTree(data);
    });
  }, []);

  return (
    <div>
      {initialAFTree ? (
        <ul style={{ listStyleType: 'none', margin: 0, padding: 0 }}>
          {initialAFTree.map((item) => (
            <AFTreeItem key={item.Id} item={item} setSelectedAFItem={setSelectedAFItem} />
          ))}
        </ul>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default AFTree;
