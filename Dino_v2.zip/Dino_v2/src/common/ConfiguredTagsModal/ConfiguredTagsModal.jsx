import React, { useState, useCallback } from 'react';
import { Dialog, DialogTitle, Button, ToggleButtonGroup, ToggleButton } from '@mui/material';
import { useTheme } from '@mui/styles';

import AFSearch from './AFSearch';
import AFTree from './AFTree';
import Card from './Card';
import {
  afTreeWrapperStyle,
  afValueWrapperStyle,
  modalPaperStyle,
  toggleButtonStyle,
} from './styles';

const tabs = { afTree: 'AF Tree', search: 'Search' };

const ConfiguredTagsModal = ({ isOpen, close, onSelect }) => {
  const [selectedItem, setSelectedAFItem] = useState({});
  const [tab, setTab] = useState(tabs.afTree);
  const { palette } = useTheme();

  const handleChangeTab = useCallback((e) => {
    setSelectedAFItem(null);
    setTab(e.target.value);
  }, []);

  const handleSelectAF = useCallback(() => {
    if (selectedItem?.Path) {
      onSelect(selectedItem.Path);
      close();
    }
  }, [selectedItem?.Path]);

  return (
    <Dialog
      sx={{ background: '#5051F935', zIndex: 1400 }}
      PaperProps={{
        sx: modalPaperStyle,
      }}
      onClose={close}
      open={isOpen}
    >
      <div
        style={{
          width: '100%',
          height: 620,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
        }}
      >
        <DialogTitle sx={{ padding: 0, color: palette.action.active }}>Search AF</DialogTitle>

        <ToggleButtonGroup
          color="primary"
          variant="contained"
          size="small"
          sx={{ width: '40%' }}
          value={tab}
          exclusive
          onChange={handleChangeTab}
        >
          <ToggleButton sx={toggleButtonStyle} value={tabs.afTree} children="AF Tree" />
          <ToggleButton sx={toggleButtonStyle} value={tabs.search} children="Search" />
        </ToggleButtonGroup>

        <div style={{ overflow: 'auto' }}>
          <div style={afTreeWrapperStyle}>
            {tab === tabs.afTree && <AFTree setSelectedAFItem={setSelectedAFItem} />}
            {tab === tabs.search && <AFSearch />}
          </div>
          <div style={afValueWrapperStyle}>
            <Card selectedItem={selectedItem} />
          </div>
        </div>

        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            width: '100%',
          }}
        >
          <Button
            variant="contained"
            sx={{ width: 160 }}
            children="Select AF Value"
            onClick={handleSelectAF}
          />
          <Button
            sx={{ width: 100, background: palette.action.selected }}
            children="Close"
            onClick={close}
          />
        </div>
      </div>
    </Dialog>
  );
};

export default ConfiguredTagsModal;
