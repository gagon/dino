import React from 'react';
import moment from 'moment';
import { Alert } from '@mui/material';

const cardKeys = {
  Name: 'Name',
  Description: 'Description',
  Path: 'Path',
  'Default Unit': 'DefaultUnit',
  Type: 'Type',
  'Data Reference': 'DataReferencePlugIn',
  'DR Config String': 'ConfigString',
  Span: 'Span',
  Zero: 'Zero',
};

const Card = ({ selectedItem }) => {
  return (
    <ul style={{ listStyleType: 'none', margin: 0, padding: 0 }}>
      {Object.entries(cardKeys).map(([key, value]) => (
        <li style={{ display: 'flex', gap: 5, marginBottom: 8 }} key={key}>
          <label style={{ fontWeight: 'bold' }}>{key}: </label>
          <span>{selectedItem?.[value]}</span>
        </li>
      ))}
      {(selectedItem?.Value || selectedItem?.Timestamp) && (
        <li style={{ display: 'flex', gap: 5, marginBottom: 8 }}>
          <Alert sx={{ fontWeight: 'bold' }} severity={selectedItem?.Good ? 'success' : 'error'}>
            {moment(selectedItem?.Timestamp).format('DD-MM-YYYY HH:mm:ss')}:
            <span style={{ marginLeft: 8 }}>
              {selectedItem?.Value?.Value || selectedItem?.Value}
            </span>
          </Alert>
        </li>
      )}
    </ul>
  );
};

export default Card;
