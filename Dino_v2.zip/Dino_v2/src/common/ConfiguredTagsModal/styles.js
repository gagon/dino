export const modalPaperStyle = {
  padding: '25px 28px ',
  borderTopRightRadius: 20,
  borderTopLeftRadius: 20,
  borderBottomLeftRadius: 20,
  borderBottomRightRadius: 20,
  maxWidth: 1536,
  maxHeight: 'calc(100% - 64px)',
  width: 'calc(100% - 64px)',
};

export const toggleButtonStyle = { width: '100%', textTransform: 'none' };

export const afTreeWrapperStyle = {
  float: 'left',
  width: '40%',
  minHeight: '200px',
  height: 470,
  overflow: 'auto',
  border: '1px solid rgba(0, 0, 0, 0.12)',
  borderTopLeftRadius: 8,
  borderBottomLeftRadius: 8,
  padding: 15,
};

export const afValueWrapperStyle = {
  float: 'right',
  width: '60%',
  minHeight: '200px',
  height: '100%',
  border: '1px solid rgba(0, 0, 0, 0.12)',
  borderLeft: 'none',
  borderTopRightRadius: 8,
  borderBottomRightRadius: 8,
  padding: 15,
};
