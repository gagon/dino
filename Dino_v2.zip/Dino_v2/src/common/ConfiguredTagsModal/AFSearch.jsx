import React, { useCallback, useState } from 'react';
import { TextField, Button } from '@mui/material';
import { useSelector } from 'react-redux';

import { PIDataApi } from '../../_helpers/service';
import { loginModule } from '../../pages/Login/LoginDucks';

const AFSearch = () => {
  const [searchStr, setSearchStr] = useState('');
  const [noResults, setNoResults] = useState(false);
  const afServer = useSelector((state) => state[loginModule].appConfig['AF:AFServer']);

  const handleChangeSearchStr = useCallback((e) => {
    setSearchStr(e.target.value.replace('[+-&&||!(){}[]^"~*?:]', '\\$&'));
  }, []);

  const handleSearch = useCallback(async () => {
    if (searchStr.length) {
      const searchLink = 'https://' + afServer + '/piwebapi/search/query?q=name:' + searchStr;
      const { data } = await PIDataApi.get(searchLink);
      if (data.Items.length > 0) {
        setNoResults(false);
        // implement the af directory tree when the PI search will be fixed
      } else {
        setNoResults(true);
      }
    }
  }, [searchStr, afServer]);

  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
        <TextField
          sx={{ width: '80%', margin: 0 }}
          InputProps={{ sx: { px: '16px', py: '5.5px' } }}
          onChange={handleChangeSearchStr}
          value={searchStr}
        />
        <Button
          variant="contained"
          size="small"
          children="Search"
          sx={{ ml: 1, textTransform: 'none' }}
          onClick={handleSearch}
          disabled={searchStr.length < 1}
        />
      </div>

      {noResults && <h4>No search results returned.</h4>}
    </>
  );
};

export default AFSearch;
