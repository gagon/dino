import React, { useCallback, useState } from 'react';
import { IconButton } from '@mui/material';
import { useTheme } from '@mui/styles';
import FolderIcon from '@mui/icons-material/Folder';
import SellIcon from '@mui/icons-material/Sell';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { PIDataApi } from '../../_helpers/service';

const childrenMap = {
  afelement: ['Self'],
  PISystems: ['AssetServers'],
  AssetServers: ['Databases'],
  Databases: ['Elements'],
  Elements: ['Elements', 'Attributes'],
  Attributes: ['Attributes'],
};

const AFTreeItem = ({ item, setSelectedAFItem }) => {
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [contents, setContents] = useState([]);
  const { palette } = useTheme();

  const handleSelectAFItem = useCallback(() => setSelectedAFItem(item), [setSelectedAFItem, item]);

  const toggleSelectedFolder = useCallback(async () => {
    if (selectedFolder === item.Id) {
      setSelectedFolder(null);
      setContents([]);
      return;
    }

    setSelectedFolder(item.Id);

    await childrenMap[item.Type].forEach(async (childCollection) => {
      const url = item.Links[childCollection];
      const { data } = await PIDataApi.get(url);
      const childrenItems = data.Items.map((el) => ({
        ...el,
        Type: childCollection,
      }));

      setContents((prev) => [...prev, ...childrenItems]);
    });
  }, [selectedFolder, item]);

  return (
    <li>
      <div
        style={{
          display: 'flex',
          alignItems: 'flex-end',
          color: palette.primary.main,
          cursor: 'pointer',
          paddingLeft: item.Type === 'Attributes' || item.Type === 'pipoint' ? 20 : 0,
        }}
      >
        {!(item.Type === 'Attributes' || item.Type === 'pipoint') && (
          <IconButton
            sx={{ padding: 0, margin: 0, color: palette.primary.main }}
            children={
              selectedFolder === item.Id ? (
                <KeyboardArrowDownIcon fontSize="small" />
              ) : (
                <KeyboardArrowRightIcon fontSize="small" />
              )
            }
            onClick={toggleSelectedFolder}
          />
        )}

        <div onClick={handleSelectAFItem} style={{ display: 'flex', alignItems: 'flex-end' }}>
          {item.Type === 'Attributes' || item.Type === 'pipoint' ? (
            <SellIcon fontSize="small" sx={{ marginRight: '3px' }} />
          ) : (
            <FolderIcon fontSize="small" sx={{ marginRight: '3px' }} />
          )}
          {item.Name}
        </div>
      </div>

      <ul
        style={{
          paddingLeft: 10,
          listStyleType: 'none',
          margin: 0,
        }}
      >
        {contents.map((item) => (
          <AFTreeItem key={item.Id} item={item} setSelectedAFItem={setSelectedAFItem} />
        ))}
      </ul>
    </li>
  );
};

export default AFTreeItem;
