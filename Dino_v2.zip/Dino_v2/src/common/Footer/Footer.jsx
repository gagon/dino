import React from 'react';
import { StyledFooter } from './FooterStyle';

function Footer() {
  return (
    <StyledFooter>
      <div className="center bold flex items-center justify-center p3">
        © Dino 2022, All Rights Reserved
      </div>
    </StyledFooter>
  );
}

export default Footer;
