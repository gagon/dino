import styled from 'styled-components';

export const StyledFooter = styled.div`
  background-color: #d8d8e0;
  border-top: 1px solid ${(props) => props.theme.palette.divider};
`;
