import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';
import Tooltip from '@mui/material/Tooltip/Tooltip';

const JointNode = ({ id, data }) => {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
      }}
    >
      <Tooltip title={id}>
        <div
          style={{
            backgroundColor: 'red',
            width: '16px',
            height: '16px',
            borderRadius: '10px',
            border: '2px black solid',
          }}
        />
      </Tooltip>

      <div style={{ position: 'absolute', marginTop: '20px', fontSize: '10px' }}>{data.label}</div>
      <Handle type="target" position={Position.Left} id={id} />
      {!data.isLastJoint && <Handle type="source" position={Position.Right} id={id} />}
    </div>
  );
};

export default memo(JointNode);
