import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';

const WellNode = ({ id, data }) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
      <div
        style={{
          width: 0,
          height: 0,
          borderStyle: 'solid',
          borderWidth: '0 50px 90px 50px',
          borderColor: 'transparent transparent #A4DE02 transparent',
        }}
      />
      <div
        style={{
          fontWeight: 'bold',
        }}
      >
        {data.wellName}
      </div>
      <Handle
        type="source"
        position={Position.Right}
        id={id}
        style={{ position: 'absolute', top: 55, left: 80 }}
      />
    </div>
  );
};

export default memo(WellNode);
