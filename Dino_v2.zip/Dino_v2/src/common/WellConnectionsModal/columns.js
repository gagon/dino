export const columns = [
  {
    width: 120,
    field: 'well',
    headerName: 'Well',
    renderCell: ({ row }) => <Cell value={row?.gap_name} />,
  },
  {
    width: 80,
    field: 'unit',
    headerName: 'Unit',
    renderCell: ({ row }) => <Cell value={row?.unit} />,
  },
  {
    flex: 0.6,
    minWidth: 90,
    field: 'rms',
    headerName: 'RMS',
    renderCell: ({ row }) => <Cell value={row?.rms} />,
  },
  {
    minWidth: 100,
    field: 'line',
    headerName: 'Line',
    renderCell: ({ row }) => <Cell value={row?.trunk} />,
  },
  {
    width: 120,
    field: 'mp/lp',
    headerName: 'MP/LP',
    renderCell: ({ row }) => <Cell value={row?.mplp} />,
  },
  {
    width: 80,
    field: 'slot',
    headerName: 'Slot',
    renderCell: ({ row }) => <Cell value={row?.slot} />,
  },
  {
    flex: 0.6,
    minWidth: 100,
    field: 'slotPressPipe',
    headerName: 'Slot Press Pipe',
    renderCell: ({ row }) => <Cell value={row?.os_pipe} />,
  },
  {
    flex: 1.2,
    minWidth: 100,
    field: 'branchJoints',
    headerName: 'Branch Joints',
    renderCell: ({ row }) => <Cell value={row?.branchStr} />,
  },
  {
    flex: 1.2,
    minWidth: 100,
    field: 'maskPipes',
    headerName: 'Mask Pipes',
    renderCell: ({ row }) => <Cell value={row?.maskStr} />,
  },
];

const Cell = ({ value }) => <div style={{ paddingLeft: 8 }}>{value}</div>;
