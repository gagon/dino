import React, { useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { FormControlLabel, IconButton, Button, Checkbox, Select, MenuItem } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

import PopoverWindow from '../Popover/Popover';
import DinoSocket from '../../_helpers/socket';
import { StyledInput } from '../../pages/Config/Wells/Components/StyledInput';
import useSocketMessage from '../_hooks/useSocketMessage';
import {
  clearPipeChangesData,
  onCellChange,
  setPipeData,
  wellConnectionsModule,
} from './WellConnectionsDucks';

const fields = [
  { title: 'Name', name: 'label' },
  { title: 'Correlation', name: 'PIPECORR', type: 'select', options: [] },
  { title: 'Gravity Coefficient', name: 'GRAVITY' },
  { title: 'Friction Coefficient', name: 'FRICTION' },
  { label: 'Mask Pipe', name: 'ISMASKED', type: 'checkbox' },
];

const correlationOptions = [
  'BeggsandBrill',
  'BeggsandBrillGasHead',
  'DuklerEatonFlannigan',
  'DuklerFlannigan',
  'DunsandRosModified',
  'DunsandRosOriginal',
  'FancherBrown',
  'GREmodifiedbyPE',
  'GREoriginal',
  'GREwithAE',
  'GREwithDSM',
  'HagedornBrown',
  'Hydro2P',
  'Hydro3P',
  'LedaFlow2P',
  'LedaFlow3P',
  'LedaFlow3P',
  'OLGAS2P',
  'OLGAS3P',
  'OLGAS3PEXT',
  'PE5Extended',
  'PetroleumExperts',
  'PetroleumExperts2',
  'PetroleumExperts3',
  'PetroleumExperts4',
  'PetroleumExperts5',
];

const PipePopover = ({ anchorEl, setAnchorEl, pipeId }) => {
  const pipeData = useSelector((state) => state[wellConnectionsModule].pipeData);
  const pipeChangesData = useSelector((state) => state[wellConnectionsModule].pipeChangesData);
  const gapConfig = useSelector((state) => state[wellConnectionsModule].gapConfig);
  const socket = DinoSocket.socket;
  const dispatch = useDispatch();
  const gapId = gapConfig?.id;

  const onClose = () => {
    dispatch(clearPipeChangesData());
    setAnchorEl(null);
  };

  const handlePipeData = (data) => {
    dispatch(setPipeData(data));
  };

  const handleSave = useCallback(() => {
    const saveObj = { values: {}, gapId };
    Object.entries(pipeChangesData).forEach(([key, value]) => {
      saveObj.values[key] = {
        variable: `GAP.MOD[{PROD}].PIPE[${pipeId}].${key}`,
        val: value,
        cmd: false,
      };
    });
    socket.emit('save_pipe_data_to_gap', JSON.stringify(saveObj));
  }, [pipeChangesData, pipeId]);

  useEffect(() => {
    if (anchorEl && socket) {
      socket.emit('get_pipe_data_from_gap', JSON.stringify({ gapId, pipeId }));
    }
  }, [anchorEl, pipeId, gapId]);

  useSocketMessage('get_pipe_data_from_gap_reply', handlePipeData);
  useSocketMessage('save_pipe_data_to_gap_reply', onClose);

  return (
    <PopoverWindow open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={onClose}>
      <div className="pt2" style={{ minWidth: 800 }}>
        <div
          className="if-header flex items-center justify-between pl3 pr2 pb2"
          style={{ borderBottom: '1px solid lightgray' }}
        >
          <div className="bold">Edit Pipe In Gap - {pipeId}</div>
          <IconButton size="small" onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </div>

        <div className="px3 pb3 pt2 overflow-auto" style={{ maxHeight: 500 }}>
          {fields.map((field) => (
            <div key={field.name} className="clearfix" style={{ marginTop: 2 }}>
              <div className="col col-5 pt1">{field.title}</div>
              <div className="col col-7">
                {!field.type && (
                  <StyledInput
                    value={
                      pipeChangesData?.[field.name]
                        ? pipeChangesData?.[field.name]
                        : pipeData?.vars?.[field.name] || ''
                    }
                    currentValue={pipeData?.vars?.[field.name] || ''}
                    onChange={(e) => dispatch(onCellChange(field.name, e.target.value))}
                  />
                )}

                {field.type === 'select' && (
                  <Select
                    sx={{
                      padding: '4px 8px',
                      fontSize: '14px',
                      width: '100%',
                      backgroundColor:
                        pipeChangesData?.[field.name] !== undefined
                          ? 'rgb(227,174,115)'
                          : 'transparent',
                    }}
                    value={
                      pipeChangesData?.[field.name] !== undefined
                        ? pipeChangesData?.[field.name]
                        : pipeData?.vars?.[field.name] || ''
                    }
                    onChange={(e) => dispatch(onCellChange(field.name, e.target.value))}
                  >
                    {correlationOptions.map((option) => (
                      <MenuItem key={option} value={option} children={option} />
                    ))}
                  </Select>
                )}

                {field.type === 'checkbox' && (
                  <FormControlLabel
                    sx={{ marginRight: 3 }}
                    label={<span className="fs-12">{field.label}</span>}
                    control={
                      <Checkbox
                        title={field.label}
                        size="small"
                        checked={
                          !!pipeChangesData?.[field.name] !== undefined
                            ? !!pipeChangesData?.[field.name]
                            : !!pipeData?.vars?.[field.name]
                        }
                        onChange={(e) => dispatch(onCellChange(field.name, e.target.checked))}
                      />
                    }
                  />
                )}
              </div>
            </div>
          ))}
          <div className="flex justify-between mt4">
            <Button variant="contained" sx={{ width: 150 }} children="Save" onClick={handleSave} />
            <Button variant="outlined" sx={{ width: 150 }} children="Close" onClick={onClose} />
          </div>
        </div>
      </div>
    </PopoverWindow>
  );
};

export default PipePopover;
