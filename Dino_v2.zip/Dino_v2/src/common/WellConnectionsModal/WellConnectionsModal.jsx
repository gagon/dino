import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { Dialog, DialogTitle, Button } from '@mui/material';
import { useTheme } from '@mui/styles';

import ConnectionsTable from './ConnectionsTable';
import ConnectionsSchema from './ConnectionsSchema';
import { setEditMode, loadConnections } from './WellConnectionsDucks';

import { buttonWrapperStyle, contentWrapperStyle, modalWrapperStyle, paperStyle } from './styles';

const WellConnectionsModal = ({ wellId, gapId, onRowClick, isEditMode, isOpen, onClose }) => {
  const { palette } = useTheme();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(setEditMode(isEditMode));
    dispatch(loadConnections(gapId, wellId));
  }, [dispatch, setEditMode, loadConnections, wellId, gapId, isEditMode]);

  return (
    <Dialog
      sx={{ background: '#5051F935', zIndex: 2 }}
      PaperProps={{
        sx: paperStyle,
      }}
      onClose={onClose}
      open={isOpen}
    >
      <div style={modalWrapperStyle}>
        <DialogTitle sx={{ padding: 0, color: palette.action.active }}>
          Well Connections
        </DialogTitle>

        <div style={contentWrapperStyle}>
          <ConnectionsSchema />
          <ConnectionsTable onRowClick={onRowClick} />
        </div>

        <div style={buttonWrapperStyle}>
          <Button
            children="close"
            style={{ background: palette.action.selected, width: 100 }}
            onClick={onClose}
          />
        </div>
      </div>
    </Dialog>
  );
};

export default WellConnectionsModal;
