export const paperStyle = {
  padding: '25px 28px',
  borderTopRightRadius: 20,
  borderTopLeftRadius: 20,
  borderBottomLeftRadius: 20,
  borderBottomRightRadius: 20,
  maxWidth: 1536,
  maxHeight: 'calc(100% - 48px)',
  width: 'calc(100% - 64px)',
};

export const modalWrapperStyle = {
  width: '100%',
  height: 680,
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
};

export const contentWrapperStyle = {
  height: 600,
  display: 'flex',
  flexDirection: 'column',
  gap: 10,
};

export const buttonWrapperStyle = {
  display: 'flex',
  justifyContent: 'flex-end',
  width: '100%',
  marginTop: 10,
};
