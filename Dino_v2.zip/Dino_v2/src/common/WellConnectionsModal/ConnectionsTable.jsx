import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import Table from '../Table/Table';
import { columns } from './columns';
import { wellConnectionsModule } from './WellConnectionsDucks';

const ConnectionsTable = ({ onRowClick }) => {
  const rows = useSelector((state) => state[wellConnectionsModule].connections);

  return (
    <Table
      sx={{
        '& .MuiDataGrid-columnHeader:last-child .MuiDataGrid-columnSeparator': {
          display: 'none',
        },
        '& .super-app-theme': {
          bgcolor: '#D4EEFF',
        },
      }}
      getRowClassName={(params) => {
        if (params.row.selected) return 'super-app-theme';
      }}
      headerHeight={46}
      rowHeight={35}
      rows={rows}
      getRowId={(row) => row?.id}
      columns={columns}
      hideFooter
      disableColumnMenu
      disableSelectionOnClick
      disableMultipleColumnsSorting
      disableExtendRowFullWidth={false}
      {...(onRowClick && { onRowClick: ({ row }) => onRowClick(row) })}
    />
  );
};

export default ConnectionsTable;
