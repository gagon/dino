import React, { useState, useEffect, useMemo } from 'react';
import { useSelector } from 'react-redux';
import ReactFlow, { Controls, Background, useNodesState, useEdgesState } from 'reactflow';

import JointNode from './Nodes/JointNode';
import WellNode from './Nodes/WellNode';
import PipePopover from './PipePopover';
import { wellConnectionsModule } from './WellConnectionsDucks';

import 'reactflow/dist/style.css';

const nodeTypes = {
  well: WellNode,
  joint: JointNode,
};

const ConnectionsSchema = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [pipeId, setPipeId] = useState('');
  const isEditMode = useSelector((state) => state[wellConnectionsModule].isEditMode);
  const { well, joints, pipes } = useSelector((state) => state[wellConnectionsModule].nodes);
  const [nodes, setNodes, onNodesChange] = useNodesState();
  const [edges, setEdges, onEdgesChange] = useEdgesState();

  const allNodes = useMemo(() => {
    if (well?.id && joints.length > 0) {
      return [well, ...joints];
    }
    return [];
  }, [well?.id, joints]);

  useEffect(() => {
    if (allNodes.length > 0) {
      setNodes(allNodes);
    }
  }, [allNodes]);

  useEffect(() => {
    if (pipes.length > 0) {
      setEdges(pipes);
    }
  }, [pipes]);

  const onEdgeClick = (e, node) => {
    if (isEditMode) {
      setAnchorEl(e.currentTarget);
      setPipeId(node.data.pipeId);
    }
  };

  return (
    <div
      style={{
        width: '100%',
        height: '400px',
        display: 'flex',
        justifyContent: 'center',
      }}
    >
      {anchorEl && isEditMode && (
        <PipePopover anchorEl={anchorEl} setAnchorEl={setAnchorEl} pipeId={pipeId} />
      )}

      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onEdgeClick={onEdgeClick}
        fitView
        attributionPosition="top-right"
        nodeTypes={nodeTypes}
        nodesDraggable={false}
        nodesConnectable={false}
      >
        <Controls />
        <Background color="lightgray" gap={25} />
      </ReactFlow>
    </div>
  );
};

export default ConnectionsSchema;
