import { createReducer } from '@reduxjs/toolkit';
import { MarkerType } from 'reactflow';

import { WellsApi, CaseApi } from '../../_helpers/service';
import { handleError } from '../utils/handleError';
import { handleCaseConfig } from '../calculationUtils/caseConfigSettings';
import { loginModule } from '../../pages/Login/LoginDucks';

/**
 * Constants
 */
export const wellConnectionsModule = 'wellConnections';
const SET_LOADING = `${wellConnectionsModule}/SET_LOADING`;
const SET_CONNECTIONS = `${wellConnectionsModule}/SET_CONNECTIONS`;
const SET_PIPE_DATA = `${wellConnectionsModule}/SET_PIPE_DATA`;
const SET_GAP_CONFIG = `${wellConnectionsModule}/SET_GAP_CONFIG`;
const SET_CASE_CONFIG = `${wellConnectionsModule}/SET_CASE_CONFIG`;
const ON_CELL_CHANGE = `${wellConnectionsModule}/ON_CELL_CHANGE`;
const CLEAR_PIPE_CHANGES_DATA = `${wellConnectionsModule}/CLEAR_PIPE_CHANGES_DATA`;
const SET_EDIT_MODE = `${wellConnectionsModule}/SET_EDIT_MODE`;
const SET_NODES = `${wellConnectionsModule}/SET_NODES`;

const initialNodes = {
  well: null,
  joints: [],
  pipes: [],
};

/**
 * Reducer
 */
const initialState = {
  loading: false,
  connections: [],
  pipeData: null,
  pipeChangesData: {},
  gapConfig: null,
  caseConfig: null,
  isEditMode: false,
  nodes: initialNodes,
};

export default createReducer(initialState, {
  [SET_LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [SET_CONNECTIONS]: (state, { payload }) => {
    state.connections = payload;
  },
  [SET_NODES]: (state, { payload }) => {
    state.nodes = payload;
  },
  [SET_PIPE_DATA]: (state, { payload }) => {
    state.pipeData = payload;
  },
  [ON_CELL_CHANGE]: (state, { field, value }) => {
    state.pipeChangesData[field] = value;
  },
  [CLEAR_PIPE_CHANGES_DATA]: (state) => {
    state.pipeChangesData = {};
  },
  [SET_GAP_CONFIG]: (state, { payload }) => {
    state.gapConfig = payload;
  },
  [SET_CASE_CONFIG]: (state, { payload }) => {
    state.caseConfig = payload;
  },
  [SET_EDIT_MODE]: (state, { payload }) => {
    state.isEditMode = payload;
  },
});

/**
 * Actions
 */

export const loadConnections = (gapId, wellId) => async (dispatch, getState) => {
  try {
    dispatch({ type: SET_NODES, payload: initialNodes });

    let gapConfig = getState()[wellConnectionsModule].gapConfig;
    let wellConfig = getState()[wellConnectionsModule].caseConfig?.wellCfg;

    if (!gapConfig) {
      const { data } = await WellsApi.getCurrentGapFileData();
      dispatch({ type: SET_GAP_CONFIG, payload: data });
      gapConfig = data;
    }

    if (!wellConfig) {
      const userConfig = getState()[loginModule].userConfig;
      const { data } = await CaseApi.loadCaseConfigSetting();
      const caseConfig = handleCaseConfig(data, userConfig);
      dispatch({ type: SET_CASE_CONFIG, payload: caseConfig });
      wellConfig = caseConfig.wellCfg;
    }

    const { data } = await WellsApi.getConnectionsFromGap({ gapId, wellId });

    const results = data.results;
    const gap_well = gapConfig.gap_wells[data.wellId];
    const well = wellConfig[gap_well?.well_id];
    const gapName = well?.gap_name;

    const connections = results.map((conn, index) => {
      const branchArr = conn.branches.map((val) => val.id);
      const maskArr = conn.switches.map((val) => val.lbl);
      const matchingConn = gap_well.connections.find(
        (connection) => connection?.opensvr_mask === maskArr.join(',')
      );
      return {
        ...conn,
        id: index,
        gap_name: gapName,
        branchStr: branchArr.join(', '),
        maskStr: maskArr.join(', '),
        conn_id: matchingConn ? matchingConn.conn_map_id : null,
      };
    });
    dispatch({ type: SET_CONNECTIONS, payload: connections });

    const jointsDict = {};
    const linksDict = {};

    const pipes = results.map((row, index) => {
      const pipesRow = [];
      row.pipes.forEach((pipe) => {
        pipesRow.push({ id: pipe.id, lbl: pipe.lbl });
      });
      return pipesRow;
    });

    const joints = results.map((row, i) => {
      const jointsRow = [];

      row.joints.forEach((joint, j) => {
        const jointNode = {
          id: joint.id,
          data: {
            label: joint.lbl,
            isLastJoint: j === row.joints.length - 1,
          },
          type: 'joint',
          position: { x: 150 + j * 150, y: 75 + i * 75 },
        };
        jointsRow.push(jointNode);

        if (joint.id in jointsDict) {
          return;
        }

        jointsDict[joint.id] = jointNode;
      });
      return jointsRow;
    });

    joints.forEach((jointsRow, i) =>
      jointsRow.forEach((joint, j) => {
        if (j < jointsRow.length - 1) {
          let sourcePort = joint.id;
          if (joint.id in jointsDict) {
            sourcePort = jointsDict[joint.id].id;
          }

          let targetPort = jointsRow[j + 1].id;
          if (jointsRow[j + 1].id in jointsDict) {
            targetPort = jointsDict[jointsRow[j + 1].id].id;
          }

          const linkId = sourcePort + targetPort;
          const appropriatePipe = pipes[i][j];

          if (linkId in linksDict) {
            return;
          }

          const linkEdge = {
            id: linkId,
            data: {
              pipeId: appropriatePipe?.id,
            },
            label: appropriatePipe?.lbl,
            source: sourcePort,
            target: targetPort,
            type: 'simplebezier',
            animated: false,
            markerEnd: {
              type: MarkerType.ArrowClosed,
              color: 'black',
            },
            style: { stroke: 'black', strokeWidth: '1.6px' },
          };
          linksDict[linkId] = linkEdge;
        }
      })
    );

    Object.values(linksDict).forEach((link) => {
      const targetX = jointsDict[link.target].position.x;
      const sourceX = jointsDict[link.source].position.x;
      if (targetX <= sourceX) {
        jointsDict[link.target].position.x = sourceX + 150;
      }
    });
    Object.values(linksDict).forEach((link) => {
      const targetX = jointsDict[link.target].position.x;
      const sourceX = jointsDict[link.source].position.x;
      if (targetX <= sourceX) {
        jointsDict[link.target].position.x = sourceX + 150;
      }
    });

    const wellNode = {
      id: gapName,
      data: {
        wellName: gapName,
      },
      type: 'well',
      position: { x: 0, y: 28 },
    };

    const linkFromWell = {
      id: 'linkFromWell',
      data: {
        pipeId: 'Well pipe',
      },
      source: wellNode.id,
      target: Object.values(jointsDict)[0].id,
      type: 'simplebezier',
      animated: false,
      label: '',
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: 'black',
      },
      style: { stroke: 'black', strokeWidth: '1.6px' },
    };

    const jointsArr = Object.values(jointsDict);
    const linksArr = [linkFromWell, ...Object.values(linksDict)];

    dispatch({
      type: SET_NODES,
      payload: {
        well: wellNode,
        joints: jointsArr,
        pipes: linksArr,
      },
    });
  } catch (e) {
    handleError(e, 'Failed to load connections data');
  }
};

export const setPipeData = (data) => ({ type: SET_PIPE_DATA, payload: data });

export const onCellChange = (field, value) => ({
  type: ON_CELL_CHANGE,
  field,
  value,
});

export const clearPipeChangesData = () => ({ type: CLEAR_PIPE_CHANGES_DATA });

export const setEditMode = (isEditMode) => ({ type: SET_EDIT_MODE, payload: isEditMode });
