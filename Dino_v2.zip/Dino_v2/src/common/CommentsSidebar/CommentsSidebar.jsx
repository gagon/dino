import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { Drawer, TextField, Button, IconButton, Box } from '@mui/material';
import MessageIcon from '@mui/icons-material/MessageOutlined';
import ClearIcon from '@mui/icons-material/Clear';

import {
  commentsSidebarModule,
  getComments,
  addComment,
  removeComment,
} from './CommentsSidebarDucks';
import { loginModule } from '../../pages/Login/LoginDucks';

const CommentsSidebar = ({ well }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const userName = useSelector((state) => state[loginModule].user.user_name);
  const comments = useSelector((state) => state[commentsSidebarModule].comments);
  const wellName = well.gapName;
  const caseId = well.case_id;
  const dispatch = useDispatch();

  const handleToggleDrawer = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      dispatch(getComments(wellName, caseId));
    }
  };

  const handleSend = () => {
    if (message.trim().length > 0) {
      dispatch(addComment(userName, message, wellName, caseId));
      setMessage('');
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSend();
    }
  };

  const handleRemoveComment = (id) => {
    dispatch(removeComment(id));
  };

  return (
    <>
      <IconButton onClick={handleToggleDrawer} sx={{ ml: '2px' }}>
        <MessageIcon fontSize="10" />
      </IconButton>

      <Drawer anchor="right" open={isOpen} onClose={handleToggleDrawer}>
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            width: 440,
            height: '100%',
            padding: '25px 20px',
          }}
        >
          <div
            style={{
              height: 'calc(100% - 50px)',
              overflowY: 'scroll',
              paddingRight: '15px',
            }}
          >
            {!comments.length && <div>There are no comments yet</div>}
            {comments.map(({ comment_id, comment, user_name, start_date }) => (
              <div
                key={comment_id}
                style={{
                  float: user_name === userName ? 'right' : 'left',
                  width: '60%',
                  marginTop: '12px',
                  backgroundColor: user_name === userName ? 'lightblue' : 'lightgreen',
                  borderRadius: '8px',
                  padding: '5px 5px 10px 5px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 1,
                }}
              >
                <div
                  style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
                >
                  <div style={{ fontWeight: 800, paddingLeft: '15px' }}>{user_name}</div>
                  <IconButton onClick={() => handleRemoveComment(comment_id)} sx={{ mb: 1, p: 0 }}>
                    <ClearIcon fontSize="10" />
                  </IconButton>
                </div>
                <div style={{ paddingLeft: '5px' }}>{comment}</div>
                <div
                  style={{
                    textAlign: 'right',
                    fontWeight: 500,
                    fontSize: '12px',
                    paddingRight: '5px',
                    marginTop: 2,
                  }}
                >
                  {moment(start_date).format('YYYY-MM-DD HH:mm')}
                </div>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 4 }}>
            <TextField
              placeholder="Enter new comment here"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              sx={{ width: '100%', margin: 0 }}
              InputProps={{ sx: { padding: '8px', fontSize: '14px' } }}
            />
            <Button
              variant="contained"
              color="primary"
              onClick={handleSend}
              size="small"
              sx={{ textTransform: 'none' }}
            >
              Submit
            </Button>
          </div>
        </Box>
      </Drawer>
    </>
  );
};

export default CommentsSidebar;
