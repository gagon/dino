import { createReducer } from '@reduxjs/toolkit';

import { handleError } from '../utils/handleError';
import { CommentsApi } from '../../_helpers/service';

/**
 * Constants
 */
export const commentsSidebarModule = 'commentsSidebar';
const SET_LOADING = `${commentsSidebarModule}/SET_LOADING`;
const SET_COMMENTS = `${commentsSidebarModule}/SET_COMMENTS`;
const ADD_COMMENT = `${commentsSidebarModule}/ADD_COMMENT`;
const REMOVE_COMMENT = `${commentsSidebarModule}/REMOVE_COMMENT`;

/**
 * Reducer
 */
const initialState = {
  loading: false,
  comments: [],
};

export default createReducer(initialState, {
  [SET_LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [SET_COMMENTS]: (state, { payload }) => {
    state.comments = payload;
  },
  [ADD_COMMENT]: (state, { payload }) => {
    state.comments = [...state.comments, payload];
  },
  [REMOVE_COMMENT]: (state, { payload }) => {
    state.comments = state.comments.filter((comment) => comment.comment_id !== payload);
  },
});

/**
 * Actions
 */
export const getComments = (wellName, caseId) => async (dispatch) => {
  try {
    dispatch({ type: SET_LOADING, payload: true });
    const { data } = await CommentsApi.getComments(wellName, caseId);
    const filteredComments = data[0].filter((comment) => comment.end_date === null);
    dispatch({ type: SET_COMMENTS, payload: filteredComments });
  } catch (e) {
    handleError(e, 'Failed to load comments');
  } finally {
    dispatch({ type: SET_LOADING, payload: false });
  }
};

export const addComment = (user_name, comment, well_name, case_id) => async (dispatch) => {
  try {
    dispatch({ type: SET_LOADING, payload: true });
    const commentData = {
      user_name,
      comment,
      well_name,
      case_id,
    };
    const { data } = await CommentsApi.addComment(commentData);
    dispatch({ type: ADD_COMMENT, payload: data });
  } catch (e) {
    handleError(e, 'Failed to add comment');
  } finally {
    dispatch({ type: SET_LOADING, payload: false });
  }
};

export const removeComment = (commentId) => async (dispatch) => {
  try {
    dispatch({ type: SET_LOADING, payload: true });
    const data = await CommentsApi.removeComment(commentId);
    dispatch({ type: REMOVE_COMMENT, payload: commentId });
  } catch (e) {
    handleError(e, 'Failed to add comment');
  } finally {
    dispatch({ type: SET_LOADING, payload: false });
  }
};
