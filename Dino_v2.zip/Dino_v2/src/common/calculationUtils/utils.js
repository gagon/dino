export const updateSeperatorGrouping = function (variable, units, unitCfg, userCfg) {
  let refName = null;
  if (variable == 'MP_LP_TABLE_SPLIT') {
    refName = 'table';
  } else {
    // variable == 'MP_LP_CHART_SPLIT'
    refName = 'chart';
  }
  const bSplit = userCfg[variable] && userCfg[variable] == '1';
  units[refName] = {};

  for (let unit of Object.values(unitCfg)) {
    if (bSplit) {
      for (let sep of unit.separators) {
        var tblLabel = unit.unit;
        tblLabel += sep.mp_lp ? ' - ' + sep.mp_lp : '';
        var tblKey = tblLabel.replace(/\s/g, '');
        units[refName][tblKey] = { lbl: tblLabel, sep: sep };
      }
    } else {
      units[refName][unit.unit] = { lbl: unit.unit, sep: unit.separators[0] };
    }
  }
};

export const createConnectionMappings = function (dino) {
  dino.connection.tagMap = {};
  for (let conn_map of Object.values(dino.connection.mapping)) {
    if (conn_map.tag_unit && conn_map.tag_rms && conn_map.tag_mp_lp && conn_map.tag_tl) {
      var rmsKeys = conn_map.tag_rms.split(',');
      var mplpKeys = conn_map.tag_mp_lp.split(',');
      var tlKeys = conn_map.tag_tl.split(',');
      for (let rmsKey of rmsKeys) {
        for (let mplpKey of mplpKeys) {
          for (let tlKey of tlKeys) {
            var tagKey = conn_map.tag_unit + rmsKey + tlKey + mplpKey;
            tagKey = tagKey.toUpperCase();
            dino.connection.tagMap[tagKey] = conn_map;
          }
        }
      }
    }
  }
};

export const setMapConnections = (gapWellData, userCfg, wellDict, connMapDict, jointDict) => {
  const gapWell = {
    connectionMap: {},
    connectionTagMap: {},
    comingledWells: [],
    defaultConn: null,
    ...gapWellData,
  };

  const unitsSet = new Set();
  for (let conn of gapWell.connections) {
    unitsSet.add(conn.conn_map.unit);
  }

  const dual_unit = Array.from(unitsSet).join('/');

  for (let conn of gapWell.connections) {
    // only add the conn if it has unit/RMS and slot values
    if (conn.conn_map?.unit && conn.conn_map?.rms) {
      if (conn.conn_map.default || !gapWell.defaultConn)
        gapWell.defaultConn = conn.conn_map.default;
      var connStr = conn.conn_map.unit + ' ' + conn.conn_map.rms;
      if (conn.conn_map.tl) {
        connStr += ' ' + conn.conn_map.tl;
      }
      if (conn.conn_map.mp_lp) {
        connStr += ' ' + conn.conn_map.mp_lp;
      }
      connStr += ' slot ' + conn.slot;

      var bSplit = userCfg?.MP_LP_TABLE_SPLIT && userCfg['MP_LP_TABLE_SPLIT'] == '1';
      var tblLabel =
        bSplit && conn.conn_map.mp_lp
          ? conn.conn_map.unit + ' - ' + conn.conn_map.mp_lp
          : conn.conn_map.unit;
      var tblKey = tblLabel.replace(/\s/g, '');

      gapWell.connectionMap[conn.conn_map_id] = {
        conn_map_id: conn.conn_map_id,
        name: connStr,
        unit: conn.conn_map.unit,
        rms: conn.conn_map.rms,
        tl: conn.conn_map.tl,
        mp_lp: conn.conn_map.mp_lp,
        default: conn.conn_map.default,
        tblLabel: tblLabel,
        tblKey: tblKey,
      };

      if (connMapDict) {
        if (connMapDict[conn.conn_map_id] == null) {
          connMapDict[conn.conn_map_id] = {};
        }
        connMapDict[conn.conn_map_id][gapWell.well_id] = conn.conn_map_id;
      }

      var joints = [];
      if (conn.branch_joints) joints = conn.branch_joints.split(',');

      gapWell.connectionMap[conn.conn_map_id]['joints'] = joints;
      if (jointDict) {
        for (let joint of Object.values(joints)) {
          if (jointDict[joint] == null) {
            jointDict[joint] = {};
          }
          if (jointDict[joint][gapWell.well_id] == null) {
            jointDict[joint][gapWell.well_id] = [];
          }
          jointDict[joint][gapWell.well_id].push(gapWell.connectionMap[conn.conn_map_id]);
        }
      }

      gapWell.connectionMap[conn.conn_map_id]['comingled'] = '';
      if (conn.comingled1 && conn.comingled2) {
        gapWell.connectionMap[conn.conn_map_id]['comingled'] = [
          wellDict[conn.comingled1].gap_name,
          wellDict[conn.comingled2].gap_name,
        ].join();
      } else if (conn.comingled1 != null && conn.comingled1 in wellDict) {
        gapWell.connectionMap[conn.conn_map_id]['comingled'] = wellDict[conn.comingled1].gap_name;
      } else if (conn.comingled2 != null && conn.comingled2 in wellDict) {
        gapWell.connectionMap[conn.conn_map_id]['comingled'] = wellDict[conn.comingled2].gap_name;
      }
      gapWell.connectionMap[conn.conn_map_id]['dual_unit'] = dual_unit;

      if (conn.comingled1 && !gapWell.comingledWells.includes(conn.comingled1)) {
        gapWell.comingledWells.push(conn.comingled1);
      }
      if (conn.comingled2 && !gapWell.comingledWells.includes(conn.comingled2)) {
        gapWell.comingledWells.push(conn.comingled2);
      }

      var rmsKeys = conn.conn_map.tag_rms.split(',');
      var mplpKeys = conn.conn_map.tag_mp_lp.split(',');
      var tlKeys = conn.conn_map.tag_tl.split(',');
      for (let rmsKey of rmsKeys) {
        for (let mplpKey of mplpKeys) {
          for (let tlKey of tlKeys) {
            var tagKey = conn.conn_map.tag_unit + rmsKey + tlKey + mplpKey;
            tagKey = tagKey.toUpperCase();
            gapWell.connectionTagMap[tagKey] = {
              conn_map_id: conn.conn_map_id,
              unit: conn.conn_map.unit,
              rms: conn.conn_map.rms,
              tl: conn.conn_map.tl,
              mp_lp: conn.conn_map.mp_lp,
            };
          }
        }
      }
    }
  }

  return gapWell;
};

export const handleCaseFields = (caseData, caseConfig) => {
  const fieldValues = caseData?.field_config_values;

  //Групируем поля согласно параметру config_group
  const fields = Object.values(caseConfig?.fieldCfg).reduce((group, field) => {
    const dependants = [];
    if (!group[field?.config_group]) {
      group[field?.config_group] = {};
    }
    let values = fieldValues[field.id];
    let value = '';
    if (values?.value) {
      value = parseFloat(values?.value).toFixed(2);
    }

    group[field?.config_group][field.name] = {
      ...field,
      ...values,
      value,
      dependants,
      savedValue: value,
    };
    return group;
  }, {});

  //записываем зависимых полей которые меняются по формуле при изменений данного поля
  const setDependants = () => {
    Object.values(caseConfig?.fieldCfg).map((field) => {
      const fieldValue = function (group, item) {
        fields[group][item]?.dependants.push({
          group: field.config_group,
          name: field.name,
          source_tag: field?.source_tag,
        });
      };
      if (!field?.is_constraint && field?.source_type === 'calc') {
        try {
          eval(field?.source_tag);
        } catch (err) {
          console.log(err);
        }
      }
    });
  };

  setDependants();
  return fields;
};
