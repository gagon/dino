import { convertUnitDbRef } from './units';
import { FL_PRESSURE_CONFIG_ID, WH_PRESSURE_CONFIG_ID } from '../../_helpers/constants';

export const checkError = (data, unitCfg, Process, classByUnits, unitsByClass) => {
  const whPres = data?.whPressur;
  const flPres = data?.flPressur;
  const slotPres = data?.slotPressur;
  let pressureLookup = '';
  const selConn = data.gap_well.connectionMap[data.gap_conn_id];
  const validate = {};

  if (selConn) {
    unitCfg[selConn.unit].separators.map((sep) => {
      if ((!selConn.mp_lp && !sep.mp_lp) || selConn.mp_lp == sep.mp_lp) {
        pressureLookup = sep.pressure_lookup;
      }
    });
  }

  const fvRef = Process[pressureLookup];
  const fvPres = fvRef ? convertUnitDbRef(fvRef, whPres, false, classByUnits, unitsByClass) : null;

  if (whPres < flPres) {
    validate[WH_PRESSURE_CONFIG_ID] = 'Below FL Pressure';
  } else if (whPres < slotPres) {
    validate[WH_PRESSURE_CONFIG_ID] = 'Below Slot Pressure';
  } else if (fvPres && whPres < fvPres) {
    validate[WH_PRESSURE_CONFIG_ID] = 'Below ' + pressureLookup;
  }

  if (flPres < slotPres) {
    validate[FL_PRESSURE_CONFIG_ID] = 'Below Slot Pressure';
  } else if (fvPres && flPres < fvPres) {
    validate[FL_PRESSURE_CONFIG_ID] = 'Below ' + pressureLookup;
  }

  if (fvPres && slotPres < fvPres) {
    validate[WH_PRESSURE_CONFIG_ID] = 'Below ' + pressureLookup;
  }

  return validate;
};
