export const buildCalcDict = (classByUnits, unitsByClass, caseConfig, userConfig) => {
  const calcDict = {};
  const calcNameLookup = {};
  const labelDict = {};

  if (!Object.values(calcDict).length) {
    for (let calc of caseConfig.resultCalculation) {
      calcDict[calc.name] = {
        id: calc.id,
        calc: calc.calc,
        name: calc.name,
        results: {},
        uom: calc.uom,
        displayUom: null,
      };
      calcNameLookup[calc.id] = calc.name;
    }

    setupUnitConversions(
      caseConfig,
      calcDict,
      calcNameLookup,
      classByUnits,
      unitsByClass,
      userConfig,
      labelDict
    );
  }

  return { calcDict, calcNameLookup, labelDict };
};

const setupUnitConversions = function (
  setupData,
  calcDict,
  calcNameLookup,
  classByUnits,
  unitsByClasss,
  userConfig,
  labelDict
) {
  const isHourUnits = userConfig.isHourUnits;
  const searchPostFix = /(.+\/)(d)$/;
  const replacePostFix = '$1h';

  for (let label of Object.values(setupData.resultLabel)) {
    if (!(label.group in labelDict)) {
      labelDict[label.group] = {};
    }
    if (label.calc_id !== null) {
      var lblCalc = calcNameLookup[label.calc_id];
      // there should only be one label for a calculation per label group
      labelDict[label.group][lblCalc] = label;
      if (isHourUnits && calcDict[lblCalc].uom) {
        var newUom = calcDict[lblCalc].uom.replace(searchPostFix, replacePostFix);
        const isConvert = canConvert(calcDict[lblCalc].uom, newUom, classByUnits, unitsByClasss);
        if (newUom != calcDict[lblCalc].uom && isConvert) {
          calcDict[lblCalc].displayUom = newUom;
        } else {
          calcDict[lblCalc].displayUom = null;
        }
      }
    }
  }
};

const canConvert = function (uFrom, uTo, classByUnits, UnitsByClass) {
  if (uFrom in classByUnits) {
    var className = classByUnits[uFrom].class;
    var uClass = UnitsByClass[className];
    if (uTo in uClass.Units) return true;
  }
  return false;
};

export const evaluateCalculationString = function (
  calcstr,
  key,
  fbTotalArr,
  fields,
  units,
  calcDict
) {
  var totals = fbTotalArr[key];

  var fieldValue = function (group, item) {
    const value = fields[group][item].value;
    return parseFloat(fields[group][item].value);
  };

  var unitTotal = function (unit, product) {
    let retVal = 0;

    for (let [unitKey, unitValue] of Object.entries(units.chart)) {
      if (unitValue.sep.unit === unit) {
        retVal += totals[unitKey][product];
      }
    }
    return retVal;
  };

  var maxDC = function () {
    return Math.max.apply(null, arguments);
  };

  var minDC = function () {
    return Math.min.apply(null, arguments);
  };

  var ifDC = function (test, ifT, ifF) {
    return test ? ifT : ifF;
  };

  var calcCaseValue = function (caseIdx, calName) {
    // deal with the case idx being 0 rather than default in the calc
    if (!(caseIdx in calcDict[calName].results)) {
      caseIdx = 'default';
    }
    if (calcDict[calName].results[caseIdx].value === null) {
      try {
        calcDict[calName].results[caseIdx].value = eval(calcDict[calName].calc);
        return parseFloat(calcDict[calName].results[caseIdx].value);
      } catch (err) {
        calcDict[calName].results[caseIdx].error = 'Calculation error:' + err.message;
      }
      return NaN;
    }
    return calcDict[calName].results[caseIdx].value;
  };

  var calcValue = function (calName) {
    return calcCaseValue(key, calName);
  };

  return eval(calcstr);
};

export const evaluateCalcDict = function (keyItem, calcDict, fbTotalArr, fields, units) {
  const key = keyItem === undefined ? 'default' : keyItem;
  // reset all the values - need to do this to make sure everything is recalced.
  for (let calc of Object.values(calcDict)) {
    calc.results[key] = {
      value: null,
      error: null,
      uom: calc.uom,
      name: calc.name,
      source_tag: calc.calc,
    };
  }

  // evaluate calculations
  for (let calc of Object.values(calcDict)) {
    if (!calc.results[key].value) {
      try {
        calc.results[key].value = evaluateCalculationString(
          calc.calc,
          key,
          fbTotalArr,
          fields,
          units,
          calcDict
        );
      } catch (err) {
        calc.results[key].error = 'Calculation error:' + err.message;
        calc.error = 'Calculation error:' + err.message;
      }
    }
  }

  // evaluate calculations
  for (let calc of Object.values(calcDict)) {
    if (calc.results[key].value) {
      try {
        calc.results[key].value = parseFloat(calc.results[key].value.toFixed(2));
      } catch (e) {
        console.error(e.message);
      }
    }
  }
};

export const initFieldData = (fieldCfg, keyProps) => {
  let key = keyProps;
  const fieldDataArr = {};
  if (key === undefined) {
    key = 'default';
  }

  fieldDataArr[key] = {};
  var fieldData = fieldDataArr[key];

  for (let conf of Object.values(fieldCfg)) {
    if (!(conf.config_group in fieldData)) {
      fieldData[conf.config_group] = {};
      fieldData[conf.config_group].items = {};
    }

    fieldData[conf.config_group].items[conf.name] = {};
  }

  return fieldData;
};

export const getTotalFromOption = (keyItem, fbData) => {
  const key = keyItem === undefined ? 'default' : keyItem;
  const fbTotalArr = { [key]: fbData?.totals };
  return fbTotalArr;
};
