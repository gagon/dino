import nullOrFixed from '../../pages/utils/nullOrFixed';

export const unitConversionObj = (unitClasses, units) => {
  const unitsByClass = {};
  const classByUnits = {};
  for (let uClassIndex in unitClasses.Items) {
    const uClass = unitClasses.Items[uClassIndex];
    unitsByClass[uClass.Name] = { ...uClass };
    const retUnits = units[uClassIndex];

    unitsByClass[uClass.Name].Units = {};
    for (let unit of retUnits.Items) {
      unitsByClass[uClass.Name].Units[unit.Abbreviation] = unit;
      classByUnits[unit.Abbreviation] = {
        class: uClass.Name,
        clash: unit.Abbreviation in classByUnits,
      };
    }
  }
  return { unitsByClass, classByUnits };
};

export const unitConvert = (sumHead, value, fixed, classByUnits, unitsByClass) => {
  if (sumHead.dispUnit) {
    value = convertUnit(value, sumHead.unit, sumHead.dispUnit, classByUnits, unitsByClass);
  }
  return nullOrFixed(value, fixed);
};

const convertUnit = function (value, from, to, classByUnits, unitsByClass) {
  try {
    var className = classByUnits[from].class;

    var uClass = unitsByClass[className];

    var fromUnit = uClass.Units[from];

    var toUnit = uClass.Units[to];

    if (toUnit && fromUnit) {
      return (value * fromUnit.Factor + fromUnit.Offset - toUnit.Offset) / toUnit.Factor;
    } else {
      return value;
    }
  } catch (e) {
    return value;
  }
};

export const buildUnitSummary = (case_wells) => {
  const unitSummary = {
    KPC: { count: 0, shutin: 0, qoil: 0, qoiltd: 0, qgas: 0, qwat: 0, rms: {} },
    U2: { count: 0, shutin: 0, qoil: 0, qoiltd: 0, qgas: 0, qwat: 0, rms: {} },
    U3: { count: 0, shutin: 0, qoil: 0, qoiltd: 0, qgas: 0, qwat: 0, rms: {} },
  };
  for (let caseWell of case_wells) {
    if (caseWell.gap_conn_id) {
      // call case Well Results Display
      var currentConnId = caseWell.gap_conn_id;
      var unitName = caseWell.gap_well.connectionMap[currentConnId].unit;
      var rmsName = caseWell.gap_well.connectionMap[currentConnId].rms;

      // add up the values for each unit and rms
      if (
        unitSummary[unitName] &&
        unitSummary[unitName]['rms'] &&
        unitSummary[unitName]['rms'][rmsName] == null
      ) {
        unitSummary[unitName]['rms'][rmsName] = {
          count: 0,
          shutin: 0,
          qoil: 0,
          qoiltd: 0,
          qgas: 0,
          qwat: 0,
        };
      }
      unitSummary[unitName]['count']++;
      unitSummary[unitName]['rms'][rmsName]['count']++;

      if (caseWell.res_shutin_reason && !caseWell.res_shutin_reason.startsWith('Swing well')) {
        unitSummary[unitName]['shutin']++;
        unitSummary[unitName]['rms'][rmsName]['shutin']++;
      }

      unitSummary[unitName]['qoil'] += caseWell.res_oil_rate;
      unitSummary[unitName]['qoiltd'] += caseWell.res_oil_rate * caseWell.gap_well.oil_sg;
      unitSummary[unitName]['qgas'] += caseWell.res_gas_rate;
      unitSummary[unitName]['qwat'] += caseWell.res_wat_rate;
      unitSummary[unitName]['rms'][rmsName]['qoil'] += caseWell.res_oil_rate;
      unitSummary[unitName]['rms'][rmsName]['qoiltd'] +=
        caseWell.res_oil_rate * caseWell.gap_well.oil_sg;
      unitSummary[unitName]['rms'][rmsName]['qgas'] += caseWell.res_gas_rate;
      unitSummary[unitName]['rms'][rmsName]['qwat'] += caseWell.res_wat_rate;
    }
  }

  return unitSummary;
};

export const convertUnitDbRef = function (fromDb, toDb, disp, classByUnits, unitsByClass) {
  if (fromDb && toDb) {
    var fromUnit = fromDb.uom;
    var toUnit = null;
    if (toDb.displayUom && disp) {
      toUnit = toDb.displayUom;
    } else {
      toUnit = toDb.uom;
    }
    return convertUnit(fromDb.currValue, fromUnit, toUnit, classByUnits, unitsByClass);
  }
  return '';
};
