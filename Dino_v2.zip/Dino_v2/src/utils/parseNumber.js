export default function parseNumber(value) {
  return typeof value === 'string' ? parseFloat(value) : value;
}
