import React from 'react';
import { SvgIcon } from '@mui/material';

function LeftArrowIcon(props) {
  return (
    <SvgIcon {...props} viewBox={'0 0 18 18'} fill={'none'}>
      <path
        d="M6.75 16.5H11.25C15 16.5 16.5 15 16.5 11.25V6.75C16.5 3 15 1.5 11.25 1.5H6.75C3 1.5 1.5 3 1.5 6.75V11.25C1.5 15 3 16.5 6.75 16.5Z"
        stroke="#5F6388"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M9.94469 11.6475L7.30469 9.00004L9.94469 6.35254"
        stroke="#5F6388"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
    </SvgIcon>
  );
}

export default LeftArrowIcon;
