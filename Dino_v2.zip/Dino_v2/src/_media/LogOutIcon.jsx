import React from 'react';
import { SvgIcon } from '@mui/material';

function LogOutIcon(props) {
  return (
    <SvgIcon {...props} viewBox={'0 0 18 18'}>
      <path
        fill={'none'}
        d="M13.08 10.965L15 9.045L13.08 7.125"
        stroke="#5250F9"
        strokeMiterlimit="10"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        fill={'none'}
        d="M7.32031 9.04504H14.9478"
        stroke="#5250F9"
        strokeMiterlimit="10"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        fill={'none'}
        d="M8.82031 15C5.50531 15 2.82031 12.75 2.82031 9C2.82031 5.25 5.50531 3 8.82031 3"
        stroke="#5250F9"
        strokeMiterlimit="10"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </SvgIcon>
  );
}

export default LogOutIcon;
