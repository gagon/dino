import React from 'react';
import { SvgIcon } from '@mui/material';

function FieldArrowIcon({stroke = 'white', ...props}) {
  return (
    <SvgIcon {...props} viewBox={'0 0 9 9'} fill={'none'}>
      <path
        d="M3.375 8.25H5.625C7.5 8.25 8.25 7.5 8.25 5.625V3.375C8.25 1.5 7.5 0.75 5.625 0.75H3.375C1.5 0.75 0.75 1.5 0.75 3.375V5.625C0.75 7.5 1.5 8.25 3.375 8.25Z"
        stroke={stroke}
        strokeWidth="0.7"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M4.97234 5.82377L3.65234 4.50002L4.97234 3.17627"
        stroke={stroke}
        strokeWidth="0.7"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
    </SvgIcon>
  );
}

export default FieldArrowIcon;
