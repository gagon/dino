import React from 'react';
import { SvgIcon } from '@mui/material';

function PagesIcon(props) {
  return (
    <SvgIcon {...props} viewBox={'0 0 18 18'}>
      <path
        d="M12.75 10.05V12.3C12.75 15.3 11.55 16.5 8.55 16.5H5.7C2.7 16.5 1.5 15.3 1.5 12.3V9.45C1.5 6.45 2.7 5.25 5.7 5.25H7.95"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M12.75 10.05H10.35C8.55001 10.05 7.95001 9.45 7.95001 7.65V5.25L12.75 10.05Z"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M8.70001 1.5H11.7"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M5.25 3.75C5.25 2.505 6.255 1.5 7.5 1.5H9.465"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M16.5 6V10.6425C16.5 11.805 15.555 12.75 14.3925 12.75"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M16.5 6H14.25C12.5625 6 12 5.4375 12 3.75V1.5L16.5 6Z"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
    </SvgIcon>
  );
}

export default PagesIcon;
