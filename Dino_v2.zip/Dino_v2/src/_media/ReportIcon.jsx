import React from 'react';
import { SvgIcon } from '@mui/material';

function ReportIcon(props) {
  return (
    <SvgIcon {...props} viewBox={'0 0 25 25'} fill={'none'}>
      <path
        d="M10.2246 6.41602H14.2246C16.2246 6.41602 16.2246 5.41602 16.2246 4.41602C16.2246 2.41602 15.2246 2.41602 14.2246 2.41602H10.2246C9.22461 2.41602 8.22461 2.41602 8.22461 4.41602C8.22461 6.41602 9.22461 6.41602 10.2246 6.41602Z"
        stroke="#5F6388"
        strokeWidth="2"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M14.2246 22.416H9.22461C4.22461 22.416 3.22461 20.416 3.22461 16.416V10.416C3.22461 5.85604 4.89461 4.61604 8.22461 4.43604"
        stroke="#5F6388"
        strokeWidth="2"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M16.2246 4.43604C19.5546 4.61604 21.2246 5.84604 21.2246 10.416V15.416"
        stroke="#5F6388"
        strokeWidth="2"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M21.2246 19.416V22.416H18.2246"
        stroke="#5F6388"
        strokeWidth="2"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M15.2246 16.416L21.1846 22.376"
        stroke="#5F6388"
        strokeWidth="2"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
    </SvgIcon>
  );
}

export default ReportIcon;
