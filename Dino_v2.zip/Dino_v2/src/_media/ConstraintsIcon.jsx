import React from 'react';
import { SvgIcon } from '@mui/material';

function ConstraintsIcon({ color }) {
  const stroke = color || "#5F6388";
  return (
    <SvgIcon fill={'none'}>
      <svg
        viewBox="3 3 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M7.21484 15.543H11.2148"
          stroke={stroke}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M9.71606 18.543L12.7161 15.543L9.71606 12.543"
          stroke={stroke}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M15.2246 7.46289L15.2246 11.4629"
          stroke={stroke}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M12.2246 9.96338L15.2246 12.9634L18.2246 9.96338"
          stroke={stroke}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M15.2246 23.375L15.2246 19.375"
          stroke={stroke}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M12.2246 20.8757L15.2246 17.8757L18.2246 20.8757"
          stroke={stroke}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M23.3066 15.416H19.3066"
          stroke={stroke}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M20.8069 18.416L17.8069 15.416L20.8069 12.416"
          stroke={stroke}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <rect
          x="6.22461"
          y="6.41602"
          width="18"
          height="18"
          rx="4"
          stroke={stroke}
          strokeWidth="2"
        />
      </svg>
    </SvgIcon>
  );
}

export default ConstraintsIcon;
