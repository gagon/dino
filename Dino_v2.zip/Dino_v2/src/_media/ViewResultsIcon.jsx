import React from 'react';
import { SvgIcon } from '@mui/material';

function ViewResultsIcon(props) {
  return (
    <SvgIcon {...props} viewBox={'0 0 25 25'} fill={'none'}>
      <path
        d="M21.2246 7.41602V17.416C21.2246 20.416 19.7246 22.416 16.2246 22.416H8.22461C4.72461 22.416 3.22461 20.416 3.22461 17.416V7.41602C3.22461 4.41602 4.72461 2.41602 8.22461 2.41602H16.2246C19.7246 2.41602 21.2246 4.41602 21.2246 7.41602Z"
        strokeWidth="2"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M15.7246 2.41602V10.276C15.7246 10.716 15.2046 10.936 14.8846 10.646L12.5646 8.50604C12.3746 8.32604 12.0746 8.32604 11.8846 8.50604L9.56464 10.646C9.24464 10.936 8.72461 10.716 8.72461 10.276V2.41602H15.7246Z"
        strokeWidth="1.5"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M13.4746 14.416H17.7246"
        strokeWidth="1.5"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M9.22461 18.416H17.7246"
        strokeWidth="1.5"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
    </SvgIcon>
  );
}

export default ViewResultsIcon;
