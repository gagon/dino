import React from 'react';
import { SvgIcon } from '@mui/material';

function DoubleArrowIcon(props) {
  return (
    <SvgIcon {...props} viewBox={'0 0 18 18'}>
      <path
        d="M11.96 6.83751L14.75 4.04749L11.96 1.25751"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M1.25 4.04749H14.75"
        strokeWidth="1.5"
        strokeLinejoin="round"
        strokeLinecap="round"
        fill={'none'}
      />
      <path
        d="M4.03998 9.16248L1.25 11.9525L4.03998 14.7425"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M14.75 11.9525H1.25"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
    </SvgIcon>
  );
}

export default DoubleArrowIcon;
