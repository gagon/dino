import React from 'react';
import { SvgIcon } from '@mui/material';

function DownloadIcon(props) {
  return (
    <SvgIcon {...props} viewBox={'0 0 18 18'}>
      <path
        d="M12.3304 6.67505C15.0304 6.90755 16.1329 8.29505 16.1329 11.3325V11.43C16.1329 14.7825 14.7904 16.125 11.4379 16.125H6.55535C3.20285 16.125 1.86035 14.7825 1.86035 11.43V11.3325C1.86035 8.31755 2.94785 6.93005 5.60285 6.68255"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M9 1.5V11.16"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
      <path
        d="M11.5125 9.48749L9 12L6.4875 9.48749"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill={'none'}
      />
    </SvgIcon>
  );
}

export default DownloadIcon;
