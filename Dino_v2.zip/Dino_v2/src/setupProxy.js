const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
  app.use(
    createProxyMiddleware('/socket.io/', {
      target: 'ws://tstapp13:2000',
      ws: true,
    })
  );
};
