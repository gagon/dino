import React from 'react';
import {CssBox} from './Page403Style';
import Button from '@mui/material/Button';
import {Link} from 'react-router-dom';
import paths from '../../_helpers/paths';
import './Page404Translate';
import {useTranslation} from 'react-i18next';
import HeadTitle from '../../common/HeadTitle';

export default function Page403() {
	const {t} = useTranslation();
	return (
		<CssBox>
			<HeadTitle title={t('page403_oops')}/>
			<div className="container">
				<div className="error">403</div>
				<div className="oops">{t('page403_oops')}</div>
				<div className="not-found">{t('page403_access')}</div>
				<Button
					component={Link}
					to={paths.trips}
					variant="contained"
					color="secondary"
					children={t('page404_toHome')}
				/>
			</div>
		</CssBox>
	);
}
