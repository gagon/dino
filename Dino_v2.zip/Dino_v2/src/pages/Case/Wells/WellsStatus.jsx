import React, { useMemo } from 'react';
import { useSelector } from 'react-redux';

import { caseModule } from '../CaseDucks/CaseDucks';

const WellsStatus = ({ tab }) => {
  const inputData = useSelector((state) => Object.values(state[caseModule].caseWells?.inputData));

  const tabWells = useMemo(() => {
    return inputData.filter((caseWell) => {
      const currentConnId = caseWell.gap_conn_id;
      const unitName = caseWell.gap_well.connectionMap[currentConnId].unit;
      return unitName === tab;
    });
  }, [inputData, tab]);

  const closedCount = useMemo(() => {
    return tabWells.filter((well) => well.mask_well).length;
  }, [tabWells]);

  const openedCount = useMemo(() => {
    return tabWells.filter((well) => !well.mask_well).length;
  }, [tabWells]);

  return (
    <div>
      <span className="bold text-secondary ml1 mr1">Shut in / Open count</span>-
      <span className="ml1 bold">
        {closedCount} / {openedCount}
      </span>
    </div>
  );
};

export default WellsStatus;
