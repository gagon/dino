import React, { useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Typography from '@mui/material/Typography';
import { useTheme } from '@mui/styles';

import ColumnsFilter from '../../../common/Table/ColumnsFilter';
import useColumnsFilter from '../../../common/Table/useColumnsFilter';
import WellTable from './WellTable';
import { caseModule, changeCaseWells } from '../CaseDucks/CaseDucks';
import { kpcColumns } from './columns/kpcColumns';

export default function Wells({ tab }) {
  const case_wells = useSelector((state) => state[caseModule].caseWells.tableData);
  const { columnFilter, changeFilter } = useColumnsFilter();
  const { palette } = useTheme();
  const dispatch = useDispatch();

  const list = useMemo(() => {
    if (!case_wells) {
      return [];
    }
    return case_wells.filter((well) => {
      const connectionId = well.gap_conn_id;
      const unitName = well.gap_well.connectionMap[connectionId].unit;
      return unitName === tab;
    });
  }, [case_wells]);

  const onChangeCell = (well, saveObj, isSelect) => {
    dispatch(changeCaseWells(well, saveObj, isSelect));
  };

  const columns = kpcColumns(onChangeCell, dispatch, tab).filter(
    ({ field }) => !columnFilter.includes(field)
  );

  return (
    <>
      <div className="flex items-center mt1">
        <Typography
          variant={'h5'}
          children={'Wells'}
          sx={{
            color: palette.action.active,
          }}
        />
        <ColumnsFilter
          columns={kpcColumns()}
          changeFilter={changeFilter}
          columnFilter={columnFilter}
        />
      </div>

      <WellTable columns={columns} list={list} tab={tab} stickyHeader sortable />
    </>
  );
}
