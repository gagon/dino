import React, { useState, useMemo } from 'react';
import { useSelector } from 'react-redux';
import { Select, MenuItem, Divider } from '@mui/material';
import moment from 'moment';

import PopoverWindow from '../../../../common/Popover/Popover';
import DateTimePicker, { DATE_FORMAT } from '../../../../common/_MuiHookForm/DesktopDatePicker';
import Chart from '../../Fields/FieldComponents/Chart';
import { caseModule } from '../../CaseDucks/CaseDucks';

import { InputPopoverStyle, selectStyle } from '../../Fields/styles';

const WellInfoRow = ({ label, value, withTitle }) => (
  <div className="row nowrap">
    <div className="label">{label}:</div>
    <div className="info" title={withTitle ? value : undefined}>
      {value}
    </div>
  </div>
);

const WellTableCellPopover = ({
  data,
  anchorEl,
  setAnchorEl,
  isStringDataType,
  onChartClick,
  value,
}) => {
  const [selectedStartTime, setSelectedStartTime] = useState(null);
  const [selectedEndTime, setSelectedEndTime] = useState(null);
  const [selectedUnits, setSelectedUnits] = useState(null);

  const classByUnits = useSelector((state) => state[caseModule].classByUnits);
  const unitsByClass = useSelector((state) => state[caseModule].unitsByClass);
  const wellColumns = useSelector((state) => state[caseModule].caseConfig.wellColumns);
  const wellCfg = useSelector((state) => state[caseModule].caseConfig.wellCfg);
  const timestamp = useSelector((state) => state[caseModule].caseForm?.timestamp);

  const isOpen = Boolean(anchorEl);
  const wellId = data?.well_id;
  const configId = data?.config_id;
  const sourceType = data?.data_source;
  const sourceTag = wellCfg[wellId].configs[configId].source_tag;
  const baseUnits = wellColumns[configId].uom;
  const title = wellColumns[configId].name;
  const isTimePicker = wellColumns[configId].time_picker;
  const chartDays = wellColumns[configId].chart_days || 1;
  const unitsData = unitsByClass?.[classByUnits?.[baseUnits]?.class];

  const times = useMemo(() => {
    if (timestamp && isTimePicker) {
      const defaultStartTime = moment(timestamp, DATE_FORMAT).subtract(chartDays, 'day');
      const defaultEndTime = moment(timestamp, DATE_FORMAT);
      return { defaultStartTime, defaultEndTime };
    }
    return { defaultStartTime: null, defaultEndTime: null };
  }, [timestamp, isTimePicker, chartDays]);

  const unitsOtions = useMemo(() => {
    if (unitsData?.Units) {
      return Object.keys(unitsData.Units);
    }
    return [];
  }, [unitsData]);

  return (
    <PopoverWindow open={isOpen} anchorEl={anchorEl} onClose={() => setAnchorEl(null)}>
      <InputPopoverStyle>
        <div className="title py1 px2">Well - {title}</div>
        <Divider />
        <div className="p2">
          {sourceTag && <WellInfoRow label="Source" value={sourceTag} withTitle />}
          {baseUnits && <WellInfoRow label="Base Unit" value={baseUnits} />}

          {baseUnits && (
            <div className="row nowrap">
              <div className="label">Display Unit:</div>
              <Select
                sx={selectStyle}
                value={selectedUnits || baseUnits}
                onChange={(e) => setSelectedUnits(e.target.value)}
              >
                {unitsOtions.map((unit) => {
                  const { Abbreviation, Name } = unitsData?.Units?.[unit];
                  return (
                    <MenuItem
                      key={Abbreviation}
                      value={Abbreviation}
                      sx={{ height: 20, px: 1, py: 1.5, fontSize: 14 }}
                    >
                      {`${Abbreviation} - ${Name}`}
                    </MenuItem>
                  );
                })}
              </Select>
            </div>
          )}

          {sourceType && <WellInfoRow label="Value Source" value={sourceType} />}
          {value && <WellInfoRow label="Current Value" value={value} />}
          {timestamp && <WellInfoRow label="Timestamp" value={timestamp || ''} />}

          {timestamp && (
            <>
              <div className="row date_picker">
                <div className="label">Start:</div>
                <DateTimePicker
                  value={selectedStartTime || times.defaultStartTime}
                  onChange={setSelectedStartTime}
                  fontSize={'13px'}
                  fontWeight={800}
                />

                <div className="end">End:</div>
                <DateTimePicker
                  value={selectedEndTime || times.defaultEndTime}
                  onChange={setSelectedEndTime}
                  fontSize={'13px'}
                  fontWeight={800}
                />
              </div>

              <Chart
                selectedStartTime={selectedStartTime || times.defaultStartTime}
                selectedEndTime={selectedEndTime || times.defaultEndTime}
                title={title}
                desiredUnits={selectedUnits || baseUnits}
                isTimePicker={isTimePicker}
                sourceTag={sourceTag}
                sourceType={sourceType}
                isStringDataType={isStringDataType}
                onChartClick={onChartClick}
              />
            </>
          )}
        </div>
      </InputPopoverStyle>
    </PopoverWindow>
  );
};

export default WellTableCellPopover;
