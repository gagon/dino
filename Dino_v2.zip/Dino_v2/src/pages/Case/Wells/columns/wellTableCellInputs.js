import React, { useState, useRef } from 'react';
import { useSelector } from 'react-redux';
import { Checkbox } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import ShuffleIcon from '@mui/icons-material/Shuffle';

import {
  FL_PRESSURE_CONFIG_ID,
  SLOT_PRESSURE_CONFIG_ID,
  SLOT_TEMPERATURE_CONFIG_ID,
  WH_PRESSURE_CONFIG_ID,
} from '../../../../_helpers/constants';
import LeftArrowIcon from '../../../../_media/LeftArrowIcon';
import Select from '../../../../common/Select/Select';
import CommentsSidebar from '../../../../common/CommentsSidebar/CommentsSidebar';
import WellConnectionsModal from '../../../../common/WellConnectionsModal/WellConnectionsModal';
import WellCoefficientsCharts from '../../../Config/Wells/WellCoefficients/WellCoefficientsCharts';
import WellTableCellPopover from './WellTableCellPopover';
import { caseModule } from '../../CaseDucks/CaseDucks';

import { createInputStyle, cellWrapperClassNames } from './styles';

function handleValue(value) {
  if (!value && value !== 0) {
    return '';
  } else {
    return value;
  }
}

export const WellTableCell_GapConId = ({ row, onChangeCell }) => {
  const connMap = Object.values(row?.gap_well.connectionMap);
  const value = row?.gap_conn_id;
  const originalValueRef = useRef(value);
  const options = connMap.map((item) => ({ ...item, value: item?.conn_map_id }));
  const changedValue = useSelector(
    (state) => (state[caseModule].changesData.CaseWell[row.id] || {})?.gap_conn_id
  );

  let background =
    changedValue && changedValue !== originalValueRef.current ? '#EDB901' : 'transparent';

  return (
    <div className={`${cellWrapperClassNames} fullWidth`}>
      <Select
        selectStyle={{ height: 24, padding: 5, borderRadius: 3 }}
        style={{ background, borderRadius: 3 }}
        placeholder={'not chosen'}
        value={value}
        withoutForm
        withoutEmptyOption
        height={24}
        onChange={({ target: { value } }) =>
          onChangeCell({ id: row.id, key: 'gap_conn_id', value }, { column: 'gap_conn_id' }, true)
        }
        options={options}
      />
    </div>
  );
};

export const WellTableCell_WellGapName = ({ row }) => {
  const [isOpen, setIsOpen] = useState(false);
  const gapName = row.gapName;
  const gapId = row.gap_id;
  const wellId = row.well_id;
  const handleClose = () => setIsOpen(false);

  return (
    <div className={cellWrapperClassNames}>
      {isOpen && (
        <WellConnectionsModal
          isOpen={isOpen}
          onClose={handleClose}
          wellId={wellId}
          gapId={gapId}
          isEditMode={false}
        />
      )}

      <div style={{ width: 60 }}>{gapName}</div>
      <CommentsSidebar well={row} />
      <IconButton
        size="small"
        onClick={() => setIsOpen(true)}
        children={<ShuffleIcon fontSize="10" />}
        sx={{ padding: '1px' }}
      />
    </div>
  );
};

export const WellTableCell_TargetPressure = ({ row, onChangeCell }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const isOpen = Boolean(anchorEl);
  const changedValue = useSelector(
    (state) => !!(state[caseModule].changesData.CaseWell[row.id] || {})?.target_pressure
  );
  const value = useSelector(
    (state) => (state[caseModule].caseWells.inputData[row.id] || {})?.target_pressure
  );
  let background = changedValue ? '#EDB901' : 'transparent';

  const handleOpen = (e) => setAnchorEl(e.currentTarget);
  const handleClose = () => setAnchorEl(null);
  const handleOnChange = (e) => {
    const value = e.target.value;
    onChangeCell(
      { id: row.id, key: 'target_pressure', value },
      { CaseWell: { [row.id]: { target_pressure: value } } }
    );
  };

  return (
    <>
      {isOpen && (
        <WellCoefficientsCharts
          well={row.gap_well}
          wellName={row.gapName}
          currentTargetPressure={parseFloat(value)}
          anchorEl={anchorEl}
          onClose={handleClose}
          isOpen={isOpen}
        />
      )}

      <div className={cellWrapperClassNames}>
        <input
          type="number"
          style={createInputStyle(null, background)}
          value={handleValue(value)}
          onChange={handleOnChange}
        />
        <IconButton
          onClick={handleOpen}
          style={{ paddingRight: 0 }}
          children={<LeftArrowIcon style={{ fontSize: 20 }} />}
        />
      </div>
    </>
  );
};

export const WellTableCell_WHPressure = ({ row, onChangeCell }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const isError = WH_PRESSURE_CONFIG_ID in row?.validate;
  const changedValue = useSelector(
    (state) =>
      !!state[caseModule].changesData.CaseWellConfigItem[`${row.id}-${row?.whPressur?.config_id}`]
  );
  let background = changedValue ? '#EDB901' : 'transparent';
  const value = useSelector(
    (state) => (state[caseModule].caseWells.inputData[row.id] || {})?.whPressur?.value
  );
  const handleOpenPopover = (e) => setAnchorEl(e.currentTarget);
  const handleOnChange = (value) => {
    const config = row?.whPressur;
    const saveObjValue = { value, data_source: config?.data_source };
    const saveObj = {
      CaseWellConfigItem: { [`${row.id}-${config.config_id}`]: saveObjValue },
    };
    onChangeCell({ id: row.id, key: 'whPressur', value: { ...config, value } }, saveObj);
  };

  return (
    <div className={cellWrapperClassNames}>
      {anchorEl && (
        <WellTableCellPopover
          value={value}
          data={row?.whPressur}
          anchorEl={anchorEl}
          setAnchorEl={setAnchorEl}
          onChartClick={handleOnChange}
        />
      )}

      <input
        type="number"
        style={createInputStyle(isError, background)}
        value={handleValue(value)}
        onChange={(e) => handleOnChange(e.target.value)}
      />
      <IconButton
        children={<LeftArrowIcon style={{ fontSize: 20 }} />}
        style={{ paddingRight: 0 }}
        onClick={handleOpenPopover}
      />
    </div>
  );
};

export const WellTableCell_FLPressure = ({ row, onChangeCell }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const isError = FL_PRESSURE_CONFIG_ID in row?.validate;
  const changedValue = useSelector(
    (state) =>
      !!state[caseModule].changesData.CaseWellConfigItem[`${row.id}-${row?.flPressur?.config_id}`]
  );
  let background = changedValue ? '#EDB901' : 'transparent';
  const value = useSelector(
    (state) => (state[caseModule].caseWells.inputData[row.id] || {})?.flPressur?.value
  );
  const handleOpenPopover = (e) => setAnchorEl(e.currentTarget);
  const handleOnChange = (value) => {
    const config = row?.flPressur;
    const saveObjValue = { value, data_source: config?.data_source };
    const saveObj = {
      CaseWellConfigItem: { [`${row.id}-${config.config_id}`]: saveObjValue },
    };
    onChangeCell({ id: row.id, key: 'flPressur', value: { ...config, value } }, saveObj);
  };

  return (
    <div className={cellWrapperClassNames}>
      {anchorEl && (
        <WellTableCellPopover
          value={value}
          data={row?.flPressur}
          anchorEl={anchorEl}
          setAnchorEl={setAnchorEl}
          onChartClick={handleOnChange}
        />
      )}

      <input
        type="number"
        style={createInputStyle(isError, background)}
        value={handleValue(value)}
        onChange={(e) => handleOnChange(e.target.value)}
      />
      <IconButton
        children={<LeftArrowIcon style={{ fontSize: 20 }} />}
        style={{ paddingRight: 0 }}
        onClick={handleOpenPopover}
      />
    </div>
  );
};

export const WellTableCell_SlotPressure = ({ row, onChangeCell }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const isError = SLOT_PRESSURE_CONFIG_ID in row?.validate;
  const changedValue = useSelector(
    (state) =>
      !!state[caseModule].changesData.CaseWellConfigItem[`${row.id}-${row?.slotPressur?.config_id}`]
  );
  let background = changedValue ? '#EDB901' : 'transparent';
  const value = useSelector(
    (state) => (state[caseModule].caseWells.inputData[row.id] || {})?.slotPressur?.value
  );
  const handleOpenPopover = (e) => setAnchorEl(e.currentTarget);
  const handleOnChange = (value) => {
    const config = row?.slotPressur;
    const saveObjValue = { value, data_source: config?.data_source };
    const saveObj = {
      CaseWellConfigItem: { [`${row.id}-${config.config_id}`]: saveObjValue },
    };
    onChangeCell({ id: row.id, key: 'slotPressur', value: { ...config, value } }, saveObj);
  };

  return (
    <div className={cellWrapperClassNames}>
      {anchorEl && (
        <WellTableCellPopover
          value={value}
          data={row?.slotPressur}
          anchorEl={anchorEl}
          setAnchorEl={setAnchorEl}
          onChartClick={handleOnChange}
        />
      )}

      <input
        type="number"
        style={createInputStyle(isError, background)}
        value={handleValue(value)}
        onChange={(e) => handleOnChange(e.target.value)}
      />
      <IconButton
        children={<LeftArrowIcon style={{ fontSize: 20 }} />}
        style={{ paddingRight: 0 }}
        onClick={handleOpenPopover}
      />
    </div>
  );
};

export const WellTableCell_SlotTemperature = ({ row, onChangeCell }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const isError = SLOT_TEMPERATURE_CONFIG_ID in row?.validate;
  const changedValue = useSelector(
    (state) =>
      !!state[caseModule].changesData.CaseWellConfigItem[
        `${row.id}-${row?.slotTemperature?.config_id}`
      ]
  );
  let background = changedValue ? '#EDB901' : 'transparent';
  const value = useSelector(
    (state) => (state[caseModule].caseWells.inputData[row.id] || {})?.slotTemperature?.value
  );
  const handleOpenPopover = (e) => setAnchorEl(e.currentTarget);
  const handleOnChange = (value) => {
    const config = row?.slotTemperature;
    const saveObjValue = { value, data_source: config?.data_source };
    const saveObj = {
      CaseWellConfigItem: { [`${row.id}-${config.config_id}`]: saveObjValue },
    };
    onChangeCell({ id: row.id, key: 'slotTemperature', value: { ...config, value } }, saveObj);
  };

  return (
    <div className={cellWrapperClassNames}>
      {anchorEl && (
        <WellTableCellPopover
          value={value}
          data={row?.slotTemperature}
          anchorEl={anchorEl}
          setAnchorEl={setAnchorEl}
          onChartClick={handleOnChange}
        />
      )}

      <input
        type="number"
        style={createInputStyle(isError, background)}
        value={handleValue(value)}
        onChange={(e) => handleOnChange(e.target.value)}
      />
      <IconButton
        children={<LeftArrowIcon style={{ fontSize: 20 }} />}
        style={{ paddingRight: 0 }}
        onClick={handleOpenPopover}
      />
    </div>
  );
};

export const WellTableCell_ChokePosition = ({ row, onChangeCell }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const changedValue = useSelector(
    (state) =>
      !!state[caseModule].changesData.CaseWellConfigItem[
        `${row.id}-${row?.chokePosition?.config_id}`
      ]
  );
  let background = changedValue ? '#EDB901' : 'transparent';
  const value = useSelector(
    (state) => (state[caseModule].caseWells.inputData[row.id] || {})?.chokePosition?.value
  );
  const handleOpenPopover = (e) => setAnchorEl(e.currentTarget);
  const handleOnChange = (value) => {
    const config = row?.chokePosition;
    const saveObjValue = { value, data_source: config?.data_source };
    const saveObj = {
      CaseWellConfigItem: { [`${row.id}-${config.config_id}`]: saveObjValue },
    };
    onChangeCell({ id: row.id, key: 'chokePosition', value: { ...config, value } }, saveObj);
  };

  return (
    <div className={cellWrapperClassNames}>
      {anchorEl && (
        <WellTableCellPopover
          value={value}
          data={row?.chokePosition}
          anchorEl={anchorEl}
          setAnchorEl={setAnchorEl}
          onChartClick={handleOnChange}
        />
      )}

      <input
        type="number"
        style={createInputStyle(null, background)}
        value={handleValue(value)}
        onChange={(e) => handleOnChange(e.target.value)}
      />
      <IconButton
        style={{ paddingRight: 0 }}
        children={<LeftArrowIcon style={{ fontSize: 20 }} />}
        onClick={handleOpenPopover}
      />
    </div>
  );
};

export const WellTableCell_OnlineStatus = ({ row, onChangeCell }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const changedValue = useSelector(
    (state) =>
      !!state[caseModule].changesData.CaseWellConfigItem[
        `${row.id}-${row?.onlineStatus?.config_id}`
      ]
  );
  let background = changedValue ? '#EDB901' : 'transparent';
  const value = useSelector(
    (state) => (state[caseModule].caseWells.inputData[row.id] || {})?.onlineStatus?.value
  );
  const handleOpenPopover = (e) => setAnchorEl(e.currentTarget);

  const handleOnChange = (e) => {
    const value = e.target.value;
    const config = row?.onlineStatus;
    const saveObjValue = { value, data_source: config?.data_source };
    const saveObj = {
      CaseWellConfigItem: { [`${row.id}-${config.config_id}`]: saveObjValue },
    };
    onChangeCell({ id: row.id, key: 'onlineStatus', value: { ...config, value } }, saveObj);
  };

  return (
    <div className={cellWrapperClassNames}>
      {anchorEl && (
        <WellTableCellPopover
          value={value}
          data={row?.onlineStatus}
          anchorEl={anchorEl}
          setAnchorEl={setAnchorEl}
          isStringDataType
        />
      )}

      <input
        type="text"
        style={createInputStyle(null, background)}
        value={handleValue(value)}
        onChange={handleOnChange}
      />
      <IconButton
        children={<LeftArrowIcon style={{ fontSize: 20 }} />}
        style={{ paddingRight: 0 }}
        onClick={handleOpenPopover}
      />
    </div>
  );
};

export const WellTableCell_GatheringStatus = ({ row, onChangeCell }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const changedValue = useSelector(
    (state) =>
      !!state[caseModule].changesData.CaseWellConfigItem[
        `${row.id}-${row?.gatheringStatus?.config_id}`
      ]
  );
  let background = changedValue ? '#EDB901' : 'transparent';
  const value = useSelector(
    (state) => (state[caseModule].caseWells.inputData[row.id] || {})?.gatheringStatus?.value
  );
  const handleOpenPopover = (e) => setAnchorEl(e.currentTarget);

  const handleOnChange = (e) => {
    const value = e.target.value;
    const config = row?.gatheringStatus;
    const saveObjValue = { value, data_source: config?.data_source };
    const saveObj = {
      CaseWellConfigItem: { [`${row.id}-${config.config_id}`]: saveObjValue },
    };
    onChangeCell({ id: row.id, key: 'gatheringStatus', value: { ...config, value } }, saveObj);
  };

  return (
    <div className={cellWrapperClassNames}>
      {anchorEl && (
        <WellTableCellPopover
          value={value}
          data={row?.gatheringStatus}
          anchorEl={anchorEl}
          setAnchorEl={setAnchorEl}
          isStringDataType
        />
      )}

      <input
        style={createInputStyle(null, background)}
        type="text"
        value={handleValue(value)}
        onChange={handleOnChange}
      />
      <IconButton
        children={<LeftArrowIcon style={{ fontSize: 20 }} />}
        style={{ paddingRight: 0 }}
        onClick={handleOpenPopover}
      />
    </div>
  );
};

export const WellTableCell_WellConId = ({ row, onChangeCell }) => {
  const connMap = Object.values(row?.gap_well.connectionMap);
  const value = row?.well_conn_id;
  const originalValueRef = useRef(value);

  const options = connMap.map((item) => ({ ...item, value: item?.conn_map_id }));
  const changedValue = useSelector(
    (state) => (state[caseModule].changesData.CaseWell[row.id] || {})?.well_conn_id
  );
  let background =
    changedValue && changedValue !== originalValueRef.current ? '#EDB901' : 'transparent';

  return (
    <div className={`${cellWrapperClassNames} fullWidth`}>
      <Select
        selectStyle={{ height: 24, padding: 5, borderRadius: 3, width: '100%', background }}
        style={{ background, borderRadius: 3 }}
        placeholder={'not chosen'}
        value={value}
        withoutForm
        withoutEmptyOption
        height={24}
        options={options}
        onChange={({ target: { value } }) =>
          onChangeCell({ id: row.id, key: 'well_conn_id', value }, { column: 'well_conn_id' }, true)
        }
      />
    </div>
  );
};

export const WellTableCell_MaskWell = ({ row, onChangeCell }) => {
  const checked = useSelector((state) =>
    Boolean((state[caseModule].caseWells.inputData[row.id] || {})?.mask_well)
  );

  const handleOnChange = (e) => {
    const value = e.target.checked;
    onChangeCell(
      { id: row.id, key: 'mask_well', value },
      { CaseWell: { [row.id]: { mask_well: value } } }
    );
  };

  return (
    <div className={cellWrapperClassNames}>
      <Checkbox
        checked={checked}
        color={'success'}
        sx={{ '& .MuiSvgIcon-root': { fontSize: 22, borderRadius: 20 } }}
        onChange={handleOnChange}
      />
    </div>
  );
};

export const WellTableCell_GasOp = ({ row, onChangeCell }) => {
  const checked = useSelector((state) =>
    Boolean((state[caseModule].caseWells.inputData[row.id] || {})?.gas_opt)
  );

  const handleOnChange = (e) => {
    const value = e.target.checked;
    onChangeCell(
      { id: row.id, key: 'gas_opt', value },
      { CaseWell: { [row.id]: { gas_opt: value } } }
    );
  };

  return (
    <div className={cellWrapperClassNames}>
      <Checkbox
        checked={checked}
        color={'success'}
        sx={{ '& .MuiSvgIcon-root': { fontSize: 22, borderRadius: 20 } }}
        onChange={handleOnChange}
      />
    </div>
  );
};

export const WellTableCell_BellowMap = ({ row, onChangeCell }) => {
  const checked = useSelector((state) =>
    Boolean((state[caseModule].caseWells.inputData[row.id] || {})?.below_map)
  );

  const handleOnChange = (e) => {
    const value = e.target.checked;
    onChangeCell(
      { id: row.id, key: 'below_map', value },
      { CaseWell: { [row.id]: { below_map: value } } }
    );
  };

  return (
    <div className={cellWrapperClassNames}>
      <Checkbox
        checked={checked}
        color={'success'}
        sx={{ '& .MuiSvgIcon-root': { fontSize: 22, borderRadius: 20 } }}
        onChange={handleOnChange}
      />
    </div>
  );
};

export const WellTableCell_FixWellTarget = ({ row, onChangeCell }) => {
  const checked = useSelector((state) =>
    Boolean((state[caseModule].caseWells.inputData[row.id] || {})?.fixed)
  );

  const handleOnChange = (e) => {
    const value = e.target.checked;
    onChangeCell({ id: row.id, key: 'fixed', value }, { CaseWell: { [row.id]: { fixed: value } } });
  };

  return (
    <div className={cellWrapperClassNames}>
      <Checkbox
        checked={checked}
        color={'success'}
        sx={{ '& .MuiSvgIcon-root': { fontSize: 22, borderRadius: 20 } }}
        onChange={handleOnChange}
      />
    </div>
  );
};
