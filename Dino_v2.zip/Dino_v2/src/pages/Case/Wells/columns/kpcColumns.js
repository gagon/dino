import React from 'react';
import { Button } from '@mui/material';

import {
  WellTableCell_BellowMap,
  WellTableCell_ChokePosition,
  WellTableCell_FixWellTarget,
  WellTableCell_FLPressure,
  WellTableCell_GapConId,
  WellTableCell_GasOp,
  WellTableCell_GatheringStatus,
  WellTableCell_MaskWell,
  WellTableCell_OnlineStatus,
  WellTableCell_SlotPressure,
  WellTableCell_SlotTemperature,
  WellTableCell_TargetPressure,
  WellTableCell_WellConId,
  WellTableCell_WellGapName,
  WellTableCell_WHPressure,
} from './wellTableCellInputs';
import {
  wellAllSelect,
  wellCopyConnection,
  wellCopyGathering,
  wellCopyPressure,
  wellInvertSelect,
  wellResetToMap,
} from '../../CaseDucks/CaseDucks';

const HeaderRender = ({ isButton, buttonLabel, onClick }) => {
  const onClickItem = (e) => {
    e.preventDefault();
    e.stopPropagation();
    onClick();
  };
  return (
    <div style={{ lineHeight: 1, whiteSpace: 'normal', transform: 'translateY(-8px)' }}>
      {isButton && (
        <Button
          variant="outlined"
          size="small"
          onClick={onClickItem}
          style={{ fontWeight: 600, textTransform: 'none' }}
        >
          {buttonLabel}
        </Button>
      )}
      {!isButton && (
        <div className="color-primary link" onClick={onClickItem}>
          {buttonLabel}
        </div>
      )}
    </div>
  );
};

export const kpcColumns = (onChange, dispatch, tab) => {
  return [
    {
      field: 'gapName',
      headerName: 'Well Name',
      fixedColumn: true,
      minWidth: 120,
      valueGetter: ({ row: { gapName } }) => gapName,
      renderCell: ({ row }) => <WellTableCell_WellGapName row={row} />,
    },
    {
      field: 'GOR',
      headerName: 'GOR',
      minWidth: 60,
      align: 'center',
      type: 'number',
      valueGetter: ({ row: { gap_well } }) => gap_well.gor.toFixed(0),
    },
    {
      field: 'Watercut',
      headerName: 'WC',
      minWidth: 60,
      align: 'center',
      type: 'number',
      valueGetter: ({ row: { gap_well } }) => (gap_well.wct * 100).toFixed(0),
    },
    {
      field: 'Connected',
      headerName: 'Connected',
      minWidth: 80,
      align: 'center',
      valueGetter: ({ row }) => row?.gap_well?.connectionMap[row?.gap_conn_id]?.dual_unit,
    },
    {
      field: 'Comingled',
      headerName: 'Comingled',
      type: 'number',
      minWidth: 90,
      align: 'center',
      valueGetter: ({ row }) => {
        const connections = row.gap_well.connectionMap;
        return connections[row.well_conn_id]['comingled'];
      },
    },
    {
      field: 'ConfiguredFlow',
      headerName: 'Configured Flow',
      sortable: false,
      minWidth: 200,
      valueGetter: ({ row: { well_conn_id } }) => well_conn_id,
      renderCell: ({ row }) => <WellTableCell_WellConId row={row} onChangeCell={onChange} />,
    },
    {
      field: 'GapFlow',
      headerName: 'Gap Flow',
      sortable: false,
      minWidth: 200,
      cellClassName: 'super-app-theme--cell',
      valueGetter: ({ row: { gap_conn_id } }) => gap_conn_id,
      renderCell: ({ row }) => <WellTableCell_GapConId row={row} onChangeCell={onChange} />,
      renderHeader: (params) => (
        <HeaderRender
          title="Gap Flow"
          isButton
          buttonLabel="Copy Flow"
          onClick={() => dispatch(wellCopyConnection(tab))}
        />
      ),
    },
    {
      field: 'TargetPressure',
      headerName: 'Target Pressure',
      sortable: false,
      cellClassName: 'super-app-theme--cell',
      valueGetter: ({ row: { target_pressure } }) => target_pressure,
      renderCell: ({ row }) => <WellTableCell_TargetPressure row={row} onChangeCell={onChange} />,
      renderHeader: (params) => (
        <HeaderRender
          title="Target Pressure"
          isButton
          buttonLabel="Copy WH"
          onClick={() => dispatch(wellCopyPressure(tab))}
        />
      ),
    },
    {
      field: 'MAP',
      headerName: 'MAP',
      minWidth: 60,
      type: 'number',
      align: 'center',
      cellClassName: 'super-app-theme--cell',
      valueGetter: ({ row }) => row.gap_well.map,
    },
    {
      field: 'WHPressur',
      headerName: 'WH Pressure',
      sortable: false,
      valueGetter: ({ row: { whPressur } }) => whPressur?.value,
      renderCell: ({ row }) => <WellTableCell_WHPressure row={row} onChangeCell={onChange} />,
      renderHeader: (params) => (
        <HeaderRender
          title="WH Pressure"
          buttonLabel="Reset all to MAP"
          onClick={() => dispatch(wellResetToMap(tab))}
        />
      ),
    },
    {
      field: 'FLPressur',
      headerName: 'FL Pressure',
      sortable: false,
      valueGetter: ({ row: { flPressur } }) => flPressur?.value,
      renderCell: ({ row }) => <WellTableCell_FLPressure row={row} onChangeCell={onChange} />,
    },
    {
      field: 'SlotPressur',
      headerName: 'Slot Pressure',
      sortable: false,
      valueGetter: ({ row: { slotPressur } }) => slotPressur?.value,
      renderCell: ({ row }) => <WellTableCell_SlotPressure row={row} onChangeCell={onChange} />,
    },
    {
      field: 'SlotTemperature',
      headerName: 'Slot Temperature',
      sortable: false,
      valueGetter: ({ row: { slotTemperature } }) => slotTemperature?.value,
      renderCell: ({ row }) => <WellTableCell_SlotTemperature row={row} onChangeCell={onChange} />,
    },
    {
      field: 'ChokePosition',
      headerName: 'Choke Position',
      sortable: false,
      valueGetter: ({ row: { chokePosition } }) => chokePosition?.value,
      renderCell: ({ row }) => <WellTableCell_ChokePosition row={row} onChangeCell={onChange} />,
    },
    {
      field: 'OnlineStatus',
      headerName: 'Online Status',
      sortable: false,
      valueGetter: ({ row: { onlineStatus } }) => onlineStatus?.value,
      renderCell: ({ row }) => <WellTableCell_OnlineStatus row={row} onChangeCell={onChange} />,
    },
    {
      field: 'GatheringStatus',
      headerName: 'Gathering Status',
      sortable: false,
      valueGetter: ({ row: { gatheringStatus } }) => gatheringStatus?.value,
      renderCell: ({ row }) => <WellTableCell_GatheringStatus row={row} onChangeCell={onChange} />,
    },
    {
      field: 'MaskWel',
      headerName: 'Mask Well',
      sortable: false,
      minWidth: 90,
      cellClassName: 'super-app-theme--cell',
      valueGetter: ({ row: { mask_well } }) => Boolean(mask_well),
      renderCell: ({ row }) => <WellTableCell_MaskWell row={row} onChangeCell={onChange} />,
      renderHeader: (params) => (
        <HeaderRender
          isButton
          title="Mask Well"
          buttonLabel="Copy GTH"
          onClick={() => dispatch(wellCopyGathering(tab))}
        />
      ),
    },
    {
      field: 'GasOp',
      headerName: 'Gas Opt',
      sortable: false,
      minWidth: 75,
      valueGetter: ({ row: { gas_opt } }) => Boolean(gas_opt),
      renderCell: ({ row }) => <WellTableCell_GasOp row={row} onChangeCell={onChange} />,
      renderHeader: () => (
        <HeaderRender
          title="Gas Opt"
          buttonLabel="Select / Deselect All"
          onClick={() => dispatch(wellAllSelect(tab, 'gas_opt'))}
        />
      ),
    },
    {
      field: 'bellowMap',
      headerName: 'Let below MAP',
      sortable: false,
      valueGetter: ({ row: { below_map } }) => Boolean(below_map),
      renderCell: ({ row }) => <WellTableCell_BellowMap row={row} onChangeCell={onChange} />,
      renderHeader: (params) => (
        <HeaderRender
          title="Let below MAP"
          buttonLabel="Select / Deselect All"
          onClick={() => dispatch(wellAllSelect(tab, 'below_map'))}
        />
      ),
    },
    {
      field: 'fixWellTarget',
      headerName: 'Fix Target FWHP',
      sortable: false,
      valueGetter: ({ row: { fixed } }) => Boolean(fixed),
      renderCell: ({ row }) => <WellTableCell_FixWellTarget row={row} onChangeCell={onChange} />,
      renderHeader: (params) => (
        <HeaderRender
          title="Fix well Target FWHP"
          buttonLabel="Invert select"
          onClick={() => dispatch(wellInvertSelect(tab))}
        />
      ),
    },
  ];
};
