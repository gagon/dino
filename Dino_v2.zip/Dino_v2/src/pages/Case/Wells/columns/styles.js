export const createInputStyle = (isError, background) => ({
  height: 24,
  padding: 5,
  borderRadius: 3,
  width: 70,
  border: isError ? '1px solid red' : '1px solid lightgray',
  background,
});

export const cellWrapperClassNames = 'flex items-center';
