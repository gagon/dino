import styled from 'styled-components';

export const WellTableStyle = styled.div`
  padding: 30px;
  background: white;
  border-radius: 20px;
  margin-bottom: 30px;
  margin-top: 30px;
  text-align: right;

  .fixed_column {
    position: sticky;
    left: 0;
    z-index: 2;
    background: white;
    width: 120px;
  }

  .MuiTableRow-hover:hover .fixed_column {
    background: #f7f7f7;
  }

  .MuiTableRow-hover:hover .water {
    background: #74ccf4;
  }

  .MuiTableRow-hover:hover .disabled {
    background: #ff6461;
  }

  .fixed_head_1 {
    position: absolute;
    left: 0;
    top: 0;
    z-index: 3;
    width: 120px;
    display: flex;
    align-items: center;
  }
  .fixed_head_2 {
    position: absolute;
    left: 0;
    top: 50px;
    z-index: 3;
    width: 120px;
    height: 29px;
  }

  .fullscreen {
    .fixed_head_1 {
      position: fixed;
      top: 30px;
      left: 30px;
    }
    .fixed_head_2 {
      position: fixed;
      left: 30px;
      top: 80px;
    }
  }
`;

export const wtContainerStyle = {
  borderRadius: 18,
  height: 'calc(100vh - 380px)',
  minHeight: 600,
  overflow: 'auto',
};

export const wtBtnBoxStyle = {
  background: 'white',
  position: 'fixed',
  zIndex: 999,
  width: '100%',
  top: 0,
};

export const wtLeftBoxStyle = {
  background: 'white',
  position: 'fixed',
  zIndex: 999,
  height: '100vh',
  width: '30px',
  top: 0,
  left: 0,
};

export const boxSx = {
  borderRadius: '12px',
  width: 1,
  '& .super-app-theme--cell': {
    background: '#D4EEFF80',
  },
};

export const wtHeadCellSx = {
  lineHeight: 1,
  fontWeight: 600,
  fontSize: 12,
  padding: '0px 5px',
  cursor: 'pointer',
  background: '#E8E8F0',
  border: 'none',
  position: 'sticky',
  top: 50,
};

export const wtCellSx = (column) => ({
  width: column.width,
  minWidth: column.minWidth,
  lineHeight: 1,
  padding: '0px 5px',
});

export const getHeadCellStyle = (columns, index) => ({
  borderTopLeftRadius: index === 0 ? 12 : 0,
  borderTopRightRadius: columns.length - 1 === index ? 12 : 0,
  lineHeight: 1,
  border: 'none',
  fontWeight: 600,
  fontSize: 12,
  whiteSpace: 'nowrap',
  padding: '0px 5px',
  height: 50,
  cursor: 'pointer',
});
