import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import IconButton from '@mui/material/IconButton';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import FullscreenExitIcon from '@mui/icons-material/FullscreenExit';

import WellsStatus from './WellsStatus';
import {
  boxSx,
  wtHeadCellSx,
  getHeadCellStyle,
  wtBtnBoxStyle,
  wtCellSx,
  wtContainerStyle,
  WellTableStyle,
  wtLeftBoxStyle,
} from './WellTableStyle';

export default function WellTable({ columns, list, tab, stickyHeader, sortable: sortingTable }) {
  const [sortable, setSortable] = useState({});
  const [fullscreen, setFullscreen] = useState(false);
  const setColumnSorting = (column) => {
    if (sortable.column === column && sortable.sort === 'desc') {
      setSortable({ column, sort: 'asc' });
    } else if (sortable.column === column && sortable.sort === 'asc') {
      setSortable({});
    } else {
      setSortable({ column, sort: 'desc' });
    }
  };

  return (
    <WellTableStyle>
      <div className="flex items-center justify-between">
        <WellsStatus tab={tab} />
        <IconButton onClick={() => setFullscreen(!fullscreen)}>
          <FullscreenIcon />
        </IconButton>
      </div>

      <div className="relative">
        <div className={fullscreen ? 'fullscreen' : ''} style={wtContainerStyle}>
          {fullscreen && (
            <>
              <div className="flex items-center justify-between" style={wtBtnBoxStyle}>
                <WellsStatus tab={tab} />
                <IconButton style={{ marginRight: 40 }} onClick={() => setFullscreen(!fullscreen)}>
                  <FullscreenExitIcon />
                </IconButton>
              </div>

              <div style={wtLeftBoxStyle} />
            </>
          )}

          <Box sx={boxSx}>
            <TableContainer sx={{ overflowX: 'inherit' }}>
              <Table stickyHeader={stickyHeader}>
                <TableHead>
                  <TableRow>
                    {columns.map((column, index) => (
                      <TableCell
                        key={column.headerName}
                        align={column.align || 'left'}
                        onClick={() =>
                          sortingTable && column.valueGetter && setColumnSorting(column.headerName)
                        }
                        className={column.fixedColumn ? ' fixed_head_1' : ''}
                        sx={getHeadCellStyle(columns, index)}
                      >
                        {column.headerName}
                        {sortable.column === column.headerName &&
                          sortable.sort === 'desc' &&
                          column.valueGetter && (
                            <IconButton size="small">
                              <ArrowDownwardIcon fontSize="small" />
                            </IconButton>
                          )}
                        {sortable.column === column.headerName &&
                          sortable.sort === 'asc' &&
                          column.valueGetter && (
                            <IconButton size="small">
                              <ArrowUpwardIcon fontSize="small" />
                            </IconButton>
                          )}
                      </TableCell>
                    ))}
                  </TableRow>

                  <TableRow>
                    {columns.map((column) => (
                      <TableCell
                        key={column.headerName}
                        align={column.align || 'left'}
                        className={column.fixedColumn ? ' fixed_head_2' : ''}
                        sx={wtHeadCellSx}
                        children={column.renderHeader ? column.renderHeader() : ''}
                      />
                    ))}
                  </TableRow>
                </TableHead>

                <TableBody>
                  {list
                    .sort((a, b) => compare(a, b, sortable, columns))
                    .map((row) => {
                      return (
                        <TableRow hover role="checkbox" tabIndex={-1} key={`row` + row.id}>
                          {columns.map((column) => (
                            <TableCell
                              align={column.align || 'left'}
                              className={
                                column.cellClassName +
                                (column.fixedColumn ? ' fixed_column' : '') +
                                (row?.gap_well?.wct > 0 ? ' water' : '') +
                                (Boolean(row?.mask_well) ? ' disabled' : '')
                              }
                              key={column.headerName + `column`}
                              sx={wtCellSx(column)}
                              children={
                                column.renderCell
                                  ? column.renderCell({ row })
                                  : column.valueGetter({ row })
                              }
                            />
                          ))}
                        </TableRow>
                      );
                    })}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </div>
      </div>
    </WellTableStyle>
  );
}

function compare(rowA, rowB, sortableObj, columns) {
  const sortable =
    Object.keys(sortableObj).length > 0 ? sortableObj : { sort: 'desc', column: 'Well Name' };
  const column = columns.find((c) => c.headerName === sortable.column);
  if (column && sortable.sort && column.valueGetter) {
    let a = column.valueGetter({ row: rowA });
    let b = column.valueGetter({ row: rowB });

    if (column.type === 'number') {
      a = parseFloat(a) || 0;
      b = parseFloat(b) || 0;
    }
    if (a < b && sortable.sort === 'desc') {
      return -1;
    }
    if (a > b && sortable.sort === 'desc') {
      return 1;
    }
    if (a < b && sortable.sort === 'asc') {
      return 1;
    }
    if (a > b && sortable.sort === 'asc') {
      return -1;
    }
  }
  return 0;
}
