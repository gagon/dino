import React from 'react';
import moment from 'moment';
import { useSelector } from 'react-redux';
import { Checkbox } from '@mui/material';

import { caseModule, setCaseImplemented } from './CaseDucks/CaseDucks';

const CaseInfoItem = ({ title, value }) =>
  value && (
    <div className="flex items-center text-secondary">
      <div className="mr1">{title} :</div>
      <div className="bold mr2">{value}</div>
    </div>
  );

export default function CaseInfoBlock() {
  const implemented = useSelector((state) => state[caseModule].caseData?.implemented);
  const description = useSelector((state) => state[caseModule].caseData?.description);
  const timestamp = useSelector((state) => state[caseModule].caseForm?.timestamp);
  const caseName = useSelector((state) => state[caseModule].caseData?.name);
  const creator = useSelector((state) => state[caseModule].caseData?.creator?.name);
  const gapFileName = useSelector((state) => state[caseModule].caseData?.gap_file?.name);
  const loading = useSelector((state) => state[caseModule].loading);

  if (loading) return null;

  return (
    <div className="flex mb2">
      <CaseInfoItem title={'Gap file'} value={gapFileName} />
      <CaseInfoItem title={'Created by'} value={creator} />
      <CaseInfoItem
        title={'Implemented'}
        value={<Checkbox size="small" checked={implemented} sx={{ padding: 0, margin: 0 }} />}
      />
      <CaseInfoItem title={'Case name'} value={caseName} />
      <CaseInfoItem title={'Case date'} value={timestamp} />
      <CaseInfoItem title={'Case description'} value={description} />
    </div>
  );
}
