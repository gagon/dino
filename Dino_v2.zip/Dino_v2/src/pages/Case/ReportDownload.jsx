import React from 'react';
import { IconButton, useTheme } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import ReportIcon from '../../_media/ReportIcon';
import { caseMenuModule, changeActiveMenu } from './SideBar/CaseMenuDucks';
import { CONSTRAINS, OPTIMIZATION } from './SideBar/MenuItems';
import SideButton from './SideBar/SideButton';
import useStep from './useStep';
import { CaseApi } from '../../_helpers/service';
import { caseModule } from './CaseDucks/CaseDucks';

export default function ReportDownload() {
  const calcDict = useSelector((state) => state[caseModule].calculation?.calcDict);
  const caseId = useSelector((state) => state[caseModule].caseData?.id);
  const { noResult } = useStep();

  if (noResult) return null;

  return (
    <>
      <SideButton
        icon={
          <IconButton onClick={() => CaseApi.loadReport(caseId, calcDict).then(downloadFile)}>
            <ReportIcon />
          </IconButton>
        }
      />
      <p className="fs-10" style={{ marginTop: 0 }} children={'Report'} />
    </>
  );
}

function downloadFile(response) {
    const data = response.data;
    const fileName = response.headers.filename;
    // csv => Blob
    let blob = new Blob([data]);

    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      // for IE
      window.navigator.msSaveOrOpenBlob(blob, fileName);
    } else {
      // for others
      let url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    }
}
