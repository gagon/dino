import { LoadingButton } from '@mui/lab';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Typography,
  useTheme,
} from '@mui/material';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import SideMenuItemModal from '../../../common/SideMenuItemModal/SideMenuItemModal';
import ConstraintsIcon from '../../../_media/ConstraintsIcon';
import { copyToConstraints } from '../CaseDucks/CaseDucks';
import { caseMenuModule, changeActiveMenu } from '../SideBar/CaseMenuDucks';
import { CONSTRAINS, OPTIMIZATION } from '../SideBar/MenuItems';
import SideButton from '../SideBar/SideButton';
import useStep from '../useStep';

const paperSx = {
  borderTopRightRadius: 20,
  borderTopLeftRadius: 20,
  borderBottomLeftRadius: 20,
  borderBottomRightRadius: 20,
  padding: '0px 20px 20px 20px',
};

export default function CopyToConstraint() {
  const { palette } = useTheme();
  const { constraintDisabled: disabled, constraintNextDisabled } = useStep();
  const dispatch = useDispatch();
  const { activeMenu } = useSelector((state) => state[caseMenuModule]);
  const isActive = activeMenu === CONSTRAINS;
  const iconColor = isActive
    ? palette.common.white
    : disabled
    ? palette.action.disabled
    : palette.action.active;
  const nextBtnHandle = () => {
    dispatch(changeActiveMenu(OPTIMIZATION));
  };

  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton disabled={disabled} onClick={() => dispatch(changeActiveMenu(CONSTRAINS))}>
            <ConstraintsIcon color={iconColor} />
          </IconButton>
        }
      />
      <p
        className="fs-10"
        style={{ marginTop: 0, color: disabled ? palette.action.disabled : 'inherit' }}
        children={'Set constraints'}
      />
      {isActive && (
        <SideMenuItemModal isOpen={isActive} close={() => dispatch(changeActiveMenu(null))}>
          <div style={{ width: 250 }}>
            <Typography style={{ marginBottom: 10, fontWeight: 'bold' }}>
              Copy to constraints
            </Typography>
            Do you want to set constraints?
            <div className="flex justify-center" style={{ marginTop: 15 }}>
              <LoadingButton
                children={'Set constraints'}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23, marginRight: 2 }}
                onClick={() => dispatch(copyToConstraints())}
              />
              <LoadingButton
                children={'Next >'}
                variant={'contained'}
                disabled={constraintNextDisabled}
                color={'primary'}
                sx={{ borderRadius: 23 }}
                onClick={nextBtnHandle}
              />
            </div>
          </div>
        </SideMenuItemModal>
      )}
    </>
  );
}
