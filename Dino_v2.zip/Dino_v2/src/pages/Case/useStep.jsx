import { useSelector } from 'react-redux';

import { scheduledModule } from '../../common/ScheduledCases/ScheduledCasesDucks';
import { loginModule } from '../Login/LoginDucks';
import { caseModule } from './CaseDucks/CaseDucks';

export default function useStep() {
  const userId = useSelector((state) => state[loginModule].user?.user_id);
  const currentCaseId = useSelector((state) => state[caseModule].caseData?.id);
  const creatorId = useSelector((state) => state[caseModule].caseData?.creator?.id);
  const stepStatus = useSelector((state) => state[caseModule].stepStatus);
  const runDate = useSelector((state) => state[caseModule].caseData?.run_date);
  const scheduledData = useSelector((state) => state[scheduledModule].scheduledData);
  const running = scheduledData.some(
    (item) => !['completed', 'error'].includes(item.status) && item.case_id === currentCaseId
  );

  const noResult = !currentCaseId || !runDate || running;
  const hasAccess = userId === creatorId && !!currentCaseId;
  const disabled = !hasAccess || running;
  const fieldNextDisabled = (!stepStatus.fieldLoaded && noResult) || disabled;
  const wellDisabled = fieldNextDisabled;
  const wellNextDisabled = (!stepStatus.fieldLoaded || !stepStatus.wellLoaded) && noResult;
  const constraintDisabled = wellNextDisabled || disabled;
  const constraintNextDisabled = constraintDisabled || (!stepStatus.constraint && noResult);
  const afDisabled = noResult || disabled;
  const optimizationDisabled =
    (!stepStatus.constraint && noResult) || wellNextDisabled || !hasAccess;

  const kpcStatus =
    !stepStatus.KPC.whPressur || !stepStatus.KPC.connection || !stepStatus.KPC.gasering;
  const u2Status = !stepStatus.U2.whPressur || !stepStatus.U2.connection || !stepStatus.U2.gasering;
  const u3Status = !stepStatus.U3.whPressur || !stepStatus.U3.connection || !stepStatus.U3.gasering;
  const copyButtonStatus = kpcStatus || u2Status || u3Status;

  return {
    running,
    noResult,
    hasAccess,
    disabled,
    fieldNextDisabled,
    wellDisabled,
    wellNextDisabled,
    constraintDisabled,
    afDisabled,
    optimizationDisabled,
    copyButtonStatus,
    constraintNextDisabled: constraintNextDisabled || optimizationDisabled,
  };
}
