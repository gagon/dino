import moment from 'moment';
import { useDispatch, useSelector } from 'react-redux';
import { scheduledModule } from '../../../common/ScheduledCases/ScheduledCasesDucks';
import Notice from '../../../common/utils/Notice';
import { loginModule } from '../../Login/LoginDucks';
import { caseModule, runOptimization } from '../CaseDucks/CaseDucks';

export default function useRun() {
  const caseData = useSelector((state) => state[caseModule].caseData);
  const fields = useSelector((state) => state[caseModule].fields);
  const { userConfig } = useSelector((state) => state[loginModule]);
  const scheduledData = useSelector((state) => state[scheduledModule].scheduledData);
  const dispatch = useDispatch();

  return () => {
    const isValidate = validate(fields, caseData.case_wells);
    if (!isValidate) return;

    const updateData = { caseId: caseData.id, opt_routing: false };
    updateData['ScheduledCase'] = {
      priority: 1,
      save_logs: true,
      user_id: userConfig.user_id,
      run_type: null,
    };

    if (scheduledData.some((i) => ['completed', 'error'].includes(i.status))) {
      updateData['ScheduledCase'].status = 'scheduled';
    }

    if (userConfig['RUN_OPT_DEFAULT_TIME'] && userConfig['RUN_ROUTING_OPT']) {
      let dateStr = `${moment().format('YYYY-MM-DD')}T${userConfig['RUN_OPT_DEFAULT_TIME']}:00`;
      let newDate = moment(dateStr);
      if (newDate.isBefore(moment())) newDate.add(1, 'days');
      updateData['ScheduledCase'].start_time = newDate.utc().format('YYYY-MM-DDTHH:MM:SS');
    }
    dispatch(runOptimization(updateData, userConfig.user_id));
  };
}

const validate = (fields, caseWells) => {
  let caseErr = caseWells?.filter((item) => item?.errorMsg) || [];
  const fieldsErr = Object.values(fields).reduce((errors, item) => {
    for (let field of Object.values(item)) {
      if (field?.errorMsg) errors.push(field);
    }
    return errors;
  }, []);

  let errMessage = '';
  for (let err of [...fieldsErr, ...caseErr]) {
    errMessage += `${err.errMessage}`;
  }
  if (errMessage && errMessage !== '') {
    Notice.error(errMessage);
  }
  return errMessage === '';
};
