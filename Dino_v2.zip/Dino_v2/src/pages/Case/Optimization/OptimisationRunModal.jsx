import { LoadingButton } from '@mui/lab';
import { Typography } from '@mui/material';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Input from '../../../common/Input/Input';
import SideMenuItemModal from '../../../common/SideMenuItemModal/SideMenuItemModal';
import { OPT_MAX_ITERATIONS } from '../../../_helpers/constants';
import { loginModule, setParamToUserConfig } from '../../Login/LoginDucks';
import { caseModule } from '../CaseDucks/CaseDucks';
import useStep from '../useStep';
import RunGasFieldOptimisation from './RunGasFieldOptimisation';
import useRun from './useRun';

export default function OptimisationRunModal({ onClose }) {
  const runCase = useRun();
  const { running } = useStep();
  const dispatch = useDispatch();
  const loading = useSelector((state) => state[caseModule].loadingSaveCase);
  const maxIteration = useSelector((state) => state[loginModule].userConfig[OPT_MAX_ITERATIONS]);

  return (
    <SideMenuItemModal isOpen boxStyle={{ width: 310 }} close={onClose}>
      <span className="bold" children={'Run case settings'} />
      <div>
        <div className="flex items-center mt1 justify-between">
          <Typography color="textSecondary" children="Max iterations" />
          <div style={{ width: 120, paddingLeft: 15 }}>
            <Input
              withoutForm
              value={maxIteration || 10}
              type="number"
              onChange={(value) => dispatch(setParamToUserConfig(OPT_MAX_ITERATIONS, value))}
            />
          </div>
        </div>
        <RunGasFieldOptimisation />
      </div>
      <div className="flex justify-center mt2">
        <LoadingButton
          loading={loading}
          children={running ? 'this case is launched' : 'RUN'}
          disabled={running}
          variant={'contained'}
          color={'primary'}
          sx={{ borderRadius: 23 }}
          onClick={runCase}
        />
      </div>
    </SideMenuItemModal>
  );
}
