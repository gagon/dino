import React, { useEffect } from 'react';
import { Typography, Checkbox } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { loginModule, setParamToUserConfig } from '../../Login/LoginDucks';
import { GAS_FIELD_OPTIMISATION } from '../../../_helpers/constants';

export default function RunGasFieldOptimisation() {
  const dispatch = useDispatch();
  const fieldOptimization = useSelector(
    (state) => state[loginModule].userConfig[GAS_FIELD_OPTIMISATION]
  );

  const setFieldOptimization = (check) => {
    dispatch(setParamToUserConfig(GAS_FIELD_OPTIMISATION, check));
  };

  useEffect(() => {
    dispatch(setParamToUserConfig(GAS_FIELD_OPTIMISATION, false));
  }, []);

  return (
    <>
      <div className="flex items-center justify-between" style={{ marginTop: 12 }}>
        <Typography color="textSecondary" children={'Run gas field optimization'} />
        <Checkbox
          sx={{ padding: 0 }}
          checked={!!fieldOptimization}
          onChange={({ target: { checked } }) => setFieldOptimization(checked)}
        />
      </div>
    </>
  );
}
