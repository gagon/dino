import IconButton from '@mui/material/IconButton';
import { useTheme } from '@mui/styles';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import OptimizationIcon from '../../../_media/OptimizationIcon';
import { caseMenuModule, changeActiveMenu } from '../SideBar/CaseMenuDucks';
import { OPTIMIZATION } from '../SideBar/MenuItems';
import SideButton from '../SideBar/SideButton';
import useStep from '../useStep';
import OptimisationRunModal from './OptimisationRunModal';

export default function Optimization() {
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const { activeMenu } = useSelector((state) => state[caseMenuModule]);
  const isActive = activeMenu === OPTIMIZATION;
  const { optimizationDisabled: disabled } = useStep();
  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton
            disabled={disabled}
            onClick={() => {
              dispatch(changeActiveMenu(OPTIMIZATION));
            }}
          >
            <OptimizationIcon
              style={{
                fill: isActive ? palette.common.white : '#5F6388',
                stroke: isActive
                  ? palette.common.white
                  : disabled
                  ? palette.action.disabled
                  : '#5F6388',
              }}
            />
          </IconButton>
        }
      />
      <p
        className="fs-10"
        style={{ marginTop: 0, color: disabled ? palette.action.disabled : 'inherit' }}
        children={'Optimization'}
      />

      {isActive && <OptimisationRunModal onClose={() => dispatch(changeActiveMenu(null))} />}
    </>
  );
}
