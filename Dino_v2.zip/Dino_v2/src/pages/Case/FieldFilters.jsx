import BlurCircularIcon from '@mui/icons-material/BlurCircular';
import { Tooltip, Typography } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import SideMenuItemModal from '../../common/SideMenuItemModal/SideMenuItemModal';
import Switch from '../../common/Switch/Switch';
import useSimpleModal from '../../common/_hooks/useSimpleModal';
import GasIcon from '../../_media/GasIcon';
import labSvg from '../../_media/svg/lab.png';
import oilSvg from '../../_media/svg/oil.png';
import unitSvg from '../../_media/svg/unit.png';
import waterSvg from '../../_media/svg/Water.png';
import { caseModule, changeFieldFilter } from './CaseDucks/CaseDucks';
import { caseMenuModule } from './SideBar/CaseMenuDucks';
import { COMP } from './SideBar/MenuItems';
import SideButton from './SideBar/SideButton';

const SwitchParam = ({ title, urlIcon, icon, style, checked, onChange }) => {
  return (
    <div style={style} className="flex flex-column items-center mb1">
      <div className="flex items-center mb1">
        {urlIcon && <img height={11} src={urlIcon} style={{ marginRight: 5, marginBottom: 2 }} />}
        {icon}
        <div className="text-secondary fs-12">{title}</div>
      </div>
      <Switch checked={checked} onChange={onChange} />
    </div>
  );
};

export default function FieldFilters() {
  const modal = useSimpleModal();
  const dispatch = useDispatch();
  const activeMenu = useSelector((state) => state[caseMenuModule].activeMenu);
  const filterFields = useSelector((state) => state[caseModule].filterFields);
  const isActive = activeMenu === COMP;

  const onChangeHandle = (params) => {
    dispatch(changeFieldFilter({ ...filterFields, ...params }));
  };

  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <Tooltip title={'Field Filters'}>
            <IconButton
              onClick={() => {
                modal.open({});
                // dispatch(changeActiveMenu(COMP));
              }}
            >
              <BlurCircularIcon
              // style={{
              //   fill: isActive ? palette.common.white : '#5F6388',
              //   stroke: isActive ? palette.common.white : '#5F6388',
              // }}
              />
            </IconButton>
          </Tooltip>
        }
      />
      {/*<p className="fs-10" style={{ marginTop: 0 }} children={'Field filters'} />*/}

      {modal.isOpen && (
        <SideMenuItemModal {...modal} boxStyle={{ width: 340 }}>
          <div>
            <Typography style={{ marginBottom: 20 }}>Streams</Typography>
            <div className="flex items-center" style={{ marginBottom: 40 }}>
              <SwitchParam
                urlIcon={oilSvg}
                style={{ flex: 1 }}
                title={'Oil'}
                checked={filterFields?.oil}
                onChange={({ target: { checked } }) => onChangeHandle({ oil: checked })}
              />
              <SwitchParam
                title={'Gas'}
                icon={<GasIcon color={'disabled'} style={{ height: 12 }} />}
                style={{ flex: 1 }}
                checked={filterFields?.gas}
                onChange={({ target: { checked } }) => onChangeHandle({ gas: checked })}
              />
              <SwitchParam
                title={'Water'}
                urlIcon={waterSvg}
                style={{ flex: 1 }}
                checked={filterFields?.water}
                onChange={({ target: { checked } }) => onChangeHandle({ water: checked })}
              />
            </div>
            <Typography style={{ marginBottom: 20 }}>Inputs</Typography>
            <div className="fullWidth flex items-end mb2">
              <SwitchParam
                title={'Unit pressures'}
                urlIcon={unitSvg}
                style={{ flex: 1 }}
                checked={filterFields?.unitPressure}
                onChange={({ target: { checked } }) => onChangeHandle({ unitPressure: checked })}
              />
              <SwitchParam
                title={'Gas opt'}
                icon={<GasIcon color={'disabled'} style={{ height: 12 }} />}
                style={{ flex: 1 }}
                checked={filterFields?.gasopt}
                onChange={({ target: { checked } }) => onChangeHandle({ gasopt: checked })}
              />
              <SwitchParam
                title={'Lab data'}
                style={{ flex: 1 }}
                urlIcon={labSvg}
                checked={filterFields?.lab}
                onChange={({ target: { checked } }) => onChangeHandle({ lab: checked })}
              />
            </div>
          </div>
        </SideMenuItemModal>
      )}
    </>
  );
}
