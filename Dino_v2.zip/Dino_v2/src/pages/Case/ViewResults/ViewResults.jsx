import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import IconButton from '@mui/material/IconButton';
import { useTheme } from '@mui/styles';

import useStep from '../useStep';
import ViewResultsIcon from '../../../_media/ViewResultsIcon';
import SideButton from '../SideBar/SideButton';
import { caseMenuModule, changeActiveMenu } from '../SideBar/CaseMenuDucks';
import { VIEW_RESULTS } from '../SideBar/MenuItems';

export default function ViewResults() {
  const activeMenu = useSelector((state) => state[caseMenuModule].activeMenu);
  const { palette } = useTheme();
  const isActive = activeMenu === VIEW_RESULTS;
  const iconColor = isActive ? palette.common.white : '#5F6388';
  const { noResult } = useStep();
  const dispatch = useDispatch();

  if (noResult) return null;

  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton onClick={() => dispatch(changeActiveMenu(VIEW_RESULTS))}>
            <ViewResultsIcon
              style={{
                fill: iconColor,
                stroke: iconColor,
              }}
            />
          </IconButton>
        }
      />
      <p className="fs-10 mt0" children={'View Results'} />
    </>
  );
}
