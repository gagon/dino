import React, { Fragment, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Paper from '@mui/material/Paper';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';

import { caseModule, copyAllocationFactory } from '../../../CaseDucks/CaseDucks';

export default function AllocationFactors() {
  const calculation = useSelector((state) => state[caseModule].calculation);
  const currentData = calculation?.labelDict ? calculation?.labelDict['AF Table:Current'] : {};
  const newData = calculation?.labelDict ? calculation?.labelDict['AF Table:New'] : {};
  const dispatch = useDispatch();

  const data = useMemo(() => {
    return currentData
      ? Object.entries(currentData).map(([key, item]) => {
          const calcValue = calculation?.calcDict[key].results?.default?.value;
          const value = parseFloat(calcValue).toFixed(2);
          const newValueObj = Object.values(newData).find(({ name }) => name === item?.name);
          const newCalcName = calculation?.calcNameLookup[newValueObj.calc_id];
          const newCalcValue = calculation?.calcDict[newCalcName].results?.default?.value;
          const newValue = parseFloat(newCalcValue).toFixed(2);
          return { ...item, value: value || '', newValue: newValue || '' };
        })
      : [];
  }, [currentData, newData, calculation]);

  return (
    <Paper
      sx={{
        borderTopRightRadius: 20,
        borderBottomRightRadius: 20,
        borderBottomLeftRadius: 20,
        borderTopLeftRadius: 20,
        padding: '25px 30px 20px 30px',
      }}
    >
      <div className="fs-14 bold mb2" children="Allocation Factors" />
      <div>
        <div className="flex justify-end">
          <div className="fs-14 bold" children="Current" />
          <div className="fs-14 bold" children="New" style={{ marginLeft: 40, width: 82 }} />
        </div>
        {data.map((item, index) => {
          return (
            <Fragment key={index}>
              <div
                className="flex items-center justify-between "
                style={{
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                <div className="fs-12" children={item.name} />
                <div className="flex">
                  <div
                    children={item.value}
                    style={{
                      fontSize: 12,
                      width: 80,
                      textAlign: 'left',
                    }}
                  />
                  <div
                    children={item.newValue}
                    style={{
                      fontSize: 12,
                      width: 80,
                      marginLeft: 10,
                    }}
                  />
                </div>
              </div>

              {index !== data.length - 1 && (
                <Divider
                  sx={{ border: '1px solid #EEF0F9' }}
                  variant="fullWidth"
                  orientation="horizontal"
                />
              )}
            </Fragment>
          );
        })}
      </div>

      <div className="flex justify-end">
        <Button
          size="small"
          variant="contained"
          children="Copy"
          onClick={() => dispatch(copyAllocationFactory(true))}
          sx={{ width: 60 }}
        />
        <Button
          size="small"
          variant="contained"
          children="Copy"
          onClick={() => dispatch(copyAllocationFactory())}
          sx={{
            width: 60,
            marginLeft: '26px',
            marginRight: '18px',
          }}
        />
      </div>
    </Paper>
  );
}
