import React, { useState, useMemo } from 'react';
import { useSelector } from 'react-redux';
import { Grid, Switch } from '@mui/material';
const ReactHighcharts = require('react-highcharts');

import { caseModule } from '../../../CaseDucks/CaseDucks';
import { generateChart } from './generateChart';
import { getUnitSeries, setPCData } from './ChartsUtils';

export default function Charts() {
  const { caseConfig, fieldBalance } = useSelector((state) => state[caseModule]);
  const [calcGroup, setCalcGroup] = useState('calc');

  const charts = useMemo(() => {
    const chartsArray = [];
    const caseNum = 1;
    for (let [uKey, uObj] of Object.entries(caseConfig?.units?.chart || {})) {
      try {
        const { pcArr, pointArr } = setPCData(fieldBalance, 1, caseConfig.units);
        const series = getUnitSeries(uKey, calcGroup, caseNum, pcArr, pointArr);
        const PCData = pcArr[1][calcGroup][uKey];
        const chartConfig = generateChart(uObj.lbl + ' performance curve', series, PCData);
        chartsArray.push(chartConfig);
      } catch (e) {
        console.error(e);
      }
    }
    return chartsArray;
  }, [caseConfig, fieldBalance, calcGroup]);

  const switchCalcGroup = () => setCalcGroup((prev) => (prev === 'calc' ? 'orig' : 'calc'));

  return (
    <>
      <div className="flex items-center ml3 mb1 mt2">
        <span children="Unit Performance Curves" className="fs-14 bold mr2" />
        <Grid
          component="label"
          container
          alignItems="center"
          spacing={0}
          sx={{ cursor: 'pointer', width: '50%', marginLeft: 4, mt: '2px' }}
        >
          <Grid item sx={{ fontSize: 12 }}>
            Raw Data
          </Grid>
          <Grid item>
            <Switch color="primary" onChange={switchCalcGroup} checked={calcGroup === 'calc'} />
          </Grid>
          <Grid item sx={{ fontSize: 12 }}>
            AF Adjusted
          </Grid>
        </Grid>
      </div>

      <div className="fullWidth flex items-center ">
        {charts.map((item, index) => {
          const style = { marginRight: index !== charts.length - 1 ? 20 : 0 };
          const style2 = { padding: 10, borderRadius: 20, background: 'white' };
          return (
            <div key={index} className="flex-1" style={style}>
              <div style={style2}>
                <ReactHighcharts config={item} />
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
