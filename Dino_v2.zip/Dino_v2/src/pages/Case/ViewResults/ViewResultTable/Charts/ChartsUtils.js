export const setPCData = function (data, caseNum, units) {
  const pcArr = [];
  pcArr[caseNum] = JSON.parse(JSON.stringify(data.pc));
  const pointArr = { [caseNum]: {} };

  if (data) {
    pcArr[caseNum] = JSON.parse(JSON.stringify(data.pc));
    pointArr[caseNum] = { orig: {}, calc: {} };
    for (let [uKey, unit] of Object.entries(units.chart)) {
      pointArr[caseNum]['orig'][uKey] = [
        [data.pc['orig'].totals[uKey]?.gas, data.pc['orig'].totals[uKey]?.oil],
      ];
      if (data.pc['calc'].totals[uKey]) {
        pointArr[caseNum]['calc'][uKey] = [
          [data.pc['calc'].totals[uKey].gas, data.pc['calc'].totals[uKey].oil],
        ];
      } else {
        pointArr[caseNum]['calc'][uKey] = [[0.0, 0.0]];
      }
      // pcArr[caseNum]['orig'][uKey].area = [[0.0, 0.0, 0.0],... pcArr[caseNum]['orig'][uKey].area]
      // pcArr[caseNum]['calc'][uKey].area = [[0.0, 0.0, 0.0],... pcArr[caseNum]['calc'][uKey].area]

      pcArr[caseNum]['orig'][uKey]?.area.unshift([0.0, 0.0, 0.0]);
      pcArr[caseNum]['calc'][uKey]?.area.unshift([0.0, 0.0, 0.0]);
    }
  }

  return { pcArr, pointArr };
};

export const getUnitSeries = function (unit, calcGrp, caseNum, pcArrs, pointArr) {
  const pcArr = JSON.parse(JSON.stringify(pcArrs));
  let color = '#D4EEFF';
  const seriesArr = [{}, {}];
  if (caseNum == 1) color = '#D4EEFF';
  seriesArr[caseNum][unit] = [];
  seriesArr[caseNum][unit][0] = {
    name: 'Range',
    // radius: 1.5,
    color: color,
    data: pcArr[caseNum][calcGrp][unit]?.area,
    // type: 'arearange',
    lineWidth: 0,
    linkedTo: ':previous',
    fillOpacity: 0.3,
    zIndex: 0,
    // states: { hover: { enabled: false } },
    marker: {
      enabled: false,
    },
  };
  // 'lineAsc'
  seriesArr[caseNum][unit][1] = createLineSeries(
    pcArr[caseNum][calcGrp][unit]?.lineAsc,
    pcArr[caseNum][calcGrp][unit].ascOrder,
    'GOR Ascending',
    color
  );
  // 'lineDesc'
  seriesArr[caseNum][unit][2] = createLineSeries(
    pcArr[caseNum][calcGrp][unit]?.lineDesc,
    pcArr[caseNum][calcGrp][unit].descOrder,
    'GOR Descending',
    color
  );

  seriesArr[caseNum][unit][3] = {
    data: pointArr[caseNum][calcGrp][unit],
    color: '#B2E1FF',
    name: '',
    radius: 1.5,
    marker: { symbol: 'circle' },
  };

  var seriesObj = null;
  seriesObj = seriesArr[caseNum][unit];
  return seriesObj;
};

export const createLineSeries = function (pcLineData, orderArr, name, color) {
  var lineData = [];
  for (let [idx, val] of Object.entries(orderArr)) {
    lineData.push({ name: val, x: pcLineData[val].x, y: pcLineData[val].y });
  }
  lineData.unshift({ name: '', x: 0.0, y: 0.0 });
  return {
    color: color,
    data: lineData,
    type: 'line',
    name: name,
    radius: 1.5,
    states: { hover: { enabled: true } },
    marker: {
      enabled: false,
    },
  };
};
