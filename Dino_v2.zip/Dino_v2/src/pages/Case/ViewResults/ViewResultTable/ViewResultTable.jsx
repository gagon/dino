import React from 'react';

import Kpls from './KPLS/Kpls';
import AllocationFactors from './AllocationFactors/AllocationFactors';
import Charts from './Charts/Charts';

export default function ViewResultTable() {
  return (
    <>
      <div className="flex">
        <div className="col-6 " style={{ paddingRight: 10 }}>
          <Kpls />
        </div>
        <div className="col-6" style={{ paddingLeft: 10 }}>
          <AllocationFactors />
        </div>
      </div>

      <Charts />
    </>
  );
}
