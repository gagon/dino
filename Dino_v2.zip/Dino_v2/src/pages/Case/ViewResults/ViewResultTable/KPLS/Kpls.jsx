import React, { Fragment, useMemo } from 'react';
import { useSelector } from 'react-redux';
import Paper from '@mui/material/Paper';
import Divider from '@mui/material/Divider';

import { caseModule } from '../../../CaseDucks/CaseDucks';

export default function Kpls() {
  const calculation = useSelector((state) => state[caseModule].calculation);
  const tableData = calculation.labelDict ? calculation.labelDict['KPI Table'] : {};

  const data = useMemo(() => {
    return tableData
      ? Object.entries(tableData).map(([key, item]) => {
          const calcValue = calculation?.calcDict[key].results?.default?.value;
          const value = parseFloat(calcValue).toFixed(3);
          return { ...item, value: value || '' };
        })
      : [];
  }, [tableData, calculation]);

  return (
    <Paper
      sx={{
        borderTopRightRadius: 20,
        borderBottomRightRadius: 20,
        borderBottomLeftRadius: 20,
        borderTopLeftRadius: 20,
        padding: '25px 30px 20px 30px',
      }}
    >
      <div className="fs-14 bold" style={{ marginBottom: 40 }} children="KPLs" />
      <div>
        {data.map((item, index) => {
          return (
            <Fragment key={index}>
              <div
                className="flex items-center justify-between "
                style={{
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                <div className="fs-12" children={item.name} />
                <div className="fs-12" children={`${item.value} %`} />
              </div>
              {index !== data.length - 1 ? (
                <Divider
                  sx={{ border: '1px solid #EEF0F9' }}
                  variant="fullWidth"
                  orientation="horizontal"
                />
              ) : null}
            </Fragment>
          );
        })}
      </div>
    </Paper>
  );
}
