import nullOrFixed from '../../../../utils/nullOrFixed';
import { buildUnitSummary } from '../../../../../common/calculationUtils/units';

export function handleGasTableData(caseData, calcDict, caseOpts) {
  const gasAllocData = [];
  const unitSummary = buildUnitSummary(caseData?.case_wells);

  const getCalcDictValue = (key, id) => {
    return nullOrFixed((calcDict[key]?.results || {})[id]?.value);
  };

  const getCalcDictNumValue = (key, id) => {
    try {
      return parseFloat((calcDict[key].results || {})[id].value).toFixed(1);
    } catch (e) {
      return '';
    }
  };

  for (const item of [{ id: 'default' }, ...caseOpts]) {
    if (!item.id) continue;
    const id = item.id;
    let u2 = calcDict.kpc_gas_to_u2.results[id]?.value;
    let u3 = calcDict.kpc_gas_to_u3.results[id]?.value;
    let percentage = '';
    let wells = '';
    let qwater = '';

    if (id !== 'default') {
      u2 = item?.results.kpc_gas_to_u2;
      u3 = item?.results.kpc_gas_to_u3;
    }

    // percentage
    if (u2 && u3) {
      const total = u2 + u3;
      const u2Procentage = parseFloat((u2 * 100) / total).toFixed(1);
      const u3Procentage = parseFloat(100 - u2Procentage).toFixed(1);
      percentage = `U2(${u2Procentage}) | U3(${u3Procentage})`;
    }

    // wells
    if (id !== 'default') {
      try {
        if (item?.results) {
          const optionU2Open = item?.results.U2_open_well;
          const optionU2shutin = item?.results.U2_shut_well;
          const optionU3Open = item?.results.U3_open_well;
          const optionU3shutin = item?.results.U3_shut_well;
          const u2 = ` U2 (${optionU2shutin} | ${optionU2Open})`;
          const u3 = ` U3 (${optionU3shutin} | ${optionU3Open})`;
          wells = `${u2} \n ${u3}`;
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      var bseU2shutin = unitSummary?.['U2']?.shutin;
      const baseU2total = unitSummary?.['U2']?.count;
      const baseU2openWell = baseU2total - bseU2shutin;
      var bseU3shutin = unitSummary?.['U3']?.shutin;
      const baseU3total = unitSummary?.['U3']?.count;
      const baseU3openWell = baseU3total - bseU3shutin;
      wells = `U2 (${bseU2shutin} | ${baseU2openWell}) \n U3 (${bseU3shutin} | ${baseU3openWell})`;
    }

    //
    if (id !== 'default') {
      qwater = item.results?.U2?.wat_tot || 0;
      qwater += item.results?.U3?.wat_tot || 0;
      qwater += item.results?.KPC?.wat_tot || 0;
      qwater = nullOrFixed(qwater, 0);
    } else {
      qwater = calcDict.u2_wat_tot.results[id]?.value || 0;
      qwater += calcDict.u3_wat_tot.results[id]?.value || 0;
      qwater += calcDict.kpc_wat_tot.results[id]?.value || 0;
      qwater = nullOrFixed(qwater, 0);
    }

    const getOptUnitValue = (unit, key) => {
      if (item.results[unit]) {
        return nullOrFixed(item.results[unit][key]);
      }
    };

    const getOptValue = (key) => {
      return nullOrFixed(item.results[key]);
    };

    const getOptTotalValue = (key) => {
      let u2tot = 0;
      let u3tot = 0;
      let kpctot = 0;
      if (item.results.U2) {
        u2tot = item.results.U2[`${key}_tot`];
        u3tot = item.results.U3[`${key}_tot`];
      }
      if (item.results.KPC) {
        kpctot = item.results.KPC[`${key}_tot`];
      }
      return u2tot + u3tot + kpctot;
    };

    const isBase = id === 'default';
    gasAllocData.push({
      id: id === 'default' ? 'Base' : id,
      u2GasTotal: isBase ? getCalcDictValue('u2_gas_tot', id) : getOptUnitValue('U2', 'gas_tot'),
      kpcQgasU2: isBase ? getCalcDictValue('kpc_gas_to_u2', id) : getOptValue('kpc_gas_to_u2'),
      u3GasTotal: isBase ? getCalcDictValue('u3_gas_tot', id) : getOptUnitValue('U3', 'gas_tot'),
      kpcGasToU3: isBase ? getCalcDictValue('kpc_gas_to_u3', id) : getOptValue('kpc_gas_to_u3'),
      kpcTotalGas: isBase ? getCalcDictValue('kpc_tot_gas', id) : getOptUnitValue('KPC', 'gas_tot'),
      percentage: percentage,
      ogp: getCalcDictNumValue('ogp_gas', id),
      sgi: getCalcDictNumValue('gas_inj', id),
      wells: wells,
      totalQoil: isBase ? getCalcDictValue('field_tot_oil', id) : getOptTotalValue('oil'),
      totalQgas: isBase ? getCalcDictValue('field_tot_gas', id) : getOptTotalValue('gas'),
      totalQwater: qwater,
    });
  }
  return gasAllocData;
}
