export function gasColumns(isHour) {
  const HeaderTitle = ({ title, measure }) => (
    <div className="fs-12" style={{ lineHeight: 1.2, whiteSpace: 'normal' }}>
      <div className="bold nowrap">{title}</div>
      <div className="fs-10 nowrap">{measure}</div>
    </div>
  );

  return [
    {
      field: 'id',
      headerName: 'ID Combination',
      width: 100,
    },
    {
      field: 'u2GasTotal',
      renderHeader: () => (
        <HeaderTitle title="U2 Gas Total" measure={isHour ? 'ksm3/hr' : 'ksm3/d'} />
      ),
      minWidth: 110,
    },
    {
      field: 'kpcQgasU2',
      renderHeader: () => (
        <HeaderTitle title="KPC Qgas to Unit-2" measure={isHour ? 'ksm3/hr' : 'ksm3/d'} />
      ),
      minWidth: 130,
    },
    {
      field: 'u3GasTotal',
      renderHeader: () => (
        <HeaderTitle title="U3 Gas Total" measure={isHour ? 'ksm3/hr' : 'ksm3/d'} />
      ),
      minWidth: 100,
    },
    {
      field: 'kpcGasToU3',
      renderHeader: () => (
        <HeaderTitle title="KPC Qgas to Unit-3" measure={isHour ? 'ksm3/hr' : 'ksm3/d'} />
      ),
      minWidth: 140,
    },
    {
      field: 'kpcTotalGas',
      renderHeader: () => (
        <HeaderTitle title="KPC Total Gas" measure={isHour ? 'ksm3/hr' : 'ksm3/d'} />
      ),
      minWidth: 120,
    },
    {
      field: 'percentage',
      headerName: 'Percentage',
      minWidth: 150,
    },
    {
      field: 'ogp',
      headerName: 'OGP',
      minWidth: 100,
    },
    {
      field: 'sgi',
      headerName: 'SGI',
      minWidth: 100,
    },
    {
      field: 'wells',
      renderHeader: () => (
        <HeaderTitle title="Wells" measure="(shut-in|open)" />
      ),
      minWidth: 170,
    },
    {
      field: 'totalQoil',
      renderHeader: () => (
        <HeaderTitle title="Total Qoil" measure={isHour ? 'sm3/hr' : 'sm3/d'} />
      ),
      minWidth: 100,
    },
    {
      field: 'totalQgas',
      renderHeader: () => (
        <HeaderTitle title="Total Qgas" measure={isHour ? 'ksm3/hr' : 'ksm3/d'} />
      ),
      minWidth: 100,
    },
    {
      field: 'totalQwater',
      renderHeader: () => (
        <HeaderTitle title="Total Qwater" measure={isHour ? 'sm3/hr' : 'sm3/d'} />
      ),
      minWidth: 100,
    },
    {
      field: 'new case',
      headerName: 'New case',
      width: 100,
    },
  ];
}
