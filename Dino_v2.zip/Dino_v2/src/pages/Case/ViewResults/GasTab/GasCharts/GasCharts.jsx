import React from 'react';
import { useSelector } from 'react-redux';
import { caseModule } from '../../../CaseDucks/CaseDucks';
import { gasChartOptions } from './GasChartOptions';
const ReactHighcharts = require('react-highcharts');

export default function GasCharts() {
  const gasTabChart = useSelector((state) => state[caseModule].gasTabChart);
  const style = { padding: 10, borderRadius: 20, background: 'white' };
  if (gasTabChart === null) return null;

  return (
    <div className='mt3' style={{ width: '70vw' }}>
      <div style={style}>
        <ReactHighcharts config={gasChartOptions(gasTabChart, false)} />
      </div>
    </div>
  );
}
