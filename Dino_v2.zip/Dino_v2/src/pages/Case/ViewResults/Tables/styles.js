import { styled as muiStyled } from '@mui/material/styles';
import { DataGrid } from '@mui/x-data-grid';

export const MuiDataGrid = muiStyled(DataGrid)(({ theme }) => ({
  '& .MuiDataGrid-iconSeparator': {
    display: 'none',
  },
}));
