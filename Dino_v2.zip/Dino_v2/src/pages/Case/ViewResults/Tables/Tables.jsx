import React, { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import { useTheme } from '@mui/styles';
import { unitColumns } from './colums';
import { MuiDataGrid } from './styles';
import WellsTable from './WellsTable';
import { useSelector } from 'react-redux';
import { buildUnitSummary } from '../../../../common/calculationUtils/units';
import { caseModule } from '../../CaseDucks/CaseDucks';

export default function Tables({ tab }) {
  const { caseData } = useSelector((state) => state[caseModule]);
  const [tableData, setTableData] = useState([]);

  useEffect(() => {
    if (caseData) {
      const unitsTotal = buildUnitSummary(caseData?.case_wells);
      const currentSummary = unitsTotal[tab];
      const data = [{ title: 'TOTAL', ...currentSummary, id: 'total' }];
      Object.entries(currentSummary?.rms).map(([key, values]) => {
        data.push({ title: key, ...values, id: key });
      });
      setTableData(data);
    }
  }, [caseData]);

  return (
    <>
      <div
        style={{
          padding: 30,
          background: 'white',
          borderTopLeftRadius: 20,
          borderTopRightRadius: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
          marginBottom: 30,
        }}
      >
        <Box sx={{ width: '100%', overflow: 'hidden' }}>
          <MuiDataGrid
            rowHeight={28}
            headerHeight={46}
            rows={tableData}
            columns={unitColumns(tab)}
            hideFooterPagination
            hideFooter
            autoHeight
            disableColumnMenu
            disableSelectionOnClick
            disableMultipleColumnsSorting
            disableExtendRowFullWidth={false}
            sx={{ border: 'none' }}
          />
        </Box>
      </div>
      <div
        style={{
          background: 'white',
          padding: 30,
          borderTopLeftRadius: 20,
          borderTopRightRadius: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <WellsTable tab={tab} />
      </div>
    </>
  );
}
