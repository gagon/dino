import React, { useMemo } from 'react';
import { useSelector } from 'react-redux';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { useTheme } from '@mui/styles';

import useColumnsFilter from '../../../../common/Table/useColumnsFilter';
import ColumnsFilter from '../../../../common/Table/ColumnsFilter';
import Table from '../../../../common/Table/Table';
import { wellColumns } from './colums';
import { caseModule } from '../../CaseDucks/CaseDucks';

export default function WellsTable({ tab }) {
  const { caseData, caseConfig, classByUnits, unitsByClass } = useSelector(
    (state) => state[caseModule]
  );
  const { columnFilter, changeFilter } = useColumnsFilter();
  const { palette } = useTheme();

  const list = useMemo(() => {
    return caseData?.case_wells.filter((caseWell) => {
      const currentConnId = caseWell.gap_conn_id;
      const unitName = caseWell.gap_well.connectionMap[currentConnId].unit;
      return unitName === tab;
    });
  }, [caseData]);

  return (
    <div>
      <div className="flex items-center mb2 mt1">
        <Typography
          variant={'h5'}
          children={'Wells'}
          style={{
            color: palette.action.active,
          }}
        />
        <ColumnsFilter
          columns={wellColumns()}
          changeFilter={changeFilter}
          columnFilter={columnFilter}
        />
      </div>
      <Table
        headerHeight={46}
        rows={list || []}
        columns={wellColumns(
          caseConfig?.wellCfg,
          caseConfig?.wellColumns,
          classByUnits,
          unitsByClass
        ).filter(({ field }) => !columnFilter.includes(field))}
        pageSize={list.length}
        autoPageSize
        autoHeight
        hideFooterPagination
        hideFooter
        disableColumnMenu
        disableSelectionOnClick
        disableMultipleColumnsSorting
        disableExtendRowFullWidth={false}
        sx={{
          border: 'none',
          '& .water': {
            bgcolor: '#74ccf4',
          },
          '& .swing': {
            bgcolor: '#EEED09',
          },
          '& .disabled': {
            bgcolor: '#ff6461',
          },
        }}
        getRowClassName={({ row }) => {
          const isWaterWell = row?.gap_well?.wct > 0;
          const disabled = row?.mask_well;
          const isSwingReason =
            row.res_shutin_reason && row.res_shutin_reason.startsWith('Swing well');
          const isOtherReason =
            row.res_shutin_reason && !row.res_shutin_reason.startsWith('Swing well');

          if (isWaterWell && !disabled) {
            return 'water';
          } else if (isSwingReason) {
            return 'swing';
          } else if (disabled || isOtherReason) {
            return 'disabled';
          }
        }}
      />
    </div>
  );
}
