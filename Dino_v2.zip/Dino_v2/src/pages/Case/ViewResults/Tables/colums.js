import React from 'react';

import nullOrFixed from '../../../utils/nullOrFixed';
import { unitConvert } from '../../../../common/calculationUtils/units';

const HeaderTitleWithUnit = ({ title, unit }) => (
  <div style={{ lineHeight: 1, fontSize: 14, textAlign: 'center' }}>
    <div className="bold" style={{ marginBottom: unit ? 0 : 10 }}>
      {title}
    </div>
    <div>{unit}</div>
  </div>
);

const CellWrapper = ({ children }) => <div style={{ paddingRight: 5 }}>{children}</div>;

export const wellColumns = (wellCfg, wellColumns, classByUnits, unitsByClass) => {
  return [
    {
      field: 'id',
      headerName: 'Well Name',
      align: 'center',
      type: 'number',
      width: 100,
      renderHeader: () => <HeaderTitleWithUnit title="Well Name" />,
      renderCell: ({ row }) => {
        const name = wellCfg[row.well_id].gap_name;
        const isLp = row.gap_well.connectionMap[row.gap_conn_id].mp_lp == 'LP';
        return <span children={name} style={{ color: isLp ? 'blue' : 'black', paddingLeft: 5 }} />;
      },
    },
    {
      field: 'gor',
      headerName: 'GOR',
      renderHeader: () => <HeaderTitleWithUnit title="GOR" unit="(sm3/sm3)" />,
      width: 90,
      align: 'center',
      type: 'number',
      valueGetter: ({ row }) => row.gap_well?.gor,
      renderCell: ({ row }) => {
        return nullOrFixed(row.gap_well?.gor, 0);
      },
    },
    {
      field: 'watercut',
      headerName: 'Watercut',
      renderHeader: () => <HeaderTitleWithUnit title="Watercut" unit="(%)" />,
      width: 80,
      align: 'center',
      type: 'number',
      valueGetter: ({ row }) => {
        return nullOrFixed(row.gap_well.wct * 100, 0);
      },
    },
    {
      field: 'Connected',
      headerName: 'Connected',
      renderHeader: () => <HeaderTitleWithUnit title="Connected" />,
      width: 90,
      align: 'center',
      valueGetter: ({ row }) => {
        return row.gap_well.connectionMap[row.gap_conn_id].dual_unit;
      },
    },
    {
      field: 'ConfiguredFlow',
      headerName: 'Configured Flow',
      sortable: false,
      minWidth: 220,
      renderHeader: () => <HeaderTitleWithUnit title="Configured Flow" />,
      valueGetter: ({ row: { well_conn_id } }) => well_conn_id,
      renderCell: ({ row }) => {
        const connMap = Object.values(row?.gap_well.connectionMap);
        const options = connMap.find((item) => item?.conn_map_id === row?.well_conn_id);
        return <div style={{ paddingLeft: 5 }}>{options ? options.name : ''}</div>;
      },
    },
    {
      field: 'gapFlow',
      headerName: 'Flow to',
      renderHeader: () => <HeaderTitleWithUnit title="Flow to" />,
      minWidth: 220,
      background: 'green',
      valueGetter: ({ row }) => row.gap_well.connectionMap[row.gap_conn_id].name,
      renderCell: ({ row }) => {
        const flowTo = row.gap_well.connectionMap[row.gap_conn_id].name;
        const isLp = row.gap_well.connectionMap[row.gap_conn_id].mp_lp == 'LP';
        return (
          <span children={flowTo} style={{ color: isLp ? 'blue' : 'black', paddingLeft: 5 }} />
        );
      },
    },
    {
      field: 'comingled',
      headerName: 'Comingled',
      renderHeader: () => <HeaderTitleWithUnit title="Comingled" />,
      minWidth: 95,
      align: 'center',
      valueGetter: ({ row }) => {
        return row.gap_well.connectionMap[row.gap_conn_id].comingled;
      },
    },
    {
      field: 'map',
      headerName: 'MAP',
      renderHeader: () => <HeaderTitleWithUnit title="MAP" unit="(bara)" />,
      align: 'center',
      type: 'number',
      width: 60,
      valueGetter: ({ row }) => {
        return row.gap_well.map;
      },
    },

    {
      field: 'targetPressure',
      headerName: 'Target FWHP',
      renderHeader: () => <HeaderTitleWithUnit title="Target FWHP" unit="(bara)" />,
      minWidth: 110,
      type: 'number',
      valueGetter: ({ row }) => row.target_pressure,
      renderCell: ({ row }) => <CellWrapper>{nullOrFixed(row.target_pressure, 1)}</CellWrapper>,
    },
    {
      field: 'whPressure',
      headerName: 'GAP FWHP',
      renderHeader: () => <HeaderTitleWithUnit title="GAP FWHP" unit="(bara)" />,
      width: 95,
      type: 'number',
      cellClassName: ({ row }) => getCellClassName(row),
      valueGetter: ({ row }) => row.res_fwhp,
      renderCell: ({ row }) => <CellWrapper>{nullOrFixed(row.res_fwhp, 1)}</CellWrapper>,
    },
    {
      field: 'chokePosition',
      headerName: 'Choke Pos',
      renderHeader: () => <HeaderTitleWithUnit title="Choke Pos" unit="(%)" />,
      width: 90,
      type: 'number',
      valueGetter: ({ row }) => {
        let measChokeDBId = null;
        for (let obj of Object.values(wellColumns)) {
          if (obj.name == 'Choke Position') {
            measChokeDBId = obj.id;
          }
        }
        return measChokeDBId ? row.well_config_values[measChokeDBId].value : '';
      },
      renderCell: ({ row }) => {
        let measChokeDBId = null;
        for (let obj of Object.values(wellColumns)) {
          if (obj.name == 'Choke Position') {
            measChokeDBId = obj.id;
          }
        }
        return (
          <CellWrapper>
            {measChokeDBId ? nullOrFixed(row.well_config_values[measChokeDBId].value, 1) : ''}
          </CellWrapper>
        );
      },
    },
    {
      field: 'dpChoke',
      headerName: 'dP Choke',
      renderHeader: () => <HeaderTitleWithUnit title="dP Choke" unit="(bar)" />,
      minWidth: 150,
      cellClassName: ({ row }) => getCellClassName(row),
      type: 'number',
      valueGetter: ({ row }) => {
        if (row.res_shutin_reason && !row.res_shutin_reason.startsWith('Swing well')) {
          return row.res_shutin_reason;
        } else {
          var resDPText = nullOrFixed(row.res_dp, 1);
          if (row.res_shutin_reason && row.res_shutin_reason.startsWith('Swing well')) {
            return row.res_shutin_reason;
          }
          return resDPText;
        }
      },
      renderCell: ({ row }) => {
        let dpChokeNode = '';
        if (row.res_shutin_reason && !row.res_shutin_reason.startsWith('Swing well')) {
          dpChokeNode = <span children={row.res_shutin_reason} />;
        } else if (row.res_shutin_reason && row.res_shutin_reason.startsWith('Swing well')) {
          dpChokeNode = <span children={row.res_shutin_reason} />;
        } else {
          const resDPText = nullOrFixed(row.res_dp, 1);
          dpChokeNode = <span children={resDPText} />;
        }
        return <CellWrapper>{dpChokeNode}</CellWrapper>;
      },
    },
    {
      field: 'flPressure',
      headerName: 'FL pressure',
      renderHeader: () => <HeaderTitleWithUnit title="FL pressure" unit="(barg)" />,
      minWidth: 80,
      cellClassName: ({ row }) => getCellClassName(row),
      type: 'number',
      valueGetter: ({ row }) => {
        let flp = '';
        if (row.res_fwhp && row.res_dp) {
          flp = row.res_fwhp - row.res_dp;
        }
        return flp;
      },
      renderCell: ({ row }) => {
        let flp = '';
        if (row.res_fwhp && row.res_dp) {
          flp = nullOrFixed(row.res_fwhp - row.res_dp, 1);
        }
        return <CellWrapper>{flp}</CellWrapper>;
      },
    },
    {
      field: 'slotPressure',
      headerName: 'Slot pressure',
      renderHeader: () => <HeaderTitleWithUnit title="Slot pressure" unit="(barg)" />,
      minWidth: 110,
      cellClassName: ({ row }) => getCellClassName(row),
      type: 'number',
      valueGetter: ({ row }) => row.res_slotpres,
      renderCell: ({ row }) => <CellWrapper>{nullOrFixed(row.res_slotpres, 1)}</CellWrapper>,
    },
    {
      field: 'qOil',
      headerName: 'Qoil (sm3/d)',
      renderHeader: () => <HeaderTitleWithUnit title="Qoil" unit="(sm3/d)" />,
      width: 80,
      cellClassName: ({ row }) => getCellClassName(row),
      type: 'number',
      valueGetter: ({ row }) => row.res_oil_rate,
      renderCell: ({ row }) => {
        const props = { unit: 'sm3/d' };
        const qOil = unitConvert(props, row.res_oil_rate, 1, classByUnits, unitsByClass);
        return <CellWrapper>{qOil}</CellWrapper>;
      },
    },
    {
      field: 'qOil2',
      headerName: 'Qoil (t/d)',
      renderHeader: () => <HeaderTitleWithUnit title="Qoil" unit="(t/d)" />,
      cellClassName: ({ row }) => getCellClassName(row),
      width: 65,
      type: 'number',
      valueGetter: ({ row }) => row.res_oil_rate * row.gap_well.oil_sg,
      renderCell: ({ row }) => {
        const props = { unit: 't/d' };
        const value = row.res_oil_rate * row.gap_well.oil_sg;
        return (
          <CellWrapper>{unitConvert(props, value, 1, classByUnits, unitsByClass)}</CellWrapper>
        );
      },
    },
    {
      field: 'qGas',
      headerName: 'Qgas',
      renderHeader: () => <HeaderTitleWithUnit title="Qgas" unit="(kscm/d)" />,
      cellClassName: ({ row }) => getCellClassName(row),
      width: 75,
      type: 'number',
      valueGetter: ({ row }) => row.res_gas_rate,
      renderCell: ({ row }) => {
        const props = { unit: 'kscm/d' };
        return (
          <CellWrapper>
            {unitConvert(props, row.res_gas_rate, 1, classByUnits, unitsByClass)}
          </CellWrapper>
        );
      },
    },
    {
      field: 'qWater',
      headerName: 'Qwater',
      renderHeader: () => <HeaderTitleWithUnit title="Qwater" unit="(sm3/d)" />,
      cellClassName: ({ row }) => getCellClassName(row),
      width: 70,
      type: 'number',
      valueGetter: ({ row }) => row.res_wat_rate,
      renderCell: ({ row }) => {
        const props = { unit: 'sm3/d' };
        return (
          <CellWrapper>
            {unitConvert(props, row.res_wat_rate, 1, classByUnits, unitsByClass)}
          </CellWrapper>
        );
      },
    },
    {
      field: 'caseGor',
      headerName: 'Case_GOR',
      renderHeader: () => <HeaderTitleWithUnit title="Case_GOR" unit="(sm3/sm3)" />,
      width: 90,
      cellClassName: ({ row }) => getCellClassName(row),
      type: 'number',
      valueGetter: ({ row }) => row?.case_gor,
      renderCell: ({ row }) => <CellWrapper>{nullOrFixed(row?.case_gor, 1)}</CellWrapper>,
    },
    {
      field: 'caseSbhp',
      headerName: 'Case_SBHP',
      renderHeader: () => <HeaderTitleWithUnit title="Case_SBHP" />,
      width: 95,
      cellClassName: ({ row }) => getCellClassName(row),
      type: 'number',
      valueGetter: ({ row }) => row?.case_sbhp,
      renderCell: ({ row }) => <CellWrapper>{nullOrFixed(row?.case_sbhp, 1)}</CellWrapper>,
    },
  ];
};

export const unitColumns = (unitName) => {
  return [
    {
      field: 'title',
      headerName: <span children={unitName} className="fs-18 bold" />,
      width: 200,
      renderCell: ({ row }) => {
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{row.title}</span>;
      },
    },
    {
      field: 'shutInOpen',
      headerName: <span children="Shut in / Open count" className="bold" />,
      flex: 0.8,
      renderCell: ({ row }) => {
        const value = `${row.shutin}/${row.count - row.shutin}`;
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
    {
      field: 'qgas',
      headerName: <span children="Qgas (kscm/d)" className="bold" />,
      minWidth: 130,
      renderCell: ({ row }) => {
        const unit = 'kscm/d';
        const value = unitConvert({ unit }, row['qgas'], 0);
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
    {
      field: 'qoil',
      headerName: <span children="Qoil (sm3/d)" className="bold" />,
      minWidth: 130,
      renderCell: ({ row }) => {
        const unit = 'sm3/d';
        const value = unitConvert({ unit }, row['qoil'], 0);
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
    {
      field: 'qoiltd',
      headerName: <span children="Qoil (t/d)" className="bold" />,
      minWidth: 130,
      renderCell: ({ row }) => {
        const unit = 't/d';
        const value = unitConvert({ unit }, row['qoiltd'], 0);
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
    {
      field: 'qwat',
      headerName: <span children="Qwater (sm3/d)" className="bold" />,
      minWidth: 130,
      renderCell: ({ row }) => {
        const unit = 'sm3/d';
        const value = unitConvert({ unit }, row['qwat'], 0);
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
  ];
};

const getCellClassName = (row) => {
  const { mask_well, gap_well, res_shutin_reason } = row;

  if (
    mask_well ||
    (gap_well && gap_well.wct > 0) ||
    (res_shutin_reason && res_shutin_reason.startsWith('Swing well')) ||
    (res_shutin_reason && !res_shutin_reason.startsWith('Swing well'))
  ) {
    return '';
  }

  return 'super-app-theme--cell';
};
