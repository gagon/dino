import { LoadingButton } from '@mui/lab';
import { Checkbox, Typography } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import { useTheme } from '@mui/styles';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Input from '../../../common/Input/Input';
import Select from '../../../common/Select/Select';
import SideMenuItemModal from '../../../common/SideMenuItemModal/SideMenuItemModal';
import {
  WELL_FETCH_METHOD,
  WELL_FETCH_PERIOD,
  WELL_NON_NUMERIC,
} from '../../../_helpers/constants';
import WellDataIcon from '../../../_media/sideBar/WellData';
import { loginModule, setParamToUserConfig } from '../../Login/LoginDucks';
import { caseModule, loadWellPIData } from '../CaseDucks/CaseDucks';
import { caseMenuModule, changeActiveMenu } from '../SideBar/CaseMenuDucks';
import { WELL_DATA, CONSTRAINS } from '../SideBar/MenuItems';
import SideButton from '../SideBar/SideButton';
import useStep from '../useStep';

const fetchOptions = [
  { name: 'Last value', value: 'LastValue' },
  { name: 'Time Weighted Mean', value: 'TWMean' },
  { name: 'Event Weighted Mean', value: 'EWMean' },
  { name: 'Dino Calculated Mean', value: 'DinoEWMean' },
];

const nonNumericOptions = [
  { name: 'Last value', value: 'LastValueStr' },
  { name: 'Mode', value: 'Mode' },
];

export default function WellDataModal() {
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const [noticeIsShowed, setNoticeShowed] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [copyGathering, setCopyGathering] = useState(false);
  const { activeMenu } = useSelector((state) => state[caseMenuModule]);
  const { wellDisabled: disabled, wellNextDisabled } = useStep();
  const isActive = activeMenu === WELL_DATA;
  const loading = useSelector((state) => state[caseModule].loadingWellData);
  const fetchPeriod = useSelector((state) => state[loginModule].userConfig[WELL_FETCH_PERIOD]);
  const fetchMethod = useSelector((state) => state[loginModule].userConfig[WELL_FETCH_METHOD]);
  const nonNumeric = useSelector((state) => state[loginModule].userConfig[WELL_NON_NUMERIC]);

  const style = {
    fill: isActive
      ? palette.common.white
      : disabled
      ? palette.action.disabled
      : palette.action.active,
  };

  const onChange = (event, paramName) => {
    dispatch(setParamToUserConfig(paramName, event.target.value));
  };
  const loadData = () => {
    dispatch(loadWellPIData({ fetchPeriod, fetchMethod, nonNumeric }, copyGathering));
  };
  const onOpen = () => {
    dispatch(changeActiveMenu(WELL_DATA));
  };
  const nextBtnHandle = () => {
    dispatch(changeActiveMenu(CONSTRAINS));
  };

  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton disabled={disabled} onClick={onOpen}>
            <WellDataIcon style={style} />
          </IconButton>
        }
      />

      <p
        className="fs-10"
        style={{ marginTop: 0, color: disabled ? palette.action.disabled : 'inherit' }}
        children={'Well Data'}
      />
      {isActive && (
        <SideMenuItemModal isOpen={isActive} close={() => dispatch(changeActiveMenu(null))}>
          <div style={{ width: 250 }}>
            <Typography style={{ marginBottom: 20 }}>Well Data fetch settings</Typography>
            <Input
              label={'Fetch period (min)'}
              withoutForm
              value={fetchPeriod}
              style={{ marginBottom: 16 }}
              onChange={(value) => onChange({ target: { value } }, WELL_FETCH_PERIOD)}
            />
            <Select
              label={'Numeric fecth method'}
              withoutForm
              value={fetchMethod}
              style={{ marginBottom: 16 }}
              options={fetchOptions}
              onChange={(e) => onChange(e, WELL_FETCH_METHOD)}
            />
            <Select
              label={'Non numeric method'}
              withoutForm
              value={nonNumeric}
              options={nonNumericOptions}
              onChange={(e) => onChange(e, WELL_NON_NUMERIC)}
            />
            <div className="flex items-center justify-between" style={{ marginTop: 12 }}>
              <Typography color="textSecondary" children={'Load gathering data'} />
              <Checkbox
                sx={{ padding: 0 }}
                checked={!!copyGathering}
                onChange={({ target: { checked } }) => setCopyGathering(checked)}
              />
            </div>
            <div className="flex justify-center" style={{ marginTop: 15 }}>
              <LoadingButton
                loading={loading}
                children={'Load data >'}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23, marginRight: 2 }}
                onClick={loadData}
              />
              <LoadingButton
                loading={loading}
                children={'Next >'}
                disabled={wellNextDisabled}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23 }}
                onClick={
                  noticeIsShowed
                    ? nextBtnHandle
                    : () => {
                        setShowModal(true);
                        dispatch(changeActiveMenu(null));
                      }
                }
              />
            </div>
          </div>
        </SideMenuItemModal>
      )}
      {!noticeIsShowed && showModal && (
        <SideMenuItemModal isOpen close={() => setShowModal(false)}>
          <div style={{ width: 250 }}>
            <Typography style={{ marginBottom: 20 }}>
              Have the well parameters and routing data been set up?
            </Typography>
            <div className="flex justify-center" style={{ marginTop: 15 }}>
              <LoadingButton
                children={'Yes'}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23, marginRight: 2 }}
                onClick={() => {
                  nextBtnHandle();
                  setNoticeShowed(true);
                  setShowModal(false);
                }}
              />
              <LoadingButton
                children={'No'}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23 }}
                onClick={() => {
                  setNoticeShowed(true);
                  setShowModal(false);
                }}
              />
            </div>
          </div>
        </SideMenuItemModal>
      )}
    </>
  );
}
