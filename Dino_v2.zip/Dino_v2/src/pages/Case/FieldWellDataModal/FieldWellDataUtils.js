// generates the Osisoft AF server URL to get the correct value back from af

import { reject } from 'lodash';
import moment from 'moment';
import { CaseApi } from '../../../_helpers/service';

export async function getFieldsToChange({
  fieldParams,
  fields,
  afServer,
  timestamp,
  classByUnits,
  unitsByClass,
}) {
  const date = moment(timestamp, 'DD-MM-YYYY HH:mm:ssZ');
  const fetchDate = moment().isBefore(date) ? moment() : date;
  const encDate = encodeURIComponent(fetchDate.format('YYYY-MM-DDTHH:mm:ssZ'));
  const { fetchPeriod, fetchMethod, nonNumeric } = fieldParams;
  const fetchObj = generateAFServerPostfix(fetchMethod, fetchPeriod, nonNumeric, date);
  const fieldsToChange = [];

  for (const unit of Object.values(fields)) {
    for (const field of Object.values(unit)) {
      if (field.default_val && !field.value) {
        fieldsToChange.push({
          ...field,
          value: field.default_val,
          data_source: 'Default',
        });
      }

      try {
        // skip if we don't have a tag
        if (field.source_tag && !field.no_auto_fetch) {
          // assumes the server is the local server for name replacement
          if (field.source_type == 'url') {
            const url = `${field.source_tag.replace('[server]')}&end=${encDate}`;
            const { data: retVals } = await CaseApi.getDatafromUrl(url);
            if (retVals.length > 0) {
              fieldsToChange.push({
                ...field,
                value: retVals[0].Value || '',
                timestamp: retVals[0].Timestamp.replace('Z', ''),
                data_source: 'URL Fetch',
              });
            } else {
              fieldsToChange.push({
                ...field,
                value: 1,
                data_source: 'URL Fetch',
              });
            }
          } else if (
            !field.source_type ||
            field.source_type == 'Attributes' ||
            field.source_type == 'pipoint'
          ) {
            const webId = generateWebID(field.source_tag, field.source_type);
            const dtUrl = fetchObj[field.data_type].url;
            const url = `https://${afServer}/piwebapi/streams/${webId}${dtUrl}`;
            // const url = `/piwebapi/streams/${webId}${dtUrl}`;
            const { data: retColl } = await CaseApi.getDatafromUrl(url);
            const resultData = fetchObj[field.data_type].aggregate(retColl);
            // test if we have a digital state value

            if (resultData.good) {
              if (resultData.unit && field.uom && resultData.unit != field.uom) {
                resultData.val = convertUnit(
                  resultData.val,
                  resultData.unit,
                  field.uom,
                  unitsByClass,
                  classByUnits
                );
              }
              fieldsToChange.push({
                ...field,
                value: resultData.val,
                timestamp: resultData.ts.replace('Z', ''),
                data_source: resultData.msg,
              });
            }
          }
        }
      } catch (error) {
        console.error(error);
      }
    }
  }

  const changesDefault = [];
  const changesPdms = [];
  const changesDependants = [];

  fieldsToChange
    .map((field) => {
      if (isNaN(field.value) || field.value === null) {
        field.value = 0;
      }
      if (field.data_type === 'float') {
        field.value = field.value ? parseFloat(field.value).toFixed(2) : 0.0;
      }
      return field;
    })
    .forEach((field) => {
      if (field.data_source === 'Default') changesDefault.push(field);
      else if (field.dependants.length > 0) changesDependants.push(field);
      else changesPdms.push(field);
    });

  return [...changesDefault, ...changesPdms, ...changesDependants];
}

export async function getWellsToChange({
  fieldParams,
  caseWells,
  wellColumns,
  wellCfg,
  fields,
  afServer,
  timestamp,
  classByUnits,
  unitsByClass,
}) {
  const fieldKeys = {
    'WH Pressure': 'whPressur',
    'FL Pressure': 'flPressur',
    'Slot Pressure': 'slotPressur',
    'Slot Temperature': 'slotTemperature',
    'Choke Position': 'chokePosition',
    'Online Status': 'onlineStatus',
    'Gathering Status': 'gatheringStatus',
    'WLU MP_LP': 'well_conn_id',
  };

  const connKeys = ['WLU Flow to', 'WLU Routing', 'WLU Trunkline', 'WLU MP_LP'];
  const date = moment(timestamp, 'DD-MM-YYYY HH:mm:ssZ');
  const { fetchPeriod, fetchMethod, nonNumeric } = fieldParams;
  const fetchObj = generateAFServerPostfix(fetchMethod, fetchPeriod, nonNumeric, date);
  const wellsToChange = [];

  for (const caseWell of caseWells) {
    let connIndex = '';
    const well = wellCfg[caseWell.well_id];

    for (const wcv of Object.values(caseWell.well_config_values)) {
      const wellInstConfig = well.configs[wcv.config_id];
      const colConfig = wellColumns[wcv.config_id];
      const wellItem = { ...wellInstConfig, ...colConfig };

      try {
        if (wellItem.source_tag && !wellItem.no_auto_fetch) {
          const webId = generateWebID(wellItem.source_tag, wellItem.source_type);
          const dtUrl = fetchObj[wellItem.data_type].url;
          const url = `https://${afServer}/piwebapi/streams/${webId}${dtUrl}`;
          const response = await CaseApi.getDatafromUrl(url);
          const retColl = response.data;
          const resultData = fetchObj[wellItem.data_type].aggregate(retColl);

          if (resultData.good) {
            if (resultData.unit && wellItem.uom && resultData.unit != wellItem.uom) {
              resultData.val = convertUnit(
                resultData.val,
                resultData.unit,
                wellItem.uom,
                unitsByClass,
                classByUnits
              );
            }
            if (wellItem.data_type === 'float') {
              resultData.val = resultData.val ? parseFloat(resultData.val).toFixed(2) : '0.00';
            }
            if (connKeys.includes(wellItem.name)) {
              connIndex += resultData.val;
            }
            if (fieldKeys[wellItem.name]) {
              const key = fieldKeys[wellItem.name];
              if (key === 'well_conn_id') {
                connIndex = connIndex.toUpperCase();
                if (connIndex in caseWell.gap_well.connectionTagMap) {
                  const value = caseWell.gap_well.connectionTagMap[connIndex].conn_map_id;
                  wellsToChange.push({
                    caseWell: {
                      id: caseWell.id,
                      case_id: caseWell.case_id,
                      gap_well: caseWell.gap_well,
                      [key]: value,
                    },
                    saveObj: { column: key },
                    isSelect: true,
                  });
                }
              } else {
                const config = caseWell[key];
                const saveObj = {
                  CaseWellConfigItem: {
                    [`${caseWell.id}-${config.config_id}`]: {
                      value: resultData.val,
                      data_source: resultData.msg,
                    },
                  },
                };
                wellsToChange.push({
                  caseWell: {
                    id: caseWell.id,
                    case_id: caseWell.case_id,
                    [key]: { ...config, value: resultData.val },
                  },
                  saveObj,
                });
              }
            }
          }
        }
      } catch (error) {
        console.error(error);
      }

      if (wellItem.name === 'WLU MP_LP') {
        connIndex = '';
      }
    }
  }

  return wellsToChange;
}

export function generateAFServerPostfix(method, period, nonNumeric, date) {
  // if the date is in the future get the most recent date
  var fetchDate = moment().isBefore(date) ? moment() : date;
  var encDate = encodeURIComponent(fetchDate.format('YYYY-MM-DDTHH:mm:ssZ'));

  var options = {
    TWMean: {
      create: function (start, end) {
        return (
          '/Summary?endTime=' +
          end +
          '&startTime=' +
          start +
          '&summaryType=Average&calculationBasis=TimeWeighted'
        );
      },
      aggregate: function (retVal) {
        retVal = retVal.Items[0].Value;
        if (!retVal.Good) {
          var error = getAFFetchErrorMessage(retVal);
          return {
            err: error,
            ts: retVal.Timestamp,
            msg: 'AF Fetch TWMean Prev ' + period + 'mins',
            good: retVal.Good,
          };
        } else {
          return {
            val: retVal.Value,
            ts: retVal.Timestamp,
            unit: retVal.UnitsAbbreviation,
            msg: 'AF Fetch TWMean Prev ' + period + 'mins',
            good: retVal.Good,
          };
        }
      },
    },
    EWMean: {
      create: function (start, end) {
        return (
          '/Summary?endTime=' +
          end +
          '&startTime=' +
          start +
          '&summaryType=Average&calculationBasis=EventWeighted'
        );
      },
      aggregate: function (retVal) {
        retVal = retVal.Items[0].Value;
        if (!retVal.Good) {
          var error = getAFFetchErrorMessage(retVal);
          return {
            err: error,
            ts: retVal.Timestamp,
            msg: 'AF Fetch TWMean Prev ' + period + 'mins',
            good: retVal.Good,
          };
        } else {
          return {
            val: retVal.Value,
            ts: retVal.Timestamp,
            unit: retVal.UnitsAbbreviation,
            msg: 'AF Fetch TWMean Prev ' + period + 'mins',
            good: retVal.Good,
          };
        }
      },
    },
    DinoEWMean: {
      create: function (start, end) {
        return '/recorded?boundaryType=Interpolated&endTime=' + end + '&startTime=' + start;
      },
      aggregate: function (retVal) {
        var tot = 0;
        var count = 0;
        retVal.Items.forEach((val) => {
          if (val.Good) {
            tot += val.Value;
            count++;
          }
        });
        var outDate = fetchDate.format('YYYY-MM-DDTHH:mm:ss');
        if (count == 0) {
          return {
            err: 'No values in time range',
            ts: outDate,
            msg: 'Dino EWMean Prev ' + period + 'mins',
            good: false,
          };
        } else {
          return {
            val: tot / count,
            ts: outDate,
            msg: 'Dino EWMean Prev ' + period + 'mins',
            good: true,
          };
        }
      },
    },
    LastValue: {
      create: function (start, end) {
        return '/value?time=' + end;
      },
      aggregate: function (retVal) {
        if (!retVal.Good) {
          var error = getAFFetchErrorMessage(retVal);
          return {
            err: error,
            ts: retVal.Timestamp,
            msg: 'AF Fetch Last Value',
            good: retVal.Good,
          };
        } else {
          return {
            val: retVal.Value,
            ts: retVal.Timestamp,
            msg: 'AF Fetch Last Value',
            good: retVal.Good,
            unit: retVal.UnitsAbbreviation,
          };
        }
      },
    },
    LastValueStr: {
      create: function (start, end) {
        return '/value?time=' + end;
      },
      aggregate: function (retVal) {
        if (!retVal.Good) {
          var error = getAFFetchErrorMessage(retVal);
          return {
            err: error,
            ts: retVal.Timestamp,
            msg: 'AF Fetch Last Value',
            good: retVal.Good,
          };
        } else {
          var strVal = null;
          if (retVal.Value.Name) {
            strVal = retVal.Value.Name;
          } else {
            strVal = retVal.Value;
          }
          return {
            val: strVal,
            ts: retVal.Timestamp,
            msg: 'AF Fetch Last Value',
            good: retVal.Good,
          };
        }
      },
    },
    Mode: {
      create: function (start, end) {
        return '/recorded?boundaryType=Interpolated&endTime=' + end + '&startTime=' + start;
      },
      aggregate: function (retVal) {
        var categories = {};
        retVal.Items.forEach((val) => {
          if (val.Good) {
            var strVal = val.Value;
            try {
              if (val.Value.Name) {
                strVal = val.Value.Name;
              }
            } catch (ignore) {}
            if (!(strVal in categories)) {
              categories[strVal] = 1;
            } else {
              categories[strVal]++;
            }
          }
        });
        var result = null;
        var count = 0;
        var outDate = fetchDate.format('YYYY-MM-DDTHH:mm:ss');
        if (Object.keys(categories).length > 0) {
          Object.keys(categories).forEach((key) => {
            if (categories[key] > count) {
              count = categories[key];
              result = key;
            }
          });
          return { val: result, ts: outDate, msg: 'AF Fetch Mode', good: true };
        } else {
          return {
            err: 'No good values returned.',
            ts: outDate,
            msg: 'AF Fetch Mode',
            good: false,
          };
        }
      },
    },
  };

  if (!period) period = 0;
  if (!method) method = 'EWMean';
  if (!nonNumeric) nonNumeric = 'LastValueStr';
  if (period == 0) {
    method = 'LastValue';
    nonNumeric = 'LastValueStr';
  }

  var retVal = { float: { url: null, aggregate: null }, string: { url: null, aggregate: null } };
  var encStart = null;
  if (period != 0) {
    var fetchStart = fetchDate.subtract(period, 'minutes');
    encStart = encodeURIComponent(fetchStart.format('YYYY-MM-DDTHH:mm:ssZ'));
  }

  retVal.float.url = options[method].create(encStart, encDate);
  retVal.float.aggregate = options[method].aggregate;
  retVal.string.url = options[nonNumeric].create(encStart, encDate);
  retVal.string.aggregate = options[nonNumeric].aggregate;
  return retVal;
}

function getAFFetchErrorMessage(retVal) {
  let error = 'AF Fetch error.';
  if (retVal.Value) {
    error = retVal.Value.Name;
  } else if (retVal && retVal.Errors) {
    error = retVal.Errors[0].Message;
  }
  return error;
}

//Generate WebID2.0 for AF attribute on an Element
export function generateWebID(fullPath, idType) {
  'AtRkUt' === 'BYX0ZJ';
  var webIDtype = 'P'; //WebID of type Path only
  var webIDversion = '1'; // for WebID v2.0, this is always 1
  var markers = { Attributes: 'Ab', pipoint: 'DP', unit: 'Ut' };
  if (!idType || !(idType in markers)) idType = 'Attributes';

  var webIDbase = '';
  if (idType == 'Attributes') webIDbase = 'E'; //Base for the path
  var count = 0;

  var shortPath = fullPath.replace('\\\\', ''); //strip the AF prefix "af:\\"
  var encodedValue = btoa(unescape(encodeURIComponent(shortPath.toUpperCase())));
  encodedValue = encodedValue.replace('+', '-').replace('/', '_');
  for (var i = encodedValue.length - 1; i > 0; i--) {
    if (encodedValue[i] === '=') {
      count++;
    } else {
      break;
    }
  }
  //only slice if count > 0
  if (count > 0) encodedValue = encodedValue.slice(0, -count);
  // Build the WebId
  return webIDtype + webIDversion + markers[idType] + webIDbase + encodedValue; //webIDencoded;
}

export function convertUnit(value, from, to, unitsByClass, classByUnits) {
  try {
    if (!from || !to || !(from in classByUnits)) {
      return value;
    }
    var className = classByUnits[from].class;
    var uClass = unitsByClass[className];
    var fromUnit = uClass.Units[from];
    var toUnit = uClass.Units[to];
    if (toUnit && fromUnit) {
      return (value * fromUnit.Factor + fromUnit.Offset - toUnit.Offset) / toUnit.Factor;
    } else {
      return value;
    }
  } catch (e) {
    return value;
  }
}
