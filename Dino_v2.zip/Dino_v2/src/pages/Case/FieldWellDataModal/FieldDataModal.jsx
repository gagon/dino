import { LoadingButton } from '@mui/lab';
import { Typography } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import { useTheme } from '@mui/styles';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Input from '../../../common/Input/Input';
import Select from '../../../common/Select/Select';
import SideMenuItemModal from '../../../common/SideMenuItemModal/SideMenuItemModal';
import {
  FIELD_FETCH_METHOD,
  FIELD_FETCH_PERIOD,
  FIELD_NON_NUMERIC,
} from '../../../_helpers/constants';
import FieldDataIcon from '../../../_media/sideBar/FieldDataIcon';
import { loginModule, setParamToUserConfig } from '../../Login/LoginDucks';
import { caseModule, loadFieldPIData } from '../CaseDucks/CaseDucks';
import { caseMenuModule, changeActiveMenu } from '../SideBar/CaseMenuDucks';
import { FIELD_DATA, WELL_DATA } from '../SideBar/MenuItems';
import SideButton from '../SideBar/SideButton';
import useStep from '../useStep';

const fetchOptions = [
  { name: 'Last value', value: 'LastValue' },
  { name: 'Time Weighted Mean', value: 'TWMean' },
  { name: 'Event Weighted Mean', value: 'EWMean' },
  { name: 'Dino Calculated Mean', value: 'DinoEWMean' },
];

const nonNumericOptions = [
  { name: 'Last value', value: 'LastValueStr' },
  { name: 'Mode', value: 'Mode' },
];

export default function FieldDataModal() {
  const { palette } = useTheme();
  const { disabled, fieldNextDisabled } = useStep();
  const dispatch = useDispatch();
  const activeMenu = useSelector((state) => state[caseMenuModule].activeMenu);
  const isActive = activeMenu === FIELD_DATA;
  const style = {
    fill: isActive
      ? palette.common.white
      : disabled
      ? palette.action.disabled
      : palette.action.active,
  };
  const loading = useSelector((state) => state[caseModule].loadingFieldData);
  const fetchPeriod = useSelector((state) => state[loginModule].userConfig[FIELD_FETCH_PERIOD]);
  const fetchMethod = useSelector((state) => state[loginModule].userConfig[FIELD_FETCH_METHOD]);
  const nonNumeric = useSelector((state) => state[loginModule].userConfig[FIELD_NON_NUMERIC]);

  const onChange = (event, paramName) => {
    dispatch(setParamToUserConfig(paramName, event.target.value));
  };
  const loadData = () => {
    dispatch(loadFieldPIData({ fetchPeriod, fetchMethod, nonNumeric }));
  };
  const nextBtnHandle = () => {
    dispatch(changeActiveMenu(WELL_DATA));
  };
  const onOpen = () => {
    dispatch(changeActiveMenu(FIELD_DATA));
  };

  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton disabled={disabled} onClick={onOpen}>
            <FieldDataIcon style={style} />
          </IconButton>
        }
      />

      <p
        className="fs-10"
        style={{ marginTop: 0, color: disabled ? palette.action.disabled : 'inherit' }}
        children={'Field Data'}
      />
      {isActive && (
        <SideMenuItemModal isOpen={isActive} close={() => dispatch(changeActiveMenu(null))}>
          <div style={{ width: 250 }}>
            <Typography style={{ marginBottom: 20 }}>Field Data fetch settings</Typography>
            <Input
              label={'Fetch period (min)'}
              withoutForm
              value={fetchPeriod}
              style={{ marginBottom: 16 }}
              onChange={(value) => onChange({ target: { value } }, FIELD_FETCH_PERIOD)}
            />
            <Select
              label={'Numeric fecth method'}
              withoutForm
              value={fetchMethod}
              style={{ marginBottom: 16 }}
              options={fetchOptions}
              onChange={(e) => onChange(e, FIELD_FETCH_METHOD)}
            />
            <Select
              label={'Non numeric method'}
              withoutForm
              value={nonNumeric}
              options={nonNumericOptions}
              onChange={(e) => onChange(e, FIELD_NON_NUMERIC)}
            />
            <div className="flex justify-center" style={{ marginTop: 15 }}>
              <LoadingButton
                loading={loading}
                children={'Load data'}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23, marginRight: 2 }}
                onClick={loadData}
              />
              <LoadingButton
                loading={loading}
                children={'Next >'}
                disabled={fieldNextDisabled}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23 }}
                onClick={nextBtnHandle}
              />
            </div>
          </div>
        </SideMenuItemModal>
      )}
    </>
  );
}
