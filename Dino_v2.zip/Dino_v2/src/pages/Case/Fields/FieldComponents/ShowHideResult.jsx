import React from 'react';
import { useSelector } from 'react-redux';
import { caseMenuModule } from '../../SideBar/CaseMenuDucks';
import { VIEW_RESULTS } from '../../SideBar/MenuItems';

export default function ShowHideResult({ isResult, children }) {
  const activeMenu = useSelector((state) => state[caseMenuModule].activeMenu);
  const showResult = activeMenu === VIEW_RESULTS;

  if (isResult) {
    return showResult ? children : null;
  } else {
    return children;
  }
}
