import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import Highcharts from 'highcharts/highstock';
import moment from 'moment';

import { StreamsApi } from '../../../../_helpers/service';
import { generateWebID } from '../../FieldWellDataModal/FieldWellDataUtils';
import { loginModule } from '../../../Login/LoginDucks';
import { DATE_FORMAT } from '../../../../common/_MuiHookForm/DesktopDatePicker';
import { initialOptions } from './constants';

const ReactHighcharts = require('react-highcharts');

const Chart = ({
  selectedStartTime,
  selectedEndTime,
  title,
  desiredUnits,
  onChartClick,
  isTimePicker,
  sourceTag,
  dataSource,
  isStringDataType,
}) => {
  const afServer = useSelector((state) => state[loginModule].appConfig['AF:AFServer']);
  const [options, setOptions] = useState(initialOptions);

  const convertData = (item) => {
    if (isStringDataType) {
      const value = item.Value === 'ONLINE' || item.Value === 'OPEN' ? 1 : 0;
      return {
        x: moment(item.Timestamp).valueOf(),
        y: value,
        stringValue: item.Value,
      };
    }
    return [moment(item.Timestamp).format('LLL'), item.Value];
  };

  const loadCharts = async (sourceTag, sourceType, desiredUnits) => {
    try {
      const webId = generateWebID(sourceTag, sourceType);
      const encStartTime = encodeURIComponent(
        moment(selectedStartTime, DATE_FORMAT).format('YYYY-MM-DDTHH:mm:ssZ')
      );
      const encEndTime = encodeURIComponent(
        moment(selectedEndTime, DATE_FORMAT).format('YYYY-MM-DDTHH:mm:ssZ')
      );
      const { data } = await StreamsApi.loadStreams(
        afServer,
        webId,
        encStartTime,
        encEndTime,
        desiredUnits
      );
      moment.locale('en');
      const convertedData = data?.Items.filter((item) => typeof item.Value !== 'object').map(
        convertData
      );

      setOptions((prevOptions) => ({
        ...prevOptions,
        series: [
          {
            type: isStringDataType ? 'line' : 'spline',
            step: 'left',
            data: convertedData,
            name: title,
          },
        ],
        tooltip: isStringDataType
          ? {
              formatter() {
                return `${moment(this.x).format('LLL')}<br/>${this.point.stringValue}`;
              },
            }
          : {},
        yAxis: {
          min: isStringDataType ? -1 : undefined,
          max: isStringDataType ? 2 : undefined,
          title: {
            text: null,
          },
          labels: {
            enabled: !isStringDataType,
          },
        },
        chart: {
          zoomType: 'x',
          events: {
            selection: function (event) {
              event.preventDefault();

              const series = this.series[0];
              const selectedPoints = series.points.slice(
                event.xAxis[0].min,
                event.xAxis[0].max + 1
              );

              const sum = selectedPoints.reduce((total, point) => {
                return !isNaN(point.y) ? total + point.y : total;
              }, 0);
              const count = selectedPoints.filter((point) => !isNaN(point.y)).length;
              const average = sum / count;

              onChartClick && onChartClick(average.toFixed(2));
            },
          },
        },
        plotOptions: {
          series: {
            point: {
              events: {
                click() {
                  let point = this;
                  onChartClick && !isStringDataType && onChartClick(point.y.toFixed(2));
                },
              },
            },
          },
        },
      }));
    } catch (e) {
      console.error('Failed to load streams', e);
    }
  };

  useEffect(() => {
    if (isTimePicker) {
      loadCharts(sourceTag, dataSource, desiredUnits);
    }
  }, [selectedStartTime, selectedEndTime, desiredUnits, isTimePicker, sourceTag, dataSource]);

  return (
    <div onMouseMove={(e) => e.stopPropagation()}>
      <ReactHighcharts highcharts={Highcharts} config={options} />
    </div>
  );
};

export default Chart;
