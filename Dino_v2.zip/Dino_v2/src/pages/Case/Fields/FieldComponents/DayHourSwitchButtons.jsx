import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Box, useTheme } from '@mui/material';

import { loginModule, setIsHourUnits } from '../../../Login/LoginDucks';

const DayHourSwitchButtons = () => {
  const isHourUnits = useSelector((state) => state[loginModule].userConfig.isHourUnits);
  const { palette } = useTheme();
  const dispatch = useDispatch();

  const onSwitchHandler = (value) => {
    dispatch(setIsHourUnits(value));
  };

  return (
    <Box
      orientation="horizontal"
      sx={{
        display: 'flex',
        alignItems: 'end',
        gap: '8px',
      }}
    >
      <Button
        variant="outlined"
        style={{
          backgroundColor: isHourUnits ? palette.primary.main : 'white',
          color: isHourUnits ? 'white' : '',
          height: 32,
        }}
        onClick={() => onSwitchHandler(true)}
      >
        HOUR
      </Button>
      <Button
        variant="outlined"
        style={{
          backgroundColor: isHourUnits ? 'white' : palette.primary.main,
          color: isHourUnits ? '' : 'white',
          height: 32,
        }}
        onClick={() => onSwitchHandler(false)}
      >
        DAY
      </Button>
    </Box>
  );
};

export default DayHourSwitchButtons;
