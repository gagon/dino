import React from 'react';
import { useSelector } from 'react-redux';
import { caseModule } from '../../CaseDucks/CaseDucks';
import { filterTypes } from '../../../../common/FieldSchema/filterTypesConstants';

export default function ShowHideField({ group, name, children }) {
  const type = filterTypes[group] && filterTypes[group][name] ? filterTypes[group][name] : 'none';
  const show = useSelector((state) => type === 'none' || state[caseModule].filterFields[type]);
  return show ? children : null;
}

export function ShowHideBlock({ type, children }) {
  const show = useSelector((state) => type === 'none' || state[caseModule].filterFields[type]);
  return type ? (show ? children : null) : children;
}
