import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Divider, Select, MenuItem } from '@mui/material';
import moment from 'moment';

import PopoverWindow from '../../../common/Popover/Popover';
import Chart from './FieldComponents/Chart';
import DatePicker, { DATE_FORMAT } from '../../../common/_MuiHookForm/DesktopDatePicker';
import { caseModule, setHoveredUnit } from '../CaseDucks/CaseDucks';
import { COLORS, COLOR_KEYS } from './FieldsConstants';
import { CALCULATED } from '../../../common/FieldSchema/FieldSchemaConstants';
import { InputPopoverStyle, selectStyle } from './styles';

export default function InputFieldModal({
  value = '',
  data,
  isResult,
  displayedUom,
  onChange,
  selectedUnits,
  setSelectedUnits,
  anchorEl,
  setAnchorEl,
}) {
  const dispatch = useDispatch();
  const fieldData = useSelector((state) => state[caseModule].fields);
  const calcDict = useSelector((state) => state[caseModule].calculation?.calcDict);
  const fbTotal = useSelector((state) => state[caseModule].fieldBalance?.totals);
  const classByUnits = useSelector((state) => state[caseModule].classByUnits);
  const unitsByClass = useSelector((state) => state[caseModule].unitsByClass);
  const [selectedStartTime, setSelectedStartTime] = useState(null);
  const [selectedEndTime, setSelectedEndTime] = useState(null);

  const baseUnits = data?.uom;
  const dataSource = data?.data_source;
  const sourceTag = data?.source_tag;
  const configGroup = data?.config_group;
  const name = data?.name;
  const timestamp = data?.timestamp;
  const isTimePicker = data?.time_picker;
  const chartDays = data?.chart_days;
  const defaultValue = data?.default_val;
  const unitsData = unitsByClass?.[classByUnits?.[baseUnits]?.class];

  const title = useMemo(() => {
    if (configGroup && name) {
      return `${configGroup} - ${name}`;
    }
    return name;
  }, [configGroup, name]);

  const times = useMemo(() => {
    if (timestamp && isTimePicker) {
      const defaultStartTime = moment(timestamp).subtract(chartDays, 'day');
      const defaultEndTime = moment(timestamp);
      return { defaultStartTime, defaultEndTime };
    }
    return { defaultStartTime: null, defaultEndTime: null };
  }, [timestamp, isTimePicker, chartDays]);

  function getMatchedFieldsFromSourceType(source, fieldData, calcDict, fbTotal) {
    let match;
    const sourceTag = source.replaceAll("'", '"');
    const regexMatchFields = /fieldValue\("([^"]+)+",\s?"([^"]+)+"\)/g;
    const regexMatchUnits = /unitTotal\("([^"]+)+",\s?"([^"]+)+"\)/g;
    const regexMatchCalc = /calcValue\("([^"]+)+"\)/g;
    const regexMatchCaseVals = /calcCaseValue\("([^"]+)+"\)/g;
    const matchedFields = [];

    while ((match = regexMatchFields.exec(sourceTag)) !== null) {
      if (match && match.length >= 3) {
        const [sourceName, group, name] = match;
        const value = fieldData[group] ? fieldData[group][name]?.value : '';
        const color = COLORS[COLOR_KEYS[(COLOR_KEYS.length * Math.random()) << 0]];
        matchedFields.push({
          sourceName,
          group,
          name,
          value,
          color,
          groupError: !(group in fieldData) ? 'Invalid group name.' : '',
          nameError: !(name in fieldData[group]) ? 'Invalid field item name!' : '',
        });
      }
    }

    while ((match = regexMatchUnits.exec(sourceTag)) !== null) {
      if (match && match.length >= 3) {
        const [sourceName, unit, name] = match;
        const value = fbTotal && fbTotal[unit] ? Number(fbTotal[unit][name]).toFixed(2) : '';
        const color = COLORS[COLOR_KEYS[(COLOR_KEYS.length * Math.random()) << 0]];
        matchedFields.push({
          sourceName,
          unit,
          name,
          value,
          color,
          unitError: !(unit in fbTotal) ? 'Invalid unit name.' : '',
        });
      }
    }

    while ((match = regexMatchCalc.exec(sourceTag)) !== null) {
      if (match && match.length >= 2) {
        const [sourceName, name] = match;
        const value = calcDict[name]
          ? Number(calcDict[name].results?.default?.value).toFixed(2)
          : '';
        const color = COLORS[COLOR_KEYS[(COLOR_KEYS.length * Math.random()) << 0]];
        matchedFields.push({
          sourceName,
          name,
          value,
          color,
          error: !calcDict[name] ? 'Is not a known calculation value' : '',
        });
      }
    }

    while ((match = regexMatchCaseVals.exec(sourceTag)) !== null) {
      if (match && match.length >= 2) {
        const [sourceName, name] = match;
        const value = calcDict[name]
          ? Number(calcDict[name].results?.default?.value).toFixed(2)
          : '';
        const color = COLORS[COLOR_KEYS[(COLOR_KEYS.length * Math.random()) << 0]];
        matchedFields.push({
          sourceName,
          name,
          value,
          color,
          error: !calcDict[name] ? 'Is not a known calculation value' : '',
        });
      }
    }

    return matchedFields;
  }

  const dataVariables = useMemo(() => {
    if (dataSource === CALCULATED || isResult) {
      return getMatchedFieldsFromSourceType(sourceTag, fieldData, calcDict, fbTotal);
    }
    return [];
  }, [dataSource, sourceTag, fieldData, calcDict, fbTotal, isResult]);

  const resultFormula = useMemo(() => {
    if (dataSource !== CALCULATED && !isResult) return '';
    let formula = sourceTag.replaceAll("'", '"');
    for (const field of dataVariables) {
      formula = formula
        .replace(/",\s+"/g, '","')
        .replace(
          `fieldValue("${field.group}","${field.name}")`,
          `<span style="color: ${field.color};" title="${field.group}: ${field.name}">${field.value}</span>`
        )
        .replace(
          `unitTotal("${field.unit}","${field.name}")`,
          `<span style="color: ${field.color};" title="${field.unit}: ${field.name}">${field.value}</span>`
        )
        .replace(
          `calcValue("${field.name}")`,
          `<span style="color: ${field.color};" title="${field.name}">${field.value}</span>`
        )
        .replace(
          `calcCaseValue("${field.name}")`,
          `<span style="color: ${field.color};" title="${field.name}">${field.value}</span>`
        );
    }
    return `<span>${value} = </span>${formula}`;
  }, [dataSource, sourceTag, dataVariables, value, isResult]);

  const units = useMemo(() => {
    if (unitsData?.Units) {
      return Object.keys(unitsData.Units);
    }
    return [];
  }, [unitsData]);

  const onInputFieldHovered = (unitName) => {
    dispatch(setHoveredUnit(unitName));
  };

  useEffect(() => {
    return () => {
      setSelectedUnits(null);
    };
  }, []);

  return (
    <PopoverWindow open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={() => setAnchorEl(null)}>
      <InputPopoverStyle>
        <div className="title py1 px2">{isResult ? `Calculations - ${title}` : title}</div>
        <Divider />
        <div className="p2">
          {sourceTag && !isResult && (
            <div className="row nowrap">
              <div className="label">Source:</div>
              <div className="info" title={sourceTag}>
                {sourceTag}
              </div>
            </div>
          )}

          {defaultValue !== undefined && !isResult && (
            <div className="row nowrap">
              <div className="label">Default Value:</div>
              <div className="info">{defaultValue}</div>
            </div>
          )}

          {baseUnits && !isResult && (
            <div className="row nowrap">
              <div className="label">Base Unit:</div>
              <div className="info">{baseUnits}</div>
            </div>
          )}

          {baseUnits && !isResult && (
            <div className="row nowrap">
              <div className="label">Display Unit:</div>
              <Select
                sx={selectStyle}
                value={selectedUnits || displayedUom}
                onChange={(e) => setSelectedUnits(e.target.value)}
              >
                {units.map((unit) => {
                  const { Abbreviation, Name } = unitsData?.Units?.[unit];
                  return (
                    <MenuItem
                      key={Abbreviation}
                      value={Abbreviation}
                      sx={{ height: 20, px: 1, py: 1.5, fontSize: 14 }}
                    >
                      {`${Abbreviation} - ${Name}`}
                    </MenuItem>
                  );
                })}
              </Select>
            </div>
          )}

          {dataSource && !isResult && (
            <div className="row nowrap">
              <div className="label">Value Source:</div>
              <div className="info">{dataSource}</div>
            </div>
          )}

          {value !== undefined && !isResult && (
            <div className="row nowrap">
              <div className="label">Current Value:</div>
              <div className="info">{value}</div>
            </div>
          )}

          {timestamp && !isResult && (
            <div className="row nowrap">
              <div className="label">Timestamp:</div>
              <div className="info">{timestamp ? moment(timestamp).format(DATE_FORMAT) : ''}</div>
            </div>
          )}

          {isTimePicker && timestamp && dataSource !== CALCULATED && !isResult && (
            <>
              <div className="row date_picker">
                <div className="label">Start:</div>
                <DatePicker
                  value={selectedStartTime || times.defaultStartTime}
                  onChange={setSelectedStartTime}
                  fontSize={'13px'}
                  fontWeight={800}
                />
                <div className="end">End:</div>
                <DatePicker
                  value={selectedEndTime || times.defaultEndTime}
                  onChange={setSelectedEndTime}
                  fontSize={'13px'}
                  fontWeight={800}
                />
              </div>

              <Chart
                isTimePicker={isTimePicker}
                sourceTag={sourceTag}
                dataSource={dataSource}
                selectedStartTime={selectedStartTime || times.defaultStartTime}
                selectedEndTime={selectedEndTime || times.defaultEndTime}
                title={title}
                desiredUnits={selectedUnits || displayedUom}
                onChartClick={onChange}
              />
            </>
          )}

          {(isResult || dataSource === CALCULATED) && (
            <table className="table-wrapper">
              <thead>
                <tr>
                  <th className="th-var">Variable</th>
                  <th className="th-value">Value</th>
                </tr>
              </thead>

              <tbody>
                {dataVariables.map(({ sourceName, name, group, value, color }, index) => {
                  return (
                    <tr key={`${group ?? sourceName} : ${index}`}>
                      <td>{isResult ? sourceName : `${group} : ${name}`}</td>
                      <td
                        style={{ color: `${color}` }}
                        onMouseEnter={() =>
                          onInputFieldHovered(group && name ? `${group} - ${name}` : name)
                        }
                        onMouseLeave={() => onInputFieldHovered(null)}
                      >
                        {Number(value).toFixed(2)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>

              <tfoot>
                <tr className="info">
                  <td colSpan={2}>Result</td>
                </tr>
                <tr>
                  <td colSpan={2} dangerouslySetInnerHTML={{ __html: resultFormula }}></td>
                </tr>
              </tfoot>
            </table>
          )}
        </div>
      </InputPopoverStyle>
    </PopoverWindow>
  );
}
