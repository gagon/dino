import styled from '@emotion/styled';
import { makeStyles } from '@mui/styles';

export const Params = styled.div`
  width: 126px;
  height: 189px;
  border: 1px dashed #1ea7ff;
  border-radius: 10px;

  .fieldWrappers {
    background: #eef8ff;
    height: calc(100% - 23px);
    border-bottom-right-radius: 10px;
    border-bottom-left-radius: 10px;
    padding: 16px 7px 16px 7px;
  }
`;

export const FieldWrappers = styled.div`
  background: #eef8ff;
  height: calc(100% - 23px);
  border-bottom-right-radius: 10px;
  border-bottom-left-radius: 10px;
  padding: 16px 7px 16px 7px;
`;

export const rootStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  content: {
    backgroundSize: '50px 50px',
    flexGrow: 1,
    minHeight: 'calc(100vh - 210px)',
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    '& > *': {
      height: '100%',
      minHeight: 800,
      width: '100%',
    },
  },
}));

export const inputFieldStyle = (inChanged, fieldBg, hoveredUnit) => ({
  height: 17,
  width: 64,
  padding: '0px 4px 0px 4px',
  margin: 0,
  border: 'none',
  background: inChanged ? '#FE9E61' : hoveredUnit ? '#50C878' : fieldBg,

  '.MuiOutlinedInput-root': {
    padding: 0,
    border: 'none',
    borderRadius: 0,
    fontSize: 12,
  },

  '.Mui-disabled': {
    textFillColor: inChanged ? 'white' : 'black',
  },

  '.MuiOutlinedInput-notchedOutline': {
    border: 'none !important',
  },
});

export const InputContainerStyle = styled.div`
  border: ${(props) => (props.isConstraint ? '2px solid #F12BA8' : 'none')};
  border-radius: 6px;
  margin-bottom: 4px;
  overflow: hidden;

  .title {
    position: absolute;
    white-space: nowrap;
    font-size: 12px;
  }
  .position-left {
    right: 120px;
    top: -2px;
  }
  .position-right {
    left: 120px;
    top: -2px;
    text-align: right;
  }
  .position-top {
    bottom: 22px;
  }
  .position-bottom {
    top: 22px;
  }
`;

export const inputFieldbtnStyle = (buttonBg, hoveredUnit, isConstraint) => ({
  background: hoveredUnit ? 'green' : buttonBg,
  height: 17,
  width: 50,
  minWidth: 50,
  padding: '2px 4px 2px 4px',
  margin: 0,
  borderBottomLeftRadius: 0,
  borderTopLeftRadius: 0,
  borderBottomRightRadius: 5,
  borderTopRightRadius: 5,
  marginLeft: '-1px',
  textTransform: 'none',
  border: isConstraint ? '2px solid #F12BA8' : 'none',
});

export const inputPropsStyle = (inChanged) => ({
  style: {
    padding: 0,
    border: 'none',
    borderRadius: 0,
    color: 'black',
  },
});

export const selectStyle = {
  height: 12,
  minWidth: 140,
  px: '4px',
  py: 1.5,
  pl: '16px',
  fontWeight: 'bold',
  fontSize: 14,
  '&.Mui-focused fieldset': {
    borderColor: '#848884 !important',
    borderWidth: '1px !important',
  },
};

export const InputPopoverStyle = styled.div`
  max-width: 580px;

  .title {
    background-color: #efefef;
  }

  .row {
    text-overflow: ellipsis;
    overflow: hidden;
    display: flex;
    align-items: center;
  }

  .label {
    min-width: 116px;
    text-align: right;
    margin-right: 10px;
  }

  .info {
    font-weight: bold;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .date_picker {
    margin-top: -5px;
  }

  .end {
    margin: 0 10px;
  }

  .table-wrapper {
    width: 100%;
    border: 0.5px solid rgba(0, 0, 0, 0.25);
    border-radius: 5px;
    padding: 5px 5px;
    margin: 5px 0;
    text-align: left;
  }

  .th-var {
    width: 70%;
  }

  .th-value {
    width: 15%;
  }
`;
