import React, { useState, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { TextField } from '@mui/material';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

import { loginModule } from '../../Login/LoginDucks';
import { caseModule, changeFieldValue } from '../CaseDucks/CaseDucks';
import { convertUnit } from '../FieldWellDataModal/FieldWellDataUtils';
import FieldArrowIcon from '../../../_media/FieldArrowIcon';
import ShowHideResult from './FieldComponents/ShowHideResult';
import InputFieldModal from './InputFieldModal';
import ShowHideField from './FieldComponents/ShowHideField';

import {
  InputContainerStyle,
  inputFieldbtnStyle,
  inputFieldStyle,
  inputPropsStyle,
} from './styles';

export default function InputField({
  data: { name, config_group, fieldName, ...props },
  isResult,
}) {
  let fieldBg = '#FAFAD2';
  let buttonBg = '#EDB901';

  if (isResult) {
    fieldBg = 'rgb(157 247 212)';
    buttonBg = '#1d9868';
  }

  const { value, hourValue, savedValue, ...data } = useSelector((state) => {
    if (isResult) {
      if (state[caseModule]?.calculation?.calcDict) {
        if (state[caseModule]?.calculation?.calcDict[name]) {
          if (state[caseModule]?.calculation?.calcDict[name]?.results?.default) {
            return {
              ...state[caseModule]?.calculation?.calcDict[name].results.default,
              name: state[caseModule]?.calculation?.calcDict[name].name,
              uom: state[caseModule]?.calculation?.calcDict[name].uom,
            };
          }
        }
      }
    } else {
      if (state[caseModule].fields[config_group]) {
        if (state[caseModule].fields[config_group][name]) {
          return state[caseModule].fields[config_group][name];
        }
      }
    }
    return { value: '', hourValue: '', savedValue: '' };
  });

  const dispatch = useDispatch();
  const isConstraint = data.is_constraint;
  const isExport = data.config_group === 'Export' && !isConstraint;
  const classByUnits = useSelector((state) => state[caseModule].classByUnits);
  const unitsByClass = useSelector((state) => state[caseModule].unitsByClass);
  const hoveredUnit = useSelector((state) => state[caseModule].hoveredUnit);
  const isHourUnits = useSelector((state) => state[loginModule].userConfig.isHourUnits);

  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedUnits, setSelectedUnits] = useState(null);

  const inChanged = isResult ? false : savedValue !== value;
  const baseUnits = data?.uom;

  const title = useMemo(() => {
    if (data?.config_group && data?.name) {
      return `${data?.config_group} - ${data?.name}`;
    }
    return data?.name;
  }, [data?.config_group, data?.name]);

  const sx = useMemo(
    () => inputFieldStyle(inChanged, fieldBg, hoveredUnit === title),
    [inChanged, fieldBg, hoveredUnit]
  );
  const sxBtn = useMemo(
    () => inputFieldbtnStyle(buttonBg, hoveredUnit === title),
    [buttonBg, hoveredUnit]
  );
  const inputProps = useMemo(() => inputPropsStyle(inChanged), [inChanged]);

  const displayedUom = useMemo(() => {
    if (baseUnits && isHourUnits && baseUnits.includes('/d')) {
      return baseUnits.replace('/d', '/h');
    }
    return baseUnits;
  }, [baseUnits, isHourUnits]);

  const displayedValue = useMemo(() => {
    if (value === undefined) {
      return '';
    } else if (isResult) {
      return baseUnits && isHourUnits && baseUnits.includes('/d')
        ? Number(value / 24).toFixed(2)
        : Number(value).toFixed(2);
    } else if (baseUnits && isHourUnits && baseUnits.includes('/d')) {
      return hourValue || '';
    } else {
      return value;
    }
  }, [value, hourValue, isHourUnits, isResult, baseUnits]);

  const onChange = (value) => {
    let convertedValue = value;
    if (selectedUnits) {
      convertedValue = convertUnit(value, selectedUnits, baseUnits, unitsByClass, classByUnits);
    }
    dispatch(
      changeFieldValue(
        {
          ...data,
          value: convertedValue,
        },
        displayedUom,
        isHourUnits
      )
    );
  };

  return (
    <ShowHideResult isResult={isResult}>
      <ShowHideField group={config_group} name={isResult ? fieldName : name}>
        <InputContainerStyle
          className="flex items-center justify-center"
          isConstraint={isConstraint}
        >
          {['left', 'top'].includes(data.label_pos || props.label_pos) && (
            <div className={'title position-' + (data.label_pos || props.label_pos)}>
              {isResult ? fieldName : data.name}
            </div>
          )}
          <TextField
            sx={sx}
            inputProps={inputProps}
            disabled={isResult}
            value={displayedValue}
            onChange={(e) => onChange(e.target.value)}
          />
          <Button onClick={(e) => setAnchorEl(e.currentTarget)} sx={sxBtn}>
            <div className="fullWidth flex justify-between items-center">
              <Typography
                sx={{
                  fontSize: 9,
                  color: isExport ? 'black' : 'white',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                }}
                children={displayedUom}
              />
              <FieldArrowIcon
                stroke={isExport ? 'black' : 'white'}
                style={{ fontSize: 9, marginRight: 3, marginLeft: 3 }}
              />
            </div>
          </Button>
        </InputContainerStyle>

        {anchorEl && (
          <InputFieldModal
            value={value}
            data={data}
            anchorEl={anchorEl}
            setAnchorEl={setAnchorEl}
            onChange={onChange}
            selectedUnits={selectedUnits}
            setSelectedUnits={setSelectedUnits}
            displayedUom={displayedUom}
            isResult={isResult}
          />
        )}
      </ShowHideField>
    </ShowHideResult>
  );
}
