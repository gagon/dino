import React from 'react';
import { CanvasWidget } from '@projectstorm/react-canvas-core';
import { Typography, useTheme } from '@mui/material';
import DayHourSwitchButtons from './FieldComponents/DayHourSwitchButtons';
import { rootStyles } from './styles';
import FieldLegend from '../../../common/FieldLegend/FieldLegend';
import { getModel } from '../../../common/FieldSchema/FieldSchemaObjects';
import Slider from '@mui/material/Slider';

export const { engine, model } = getModel();
model.setLocked(true);
model.setOffsetY(window.innerWidth < 1600 ? 70 : 120);
model.setZoomLevel(window.innerWidth < 1600 ? 72 : 90);

export default function Fields() {
  const { palette } = useTheme();
  const classes = rootStyles('white', 'black');

  return (
    <>
      <div className="relative" style={{ zIndex: 2 }}>
        <div className="flex pb2 pr2" style={{ position: 'absolute', backgroundColor: '#E8E8F0' }}>
          <Typography variant={'h5'} children={'Fields'} style={{ color: palette.action.active }} />
        </div>
        <div
          className="flex pb2 pl2"
          style={{ position: 'absolute', right: 0, backgroundColor: '#E8E8F0' }}
        >
          <FieldLegend />
          <DayHourSwitchButtons />
        </div>
      </div>
      <div className="flex">
        <div style={{ marginTop: 90 }}>
          <div style={{ height: 200 }}>
            <Slider
              size="small"
              defaultValue={window.innerWidth < 1600 ? 12 : 30}
              valueLabelDisplay="auto"
              orientation="vertical"
              onChange={(ev, zoom) => {
                model.setZoomLevel(zoom + 60);
                engine.repaintCanvas();
              }}
            />
          </div>
        </div>
        <div className={classes.content}>
          <CanvasWidget engine={engine} />
        </div>
      </div>
    </>
  );
}
