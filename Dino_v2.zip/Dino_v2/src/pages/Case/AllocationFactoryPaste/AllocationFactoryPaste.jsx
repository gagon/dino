import ContentPasteGoIcon from '@mui/icons-material/ContentPasteGo';
import { LoadingButton } from '@mui/lab';
import { Checkbox, IconButton, Typography, useTheme } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import SideMenuItemModal from '../../../common/SideMenuItemModal/SideMenuItemModal';
import { setAllocationFactory } from '../CaseDucks/CaseDucks';
import { caseMenuModule, changeActiveMenu } from '../SideBar/CaseMenuDucks';
import { ALLOCATION_FACTORY, OPTIMIZATION } from '../SideBar/MenuItems';
import SideButton from '../SideBar/SideButton';
import useStep from '../useStep';

export default function AllocationFactoryPaste() {
  const { palette } = useTheme();
  const { afDisabled } = useStep();
  const dispatch = useDispatch();
  const { activeMenu } = useSelector((state) => state[caseMenuModule]);
  const [copied, setCopied] = useState(false);
  const [insertOne, setInsertOne] = useState(false);
  const disabled = afDisabled || !copied;
  const isActive = activeMenu === ALLOCATION_FACTORY;
  const iconColor = isActive
    ? palette.common.white
    : afDisabled
    ? palette.action.disabled
    : palette.action.active;
  const nextBtnHandle = () => {
    dispatch(changeActiveMenu(OPTIMIZATION));
  };

  useEffect(() => {
    const interval = setInterval(() => {
      const stringAfValues = localStorage.getItem('afValues');
      setCopied(!!stringAfValues);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton
            disabled={afDisabled}
            onClick={() => dispatch(changeActiveMenu(ALLOCATION_FACTORY))}
          >
            <ContentPasteGoIcon style={{ color: iconColor }} disabled={afDisabled} />
          </IconButton>
        }
      />
      <p
        className="fs-10"
        style={{ marginTop: 0, color: afDisabled ? palette.action.disabled : 'inherit' }}
        children={'Paste AFs'}
      />

      {isActive && (
        <SideMenuItemModal isOpen={isActive} close={() => dispatch(changeActiveMenu(null))}>
          <div style={{ width: 300 }}>
            <Typography style={{ marginBottom: 10, fontWeight: 'bold' }}>
              Paste allocation factors
            </Typography>
            <div>Do you want to paste allocation factors?</div>

            <div className="flex items-center" style={{ marginTop: 12 }}>
              <Typography color="textSecondary" children="Check to paste value 1" />
              <Checkbox
                sx={{ padding: 0, marginLeft: 2 }}
                disabled={disabled}
                checked={insertOne}
                onChange={({ target: { checked } }) => setInsertOne(checked)}
              />
            </div>
            <div className="flex justify-center" style={{ marginTop: 15 }}>
              <LoadingButton
                children={'Paste'}
                disabled={disabled}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23, marginRight: 2 }}
                onClick={() => dispatch(setAllocationFactory(insertOne))}
              />
              <LoadingButton
                children={'Next >'}
                disabled={disabled}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23 }}
                onClick={nextBtnHandle}
              />
            </div>
          </div>
        </SideMenuItemModal>
      )}
    </>
  );
}
