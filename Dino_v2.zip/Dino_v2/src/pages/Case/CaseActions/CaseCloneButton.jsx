import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';
import {
  FormControl,
  InputLabel,
  Menu,
  MenuItem,
  Select,
  ToggleButton,
  Typography,
  useTheme,
} from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import { CLONE_CASE_GAP_SETTING } from '../../../_helpers/constants';
import { loginModule, setParamToUserConfig } from '../../Login/LoginDucks';
import { caseModule, cloneCase } from '../CaseDucks/CaseDucks';
import { ToggleButtonGroup } from './CaseActionStyle';

const LATESTGAPFILE = 'LatestGapFile';
const SAMEGAPFILE = 'SameGapFile';

export default function CaseClonButton({ closeModal }) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { palette } = useTheme();
  const loading = useSelector((state) => state[caseModule].loadingCloneCase);  
  const id = useSelector((state) => state[caseModule].caseData.id);

  const [menuAnchor, setMenuAnchor] = useState(null);
  const caseDefaultGap = useSelector(
    (state) => state[loginModule].userConfig[CLONE_CASE_GAP_SETTING]
  );
  const saveGapSettings = (event) => {
    dispatch(setParamToUserConfig(CLONE_CASE_GAP_SETTING, event.target.value));
  };

  return (
    <>
      <ToggleButtonGroup exclusive fullWidth>
        <ToggleButton
          disabled={loading || !parseInt(id)}
          children={loading ? <CircularProgress size={20} /> : 'Clone case'}
          onClick={() => dispatch(cloneCase(navigate, closeModal))}
          value=""
        />
        <ToggleButton
          style={{ width: 47 }}
          disabled={loading}
          onClick={(event) => setMenuAnchor(event.target)}
          children={<ArrowRightAltIcon style={{ color: palette.text.primary }} />}
          value=""
        />
      </ToggleButtonGroup>
      <Menu anchorEl={menuAnchor} open={!!menuAnchor} onClose={() => setMenuAnchor(null)}>
        <div style={{ paddingLeft: 22 }}>
          <Typography variant="overline" color="#ADADAD">
            CLONE CASE SETTINGS
          </Typography>
        </div>
        <div className="p2">
          <FormControl fullWidth style={{ width: 300 }}>
            <InputLabel id="clone_case_gap_setting">Clone to GAP</InputLabel>
            <Select
              labelId="clone_case_gap_setting"
              value={caseDefaultGap || LATESTGAPFILE}
              label="Clone cse to GAP"
              onChange={saveGapSettings}
            >
              <MenuItem value={SAMEGAPFILE}>Use same GAP</MenuItem>
              <MenuItem value={LATESTGAPFILE}>Use latest GAP</MenuItem>
            </Select>
          </FormControl>
        </div>
      </Menu>
    </>
  );
}
