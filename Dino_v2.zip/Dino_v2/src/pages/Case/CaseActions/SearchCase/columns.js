import Button from '@mui/material/Button';
import moment from 'moment';
import Checkbox from '@mui/material/Checkbox';
import React from 'react';

const DATE_FORMAT = 'DD/MM/yyyy HH:mm:ss';

export const caseColumns = (palette, onSelectCase) => {
  return [
    {
      field: 'id',
      headerName: 'Case id',
      width: 75,
      renderCell: ({ row }) => <TableCell value={row.id} />,
    },
    {
      field: 'timestamp',
      headerName: 'Date',
      width: 160,
      renderCell: ({ row }) => <TableCell value={moment(row.timestamp).format(DATE_FORMAT)} />,
    },
    {
      field: 'name',
      headerName: 'Name',
      flex: 1.2,
      minWidth: 160,
      renderCell: ({ row }) => (
        <span
          style={{ overflow: 'hidden', textOverflow: 'ellipsis', paddingLeft: 5 }}
          title={row.name}
        >
          {row.name}
        </span>
      ),
    },
    {
      field: 'description',
      headerName: 'Description',
      flex: 0.7,
      minWidth: 100,
      renderCell: ({ row }) => <TableCell value={row.description} />,
    },
    {
      field: 'implemented',
      headerName: 'Implemented',
      width: 100,
      align: 'center',
      renderCell: ({ row }) => {
        return <Checkbox checked={row.implemented} disabled sx={{ py: 0 }} />;
      },
    },
    {
      field: 'user',
      headerName: 'Creator',
      flex: 0.6,
      width: 100,
      renderCell: ({ row }) => <TableCell value={row.user} />,
    },
    {
      field: 'gap_file',
      headerName: 'Gap File',
      flex: 1,
      minWidth: 100,
      renderCell: ({ row }) => <TableCell value={row.gap_file} />,
    },
    {
      field: 'gas_opt',
      headerName: 'Gas Opt',
      width: 75,
      align: 'center',
      renderCell: ({ row }) => {
        return <Checkbox checked={row.gas_opt} disabled sx={{ py: 0 }} />;
      },
    },
    {
      field: 'edit_date',
      headerName: 'Last Edit',
      flex: 1,
      width: 160,
      renderCell: ({ row }) => (
        <TableCell value={row.edit_date ? moment.utc(row.edit_date).format(DATE_FORMAT) : ''} />
      ),
    },
    {
      field: 'run_date',
      headerName: 'Last Run',
      flex: 1,
      width: 160,
      renderCell: ({ row }) => (
        <TableCell value={row.run_date ? moment.utc(row.run_date).format(DATE_FORMAT) : ''} />
      ),
    },
    {
      field: 'action',
      headerName: 'Action',
      width: 100,
      renderCell: ({ row }) => {
        return (
          <Button
            size={'small'}
            style={{
              background: palette.action.selected,
              color: palette.text.primary,
              width: 85,
            }}
            children={'open'}
            onClick={() => onSelectCase(row.id)}
          />
        );
      },
    },
  ];
};

const TableCell = ({ value }) => <div style={{ paddingLeft: 5 }}>{value}</div>;
