import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import {
  Button,
  Dialog,
  Pagination,
  PaginationItem,
  Select,
  MenuItem,
  useTheme,
  Paper,
} from '@mui/material';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

import Input from '../../../../common/Input/Input';
import Table from '../../../../common/Table/Table';
import { history } from '../../../../_helpers/history';
import paths from '../../../../_helpers/paths';
import { CaseApi } from '../../../../_helpers/service';
import { caseColumns } from './columns';

const options = [10, 25, 50, 100];
const defaultSortRule = { param: 'edit_date', asc: false };

export default function SearchCaseModal({ isOpen, close, onSelect }) {
  const [caseListData, setCaseListData] = useState({ count: 0, data: [] });
  const [page, setPage] = useState(1);
  const [searchStr, setSearchStr] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [filter, setFilter] = useState({
    searchStr: '',
    offset: 0,
    sort: defaultSortRule,
  });
  const { palette } = useTheme();
  const dispatch = useDispatch();

  const handleRowsPerPage = (e) => {
    setRowsPerPage(e.target.value);
    setPage(1);
  };

  const loadData = () => {
    CaseApi.loadAllCase({ ...filter, limit: rowsPerPage })
      .then(({ data }) => {
        setCaseListData(data);
      })
      .catch((e) => console.error(e));
  };

  const handleChangePage = (event, value) => {
    setPage(value);
    setFilter((prev) => ({ ...prev, offset: (value - 1) * rowsPerPage }));
  };

  const onSearch = () => {
    setFilter((prev) => ({ ...prev, searchStr }));
  };

  const onSelectCase = (id) => {
    window.open(paths.case.replaceAll(':caseId', id), '_self');
  };

  const onSortHandler = (params) => {
    if (params.length < 1) {
      setFilter((prev) => ({ ...prev, sort: defaultSortRule }));
      return;
    }
    setFilter((prev) => ({
      ...prev,
      sort: { param: params[0]?.field, asc: params[0]?.sort === 'asc' ? true : false },
    }));
  };

  useEffect(() => {
    loadData();
  }, [filter, rowsPerPage]);

  return (
    <Dialog
      fullWidth
      maxWidth={'xl'}
      sx={{ background: '#5051F935', zIndex: 5 }}
      PaperProps={{
        sx: {
          borderTopRightRadius: 20,
          borderTopLeftRadius: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
          padding: '28px 36px',
        },
      }}
      onClose={close}
      open
    >
      <div className="mb2">
        <span children="Search Cases" style={{ color: palette.action.active, fontSize: '20px' }} />

        <div
          className="flex justify-between items-center"
          style={{ width: '50%', marginTop: '8px' }}
        >
          <Input
            value={searchStr}
            onChange={(value) => setSearchStr(value)}
            withoutForm
            placeholder={'Search for ...'}
          />
          <Button
            variant="contained"
            children="search"
            onClick={onSearch}
            style={{ marginLeft: 10, width: 100 }}
          />
        </div>
      </div>

      <Paper variant="outlined" sx={{ height: '686px', overflowY: 'auto', overflowX: 'hidden' }}>
        <Table
          headerHeight={46}
          rows={caseListData?.data}
          columns={caseColumns(palette, onSelect ? onSelect : onSelectCase)}
          rowsPerPage={rowsPerPage}
          hideFooter
          autoHeight
          disableColumnMenu
          disableSelectionOnClick
          disableMultipleColumnsSorting
          disableExtendRowFullWidth={false}
          sortingMode="server"
          onSortModelChange={onSortHandler}
        />
      </Paper>

      <div
        style={{
          display: 'flex',
          gap: 12,
          justifyContent: 'flex-end',
          alignItems: 'center',
          marginTop: 10,
        }}
      >
        <span style={{ color: palette.action.active, fontSize: 14 }}>Cases per page :</span>
        <Select
          value={rowsPerPage}
          onChange={handleRowsPerPage}
          sx={{ fontSize: 16, padding: '5px 8px' }}
        >
          {options.map((option) => (
            <MenuItem key={option} value={option} children={option} />
          ))}
        </Select>
        <Pagination
          color="primary"
          shape="rounded"
          count={Math.ceil(caseListData?.count / rowsPerPage)}
          page={page}
          onChange={handleChangePage}
          renderItem={(item) => (
            <PaginationItem
              color="primary"
              components={{ previous: ArrowBackIosNewIcon, next: ArrowForwardIosIcon }}
              {...item}
            />
          )}
        />
      </div>
    </Dialog>
  );
}
