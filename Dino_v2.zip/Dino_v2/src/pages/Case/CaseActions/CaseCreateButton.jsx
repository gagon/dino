import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';
import { FormControlLabel, TextField, ToggleButton, useTheme, Typography } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import CircularProgress from '@mui/material/CircularProgress';
import Menu from '@mui/material/Menu';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import { NEW_CASE_DEFAULT_TIME } from '../../../_helpers/constants';
import { loginModule, setParamToUserConfig } from '../../Login/LoginDucks';
import { caseModule, createNewCase } from '../CaseDucks/CaseDucks';
import { caseMenuModule } from '../SideBar/CaseMenuDucks';
import { CreateButtonStyle, ToggleButtonGroup } from './CaseActionStyle';
import moment from 'moment';
import { StaticTimePicker } from '@mui/x-date-pickers/StaticTimePicker';

export default function CaseCreateButton({ closeModal }) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { palette } = useTheme();
  const loading = useSelector((state) => state[caseModule].loadingCreateCase);
  const [newCaseMenu, setNewCaseMenu] = useState(null);
  const caseDefaultTime = useSelector(
    (state) => state[loginModule].userConfig[NEW_CASE_DEFAULT_TIME]
  );
  const [isCurrentTime, setCurrentTime] = useState(
    !!caseDefaultTime && caseDefaultTime === '08:00'
  );
  const setDefaultTime = (momentTime) => {
    dispatch(setParamToUserConfig(NEW_CASE_DEFAULT_TIME, momentTime.format('HH:mm')));
  };

  return (
    <>
      <ToggleButtonGroup exclusive fullWidth>
        <ToggleButton
          sx={{ minWidth: 94 }}
          disabled={loading}
          children={loading ? <CircularProgress size={20} /> : 'New case'}
          onClick={() => dispatch(createNewCase(navigate, closeModal))}
          value=""
        />
        <ToggleButton
          style={{ width: 47 }}
          disabled={loading}
          onClick={(event) => setNewCaseMenu(event.target)}
          children={<ArrowRightAltIcon style={{ color: palette.text.primary }} />}
          value=""
        />
      </ToggleButtonGroup>
      <Menu anchorEl={newCaseMenu} open={!!newCaseMenu} onClose={() => setNewCaseMenu(null)}>
        <div style={{ paddingLeft: 22 }}>
          <Typography variant="overline" color="#ADADAD">
            NEW CASE DEFAULT TIME
          </Typography>
        </div>
        <div className="pl1">
          <FormControlLabel
            label="USE CURRENT TIME"
            labelPlacement="start"
            control={
              <Checkbox
                style={{ marginLeft: 5 }}
                checked={isCurrentTime}
                onChange={(e, checked) => {
                  setCurrentTime(checked);
                  if (checked) setDefaultTime(moment('08:00', 'HH:mm'));
                }}
              />
            }
          />
        </div>
        <StaticTimePicker
          ampm
          disabled={isCurrentTime}
          style={{ marginTop: -15 }}
          toolbarTitle=""
          value={moment(caseDefaultTime || '08:00', 'HH:mm')}
          onChange={setDefaultTime}
          renderInput={(params) => <TextField {...params} />}
        />
      </Menu>
    </>
  );
}
