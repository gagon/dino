import React, { useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Checkbox, Dialog, ToggleButton, useTheme } from '@mui/material';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import lodash from 'lodash';
import moment from 'moment';
import Input from '../../../common/Input/Input';
import DatePicker from '../../../common/_MuiHookForm/DesktopDatePicker';
import MenuInfoIcon from '../../../_media/sideBar/MenuInfoIcon';
import useSimpleModal from '../../../common/_hooks/useSimpleModal';
import useStep from '../useStep';
import {
  caseModule,
  saveChangesCase,
  setCaseDescription,
  setCaseImplemented,
  setCaseName,
  setCaseTimestamp,
} from '../CaseDucks/CaseDucks';
import { caseMenuModule, changeActiveMenu } from '../SideBar/CaseMenuDucks';
import { CASE_ACTION_MODAL, FIELD_DATA } from '../SideBar/MenuItems';
import SideButton from '../SideBar/SideButton';
import CaseCloneButton from './CaseCloneButton';
import CaseCreateButton from './CaseCreateButton';
import CaseDeleteButton from './CaseDeleteButton';
import SearchCaseModal from './SearchCase/SearchCaseModal';

import { buttonStyle } from './CaseActionStyle';

const CaseInfoItem = ({ title, value }) =>
  value && (
    <div className="flex items-center" style={{ marginBottom: '12px' }}>
      <Typography color={'textSecondary'} children={title} style={{ width: 100 }} />
      <Typography color={'textSecondary'} children={value} style={{ fontWeight: 'bold' }} />
    </div>
  );

export default function CaseActionModal({ isOpen, close }) {
  const searchModal = useSimpleModal();
  const dispatch = useDispatch();
  const activeMenu = useSelector((state) => state[caseMenuModule].activeMenu);
  const changesData = useSelector((state) => state[caseModule].changesData);
  const caseForm = useSelector((state) => state[caseModule].caseForm);
  const implemented = useSelector((state) => state[caseModule].caseData?.implemented);
  const description = useSelector((state) => state[caseModule].caseData?.description);
  const timestamp = useSelector((state) => state[caseModule].caseData?.timestamp);
  const caseName = useSelector((state) => state[caseModule].caseData?.name);
  const creator = useSelector((state) => state[caseModule].caseData?.creator?.name);
  const gapFileName = useSelector((state) => state[caseModule].caseData?.gap_file?.name);
  const loading = useSelector((state) => state[caseModule].loadingSaveCase);
  const { disabled, noResult } = useStep();
  const isActive = activeMenu === CASE_ACTION_MODAL;
  const { palette } = useTheme();
  const nextBtnHandle = () => dispatch(changeActiveMenu(FIELD_DATA));
  const oldTimestamp = useMemo(
    () => moment.utc(timestamp).local().format('DD-MM-YYYY HH:mm:ss'),
    [timestamp]
  );

  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton onClick={() => dispatch(changeActiveMenu(CASE_ACTION_MODAL))}>
            <MenuInfoIcon
              style={{ fill: 'none', stroke: isActive ? palette.common.white : '#059DB5' }}
            />
          </IconButton>
        }
      />

      {isActive && (
        <Dialog
          sx={{ background: '#5051F935', zIndex: 4 }}
          PaperProps={{
            sx: {
              borderTopRightRadius: 20,
              borderTopLeftRadius: 20,
              borderBottomLeftRadius: 20,
              borderBottomRightRadius: 20,
            },
          }}
          onClose={() => dispatch(changeActiveMenu(null))}
          open={true}
        >
          {searchModal.isOpen && <SearchCaseModal {...searchModal} />}

          <div style={{ padding: '33px 28px 25px 28px' }}>
            <div className="flex">
              <div style={{ width: 500, paddingRight: 5 }}>
                <div className="fullWidth">
                  <CaseInfoItem title="Gap file" value={gapFileName} />
                  <CaseInfoItem title="Created by" value={creator} />
                  <CaseInfoItem
                    title="Implemented"
                    value={
                      <Checkbox
                        checked={caseForm.implemented}
                        sx={{ padding: 0, margin: 0 }}
                        onChange={(e, checked) => dispatch(setCaseImplemented(checked))}
                      />
                    }
                  />
                </div>

                <div style={{ marginTop: 30 }}>
                  <Input
                    withoutForm
                    value={caseForm.name}
                    label="Case name"
                    name="title"
                    onChange={(value) => dispatch(setCaseName(value))}
                    inputStyle={{
                      background:
                        caseForm.name !== caseName && caseName !== undefined
                          ? 'rgb(237, 185, 1)'
                          : 'transparent',
                    }}
                  />
                </div>

                <div style={{ margin: '10px 0' }}>
                  <Typography color={'textSecondary'} children={'Date'} />
                  <DatePicker
                    value={caseForm.timestamp}
                    background={
                      caseForm.timestamp !== oldTimestamp && timestamp !== undefined
                        ? 'rgb(237, 185, 1)'
                        : 'transparent'
                    }
                    onChange={(value) => dispatch(setCaseTimestamp(value))}
                    style={{ marginTop: 5 }}
                  />
                </div>

                <Input
                  withoutForm
                  multiline
                  value={caseForm.description}
                  inputStyle={{
                    background:
                      caseForm.description !== description && description !== undefined
                        ? 'rgb(237, 185, 1)'
                        : 'transparent',
                  }}
                  minRows={4}
                  name="description"
                  label="Case description"
                  onChange={(value) => dispatch(setCaseDescription(value))}
                />
              </div>

              <div style={{ width: 145, paddingLeft: 10, position: 'relative' }}>
                <CaseCreateButton closeModal={close} />

                <ToggleButton
                  children="Search cases"
                  sx={buttonStyle(palette)}
                  onClick={() => searchModal.open({})}
                  value=""
                />

                <div style={{ marginTop: 14, marginBottom: 14 }}>
                  <ToggleButton
                    disabled={
                      (lodash.isEmpty(changesData.CaseWell) &&
                        lodash.isEmpty(changesData.CaseWellConfigItem) &&
                        lodash.isEmpty(changesData.CaseFieldConfigItem) &&
                        caseForm.implemented === !!implemented &&
                        caseForm.name === caseName &&
                        caseForm.description === description) ||
                      disabled ||
                      loading
                    }
                    onClick={() => dispatch(saveChangesCase(close))}
                    children="Save changes"
                    sx={buttonStyle(palette)}
                    value=""
                  />
                </div>

                <CaseCloneButton closeModal={close} />

                <CaseDeleteButton />

                <Button
                  children="Next >"
                  variant="contained"
                  disabled={disabled}
                  color="primary"
                  sx={{ borderRadius: '23px', position: 'absolute', bottom: 2, width: 130 }}
                  onClick={nextBtnHandle}
                />
              </div>
            </div>
          </div>
        </Dialog>
      )}
    </>
  );
}
