import React from 'react';
import { ToggleButton, Typography, useTheme, Button, Dialog, DialogActions } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import { useDispatch, useSelector } from 'react-redux';

import useSimpleModal from '../../../common/_hooks/useSimpleModal';
import useStep from '../useStep';
import { caseModule, deleteCase } from '../CaseDucks/CaseDucks';

import { dialogPaperSx, buttonStyle } from './CaseActionStyle';

export default function CaseDeleteButton() {
  const dispatch = useDispatch();
  const { palette } = useTheme();
  const loading = useSelector((state) => state[caseModule].loadingDeleteCase);
  const caseId = useSelector((state) => state[caseModule].caseData.id);
  const caseName = useSelector((state) => state[caseModule].caseData.name);
  const { hasAccess } = useStep();
  const modal = useSimpleModal();
  const closeInnerModal = modal.close;
  const onDelete = () => dispatch(deleteCase(caseId, closeInnerModal));

  return (
    <>
      <ToggleButton
        value=""
        disabled={loading || !hasAccess}
        sx={buttonStyle(palette)}
        onClick={() => modal.open(true)}
        children={loading ? <CircularProgress size={20} /> : 'Delete case'}
      />

      <Dialog
        sx={{ background: '#5051F935', zIndex: 5 }}
        maxWidth={'xl'}
        PaperProps={{ sx: dialogPaperSx }}
        onClose={modal.close}
        open={modal.isOpen}
      >
        <div className="fs-14 bold">Deleting case</div>
        <div className="center py2">
          <Typography>Do you want to delete a case "{caseName}"?</Typography>
        </div>

        <DialogActions>
          <Button variant="contained" children="Delete" onClick={onDelete} />
          <Button
            children="Cancel"
            style={{ background: palette.action.selected }}
            onClick={closeInnerModal}
          />
        </DialogActions>
      </Dialog>
    </>
  );
}
