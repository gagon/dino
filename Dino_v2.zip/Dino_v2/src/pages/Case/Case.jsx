import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router';
import TabPanel from '../../common/TabPanel';
import { loadCase, clear, caseModule } from './CaseDucks/CaseDucks';
import Fields from './Fields/Fields';
import CaseSideBar from './SideBar/CaseMenu';
import { caseMenuModule, setTabPage } from './SideBar/CaseMenuDucks';
import { VIEW_RESULTS } from './SideBar/MenuItems';
import TabsButton from './TabsButton';
import GasTab from './ViewResults/GasTab/GasTab';
import Tables from './ViewResults/Tables/Tables';
import ViewResultTable from './ViewResults/ViewResultTable/ViewResultTable';
import Wells from './Wells/Wells';
import PageLoader from '../../common/PageLoader/PageLoader';
import { loginModule, setParamToUserConfig } from '../Login/LoginDucks';
import { LAST_VIEWED_CASE } from '../../_helpers/constants';
import paths from '../../_helpers/paths';
import CaseInfoBlock from './CaseInfoBlock';

export default function Case() {
  const dispatch = useDispatch();
  const { caseId } = useParams();
  const { activeMenu, page } = useSelector((state) => state[caseMenuModule]);
  const loading = useSelector((state) => state[caseModule].loading);
  const lastViewedCase = useSelector((state) => state[loginModule].userConfig[LAST_VIEWED_CASE]);
  const isViewResult = activeMenu === VIEW_RESULTS;
  const navigate = useNavigate();

  useEffect(() => {
    if (parseInt(caseId)) {
      dispatch(setParamToUserConfig(LAST_VIEWED_CASE, caseId));
      dispatch(loadCase(caseId));
    } else {
      navigate(paths.case.replace(':caseId', lastViewedCase));
    }
    return () => {
      dispatch(clear());
    };
  }, [caseId, dispatch]);

  return (
    <CaseSideBar>
      <div className="relative" style={{ width: 'calc(100% - 94px)' }}>
        {loading && caseId !== '0' && <PageLoader opacity={70} position="absolute" height="80vh" />}
        <div className="flex items-center">
          <div className="content fullWidth pb2">
            <CaseInfoBlock />
            <div style={{ marginBottom: 20, marginLeft: -4 }}>
              <TabsButton page={page} setPage={(page) => dispatch(setTabPage(page))} />
            </div>
            <div style={{ height: 'calc(100% - 380px)', overflow: 'hidden' }}>
              <TabPanel value={page} index={1} children={<Fields />} controlByStyle />
              <TabPanel value={page} index={2} controlByStyle>
                {isViewResult ? <Tables tab={'KPC'} /> : <Wells tab={'KPC'} />}
              </TabPanel>
              <TabPanel value={page} index={3} controlByStyle>
                {isViewResult ? <Tables tab={'U2'} /> : <Wells tab={'U2'} />}
              </TabPanel>
              <TabPanel value={page} index={4} controlByStyle>
                {isViewResult ? <Tables tab={'U3'} /> : <Wells tab={'U3'} />}
              </TabPanel>
              <TabPanel
                controlByStyle
                value={page}
                index={5}
                children={<ViewResultTable tab={'TABLE'} />}
              />
              <TabPanel controlByStyle value={page} index={6} children={<GasTab tab={'GAS'} />} />
            </div>
          </div>
        </div>
      </div>
    </CaseSideBar>
  );
}
