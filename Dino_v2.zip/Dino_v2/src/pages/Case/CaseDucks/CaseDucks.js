import { createReducer } from '@reduxjs/toolkit';
import lodash, { omit } from 'lodash';
import moment from 'moment';

import {
  openScheduledModal,
  setSelectedCase,
} from '../../../common/ScheduledCases/ScheduledCasesDucks';
import { handleError } from '../../../common/utils/handleError';
import Notice from '../../../common/utils/Notice';
import {
  CHOKE_POSITION_CONFIG_ID,
  CLONE_CASE_GAP_SETTING,
  FL_PRESSURE_CONFIG_ID,
  GAS_FIELD_OPTIMISATION,
  GAS_OPTIMIZATION_FIELDS_COPY,
  GATHERING_STATUS_CONFIG_ID,
  NEW_CASE_DEFAULT_TIME,
  ONLINE_STATUS_CONFIG_ID,
  SLOT_PRESSURE_CONFIG_ID,
  SLOT_TEMPERATURE_CONFIG_ID,
  WH_PRESSURE_CONFIG_ID,
  afFieldMappings,
  currentFieldMappings,
} from '../../../_helpers/constants';
import paths from '../../../_helpers/paths';
import { CaseApi, ScheduledApi } from '../../../_helpers/service';
import { loginModule } from '../../Login/LoginDucks';
import nullOrFixed from '../../utils/nullOrFixed';
import {
  convertUnit,
  getFieldsToChange,
  getWellsToChange,
} from '../FieldWellDataModal/FieldWellDataUtils';
import { changeActiveMenu } from '../SideBar/CaseMenuDucks';
import { handleGasChartData } from '../ViewResults/GasTab/GasCharts/GasChartsUtils';
import { handleGasTableData } from '../ViewResults/GasTab/GasTable/GasTableUtils';
import {
  buildCalcDict,
  evaluateCalcDict,
  evaluateCalculationString,
  getTotalFromOption,
} from '../../../common/calculationUtils/calculation';
import { handleCaseConfig } from '../../../common/calculationUtils/caseConfigSettings';
import { checkError } from '../../../common/calculationUtils/checkError';
import { convertUnitDbRef, unitConversionObj } from '../../../common/calculationUtils/units';
import { setMapConnections } from '../../../common/calculationUtils/utils';
import ParamsModel from '../../../common/FieldSchema/VisualizationBoard/Params/Model';
import { engine, model } from '../Fields/Fields';
import InputField from '../Fields/InputField';
import { useSelector } from 'react-redux';

/**
 * Constants
 */

export const caseModule = 'case';
const SET_CASE_DATA = `${caseModule}/SET_CASE_DATA`;
const SET_CASE_CONFIG = `${caseModule}/SET_CASE_CONFIG`;
const LOAD_UNITS = `${caseModule}/LOAD_UNITS`;
const SET_UNITS = `${caseModule}/SET_UNITS`;
const HOVER_UNIT = `${caseModule}/HOVER_UNIT`;
const SET_CALCULATIONS = `${caseModule}/SET_CALCULATIONS`;
const SET_GAS_TAB_DATA = `${caseModule}/SET_GAS_TAB_DATA`;
const CHANGE_FIELD_FILTER = `${caseModule}/CHANGE_FIELD_FILTER`;
const FIELDS = `${caseModule}/FIELDS`;
const ON_CHANGE_FIELD_VALUE = `${caseModule}/ON_CHANGE_FIELD_VALUE`;
const FIELD_BALANCE = `${caseModule}/FIELD_BALANCE`;
const CHANGE_CASE_WELLS = `${caseModule}/CHANGE_CASE_WELLS`;
const CHANGE_FIELD_FOR_SAVE = `${caseModule}/CHANGE_FIELD_FOR_SAVE`;
const CLEAR = `${caseModule}/CLEAR`;
const LOADING_CREATE_CASE = `${caseModule}/LOADING_CREATE_CASE`;
const LOADING_CLONE_CASE = `${caseModule}/LOADING_CLONE_CASE`;
const LOADING_SAVE_CASE = `${caseModule}/LOADING_SAVE_CASE`;
const LOADING_DELETE_CASE = `${caseModule}/LOADING_DELETE_CASE`;
const CONNECTIONS_JOIN_DICT = `${caseModule}/CONNECTIONS_JOIN_DICT`;
const LOADING_FIELD_DATA = `${caseModule}/LOADING_FIELD_DATA`;
const LOADING_WELL_DATA = `${caseModule}/LOADING_WELL_DATA`;
const LOADING_CASE_OPTIONS = `${caseModule}/LOADING_CASE_OPTIONS`;
const SET_PULL_WELL_CHANGES = `${caseModule}/SET_PULL_WELL_CHANGES`;

const SET_CASE_TIMESTAMP = `${caseModule}/SET_CASE_TIMESTAMP`;
const SET_CASE_NAME = `${caseModule}/SET_CASE_NAME`;
const SET_CASE_IMPLEMENTED = `${caseModule}/SET_CASE_IMPLEMENTED`;
const SET_CASE_DESCRIPTION = `${caseModule}/SET_CASE_DESCRIPTION`;
const SET_STATUS_COPY_WHPRESSUR = 'SET_STATUS_COPY_WHPRESSUR';
const SET_STATUS_COPY_CONNECTION = 'SET_STATUS_COPY_CONNECTION';
const SET_STATUS_COPY_GASERING = 'SET_STATUS_COPY_GASERING';
const SET_STATUS_LOAD_FIELDS = 'SET_STATUS_LOAD_FIELDS';
const SET_STATUS_LOAD_WELLS = 'SET_STATUS_LOAD_WELLS';
const SET_STATUS_COPY_CONSTRAINT = 'SET_STATUS_COPY_CONSTRAINT';
const LOADING = `${caseModule}/LOADING`;

/**
 * Reducer
 */
const FieldsModels = {};
const ResultFieldModels = {};
const initialState = {
  caseForm: {
    name: '',
    timestamp: null,
    description: '',
    implemented: null,
  },
  stepStatus: {
    fieldLoaded: false,
    wellLoaded: false,
    constraint: false,
    KPC: {
      whPressur: false,
      connection: false,
      gasering: false,
    },
    U2: {
      whPressur: false,
      connection: false,
      gasering: false,
    },
    U3: {
      whPressur: false,
      connection: false,
      gasering: false,
    },
  },
  caseData: {},
  caseConfig: {},
  unitClasses: {},
  units: [],
  classByUnits: {},
  unitsByClass: {},
  hoveredUnit: null,
  calculation: {},
  gasTabTable: [],
  gasTabChart: null,
  fields: {},
  fieldBalance: {},
  filterFields: {
    oil: true,
    gas: true,
    gasopt: true,
    water: true,
    unitPressure: true,
    lab: true,
  },
  connectionsJoinDict: {},
  connMapDict: {},
  caseWells: {
    tableData: [],
    inputData: {},
  },
  changesData: { CaseWell: {}, CaseWellConfigItem: {}, CaseFieldConfigItem: {} },
  loading: false,
  loadingCreateCase: false,
  loadingCloneCase: false,
  loadingSaveCase: false,
  loadingDeleteCase: false,
  loadingFieldData: false,
  loadingCaseOptions: true,
  loadingWellData: false,
};

export default createReducer(initialState, {
  [FIELDS]: (state, { payload }) => {
    state.fields = payload;
  },
  [ON_CHANGE_FIELD_VALUE]: (state, { field, dependantsFields = [] }) => {
    state.fields[field.config_group][field.name] = field;
    for (const item of dependantsFields) {
      state.fields[item.config_group][item.name] = item;
    }
  },
  [FIELD_BALANCE]: (state, { payload }) => {
    state.fieldBalance = payload;
  },
  [SET_CASE_DATA]: (state, { payload }) => {
    state.caseData = payload;
    state.caseForm.name = payload.name;
    state.caseForm.timestamp = payload.timestamp
      ? moment.utc(payload.timestamp).local().format('DD-MM-YYYY HH:mm:ss')
      : payload.timestamp;
    state.caseForm.description = payload.description;
    state.caseForm.implemented = !!payload.implemented;

    state.caseWells.tableData = payload?.case_wells;
    for (const row of payload?.case_wells) {
      state.caseWells.inputData[row.id] = row;
    }
  },
  [SET_CASE_CONFIG]: (state, { payload }) => {
    state.caseConfig = payload;
  },
  [LOAD_UNITS]: (state, { payload }) => {
    state.unitClasses = payload?.unitClasses;
    state.units = payload?.units;
  },
  [SET_UNITS]: (state, { payload }) => {
    state.unitsByClass = payload?.unitsByClass;
    state.classByUnits = payload?.classByUnits;
  },
  [HOVER_UNIT]: (state, { payload }) => {
    state.hoveredUnit = payload;
  },
  [SET_CALCULATIONS]: (state, { payload }) => {
    state.calculation = payload;
  },
  [SET_GAS_TAB_DATA]: (state, { table, chart }) => {
    state.gasTabTable = table;
    state.gasTabChart = chart;
  },
  [CONNECTIONS_JOIN_DICT]: (state, { payload }) => {
    state.connectionsJoinDict = payload.connectionsJoinDict;
    state.connMapDict = payload.connMapDict;
  },
  [CHANGE_FIELD_FOR_SAVE]: (state, { payload }) => {
    if (lodash.isEmpty(payload)) {
      state.changesData = { CaseWell: {}, CaseWellConfigItem: {}, CaseFieldConfigItem: {} };
    } else if (!lodash.isEmpty(payload?.CaseWellConfigItem)) {
      state.changesData.CaseWellConfigItem = {
        ...state.changesData.CaseWellConfigItem,
        ...payload.CaseWellConfigItem,
      };
    } else if (!lodash.isEmpty(payload?.CaseWell)) {
      for (const key of Object.keys(payload.CaseWell)) {
        if (state.changesData.CaseWell.hasOwnProperty(key)) {
          state.changesData.CaseWell[key] = {
            ...state.changesData.CaseWell[key],
            ...payload.CaseWell[key],
          };
        } else {
          state.changesData.CaseWell[key] = payload.CaseWell[key];
        }
      }
    } else if (!lodash.isEmpty(payload?.CaseFieldConfigItem)) {
      state.changesData.CaseFieldConfigItem = {
        ...state.changesData.CaseFieldConfigItem,
        ...payload.CaseFieldConfigItem,
      };
    }
    if (payload?.CaseId) {
      state.changesData.CaseId = payload.CaseId;
    }
  },
  [CHANGE_FIELD_FILTER]: (state, { payload }) => {
    state.filterFields = payload;
  },
  [CHANGE_CASE_WELLS]: (state, { payload }) => {
    if (payload?.all) {
      state.caseData.case_wells = payload?.caseWells;
      state.caseWells.tableData = payload?.caseWells;
      for (const row of payload?.caseWells) {
        state.caseWells.inputData[row.id] = row;
      }
    } else {
      const index = state.caseData.case_wells.findIndex((object) => {
        return parseInt(object.well_id) === parseInt(payload?.caseWells.id);
      });
      state.caseData.case_wells[index] = {
        ...state.caseData.case_wells[index],
        ...payload?.caseWells,
      };
      state.caseWells.inputData[state.caseData.case_wells[index].id] = {
        ...state.caseData.case_wells[index],
        ...payload?.caseWells,
      };
    }
  },
  [SET_PULL_WELL_CHANGES]: (state, { payload }) => {
    state.caseData.case_wells = payload.caseWells;
    state.caseWells.tableData = payload.caseWells;
    for (const row of payload?.caseWells) {
      state.caseWells.inputData[row.id] = row;
    }
    state.changesData = payload.changesData;
  },
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [LOADING_CREATE_CASE]: (state, { payload }) => {
    state.loadingCreateCase = payload;
  },
  [LOADING_SAVE_CASE]: (state, { payload }) => {
    state.loadingSaveCase = payload;
  },
  [LOADING_CLONE_CASE]: (state, { payload }) => {
    state.loadingCloneCase = payload;
  },
  [LOADING_DELETE_CASE]: (state, { payload }) => {
    state.loadingDeleteCase = payload;
  },
  [LOADING_FIELD_DATA]: (state, { payload }) => {
    state.loadingFieldData = payload;
  },
  [LOADING_WELL_DATA]: (state, { payload }) => {
    state.loadingWellData = payload;
  },
  [LOADING_CASE_OPTIONS]: (state, { payload }) => {
    state.loadingCaseOptions = payload;
  },
  [SET_CASE_NAME]: (state, { payload }) => {
    state.caseForm.name = payload;
  },
  [SET_CASE_IMPLEMENTED]: (state, { payload }) => {
    state.caseForm.implemented = payload;
  },
  [SET_CASE_TIMESTAMP]: (state, { payload }) => {
    state.caseForm.timestamp = payload;
  },
  [SET_CASE_DESCRIPTION]: (state, { payload }) => {
    state.caseForm.description = payload;
  },
  [SET_STATUS_COPY_WHPRESSUR]: (state, { payload, tab }) => {
    if (tab) {
      state.stepStatus[tab].whPressur = payload;
    } else {
      ['KPC', 'U2', 'U3'].forEach((tab) => {
        state.stepStatus[tab].whPressur = payload;
      });
    }
  },
  [SET_STATUS_COPY_CONNECTION]: (state, { payload, tab }) => {
    if (tab) {
      state.stepStatus[tab].connection = payload;
    } else {
      ['KPC', 'U2', 'U3'].forEach((tab) => {
        state.stepStatus[tab].connection = payload;
      });
    }
  },
  [SET_STATUS_COPY_GASERING]: (state, { payload, tab }) => {
    if (tab) {
      state.stepStatus[tab].gasering = payload;
    } else {
      ['KPC', 'U2', 'U3'].forEach((tab) => {
        state.stepStatus[tab].gasering = payload;
      });
    }
  },
  [SET_STATUS_LOAD_FIELDS]: (state, { payload }) => {
    state.stepStatus.fieldLoaded = payload;
  },
  [SET_STATUS_LOAD_WELLS]: (state, { payload }) => {
    state.stepStatus.wellLoaded = payload;
  },
  [SET_STATUS_COPY_CONSTRAINT]: (state, { payload }) => {
    state.stepStatus.constraint = payload;
  },
  [CLEAR]: () => initialState,
});

/**
 * Actions
 */

export const setCaseImplemented = (implemented) => ({
  type: SET_CASE_IMPLEMENTED,
  payload: implemented,
});

export const setCaseName = (name) => ({ type: SET_CASE_NAME, payload: name });

export const setCaseTimestamp = (timestamp) => ({ type: SET_CASE_TIMESTAMP, payload: timestamp });

export const setCaseDescription = (description) => ({
  type: SET_CASE_DESCRIPTION,
  payload: description,
});

export const clear = () => ({ type: CLEAR });

export const changeFieldFilter = (params) => ({ type: CHANGE_FIELD_FILTER, payload: params });

export const changeCaseWells = (row, saveObj, isSelect) => async (dispatch, getState) => {
  const state = getState()[caseModule];
  const { connectionsJoinDict, connMapDict, caseData, caseWells: cs } = state;
  const caseWells = caseData?.case_wells;
  const well = { ...cs.inputData[row.id], [row.key]: row.value };
  if (row.value instanceof Object && row.value.config_id) {
    well.validate = checkValidate(state, well);
  }

  if (!isSelect) {
    dispatch({ type: CHANGE_CASE_WELLS, payload: { caseWells: well } });
    dispatch({ type: CHANGE_FIELD_FOR_SAVE, payload: { ...saveObj, CaseId: well.case_id } });
  } else {
    const updates = { [well.id]: well };
    const key = saveObj?.column;
    const selConn = well.gap_well.connectionMap[well[key]];
    const dataForSaveChange = { [well.id]: { [key]: well[key] } };
    const joints = well.gap_well.connectionMap[well[key]].joints;
    for (let joint of joints) {
      for (let [wk] of Object.entries(connectionsJoinDict[joint])) {
        if (parseInt(wk) != well.id) {
          let otherWell = caseWells.find((item) => item.id === parseInt(wk));
          let otherWellConfig = otherWell.gap_well;
          let selectedConn = otherWell[key];
          let otherConn = otherWellConfig.connectionMap[selectedConn];
          let jointLoc = otherConn.joints.indexOf(joint);
          if (jointLoc != -1) {
            let wellConnId = connMapDict[selConn.conn_map_id][wk]; // wk-> wellId
            if (wellConnId) {
              updates[wk] = { ...otherWell, [key]: wellConnId };
              dataForSaveChange[wk] = { [key]: wellConnId };
            }
          }
        }
      }
    }
    const newCaseWells = caseWells.map((i) => (i.id in updates ? updates[i.id] : i));
    dispatch({ type: CHANGE_CASE_WELLS, payload: { caseWells: newCaseWells, all: true } });
    dispatch({
      type: CHANGE_FIELD_FOR_SAVE,
      payload: { CaseWell: dataForSaveChange, CaseId: well.case_id },
    });
  }
};

function checkValidate(state, data) {
  const caseConfig = state.caseConfig;
  const process = state.fields['Process'];
  const parse = (value) => {
    return typeof value === 'string' ? parseInt(value) : value;
  };
  const whPres = parse(data?.whPressur);
  const flPres = parse(data?.flPressur);
  const slotPres = parse(data?.slotPressur);
  let pressureLookup = '';
  const connection = data.gap_well.connectionMap[data.gap_conn_id];
  const fvRef = process[pressureLookup];
  const validate = {};

  caseConfig?.unitCfg[connection.unit].separators.map((sep) => {
    if ((!connection.mp_lp && !sep.mp_lp) || connection.mp_lp == sep.mp_lp) {
      pressureLookup = sep.pressure_lookup;
    }
  });

  const fvPres = fvRef ? convertUnitDbRef(fvRef, whPres, false) : null;

  if (whPres < flPres) {
    validate[WH_PRESSURE_CONFIG_ID] = 'Below FL Pressure';
  } else if (whPres < slotPres) {
    validate[WH_PRESSURE_CONFIG_ID] = 'Below Slot Pressure';
  } else if (fvPres && whPres < fvPres) {
    validate[WH_PRESSURE_CONFIG_ID] = 'Below ' + pressureLookup;
  }

  if (flPres < slotPres) {
    validate[FL_PRESSURE_CONFIG_ID] = 'Below Slot Pressure';
  } else if (fvPres && flPres < fvPres) {
    validate[FL_PRESSURE_CONFIG_ID] = 'Below ' + pressureLookup;
  }

  if (fvPres && slotPres < fvPres) {
    validate[WH_PRESSURE_CONFIG_ID] = 'Below ' + pressureLookup;
  }

  return validate;
}

export const getChangeCaseWells = (
  well,
  saveObj,
  isSelect,
  getState,
  withJoin,
  connectionUpdatedMap
) => {
  const { connectionsJoinDict, connMapDict, caseData } = getState()[caseModule];
  const caseWells = caseData?.case_wells;
  if (!isSelect) {
    return { well: { caseWells: well }, forSave: { ...saveObj, CaseId: well.case_id } };
  } else {
    const currentWellId = well.id;
    const updates = { [currentWellId]: well };
    const key = saveObj?.column;
    const dataForSaveChange = { [currentWellId]: { [key]: well[key] } };

    if (withJoin) {
      if (connectionUpdatedMap?.[currentWellId] === false) {
        const selConn = well.gap_well.connectionMap[well[key]];
        const joints = selConn.joints;

        for (let joint of joints) {
          for (let [wk] of Object.entries(connectionsJoinDict[joint])) {
            if (parseInt(wk) != currentWellId) {
              const otherWell = caseWells.find((item) => item.id === parseInt(wk));
              const otherWellConfig = otherWell.gap_well;
              const selectedConn = otherWell[key];
              const otherConn = otherWellConfig.connectionMap[selectedConn];
              const jointLoc = otherConn.joints.indexOf(joint);

              if (connectionUpdatedMap?.[otherWell.id] === false) {
                if (jointLoc != -1) {
                  const wellConnId = connMapDict[selConn.conn_map_id][wk]; // wk-> wellId

                  if (wellConnId) {
                    updates[wk] = { [key]: wellConnId };
                    dataForSaveChange[wk] = { [key]: wellConnId };
                    connectionUpdatedMap[otherWell.id] = true;
                  }
                }
              }
            }
          }
        }
      } else {
        connectionUpdatedMap[currentWellId] = false;
      }
    }

    return {
      well: { caseWells: updates, all: true },
      forSave: { CaseWell: dataForSaveChange, CaseId: well.case_id },
    };
  }
};

const setPullWellsChanges = (listChanges) => (dispatch, getState) => {
  const state = getState();
  const stateChanges = state[caseModule].changesData || {};
  const stateCaseWells = state[caseModule].caseData.case_wells || [];
  const changesData = JSON.parse(JSON.stringify(stateChanges));
  let caseWells = JSON.parse(JSON.stringify(stateCaseWells));

  listChanges.forEach((changeItem) => {
    const wellChange = changeItem.well;
    if (wellChange?.all) {
      for (const wellId of Object.keys(wellChange.caseWells)) {
        const index = caseWells.findIndex((i) => parseInt(i.well_id) === parseInt(wellId));
        caseWells[index] = {
          ...caseWells[index],
          ...wellChange.caseWells[wellId],
        };
      }
    } else {
      const index = caseWells.findIndex((object) => {
        return parseInt(object.well_id) === parseInt(wellChange?.caseWells.id);
      });
      caseWells[index] = {
        ...caseWells[index],
        ...wellChange?.caseWells,
      };
    }
  });

  listChanges.forEach((changeItem) => {
    const wellChange = changeItem.forSave;
    if (wellChange?.CaseWellConfigItem) {
      changesData.CaseWellConfigItem = {
        ...changesData.CaseWellConfigItem,
        ...wellChange.CaseWellConfigItem,
      };
    } else if (wellChange?.CaseWell) {
      for (const key of Object.keys(wellChange.CaseWell)) {
        if (changesData.CaseWell) {
          if (changesData.CaseWell.hasOwnProperty(key)) {
            changesData.CaseWell[key] = {
              ...changesData.CaseWell[key],
              ...wellChange.CaseWell[key],
            };
          } else {
            changesData.CaseWell[key] = wellChange.CaseWell[key];
          }
        } else {
          changesData.CaseWell = {
            [key]: wellChange.CaseWell[key],
          };
        }
      }
    } else {
      changesData.CaseFieldConfigItem = {
        ...changesData.CaseFieldConfigItem,
        ...wellChange.CaseFieldConfigItem,
      };
    }
    if (wellChange?.CaseId) {
      changesData.CaseId = wellChange.CaseId;
    }
  });

  dispatch({ type: SET_PULL_WELL_CHANGES, payload: { caseWells, changesData } });
};

export const changeFieldValue =
  (field, displayedUom, isHourUnits) => async (dispatch, getState) => {
    const caseModuleState = getState()[caseModule];
    const classByUnits = caseModuleState.classByUnits;
    const unitsByClass = caseModuleState.unitsByClass;
    const fields = caseModuleState.fields;
    const caseConfig = caseModuleState.caseConfig;
    const calculation = caseModuleState.calculation;
    const fieldBalance = caseModuleState.fieldBalance;

    field.hourValue = isHourUnits ? field.value : (field.value / 24).toFixed(2);
    if (isHourUnits && displayedUom.includes('/h')) {
      field.value = nullOrFixed(
        convertUnit(field.value, displayedUom, field.uom, unitsByClass, classByUnits),
        2
      );
    }

    const newFields = JSON.parse(JSON.stringify(fields));
    newFields[field.config_group][field.name] = { ...field };
    const config = {
      data_source: field?.data_source,
      value: Number(field.value),
      hourValue: nullOrFixed(field.value / 24, 2),
    };

    if (field?.timestamp) {
      config.timestamp = field?.timestamp;
    }

    const changes = {
      CaseId: field.case_id,
      CaseFieldConfigItem: {
        [field.id]: config,
      },
    };

    const fieldTotal = getTotalFromOption(undefined, fieldBalance);
    const dependantsFields = [];

    //При изменений значений перечитываем и меняем значений зависимых полей
    const calcDeps = (field) => {
      for (let dep of field?.dependants) {
        try {
          const newValue = evaluateCalculationString(
            dep.source_tag,
            null,
            fieldTotal,
            newFields,
            caseConfig?.units,
            calculation?.calcDict
          );
          const currentField = newFields[dep.group][dep?.name];
          currentField.value = nullOrFixed(newValue, 2);
          currentField.hourValue = nullOrFixed(newValue / 24, 2);
          currentField.data_source = 'Calculated';
          currentField.timestamp = moment().format('YYYY-MM-DDTHH:mm:ss');
          changes.CaseFieldConfigItem[currentField.id] = {
            data_source: currentField?.data_source,
            value: currentField.value,
            timestamp: moment().format('YYYY-MM-DDTHH:mm:ss'),
          };
          calcDeps(currentField);
          dependantsFields.push(currentField);
        } catch (err) {
          const currentField = newFields[field.config_group][field?.name];
          currentField.errorMsg = 'Calculation error:' + err.message;
          dependantsFields.push(currentField);
          Notice.error(
            `${dep.config_group || dep.group}:${
              dep.name
            }, check the formula, some fields were not found in the formula `
          );
        }
      }
    };

    calcDeps(field);
    dispatch({ type: ON_CHANGE_FIELD_VALUE, dependantsFields, field });
    dispatch({ type: CHANGE_FIELD_FOR_SAVE, payload: changes });
  };

export const getChangeFieldValue = (field, newFields, changes, state) => {
  const { fields, caseConfig, calculation, fieldBalance } = state[caseModule];
  newFields[field.config_group][field.name] = {
    ...field,
    hourValue: (field.value / 24).toFixed(2),
  };
  const config = {
    data_source: field?.data_source,
    value: field.value,
    hourValue: (field.value / 24).toFixed(2),
  };

  if (field?.timestamp) {
    config.timestamp = moment(field?.timestamp).format('YYYY-MM-DDTHH:mm:ss');
  }

  changes.CaseFieldConfigItem[field.id] = config;
  const { classByUnits, unitsByClass } = state[caseModule];
  const fieldTotal = getTotalFromOption(undefined, fieldBalance);

  //При изменений значений перечитываем и меняем значений зависимых полей
  const calcDeps = (field) => {
    for (let dep of field?.dependants) {
      try {
        const newValue = evaluateCalculationString(
          dep.source_tag,
          null,
          fieldTotal,
          newFields,
          caseConfig?.units,
          calculation?.calcDict
        );
        const currentField = newFields[dep.group][dep?.name];
        newFields[dep.group][dep?.name].value = nullOrFixed(newValue, 2);
        newFields[dep.group][dep?.name].hourValue = nullOrFixed(newValue / 24, 2);
        newFields[dep.group][dep?.name].data_source = 'Calculated';
        newFields[dep.group][dep?.name].timestamp = moment().format('YYYY-MM-DDTHH:mm:ss');
        changes.CaseFieldConfigItem[currentField.id] = {
          data_source: currentField?.data_source,
          value: currentField.value,
          hourValue: nullOrFixed(currentField.value / 24, 2),
          timestamp: moment().format('YYYY-MM-DDTHH:mm:ss'),
        };
        calcDeps(newFields[dep.group][dep?.name]);
      } catch (err) {
        newFields[field.config_group][field?.name].errorMsg = 'Calculation error:' + err.message;
        console.error(err, 'err', dep, 'Calculation error:' + err.message);
        Notice.error(
          `${dep.config_group || dep.group}:${
            dep.name
          }, check the formula, some fields were not found in the formula `
        );
      }
    }
  };

  calcDeps(field);
};

export const loadCase = (caseId) => async (dispatch, getState) => {
  dispatch({ type: LOADING, payload: true });
  try {
    const state = getState();
    const stateCaseConfig = state[caseModule].caseConfig;
    if (Object.keys(stateCaseConfig).length === 0) {
      const userConfig = state[loginModule].userConfig;
      const { data } = await CaseApi.loadCaseConfigSetting();
      const caseConfig = handleCaseConfig(data, userConfig);
      dispatch({ type: SET_CASE_CONFIG, payload: { ...data, ...caseConfig } });
      dispatch(loadCaseData(caseId, caseConfig));
    } else {
      dispatch(loadCaseData(caseId, stateCaseConfig));
    }
  } catch (e) {
    handleError(e, 'Failed to load case config data');
  }
};

function addFieldModels(data, calcDict, calcNameLookup) {
  const fields = listToObject(data.field);
  const resultLabel = data.resultLabel.filter((i) => i.group === 'Diagram');
  const resultFields = listToObject(resultLabel);

  for (const field of Object.values(fields)) {
    if (!FieldsModels.hasOwnProperty(field.id)) {
      const fieldItem = new ParamsModel(engine, {
        children: <InputField key={field.id} data={field} />,
      });
      fieldItem.setPosition(field.xpos2, field.ypos2);
      FieldsModels[field.id] = fieldItem;
      model.addNode(fieldItem);
    }
  }

  for (const item of Object.values(resultFields)) {
    if (!ResultFieldModels.hasOwnProperty(item.id)) {
      const calcName = calcNameLookup[item.calc_id];
      const field = {
        ...item,
        ...calcDict[calcName].results?.default,
        fieldName: item.name,
        uom: calcDict[calcName]?.uom,
        name: calcDict[calcName]?.name,
      };
      const fieldItem = new ParamsModel(engine, {
        children: <InputField key={field.id + 'res'} data={field} isResult />,
      });
      fieldItem.setPosition(field.xpos2, field.ypos2);
      ResultFieldModels[field.id] = fieldItem;
      model.addNode(fieldItem);
    }
  }
  engine.repaintCanvas();
}

function listToObject(list) {
  const obj = {};
  for (const item of list) {
    obj[item.id] = item;
  }
  return obj;
}

export const loadCaseData = (caseId, caseConfig) => async (dispatch) => {
  dispatch({ type: LOADING, payload: true });
  try {
    if (caseConfig && parseInt(caseId)) {
      let { data: caseData } = await CaseApi.loadCase(caseId);
      const fieldValues = caseData?.field_config_values;

      //Групируем поля согласно параметру config_group
      const fields = Object.values(caseConfig?.fieldCfg).reduce((group, field) => {
        const dependants = [];
        if (!group[field?.config_group]) {
          group[field?.config_group] = {};
        }
        let values = fieldValues[field.id];
        let value = '';
        let hourValue = '';
        if (values?.value) {
          value = parseFloat(values?.value).toFixed(2);
          hourValue = parseFloat(values?.value / 24).toFixed(2);
        }

        group[field?.config_group][field.name] = {
          ...field,
          ...values,
          value,
          hourValue,
          dependants,
          savedValue: value,
        };
        return group;
      }, {});

      //записываем зависимых полей которые меняются по формуле при изменений данного поля
      const setDependants = () => {
        Object.values(caseConfig?.fieldCfg).map((field) => {
          const fieldValue = function (group, item) {
            fields[group][item]?.dependants.push({
              group: field.config_group,
              name: field.name,
              source_tag: field?.source_tag,
            });
          };
          if (!field?.is_constraint && field?.source_type === 'calc') {
            try {
              eval(field?.source_tag);
            } catch (err) {
              console.log(err);
            }
          }
        });
      };

      setDependants();

      dispatch({ type: FIELDS, payload: fields });
      dispatch(loadUnits(caseId, caseData, caseConfig));
    }
  } catch (e) {
    handleError(e, 'Failed to load case data');
  }
};

export const loadUnits = (caseId, caseData) => async (dispatch, getState) => {
  dispatch({ type: LOADING, payload: true });
  try {
    const { userConfig, appConfig } = getState()[loginModule];

    let loadedUnits = { unitClasses: {}, units: [] };
    const response = await CaseApi.getUnitClasses(appConfig['AF:AFServer']);
    loadedUnits.unitClasses = response?.data;

    const getUnits = async () => {
      let requests = response?.data?.Items.map((unit) => {
        return Promise.resolve(CaseApi.getUnits(unit?.Links?.Units));
      });

      return Promise.all(requests).then((responses) => {
        responses.map((res) => {
          loadedUnits.units.push(res.data);
        });
      });
    };

    if (response?.data?.Items.length > 0) {
      await getUnits();
    }
    dispatch({ type: LOAD_UNITS, payload: loadedUnits });

    const { caseConfig, fields, unitClasses, units } = getState()[caseModule];
    const convertedUnits = unitConversionObj(unitClasses, units);
    const connectionsJoinDict = {};
    const connMapDict = {};
    let fieldTotal = getTotalFromOption(undefined, {});
    dispatch({ type: SET_UNITS, payload: convertedUnits });
    const calculation = buildCalcDict(
      convertedUnits?.classByUnits,
      convertedUnits?.unitsByClass,
      caseConfig,
      userConfig
    );

    if (caseData.run_date) {
      let { data } = await CaseApi.loadFieldBalance(caseId);
      fieldTotal = getTotalFromOption(undefined, data);
      dispatch({ type: FIELD_BALANCE, payload: data });
    }

    evaluateCalcDict(undefined, calculation?.calcDict, fieldTotal, fields, caseConfig?.units);
    dispatch({ type: SET_CALCULATIONS, payload: calculation });
    addFieldModels(caseConfig, calculation?.calcDict, calculation.calcNameLookup);

    const case_wells = Object.values(caseData.case_wells).map((well) => {
      const gap_well = setMapConnections(
        well?.gap_well,
        userConfig,
        caseConfig?.wellCfg,
        connMapDict,
        connectionsJoinDict
      );

      const gapName = caseConfig?.wellCfg[well.well_id].gap_name;
      const whPressur = well?.well_config_values[WH_PRESSURE_CONFIG_ID];
      const flPressur = well?.well_config_values[FL_PRESSURE_CONFIG_ID];
      const slotPressur = well?.well_config_values[SLOT_PRESSURE_CONFIG_ID];
      const slotTemperature = well?.well_config_values[SLOT_TEMPERATURE_CONFIG_ID];
      const chokePosition = well?.well_config_values[CHOKE_POSITION_CONFIG_ID];
      const onlineStatus = well?.well_config_values[ONLINE_STATUS_CONFIG_ID];
      const gatheringStatus = well?.well_config_values[GATHERING_STATUS_CONFIG_ID];

      const values = {
        ...well,
        gap_well,
        id: well?.well_id,
        gapName,
        whPressur,
        flPressur,
        slotPressur,
        slotTemperature,
        chokePosition,
        onlineStatus,
        gatheringStatus,
      };

      const validate = checkError(
        values,
        caseConfig?.unitCfg,
        fields['Process'],
        units.classByUnits,
        units.unitsByClass
      );
      return { ...values, initValues: values, validate };
    });
    dispatch({ type: SET_CASE_DATA, payload: { ...caseData, case_wells } });
    dispatch({ type: CONNECTIONS_JOIN_DICT, payload: { connectionsJoinDict, connMapDict } });
  } catch (e) {
    console.log(e, 'error');
    handleError(e, 'Failed to load case unit data');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const createNewCase = (navigate, closeModal) => async (dispatch, getState) => {
  dispatch({ type: LOADING_CREATE_CASE, payload: true });
  try {
    const caseDefaultTime = getState()[loginModule].userConfig[NEW_CASE_DEFAULT_TIME];
    if (caseDefaultTime) {
      const currentDate = moment();
      const timeMoment = moment(caseDefaultTime, 'HH:mm');
      currentDate.hours(timeMoment.hours());
      currentDate.minutes(timeMoment.minutes());
      currentDate.seconds(0).milliseconds(0);
      const currentDateString = currentDate.utc().format('YYYY-MM-DDTHH:mm:ss');
      const { data } = await CaseApi.crateNewCase(currentDateString);
      navigate(paths.case.replace(':caseId', data.id));
      closeModal && closeModal();
    } else {
      const currentDate = moment().utc().format('YYYY-MM-DDTHH:mm:ss');
      const { data } = await CaseApi.crateNewCase(currentDate);
      navigate(paths.case.replace(':caseId', data.id));
      closeModal && closeModal();
    }
  } catch (e) {
    handleError(e, 'Failed to create new case');
  } finally {
    dispatch({ type: LOADING_CREATE_CASE, payload: false });
  }
};

export const cloneCase = (navigate, closeModal) => async (dispatch, getState) => {
  dispatch({ type: LOADING_CLONE_CASE, payload: true });
  try {
    const state = getState();
    const caseId = state[caseModule].caseData.id;
    const caseDefaultGap = state[loginModule].userConfig[CLONE_CASE_GAP_SETTING];
    if (caseId) {
      const params = { id: caseId, newGap: caseDefaultGap ?? 'LatestGapFile' };
      const { data } = await CaseApi.cloneCase(params);
      navigate(paths.case.replace(':caseId', data.id));
      closeModal && closeModal();
    }
  } catch (e) {
    handleError(e, 'Failed to clone case');
  } finally {
    dispatch({ type: LOADING_CLONE_CASE, payload: false });
  }
};

export const deleteCase = (caseId, closeInnerModal) => async (dispatch, getState) => {
  dispatch({ type: LOADING_DELETE_CASE, payload: true });
  try {
    if (caseId) {
      await CaseApi.deleteCase(caseId);
      Notice.success(`Case ${caseId} has been deleted`);
      closeInnerModal();
    }
  } catch (e) {
    handleError(e);
    Notice.error('Failed to delete case');
  } finally {
    dispatch({ type: LOADING_DELETE_CASE, payload: false });
  }
};

export const saveChangesCase = (closeModal, runOptimization) => async (dispatch, getState) => {
  dispatch({ type: LOADING_SAVE_CASE, payload: true });
  try {
    const { changesData, fields, caseForm, caseData } = getState()[caseModule];
    const dataToSave = {};
    if (changesData.CaseWell && Object.keys(changesData.CaseWell).length > 0) {
      dataToSave.CaseWell = changesData.CaseWell;
    }
    if (changesData.CaseWellConfigItem && Object.keys(changesData.CaseWellConfigItem).length > 0) {
      dataToSave.CaseWellConfigItem = changesData.CaseWellConfigItem;
    }
    if (
      changesData.CaseFieldConfigItem &&
      Object.keys(changesData.CaseFieldConfigItem).length > 0
    ) {
      const result = lodash.reduce(
        changesData.CaseFieldConfigItem,
        (acc, obj, key) => {
          acc[key] = lodash.omit(obj, 'hourValue');
          return acc;
        },
        {}
      );
      dataToSave.CaseFieldConfigItem = result;
    }
    const timestamp = moment(caseForm.timestamp, 'DD-MM-YYYY HH:mm:ss')
      .utc()
      .format()
      .replace('Z', '');
    if (
      caseForm.name !== caseData.name ||
      caseForm.description !== caseData.description ||
      caseForm.implemented !== caseData.implemented ||
      timestamp !== caseData.timestamp
    ) {
      dataToSave.Case = {
        [caseData.id]: { ...caseForm, timestamp, implemented: caseForm.implemented },
      };
    }
    if (Object.keys(dataToSave).length > 0) {
      const { data } = await CaseApi.updateCase({ ...dataToSave, CaseId: caseData.id });

      if (data.CaseFieldConfigItem) {
        const newFields = JSON.parse(JSON.stringify(fields));
        for (let [group, groupValues] of Object.entries(fields)) {
          for (let [itemKey, item] of Object.entries(groupValues)) {
            if (data?.CaseFieldConfigItem && item.id in data?.CaseFieldConfigItem) {
              const savedValue = data?.CaseFieldConfigItem[item.id];
              newFields[group][itemKey] = {
                ...item,
                ...savedValue,
                savedValue: savedValue.value,
              };
            }
          }
        }
        dispatch({ type: FIELDS, payload: newFields });
      }
      if (data.Case && data.Case[caseData.id]) {
        dispatch({ type: SET_CASE_DATA, payload: { ...caseData, ...data.Case[caseData.id] } });
      }
      dispatch({ type: CHANGE_FIELD_FOR_SAVE, payload: {} });

      Notice.success('Save case data success');
      closeModal && closeModal();
    }
    runOptimization && runOptimization();
  } catch (e) {
    handleError(e, 'Failed to save case data');
  } finally {
    dispatch({ type: LOADING_SAVE_CASE, payload: false });
  }
};

export const copyToConstraints = () => async (dispatch, getState) => {
  dispatch({ type: LOADING_SAVE_CASE, payload: true });
  try {
    const { changesData, fields, caseConfig } = getState()[caseModule];
    const { calculation, fieldBalance, caseData } = getState()[caseModule];
    const newChangeData = JSON.parse(JSON.stringify(changesData));
    const newFields = JSON.parse(JSON.stringify(fields));
    const fieldTotal = getTotalFromOption(undefined, fieldBalance);

    const calc = (source_tag, item) => {
      try {
        const newValue = evaluateCalculationString(
          source_tag,
          null,
          fieldTotal,
          newFields,
          caseConfig?.units,
          calculation?.calcDict
        );
        return newValue ? parseFloat(newValue).toFixed(2) : '0.00';
      } catch (err) {
        console.log(err, 'err');
        Notice.error(
          `${item.config_group || item.group}:${
            item.name
          }, check the formula, some fields were not found in the formula `
        );
      }
    };

    for (let [group, groupValues] of Object.entries(fields)) {
      for (let [itemKey, item] of Object.entries(groupValues)) {
        if (item.is_constraint && item.source_type === 'calc') {
          const value = calc(item.source_tag, item);
          const hourValue = (value / 24).toFixed(2);
          const newItem = { ...item, value, hourValue };
          newFields[group][itemKey] = newItem;
          if (value !== parseFloat(item.savedValue)) {
            if (newChangeData.CaseFieldConfigItem) {
              newChangeData.CaseFieldConfigItem[item.id] = {
                data_source: newItem?.data_source,
                timestamp: newItem?.timestamp ?? undefined,
                value: value,
                hourValue: (value / 24).toFixed(2),
              };
            } else {
              newChangeData.CaseFieldConfigItem = {
                [item.id]: {
                  data_source: newItem?.data_source,
                  timestamp: newItem?.timestamp ?? undefined,
                  value: value,
                  hourValue: (value / 24).toFixed(2),
                },
              };
            }
          }
        }
      }
    }
    dispatch({ type: FIELDS, payload: newFields });
    dispatch({
      type: CHANGE_FIELD_FOR_SAVE,
      payload: {
        CaseFieldConfigItem: { ...newChangeData.CaseFieldConfigItem },
        CaseId: caseData.id,
      },
    });
    dispatch({ type: SET_STATUS_COPY_CONSTRAINT, payload: true });
  } catch (e) {
    console.log(e, 'e');
    handleError(e, 'Failed to copy to constraints');
  } finally {
    dispatch({ type: LOADING_SAVE_CASE, payload: false });
  }
};

export const loadFieldPIData = (fieldParams, date) => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_FIELD_DATA, payload: true });
    const state = getState();
    const params = {
      fieldParams: fieldParams,
      timestamp: state[caseModule].caseForm.timestamp,
      fields: state[caseModule].fields,
      afServer: state[loginModule].appConfig['AF:AFServer'],
      classByUnits: state[caseModule].classByUnits,
      unitsByClass: state[caseModule].unitsByClass,
    };
    const fieldsToChange = await getFieldsToChange(params);
    const newFields = JSON.parse(JSON.stringify(state[caseModule].fields));
    const changes = {
      CaseId: state[caseModule].caseData.id,
      CaseFieldConfigItem: {},
    };

    for (const field of fieldsToChange) {
      getChangeFieldValue(field, newFields, changes, state);
    }

    dispatch({ type: FIELDS, payload: newFields });
    dispatch({ type: CHANGE_FIELD_FOR_SAVE, payload: changes });
    dispatch({ type: SET_STATUS_LOAD_FIELDS, payload: true });
  } catch (e) {
    handleError(e, 'Failed to load field data');
  } finally {
    dispatch({ type: LOADING_FIELD_DATA, payload: false });
  }
};

export const loadWellPIData = (fieldParams, copyGathering) => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_WELL_DATA, payload: true });
    const state = getState();
    const params = {
      fieldParams: fieldParams,
      caseWells: state[caseModule].caseData.case_wells,
      wellColumns: state[caseModule].caseConfig.wellColumns,
      wellCfg: state[caseModule].caseConfig.wellCfg,
      timestamp: state[caseModule].caseForm.timestamp,
      fields: state[caseModule].fields,
      afServer: state[loginModule].appConfig['AF:AFServer'],
      classByUnits: state[caseModule].classByUnits,
      unitsByClass: state[caseModule].unitsByClass,
    };

    const wellsToChange = await getWellsToChange(params);

    const connectionUpdatedMap = {};
    const changes = wellsToChange.map((change) =>
      getChangeCaseWells(
        change.caseWell,
        change.saveObj,
        change.isSelect,
        getState,
        true,
        connectionUpdatedMap
      )
    );

    dispatch(setPullWellsChanges(changes));
    if (copyGathering) {
      dispatch(wellCopyConnection());
      dispatch(wellCopyPressure());
      dispatch(wellCopyGathering());
    }
    dispatch({ type: SET_STATUS_LOAD_WELLS, payload: true });
  } catch (e) {
    handleError(e, 'Failed to load well data');
  } finally {
    dispatch({ type: LOADING_WELL_DATA, payload: false });
  }
};

export const loadGasTabData = (caseId) => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_CASE_OPTIONS, payload: true });
    const state = getState();
    const calcDict = state[caseModule].calculation?.calcDict || {};
    const caseData = state[caseModule].caseData;
    const { data } = await CaseApi.getCaseOption(caseId);
    const table = handleGasTableData(caseData, calcDict, data.caseOpts);
    const chart = handleGasChartData(data.caseOpts, calcDict);
    dispatch({ type: SET_GAS_TAB_DATA, table, chart });
  } catch (error) {
    console.error(error);
    Notice.error('Failed to load case option');
    handleError(error);
  } finally {
    dispatch({ type: LOADING_CASE_OPTIONS, payload: false });
  }
};

export const wellCopyConnection = (tab) => (dispatch, getState) => {
  try {
    const state = getState();
    const caseWells = state[caseModule].caseData?.case_wells || [];
    const unitWells = caseWells.filter((caseWell) => {
      const currentConnId = caseWell.gap_conn_id;
      var unitName = caseWell.gap_well.connectionMap[currentConnId].unit;
      return tab ? unitName === tab : ['KPC', 'U2', 'U3'].includes(unitName);
    });

    const wellChanges = unitWells.map((well) => {
      const newWell = { ...well, gap_conn_id: well.well_conn_id };
      const result = getChangeCaseWells(newWell, { column: 'gap_conn_id' }, true, getState);
      return result;
    });
    dispatch(setPullWellsChanges(wellChanges));
    dispatch({ type: SET_STATUS_COPY_CONNECTION, payload: true, tab });
  } catch (error) {
    console.error(error);
    handleError(error, 'Failed to copy connection values from "Config Flow" to "Gap Flow"');
  }
};

export const wellCopyPressure = (tab) => (dispatch, getState) => {
  try {
    const state = getState();
    const caseWells = state[caseModule].caseData?.case_wells || [];
    const unitWells = caseWells.filter((caseWell) => {
      const currentConnId = caseWell.gap_conn_id;
      var unitName = caseWell.gap_well.connectionMap[currentConnId].unit;
      return tab ? unitName === tab : ['KPC', 'U2', 'U3'].includes(unitName);
    });

    const wellChanges = unitWells.map((well) => {
      const saveObj = {
        CaseWell: { [well.id]: { target_pressure: well.whPressur.value } },
      };
      return getChangeCaseWells(
        { ...well, target_pressure: well.whPressur.value },
        saveObj,
        false,
        getState
      );
    });
    dispatch(setPullWellsChanges(wellChanges));
    dispatch({ type: SET_STATUS_COPY_WHPRESSUR, payload: true, tab });
  } catch (error) {
    handleError(error, 'Failed to copy connection values from "Config Flow" to "Gap Flow"');
  }
};

export const wellResetToMap = (tab) => (dispatch, getState) => {
  try {
    const state = getState();
    const classByUnits = state[caseModule].classByUnits;
    const unitsByClass = state[caseModule].unitsByClass;
    const wellColumns = state[caseModule].caseConfig.wellColumns;
    const caseWells = state[caseModule].caseData?.case_wells || [];
    const unitWells = caseWells.filter((caseWell) => {
      const currentConnId = caseWell.gap_conn_id;
      var unitName = caseWell.gap_well.connectionMap[currentConnId].unit;
      return unitName === tab;
    });

    const wellChanges = unitWells.map((well) => {
      const whPressur = well.whPressur;
      const newWell = { ...well };
      const column = wellColumns[whPressur.config_id];
      const map = { uom: 'bara', currValue: well.gap_well.map };
      const value = convertUnitDbRef(map, column, false, classByUnits, unitsByClass);
      const saveObj = {
        CaseWellConfigItem: {
          [`${newWell.id}-${whPressur.config_id}`]: { value, data_source: whPressur?.data_source },
        },
      };
      return getChangeCaseWells(
        { ...newWell, whPressur: { ...whPressur, value } },
        saveObj,
        false,
        getState
      );
    });
    dispatch(setPullWellsChanges(wellChanges));
  } catch (error) {
    handleError(error, 'Failed to reset to map');
  }
};

export const wellInvertSelect = (tab) => (dispatch, getState) => {
  try {
    const state = getState();
    const caseWells = state[caseModule].caseData?.case_wells || [];
    const unitWells = caseWells.filter((caseWell) => {
      const currentConnId = caseWell.gap_conn_id;
      var unitName = caseWell.gap_well.connectionMap[currentConnId].unit;
      return unitName === tab;
    });

    const wellChanges = unitWells.map((well) => {
      const newWell = { ...well, fixed: !well.fixed };
      return getChangeCaseWells(
        newWell,
        { CaseWell: { [well.id]: { fixed: !well.fixed } } },
        false,
        getState
      );
    });
    dispatch(setPullWellsChanges(wellChanges));
  } catch (error) {
    handleError(error, 'Failed to invert checkboxes');
  }
};

export const wellAllSelect = (tab, wellName) => (dispatch, getState) => {
  try {
    const state = getState();
    const caseWells = state[caseModule].caseData?.case_wells || [];
    const unitWells = caseWells.filter((caseWell) => {
      const currentConnId = caseWell.gap_conn_id;
      var unitName = caseWell.gap_well.connectionMap[currentConnId].unit;
      return unitName === tab;
    });
    let flip = true;
    for (const well of unitWells) {
      if (well[wellName]) {
        flip = false;
        break;
      }
    }
    const wellChanges = unitWells.map((well) => {
      const newWell = { ...well, [wellName]: flip };
      return getChangeCaseWells(
        newWell,
        { CaseWell: { [well.id]: { [wellName]: flip } } },
        false,
        getState
      );
    });
    dispatch(setPullWellsChanges(wellChanges));
  } catch (error) {
    console.error(error);
    handleError(error, 'Failed to copy values from to "Below map"');
  }
};

export const wellCopyGathering = (tab) => (dispatch, getState) => {
  try {
    const state = getState();
    const caseWells = state[caseModule].caseData?.case_wells || [];
    const unitWells = caseWells.filter((caseWell) => {
      const currentConnId = caseWell.gap_conn_id;
      const unitName = caseWell.gap_well.connectionMap[currentConnId].unit;
      return tab ? unitName === tab : ['KPC', 'U2', 'U3'].includes(unitName);
    });

    const wellChanges = unitWells.map((well) => {
      let newValue = well?.gatheringStatus?.value === 'CLOSED';
      return getChangeCaseWells(
        { ...well, mask_well: newValue },
        { CaseWell: { [well.id]: { mask_well: newValue } } },
        false,
        getState
      );
    });
    dispatch(setPullWellsChanges(wellChanges));
    dispatch({ type: SET_STATUS_COPY_GASERING, payload: true, tab });
  } catch (error) {
    handleError(error, 'Failed to copy values from to "Mask well"');
  }
};

export const runOptimization = (params, user_id) => (dispatch, getState) => {
  const state = getState();
  const fields = state[caseModule].fields;
  const fieldOptimization = state[loginModule].userConfig[GAS_FIELD_OPTIMISATION];
  if (fieldOptimization) {
    GAS_OPTIMIZATION_FIELDS_COPY.forEach((item) => {
      const field = fields[item.copyTo.group][item.copyTo.field];
      const value = fields[item.group][item.field].value;
      dispatch(changeFieldValue({ ...field, value, data_source: 'Paste' }));
    });
  }
  dispatch(
    saveChangesCase(null, () => {
      ScheduledApi.runOptimization(params)
        .then(() => {
          Notice.success('Data sent to run optimizations');
          dispatch(openScheduledModal(true));
          dispatch(changeActiveMenu(null));
          dispatch(setSelectedCase(params.caseId));
          setTimeout(Notice.clearAll, 5000);
        })
        .catch((e) => handleError(e, 'Failed to run optimizations'));
    })
  );
};

export const copyAllocationFactory = (isCurrent) => (dispatch, getState) => {
  try {
    const state = getState();
    const calcDict = state[caseModule].calculation?.calcDict;
    const labelDict = state[caseModule].calculation?.labelDict;
    const afValues = {};
    const labelDictKey = isCurrent ? 'AF Table:Current' : 'AF Table:New';

    for (let name of Object.keys(labelDict[labelDictKey])) {
      afValues[name] = calcDict[name]?.results?.default?.value;
    }
    afValues.isCurrent = isCurrent;
    localStorage.setItem('afValues', JSON.stringify(afValues));
  } catch (error) {
    handleError(error, 'Failed to copy allocation factors');
  }
};

export const setAllocationFactory = (isSetValueOne) => (dispatch, getState) => {
  try {
    const fields = getState()[caseModule].fields;
    const stringAfValues = localStorage.getItem('afValues');

    if (stringAfValues && !isSetValueOne) {
      const afValues = JSON.parse(stringAfValues);
      const isCurrent = afValues.isCurrent;

      for (const afName of Object.keys(isCurrent ? currentFieldMappings : afFieldMappings)) {
        const { grp, field: fieldName } = isCurrent
          ? currentFieldMappings[afName]
          : afFieldMappings[afName];
        const field = { ...fields[grp][fieldName] };
        let value = parseFloat(afValues[afName]);
        if (parseFloat(field.min) > value) {
          value = parseFloat(field.min);
        }
        dispatch(changeFieldValue({ ...field, value, data_source: 'Paste' }));
      }
    } else if (isSetValueOne) {
      for (const afName of Object.keys(afFieldMappings)) {
        const { grp, field: fieldName } = afFieldMappings[afName];
        const field = { ...fields[grp][fieldName] };
        dispatch(changeFieldValue({ ...field, value: '1.00', data_source: 'Paste' }));
      }
    }

    Notice.success('Allocation factors have been pasted');
  } catch (error) {
    handleError(error, 'Failed to copy allocation factors');
  }
};

export const setHoveredUnit = (unitName) => (dispatch) => {
  dispatch({ type: HOVER_UNIT, payload: unitName });
};
