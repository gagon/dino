import { createReducer } from '@reduxjs/toolkit';
import { ALLOCATION_FACTORY, CONSTRAINS, FIELD_DATA, WELL_DATA } from './MenuItems';

/**
 * Constants
 */

export const caseMenuModule = 'caseMenu';
export const activeMenu = `${caseMenuModule}/activeMenu`;
const CHANGE_ACTIVE_MENU = `${caseMenuModule}/CHANGE_ACTIVE_MENU`;
const SET_TAB_PAGE = `${caseMenuModule}/SET_TAB_PAGE`;
const SET_EXPAND = `${caseMenuModule}/SET_EXPAND`;
const CLEAR = `${caseMenuModule}/CLEAR`;

/**
 * Reducer
 */

const initialState = {
  activeMenu: null,
  loading: false,
  expanded: 'SETTINGS',
  page: 1
};

export default createReducer(initialState, {
  [CHANGE_ACTIVE_MENU]: (state, { payload }) => {
    if (state.activeMenu === payload) {
      state.activeMenu = null;
    } else {
      state.activeMenu = payload;
      if (payload === WELL_DATA && ![2, 3, 4].includes(state.page)) {
        state.page = 2;
      }
      if (payload === FIELD_DATA) {
        state.page = 1;
      }
      if (payload === CONSTRAINS) {
        state.page = 1;
        state.expanded = 'OPTIMIZATION';
      }
      if (payload === ALLOCATION_FACTORY) {
        state.page = 1;
        state.expanded = 'OPTIMIZATION';
      }
    }
  },
  [SET_TAB_PAGE]: (state, { payload }) => {
    state.page = payload
  },
  [SET_EXPAND]: (state, { payload }) => {
    state.expanded = payload
  },
  [CLEAR]: () => initialState,
});

/**
 * Actions
 */

export const clear = () => ({ type: CLEAR });

export const setTabPage = (page) => ({ type: SET_TAB_PAGE, payload: page });

export const setExpanded = (name) => ({ type: SET_EXPAND, payload: name });

export const changeActiveMenu = (menuItem) => ({ type: CHANGE_ACTIVE_MENU, payload: menuItem });
