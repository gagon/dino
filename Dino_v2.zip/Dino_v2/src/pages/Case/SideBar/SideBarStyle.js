import styled from 'styled-components';
import MuiAccordionSummary from '@mui/material/AccordionSummary';
import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import React from 'react';
import MuiAccordion from '@mui/material/Accordion';

export const StyledSideBar = styled.div`
  background: #fbfaff;
  padding-top: 20px;
  width: 94px;
  text-align: center;
  border: none;
  z-index: 2;
  padding-left: 8px;
  min-height: calc(100vh - 114px);

  p {
    margin: 0;
  }

  .sidebar {
    .sticky {
      position: sticky;
      top: 0;
    }

    .active {
      background-color: ${(props) => props.theme.palette.action.selected};
      div {
        color: ${(props) => props.theme.palette.primary.main};
      }
    }
  }
`;

export const Accordion = styled((props) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  minHeight: 60,
  width: 78,
  borderRadius: 14,
  // width: '100%',
  boxShadow: '0px 8px 14px 0px #3E6BE01F !important',
  marginBottom: 20,

  border: `none`,
  '&:not(:last-child)': {
    borderBottom: 0,
  },
  '&:before': {
    /* Rectangle 5372 */

    display: 'none',
  },
}));

export const AccordionSummary = styled((props) => (
  <MuiAccordionSummary
    expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: '0.9rem', minHeight: 40, height: 40 }} />}
    {...props}
  />
))(() => ({ height: 40 }));
