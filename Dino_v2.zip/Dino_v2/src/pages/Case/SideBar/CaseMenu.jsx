import React from 'react';
import DownIcon from '@mui/icons-material/KeyboardArrowDown';
import UpIcon from '@mui/icons-material/KeyboardArrowUp';
import { AccordionDetails } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import { useTheme } from '@mui/styles';
import { useDispatch, useSelector } from 'react-redux';
import FieldFilters from '../FieldFilters';
import { caseMenuModule, setExpanded } from './CaseMenuDucks';
import { menuItems } from './MenuItems';
import { Accordion, AccordionSummary, StyledSideBar } from './SideBarStyle';
import './SideBarTranslate';

export default function CaseSideBar({ children }) {
  return (
    <div className="flex">
      <CaseMenu />
      {children}
    </div>
  );
}

export function CaseMenu() {
  const dispatch = useDispatch();
  const theme = useTheme();
  const expanded = useSelector((state) => state[caseMenuModule].expanded);
  const handleChange = (panel) => {
    dispatch(setExpanded(expanded === panel ? null : panel));
  };

  return (
    <StyledSideBar className={'desktop'}>
      <div className="sidebar flex justify-center">
        <div className="">
          <FieldFilters />
          {menuItems.map((item, index) => {
            return (
              <Accordion
                key={index}
                expanded={expanded === item.text}
                onChange={() => handleChange(item.text)}
              >
                <AccordionSummary
                  aria-controls="panel1d-content"
                  id="panel1d-header"
                  expandIcon={null}
                >
                  <div>
                    <span
                      className="fs-10 bold "
                      children={item.text}
                      style={{
                        color: theme.palette.action.disabled,
                      }}
                    />
                    <div style={{ height: 8 }}>
                      {expanded === item.text ? (
                        <UpIcon color={'disabled'} />
                      ) : (
                        <DownIcon color={'disabled'} />
                      )}
                    </div>
                  </div>
                </AccordionSummary>
                <AccordionDetails style={{ paddingRight: 8, paddingLeft: 8 }}>
                  {item?.subMenu?.map((item, index) => (
                    <div key={index} className="mb2">
                      {item?.component ? (
                        item.component()
                      ) : (
                        <>
                          <IconButton>{item.icon}</IconButton>
                          <p className="fs-10">{item.text}</p>
                        </>
                      )}
                    </div>
                  ))}
                </AccordionDetails>
              </Accordion>
            );
          })}
        </div>
      </div>
    </StyledSideBar>
  );
}
