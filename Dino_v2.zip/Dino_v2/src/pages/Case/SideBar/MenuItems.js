import ProfileIcon from '@mui/icons-material/AccountCircleOutlined';
import React from 'react';
import paths from '../../../_helpers/paths';
import ReportIcon from '../../../_media/ReportIcon';
import AllocationFactoryPaste from '../AllocationFactoryPaste/AllocationFactoryPaste';
import CaseActionModal from '../CaseActions/CaseActionModal';
import CopyToConstraint from '../CopyToConstraint/CopyToConstraint';
import FieldDataModal from '../FieldWellDataModal/FieldDataModal';
import WellDataModal from '../FieldWellDataModal/WellDataModal';
import Optimization from '../Optimization/Optimization';
import ReportDownload from '../ReportDownload';
import ViewResults from '../ViewResults/ViewResults';

export const CASE_ACTION_MODAL = 'caseActionModal';
export const FIELD_DATA = 'fieldData';
export const COMP = 'comp';
export const WELL_DATA = 'wellData';
export const CONSTRAINS = 'Constraints';
export const ALLOCATION_FACTORY = 'AllocationFactory';
export const OPTIMIZATION = 'Optimization';
export const VIEW_RESULTS = 'viewResults';
export const REPORT = 'Report';

export const menuItems = [
  {
    text: 'SETTINGS',
    icon: <ProfileIcon />,
    to: paths.adminUser,
    subMenu: [
      {
        key: CASE_ACTION_MODAL,
        onClick: (modal) => modal.open(),
        component: (props) => <CaseActionModal {...props} />,
      },
      {
        key: FIELD_DATA,
        component: (props) => <FieldDataModal {...props} />,
      },
      {
        key: WELL_DATA,
        component: (props) => <WellDataModal {...props} />,
      },
    ],
  },
  {
    text: 'OPTIMIZATION',
    icon: <ProfileIcon />,
    to: paths.adminUser,
    subMenu: [
      {
        key: CONSTRAINS,
        component: (props) => <CopyToConstraint />,
      },
      {
        key: CONSTRAINS,
        component: (props) => <AllocationFactoryPaste />,
      },
      {
        key: OPTIMIZATION,
        component: (props) => <Optimization {...props} />,
      },
      {
        key: VIEW_RESULTS,
        component: (props) => <ViewResults {...props} />,
      },
      {
        key: REPORT,
        component: (props) => <ReportDownload {...props} />,
      },
    ],
  },
];
