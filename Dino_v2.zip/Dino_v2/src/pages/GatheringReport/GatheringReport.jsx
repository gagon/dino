import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import Legend from './Components/Legend';
import LoadFromDatabase from './Components/LoadFromDatabase';
import SpreadsheetInput from './Components/SpreadsheetInput';
import Wells from './Components/Wells/Wells';
import { initConfigs } from './GatheringReportDucks/GatheringReportDucks';

const GatheringReport = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(initConfigs());
  }, []);

  return (
    <>
      <div
        style={{ display: 'flex', justifyContent: 'space-between', gap: '40px', padding: '25px' }}
      >
        <SpreadsheetInput />
        <LoadFromDatabase />
        <Legend />
      </div>

      <Wells />
    </>
  );
};

export default GatheringReport;
