import styled from '@emotion/styled';

export const StyledWrapper = styled.div`
  min-width: 420px;
  width: 100%;
  height: fit-content;
  border: 1px solid;
  border-color: #ddd;
  border-radius: 8px;

  overflow: hidden;

  .title {
    background-color: #efefef;
    padding: 15px;
  }

  .children {
    padding: 20px 15px;
  }
`;

export const tableStyle = {
  marginTop: 4,
  width: '100%',
  height: '100%',
  '& .MuiDataGrid-columnHeader:last-child .MuiDataGrid-columnSeparator': {
    display: 'none',
  },
  '& .MuiDataGrid-cell': {
    whiteSpace: 'normal !important',
    alignItems: 'center',
    width: '100%',
  },
  '& .MuiDataGrid-columnHeaderTitle': {
    whiteSpace: 'normal !important',
  },
  '& .super-app-theme--found': {
    bgcolor: '#D4EEFF',
  },
  '& .super-app-theme--disabled': {
    bgcolor: 'lightgray',
  },
};

export const paginationWrapperStyle = {
  display: 'flex',
  gap: 12,
  alignItems: 'center',
  justifyContent: 'flex-end',
  marginTop: 10,
};
