import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import moment from 'moment';
import { Box, Button } from '@mui/material';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';

import DateTimePicker from '../../../common/_MuiHookForm/DesktopDatePicker';
import Wrapper from './Wrapper';
import {
  gatheringReportModule,
  getGatheringReportDates,
  getGatheringReportData,
} from '../GatheringReportDucks/GatheringReportDucks';
import { DATE_FORMAT } from '../../../common/_MuiHookForm/DesktopDatePicker';

const LoadFromDatabase = () => {
  const [date, setDate] = useState(moment().format(DATE_FORMAT));
  const dates = useSelector((state) => state[gatheringReportModule].databaseDates);
  const dispatch = useDispatch();

  const setDateToTwoWeeksAgo = () => {
    setDate((prev) => moment(prev, DATE_FORMAT).subtract(14, 'days').format(DATE_FORMAT));
  };
  const setDateToTwoWeeksLater = () => {
    setDate((prev) => moment(prev, DATE_FORMAT).add(14, 'days').format(DATE_FORMAT));
  };

  const handleLoadFromDatabase = (item) => {
    if (item.selected) {
      dispatch(getGatheringReportData(item));
    }
  };

  useEffect(() => {
    dispatch(getGatheringReportDates(date));
  }, [date]);

  return (
    <Wrapper title="Load Gathering Report From Database">
      <DateTimePicker
        onChange={(value) => setDate((prev) => value)}
        sx={{ margin: 0, width: 314 }}
        value={date}
      />

      <Box sx={{ marginTop: '15px' }}>
        <table style={{ width: '100%', borderSpacing: 0 }}>
          <tbody>
            <tr>
              {dates.day.map((item) => (
                <td
                  key={item.value}
                  style={{
                    border: '1px solid lightgray',
                    fontSize: 12,
                    textAlign: 'center',
                    height: 40,
                    backgroundColor: item.selected ? '#A4DE02' : '#f0e2a3',
                    fontWeight: 600,
                    cursor: item.selected ? 'pointer' : 'default',
                  }}
                  onClick={() => handleLoadFromDatabase(item)}
                >
                  {item.value}
                </td>
              ))}
            </tr>
            <tr>
              {dates.night.map((item) => (
                <td
                  key={item.value}
                  style={{
                    border: '1px solid lightgray',
                    fontSize: 12,
                    textAlign: 'center',
                    height: 40,
                    color: item.selected ? 'black' : 'white',
                    backgroundColor: item.selected ? '#A4DE02' : 'rgba(80, 81, 249, 0.9)',
                    cursor: item.selected ? 'pointer' : 'default',
                    fontWeight: 600,
                  }}
                  onClick={() => handleLoadFromDatabase(item)}
                >
                  {item.value}
                </td>
              ))}
            </tr>
          </tbody>
        </table>

        <Box sx={{ display: 'flex', gap: 1, marginTop: 1 }}>
          <Button
            variant="contained"
            color="primary"
            sx={{ height: '30px', minWidth: '45px', borderRadius: '4px', padding: '6px' }}
            onClick={setDateToTwoWeeksAgo}
          >
            <KeyboardDoubleArrowLeftIcon />
          </Button>
          <Button
            variant="contained"
            color="primary"
            sx={{ height: '30px', minWidth: '45px', borderRadius: '4px', padding: '6px' }}
            onClick={setDateToTwoWeeksLater}
          >
            <KeyboardDoubleArrowRightIcon />
          </Button>
        </Box>
      </Box>
    </Wrapper>
  );
};

export default LoadFromDatabase;
