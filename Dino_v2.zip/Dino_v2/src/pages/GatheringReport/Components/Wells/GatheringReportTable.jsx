import React, { useState, useMemo } from 'react';
import { useSelector } from 'react-redux';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TablePagination from '@mui/material/TablePagination';
import CircularProgress from '@mui/material/CircularProgress';
import IconButton from '@mui/material/IconButton';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';

import { gatheringReportModule } from '../../GatheringReportDucks/GatheringReportDucks';

const GatheringReportTable = ({ columns, rows }) => {
  const loading = useSelector((state) => state[gatheringReportModule].loading);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [page, setPage] = useState(0);
  const [sortable, setSortable] = useState({});

  const setColumnSorting = (column) => {
    if (sortable.column === column && sortable.sort === 'desc') {
      setSortable({ column, sort: 'asc' });
    } else if (sortable.column === column && sortable.sort === 'asc') {
      setSortable({});
    } else {
      setSortable({ column, sort: 'desc' });
    }
  };

  const currentRows = useMemo(() => {
    const startIndex = page * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    return rows.slice(startIndex, endIndex);
  }, [rows, page, rowsPerPage]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(event.target.value);
    setPage(0);
  };

  return (
    <div style={{ background: 'white', borderRadius: 8, overflow: 'hidden' }}>
      <TableContainer sx={{ maxHeight: '100%' }}>
        <Table>
          <TableHead sx={{ background: '#EEF0F9', height: 56 }}>
            <TableRow>
              {columns.map((column, index) => (
                <TableCell
                  key={column.field}
                  onClick={() => column.valueGetter && setColumnSorting(column.headerName)}
                  align={column.align || 'left'}
                  children={
                    <div
                      style={{
                        borderRight: '2px solid rgb(214 215 217)',
                        paddingRight: 16,
                      }}
                    >
                      {column.headerName}

                      {sortable.column === column.headerName &&
                        sortable.sort === 'desc' &&
                        column.valueGetter && (
                          <IconButton size="small">
                            <ArrowDownwardIcon fontSize="small" />
                          </IconButton>
                        )}
                      {sortable.column === column.headerName &&
                        sortable.sort === 'asc' &&
                        column.valueGetter && (
                          <IconButton size="small">
                            <ArrowUpwardIcon fontSize="small" />
                          </IconButton>
                        )}
                    </div>
                  }
                  sx={{
                    lineHeight: 1,
                    fontWeight: 600,
                    fontSize: 14,
                    padding: '12px 0 12px 10px',
                    cursor: column.valueGetter ? 'pointer' : 'inherit',
                  }}
                />
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {currentRows.length !== 0 && loading ? (
              <TableRow>
                <TableCell colSpan="10">
                  <div
                    className="flex items-center justify-center fullWidth"
                    style={{ height: 80 }}
                  >
                    <CircularProgress />
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              <>
                {[...currentRows]
                  .sort((a, b) => compare(a, b, sortable, columns))
                  .map((row) => (
                    <TableRow
                      key={row.id}
                      sx={{
                        bgcolor: row?.wcfg?.disabled
                          ? '#d8d8d8'
                          : row.status === 'found' || row?.backgroundColor === 'lightblue'
                          ? 'rgb(212, 238, 255)'
                          : '',
                      }}
                    >
                      {columns.map((column) => (
                        <TableCell
                          key={column.headerName + row.id}
                          align={column.align || 'left'}
                          children={column.renderCell({ row })}
                          sx={{
                            width: column.width,
                            minWidth: column.minWidth,
                            borderBottom: '1px solid #EEF0F9',
                            borderRight: '1px solid #EEF0F9',
                            maxHeight: 40,
                            padding: '4px',
                          }}
                        />
                      ))}
                    </TableRow>
                  ))}
              </>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {currentRows.length === 0 && !loading && (
        <div className="flex items-center justify-center" style={{ height: 80 }}>
          no rows
        </div>
      )}

      <TablePagination
        rowsPerPageOptions={[10, 25, 50, 100, 200]}
        component="div"
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        labelRowsPerPage="Wells per page:"
        labelDisplayedRows={({ from, to, count }) => {
          return '' + from + ' - ' + to + ' from ' + count;
        }}
      />
    </div>
  );
};

export default GatheringReportTable;

function compare(rowA, rowB, sortableObj, columns) {
  try {
    const sortable =
      Object.keys(sortableObj).length > 0
        ? sortableObj
        : { sort: 'desc', column: (columns.find((i) => i.defaultSort) || columns[0]).headerName };
    const column = columns.find((c) => c.headerName === sortable.column);
    if (column && sortable.sort && column.valueGetter) {
      let a = column.valueGetter({ row: rowA });
      let b = column.valueGetter({ row: rowB });

      if (column.type === 'number') {
        a = parseFloat(a) || 0;
        b = parseFloat(b) || 0;
      }
      if (a < b && sortable.sort === 'desc') {
        return -1;
      }
      if (a > b && sortable.sort === 'desc') {
        return 1;
      }
      if (a < b && sortable.sort === 'asc') {
        return 1;
      }
      if (a > b && sortable.sort === 'asc') {
        return -1;
      }
    }
  } catch (e) {
    console.error(e.message);
  }

  return 0;
}
