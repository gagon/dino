import React from 'react';
import { useSelector } from 'react-redux';
import { Box } from '@mui/material';

import WellsHeader from './WellsHeader';
import WellsTable from './WellsTable';
import DataLoader from '../../../../common/DataLoader';
import { gatheringReportModule } from '../../GatheringReportDucks/GatheringReportDucks';

const Wells = () => {
  const reportData = useSelector((state) => state[gatheringReportModule].reportData);
  const loadingReport = useSelector((state) => state[gatheringReportModule].loadingReport);

  if (loadingReport) return <DataLoader />;

  if (!reportData) return null;

  return (
    <Box sx={{ backgroundColor: '#fff', margin: '25px', padding: '15px', borderRadius: '8px' }}>
      <WellsHeader />
      <WellsTable />
    </Box>
  );
};

export default Wells;
