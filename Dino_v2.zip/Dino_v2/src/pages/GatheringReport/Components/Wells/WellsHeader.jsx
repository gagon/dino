import React, { useState, useCallback, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import moment from 'moment';
import { Box, Button, TextField, Typography, FormControlLabel, Checkbox } from '@mui/material';

import DateTimePicker from '../../../../common/_MuiHookForm/DesktopDatePicker';
import {
  compareToDBValues,
  compareToPIValues,
  gatheringReportModule,
  loadToPITags,
  saveToDatabase,
  toggleCheckFound,
  toggleMissingData,
} from '../../GatheringReportDucks/GatheringReportDucks';

const WellsHeader = () => {
  const [loadDate, setLoadDate] = useState(null);
  const isShowMissingData = useSelector((state) => state[gatheringReportModule].isShowMissingData);
  const isCheckFound = useSelector((state) => state[gatheringReportModule].isCheckFound);
  const { fileName, timeExcel, shiftExcel, dt } = useSelector(
    (state) => state[gatheringReportModule].reportData
  );
  const dispatch = useDispatch();

  const fileDate = useMemo(() => {
    if (loadDate) {
      return moment(loadDate, 'DD-MM-YYYY HH:mm:ss').format('YYYY-MM-DDTHH:mm:ss');
    } else {
      return dt;
    }
  }, [loadDate, dt]);

  const saveToDatabaseHandler = useCallback(() => {
    dispatch(saveToDatabase(fileDate));
  }, [dispatch, saveToDatabase, fileDate]);

  const loadToPITagsHandler = useCallback(() => {
    dispatch(loadToPITags(fileDate));
  }, [dispatch, loadToPITags, fileDate]);

  const compareToPIValuesHandler = useCallback(() => {
    dispatch(compareToPIValues(fileDate));
  }, [dispatch, compareToPIValues, fileDate]);

  const compareToDBValuesHandler = useCallback(() => {
    dispatch(compareToDBValues(fileDate));
  }, [dispatch, compareToDBValues, fileDate]);

  return (
    <>
      <Typography color="primary" sx={{ fontSize: '24px', fontWeight: 'bold' }}>
        Wells
      </Typography>

      <Box sx={{ display: 'flex', gap: 4, px: 4, marginTop: 3 }}>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <Typography sx={{ fontWeight: 'bold' }}>File Name</Typography>
            <TextField
              sx={{ width: 314, margin: 0, color: 'black !important' }}
              value={fileName || ''}
              InputProps={{ sx: { px: '16px', py: '5.5px' }, readOnly: true }}
            />
          </Box>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <Typography sx={{ fontWeight: 'bold' }}>Load Date</Typography>
            <DateTimePicker
              onChange={(value) => setLoadDate((prev) => value)}
              value={moment(fileDate).format('DD-MM-YYYY HH:mm:ss')}
              sx={{ margin: 0, width: 314, fontWeight: 500 }}
            />
          </Box>

          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, marginTop: 1 }}>
              <Button
                variant="contained"
                size="small"
                sx={{ textTransform: 'none', width: 140 }}
                onClick={saveToDatabaseHandler}
              >
                Save To Database
              </Button>
              <Button
                variant="contained"
                size="small"
                sx={{ textTransform: 'none', width: 140 }}
                onClick={loadToPITagsHandler}
              >
                Load To PI Tags
              </Button>
            </Box>

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, marginTop: 1 }}>
              <Button
                variant="contained"
                size="small"
                sx={{ textTransform: 'none', width: 200 }}
                onClick={compareToDBValuesHandler}
              >
                Compare to previous DB values
              </Button>
              <Button
                variant="contained"
                size="small"
                sx={{ textTransform: 'none', width: 200 }}
                onClick={compareToPIValuesHandler}
              >
                Compare to previous PI values
              </Button>
            </Box>
          </Box>
        </Box>

        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            gap: 1.5,
          }}
        >
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <Typography sx={{ fontWeight: 'bold' }}>Excel Date/Shift</Typography>
            <TextField
              sx={{ width: 314, margin: 0 }}
              value={timeExcel && shiftExcel ? timeExcel + ': ' + shiftExcel : timeExcel}
              InputProps={{ sx: { px: '16px', py: '5.5px' }, readOnly: true }}
            />
          </Box>
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: 1,
              alignItems: 'start',
            }}
          >
            <FormControlLabel
              control={
                <Checkbox
                  sx={{ padding: 0 }}
                  checked={isShowMissingData}
                  onChange={() => dispatch(toggleMissingData())}
                />
              }
              label={
                <Typography sx={{ fontWeight: 'bold', ml: '4px' }}>Show/Hide Missing</Typography>
              }
              sx={{ margin: 0, height: 29 }}
            />
            <FormControlLabel
              control={
                <Checkbox
                  sx={{ padding: 0 }}
                  checked={isCheckFound}
                  onChange={() => dispatch(toggleCheckFound())}
                />
              }
              label={
                <Typography sx={{ fontWeight: 'bold', ml: '4px' }}>Check/Uncheck Found</Typography>
              }
              sx={{ margin: 0, height: 29 }}
            />
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default WellsHeader;
