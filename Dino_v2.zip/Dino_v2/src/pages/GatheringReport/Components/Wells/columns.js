import React, { useCallback, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IconButton, Checkbox, Tooltip, Box } from '@mui/material';
import ShuffleIcon from '@mui/icons-material/Shuffle';

import { gatheringReportModule, updateWell } from '../../GatheringReportDucks/GatheringReportDucks';
import { buildConnStr } from '../../GatheringReportDucks/utils';
import WellConnectionsModal from '../../../../common/WellConnectionsModal/WellConnectionsModal';

export const columns = () => [
  {
    field: 'wellName',
    headerName: 'Well Name',
    minWidth: 95,
    type: 'number',
    valueGetter: ({ row }) => row?.wcfg?.pa_name || row?.excel,
    renderCell: ({ row }) => <WellNameCell row={row} />,
  },
  {
    field: 'update',
    headerName: 'Update',
    align: 'center',
    valueGetter: ({ row }) => row?.selected,
    renderCell: ({ row }) => <UpdateCell data={row} />,
  },
  {
    field: 'disabled',
    headerName: 'Disabled',
    align: 'center',
    valueGetter: ({ row }) => row?.wcfg?.disabled,
    renderCell: ({ row }) => String(row?.wcfg?.disabled),
  },
  {
    field: 'status',
    headerName: 'Status',
    align: 'center',
    valueGetter: ({ row }) => row?.status,
    renderCell: ({ row }) => <StatusCell value={row?.status} title={row?.columns?.status?.title} />,
  },
  {
    minWidth: 230,
    field: 'excelTxt',
    headerName: 'Dino Route',
    renderCell: ({ row }) => <DinoRouteCell row={row} />,
  },
  {
    field: 'gatheringStatus',
    headerName: 'Gathering Status',
    align: 'center',
    valueGetter: ({ row }) => row?.gathering_status,
    renderCell: ({ row }) => (
      <StatusCell value={row?.gathering_status} title={row?.columns?.gath_status?.title} />
    ),
  },
  {
    minWidth: 140,
    field: 'wluFlowTo',
    headerName: 'WLU Flow to',
    renderCell: ({ row }) => <SelectCell data={row} field="unit" />,
  },
  {
    minWidth: 140,
    field: 'wluRouting',
    headerName: 'WLU Routing',
    renderCell: ({ row }) => <SelectCell data={row} field="rms" />,
  },
  {
    minWidth: 140,
    field: 'wluTrunkline',
    headerName: 'WLU Trunkline',
    renderCell: ({ row }) => <SelectCell data={row} field="tl" />,
  },
  {
    minWidth: 140,
    field: 'wluMPLP',
    headerName: 'WLU MP_LP',
    renderCell: ({ row }) => <SelectCell data={row} field="mp_lp" />,
  },
];

const WellNameCell = ({ row }) => {
  const [isOpen, setIsOpen] = useState(false);
  const mapping = useSelector(
    (state) => state[gatheringReportModule].caseConfig.connection.mapping
  );
  const gapWells = useSelector((state) => state[gatheringReportModule].gapConfig.gap_wells);
  const wellId = row?.id;
  const isExist = gapWells[wellId];
  const gapId = gapWells[wellId]?.gap_id;
  const wellName = row?.wcfg?.pa_name || row?.excel;

  const dispatch = useDispatch();

  const updateColumnValues = useCallback(
    (connRow) => {
      const conn_id = connRow?.conn_id;
      const conn = mapping[conn_id];
      const updatedWell = {
        ...row,
        tag_unit: conn.tag_unit,
        tag_rms: conn.tag_rms.split(',')[0],
        tag_tl: conn.tag_tl.split(',')[0],
        tag_mp_lp: conn.tag_mp_lp.split(',')[0],
      };
      dispatch(updateWell(row?.excel, updatedWell));
    },
    [dispatch, updateWell, row, mapping]
  );

  return (
    <>
      {isOpen && (
        <WellConnectionsModal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          wellId={wellId}
          gapId={gapId}
          isEditMode={false}
          onRowClick={updateColumnValues}
        />
      )}

      <Box
        sx={{
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          paddingLeft: '5px',
        }}
      >
        {wellName}
        {isExist && (
          <IconButton
            sx={{ padding: 0, marginLeft: '4px' }}
            size="small"
            onClick={() => setIsOpen(true)}
            children={<ShuffleIcon fontSize="small" />}
          />
        )}
      </Box>
    </>
  );
};

const UpdateCell = ({ data }) => {
  const checked = data?.selected;
  const dispatch = useDispatch();
  const onChange = (e) => dispatch(updateWell(data?.excel, { ...data, selected: !checked }));

  return <Checkbox sx={{ padding: 0 }} checked={checked} onChange={onChange} />;
};

const DinoRouteCell = ({ row }) => {
  const caseConfig = useSelector((state) => state[gatheringReportModule].caseConfig);

  const routeString = useMemo(() => {
    switch (row?.status) {
      case 'found':
        return buildConnStr(row, caseConfig);
      case 'missing':
        return 'No matching Dino connection';
      default:
        return `Row(${row?.excelRow + 1}) - ${row?.excelRms} : ${row?.excelTxt}`;
    }
  }, [row, caseConfig]);

  return <div style={{ paddingLeft: 5 }}>{routeString}</div>;
};

const StatusCell = ({ value = '', title = '' }) => (
  <Tooltip title={title} enterDelay={1000}>
    <span>{value}</span>
  </Tooltip>
);

const SelectCell = ({ data, field }) => {
  const hierarchy = useSelector((state) => state[gatheringReportModule].reportData.hierarchy);
  const wellId = data?.excel;
  const value = data?.['tag_' + field] || 'not chosen';
  const color = data?.columns?.[field]?.color;
  const title = data?.columns?.[field]?.title || '';
  const options =
    field === 'tl'
      ? [...Object.values(hierarchy?.tl), 'GORLine1', 'GORLine2']
      : Object.values(hierarchy?.[field]);
  const menuItemStyle = { color };
  const dispatch = useDispatch();

  const onChange = (e) => {
    dispatch(updateWell(wellId, { ...data, ['tag_' + field]: e.target.value }));
  };

  return (
    <Tooltip title={title} enterDelay={2000}>
      <div className="flex items-center fullWidth" style={{ paddingLeft: 4 }}>
        <select
          placeholder="not chosen"
          value={value}
          onChange={onChange}
          style={{
            height: 24,
            width: '100%',
            borderRadius: '3px',
            borderColor: 'lightgray',
            paddingLeft: 5,
            color,
          }}
        >
          <option value="not chosen" style={menuItemStyle}>
            not chosen
          </option>
          {options.map((option) => (
            <option key={option} value={option} style={menuItemStyle}>
              {option}
            </option>
          ))}
        </select>
      </div>
    </Tooltip>
  );
};
