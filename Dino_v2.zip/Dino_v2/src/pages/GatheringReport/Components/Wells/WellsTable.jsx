import React, { useState, useMemo } from 'react';
import { useSelector } from 'react-redux';

import GatheringReportTable from './GatheringReportTable';
import { gatheringReportModule } from '../../GatheringReportDucks/GatheringReportDucks';
import { columns } from './columns';

const WellsTable = () => {
  const wells = useSelector((state) => state[gatheringReportModule].wells);
  const isShowMissingData = useSelector((state) => state[gatheringReportModule].isShowMissingData);

  const rows = useMemo(() => {
    if (wells) {
      const wellsList = Object.values(wells);
      return isShowMissingData ? wellsList : wellsList.filter((item) => item?.status !== 'missing');
    }
    return [];
  }, [isShowMissingData, wells]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', marginTop: 20 }}>
      <GatheringReportTable rows={rows} columns={columns()} />
    </div>
  );
};

export default WellsTable;
