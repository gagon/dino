import React from 'react';
import { Divider } from '@mui/material';

import { StyledWrapper } from '../styles';

const Wrapper = ({ title, children }) => {
  return (
    <StyledWrapper>
      <div className="title">{title}</div>
      <Divider />
      <div className="children" style={{ backgroundColor: '#fff' }}>
        {children}
      </div>
    </StyledWrapper>
  );
};

export default Wrapper;
