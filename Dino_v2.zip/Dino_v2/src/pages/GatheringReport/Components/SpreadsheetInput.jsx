import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { Button, Select, MenuItem, Box, TextField } from '@mui/material';

import Wrapper from './Wrapper';
import { uploadReport } from '../GatheringReportDucks/GatheringReportDucks';

const SpreadsheetInput = () => {
  const [uploadParams, setUploadParams] = useState({ file: null, sheet: 'RUS' });
  const dispatch = useDispatch();

  const selectedFileNameLength = uploadParams.file?.name.length || 0;
  const selectedFileName = uploadParams.file?.name
    ? `${uploadParams.file?.name.substring(0, 11)}... ${uploadParams.file?.name.substring(
        selectedFileNameLength - 18,
        selectedFileNameLength
      )}`
    : 'No file chosen';

  const onSelectFile = (e) => {
    if (!e.target.files || e.target.files.length === 0) {
      setUploadParams((prev) => ({ ...prev, file: null }));
      return;
    }
    setUploadParams((prev) => ({ ...prev, file: e.target.files[0] }));
  };

  useEffect(() => {
    if (!uploadParams.file) return;

    const uploadData = new FormData();
    uploadData.append('file', uploadParams.file);
    uploadData.append('sheet', uploadParams.sheet);
    dispatch(uploadReport(uploadData));
  }, [uploadParams]);

  return (
    <Wrapper title="Load Gathering Report Spreadsheet">
      <Box
        sx={{
          display: 'flex',
          gap: 1,
          alignItems: 'center',
        }}
      >
        <TextField
          disabled
          value={selectedFileName}
          title={uploadParams.file?.name || ''}
          sx={{
            width: 314,
            margin: 0,
          }}
          InputProps={{
            startAdornment: (
              <Button
                variant="contained"
                component="label"
                color="primary"
                sx={{
                  width: 156,
                  fontSize: '12px',
                  padding: 0,
                  textTransform: 'none',
                  marginRight: '5px',
                  borderRadius: '6px',
                  mr: 1,
                }}
              >
                Choose File
                <input type="file" hidden onChange={onSelectFile} />
              </Button>
            ),
            sx: { padding: '4px' },
          }}
        />

        <Select
          id="upload-file-lang"
          sx={{ fontSize: '12px', padding: '0 8px', height: 31 }}
          value={uploadParams.sheet}
          onChange={(e) => setUploadParams((prev) => ({ ...prev, sheet: e.target.value }))}
        >
          <MenuItem value="RUS" sx={{ height: 20, px: 1, py: 1.5, fontSize: 12 }}>
            RUS
          </MenuItem>
          <MenuItem value="ENG" sx={{ height: 20, px: 1, py: 1.5, fontSize: 12 }}>
            ENG
          </MenuItem>
        </Select>
      </Box>
    </Wrapper>
  );
};

export default SpreadsheetInput;
