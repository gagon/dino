import React from 'react';

const Legend = () => {
  return (
    <div
      style={{
        minWidth: '380px',
        width: '100%',
        padding: '15px',
        fontSize: '14px',
        border: '1px solid transparent',
        borderColor: '#ddd',
        borderRadius: '8px',
        backgroundColor: '#fff',
      }}
    >
      <span style={{ color: 'orange', fontWeight: 'bold' }}>Orange</span> - Values have not been
      transferred into PI / DINO database.
      <br /> <br />
      <span style={{ color: 'red', fontWeight: 'bold' }}>Red</span> - Indication of closed wells and
      open wells that changed routing option compared to previous PI / DINO database data (if
      Compare to previous DB values or Compare to previous PI values was pressed).
      <br /> <br />
      <span style={{ color: '#1d9868', fontWeight: 'bold' }}>Green</span> - Open wells with found
      connections that are consistent with previous data from PI / DINO database (if Compare to
      previous DB values or Compare to previous PI values was pressed).
    </div>
  );
};

export default Legend;
