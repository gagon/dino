import { createReducer } from '@reduxjs/toolkit';
import moment from 'moment';
import lodash from 'lodash';

import { CaseApi, GatheringReportApi, WellsApi } from '../../../_helpers/service';
import { handleError } from '../../../common/utils/handleError';
import { handleCaseConfig } from './configSettings';
import { colNames, prepareData } from './utils';
import { loginModule } from '../../Login/LoginDucks';
import Notice from '../../../common/utils/Notice';
import { PIData } from '../../../_helpers/piData';
import { DATE_FORMAT } from '../../../common/_MuiHookForm/DesktopDatePicker';

export const gatheringReportModule = 'gatheringReport';
const SET_WELLS = `${gatheringReportModule}/SET_WELLS`;
const SET_GATHERING_REPORT_DATA = `${gatheringReportModule}/SET_GATHERING_REPORT_DATA`;
const SET_CASE_CONFIG = `${gatheringReportModule}/SET_CASE_CONFIG`;
const SET_GAP_CONFIG = `${gatheringReportModule}/SET_GAP_CONFIG`;
const LOAD_COLMAP_IDS = `${gatheringReportModule}/LOAD_COLMAP_IDS`;
const TOGGLE_MISSING_DATA = `${gatheringReportModule}/TOGGLE_MISSING_DATA`;
const TOGGLE_CHECK_FOUND = `${gatheringReportModule}/TOGGLE_CHECK_FOUND`;
const TOGGLE_SELECTED = `${gatheringReportModule}/TOGGLE_SELECTED`;
const UPDATE_WELL = `${gatheringReportModule}/UPDATE_WELL`;
const UPDATE_COLUMNS = `${gatheringReportModule}/UPDATE_COLUMNS`;
const UNSELECT_WELLS = `${gatheringReportModule}/UNSELECT_WELLS`;
const LOADING = `${gatheringReportModule}/LOADING`;
const LOADING_REPORT = `${gatheringReportModule}/LOADING_REPORT`;
const SET_DATABASE_DATES = `${gatheringReportModule}/SET_DATABASE_DATES`;

/**
 * Reducer
 */

const initialState = {
  caseConfig: null,
  gapConfig: null,
  colMap: {
    unit: { col: 'wlu_flow_to', save: true },
    rms: { col: 'wlu_routing', save: true },
    tl: { col: 'wlu_trunkline', save: true },
    mp_lp: { col: 'wlu_mp_lp', save: true },
    gath_status: { col: 'wlu_mp_lp', save: false },
  },
  wells: null,
  reportData: null,
  databaseDates: { day: [], night: [] },
  isShowMissingData: true,
  isCheckFound: true,
  loading: false,
  loadingReport: false,
};

export default createReducer(initialState, {
  [SET_WELLS]: (state, { payload }) => {
    state.wells = payload;
  },
  [SET_GATHERING_REPORT_DATA]: (state, { payload }) => {
    state.reportData = payload;
  },
  [SET_GAP_CONFIG]: (state, { payload }) => {
    state.gapConfig = payload;
  },
  [SET_CASE_CONFIG]: (state, { payload }) => {
    state.caseConfig = payload;
  },
  [LOAD_COLMAP_IDS]: (state, { payload }) => {
    state.colMap[colNames[payload.name]].id = payload.id;
  },
  [TOGGLE_MISSING_DATA]: (state) => {
    state.isShowMissingData = !state.isShowMissingData;
  },
  [TOGGLE_CHECK_FOUND]: (state) => {
    state.isCheckFound = !state.isCheckFound;
    const wellsToToggle = Object.values(state.wells).filter((w) => w.status === 'found');
    wellsToToggle.forEach((well) => (well.selected = state.isCheckFound));
  },
  [TOGGLE_SELECTED]: (state, { payload }) => {
    state.wells[payload.id].selected = !state.wells[payload.id].selected;
  },
  [UPDATE_WELL]: (state, { payload: { wellKey, well } }) => {
    state.wells[wellKey] = well;
  },
  [UPDATE_COLUMNS]: (state, { payload }) => {
    Object.entries(payload).forEach(([key, value]) => {
      const currentWell = state.wells[key];
      currentWell.columns = { ...currentWell.columns, ...value };
    });
  },
  [UNSELECT_WELLS]: (state, { payload }) => {
    payload.forEach((key) => {
      state.wells[key].selected = false;
    });
  },
  [SET_DATABASE_DATES]: (state, { payload }) => {
    state.databaseDates = payload;
  },
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [LOADING_REPORT]: (state, { payload }) => {
    state.loadingReport = payload;
  },
});

/**
 * Actions
 */

export const setLoading = (loading) => ({ type: LOADING, payload: loading });
export const setLoadingReport = (loading) => ({ type: LOADING_REPORT, payload: loading });
export const toggleMissingData = () => ({ type: TOGGLE_MISSING_DATA });
export const toggleCheckFound = () => ({ type: TOGGLE_CHECK_FOUND });
export const updateWell = (wellKey, well) => ({ type: UPDATE_WELL, payload: { wellKey, well } });
export const updateColumns = (data) => ({ type: UPDATE_COLUMNS, payload: data });
export const unselectWells = (data) => ({ type: UNSELECT_WELLS, payload: data });
export const setDatabaseDates = (data) => ({ type: SET_DATABASE_DATES, payload: data });

export const initConfigs = () => async (dispatch, getState) => {
  try {
    const userConfig = getState()[loginModule].userConfig;
    const { data } = await CaseApi.loadCaseConfigSetting();

    const caseConfig = handleCaseConfig(data, userConfig);
    Object.values(caseConfig.wellColumns).forEach((column) => {
      if (column.name in colNames) {
        dispatch({ type: LOAD_COLMAP_IDS, payload: column });
      }
    });
    dispatch({ type: SET_CASE_CONFIG, payload: caseConfig });

    dispatch(getGapConfig());
  } catch (e) {
    handleError(e, 'Failed to load configs');
  }
};

const getGapConfig = () => async (dispatch) => {
  try {
    const { data } = await WellsApi.getCurrentGapFileData();
    dispatch({ type: SET_GAP_CONFIG, payload: data });
  } catch (e) {
    handleError(e, 'Failed to load gap config');
  }
};

export const loadToPITags = (globalDate) => async (dispatch, getState) => {
  try {
    dispatch(setLoading(true));
    const state = getState();
    const wells = state[gatheringReportModule].wells;
    const colMap = state[gatheringReportModule].colMap;
    const afServer = state[loginModule].appConfig['AF:AFServer'];
    const piFetch = new PIData(afServer);
    const results = {};
    const keysToUnselect = [];
    const promises = [];

    Object.entries(wells).forEach(([key, well]) => {
      if (well.selected) {
        const newWellColumns = { unit: {}, rms: {}, tl: {}, mp_lp: {} };
        ['unit', 'rms', 'tl', 'mp_lp'].forEach((val) => {
          // only update if we have a value
          if (well[`tag_${val}`]) {
            const sTag = well.wcfg.configs[colMap[val].id].source_tag;
            const enumVal = { Name: well[`tag_${val}`], IsSystem: false };
            promises.push(
              piFetch
                .saveAFData(sTag, globalDate, enumVal, true)
                .then(() => {
                  newWellColumns[val].color = 'green';
                  newWellColumns[val].title = `${sTag}\nValue saved`;
                  keysToUnselect.push(key);
                })
                .catch((e) => {
                  newWellColumns[val].color = 'orange';
                  newWellColumns[val].title = `${sTag}\nError while saving: ${e}`;
                })
            );
          }
        });
        results[key] = newWellColumns;
      }
    });

    await Promise.allSettled(promises);
    const uniqueKeys = [...new Set(keysToUnselect)];
    dispatch(updateColumns(results));
    dispatch(unselectWells(uniqueKeys));

    Notice.success('Loaded to PI Tags');
  } catch (e) {
    handleError(e, 'Failed to load to PI Tags');
  } finally {
    dispatch(setLoading(false));
  }
};

export const compareToPIValues = (globalDate) => async (dispatch, getState) => {
  try {
    dispatch(setLoading(true));
    const state = getState();
    const wells = state[gatheringReportModule].wells;
    const colMap = state[gatheringReportModule].colMap;
    const afServer = state[loginModule].appConfig['AF:AFServer'];
    const piFetch = new PIData(afServer);
    const results = {};
    const promises = [];

    Object.entries(wells).forEach(([key, well]) => {
      if (well?.selected) {
        const newWellColumns = { unit: {}, rms: {}, tl: {}, mp_lp: {} };
        ['unit', 'rms', 'tl', 'mp_lp'].forEach((val) => {
          const sTag = well.wcfg.configs[colMap[val].id].source_tag;
          promises.push(
            piFetch.getAFData(sTag, globalDate).then((piVal) => {
              const txtVal = piVal.data.Value.Name ? piVal.data.Value.Name : piVal.data.Value;
              if (piVal.data.Good && txtVal.toUpperCase() !== well['tag_' + val]?.toUpperCase()) {
                newWellColumns[val].color = 'red';
              } else {
                newWellColumns[val].color = 'green';
              }
              const modTime = moment(piVal.data.Timestamp).format('YYYY/MM/DD HH:mm:ss');
              newWellColumns[val].title = `${sTag}\nCurrent\nVal:${txtVal}\nTS:${modTime}`;
            })
          );
        });
        results[key] = newWellColumns;
      }
    });

    await Promise.allSettled(promises);

    dispatch(updateColumns(results));
    Notice.success('Compared with PI values');
  } catch (e) {
    Notice.error('Failed to compare with PI values');
  } finally {
    dispatch(setLoading(false));
  }
};

export const uploadReport = (uploadData) => async (dispatch, getState) => {
  try {
    dispatch(setLoadingReport(true));
    dispatch({ type: SET_WELLS, payload: null });
    dispatch({ type: SET_GATHERING_REPORT_DATA, payload: null });
    const state = getState();
    const wellCfg = state[gatheringReportModule].caseConfig.wellCfg;
    const colMap = state[gatheringReportModule].colMap;
    const afServer = state[loginModule].appConfig['AF:AFServer'];

    const { data } = await GatheringReportApi.uploadReport(uploadData);

    const wells = {};
    Object.entries(data.wells).map(([key, value]) => {
      if (value.status !== 'no config') {
        wells[key] = value;
      }
    });
    const gapData = { ...data, wells };
    const preparedData = await prepareData(wellCfg, gapData, afServer, colMap);

    dispatch({ type: SET_WELLS, payload: preparedData.wells });
    dispatch({ type: SET_GATHERING_REPORT_DATA, payload: lodash.omit(preparedData, 'wells') });
  } catch (e) {
    Notice.error('Failed to upload the file');
  } finally {
    dispatch(setLoadingReport(false));
  }
};

export const saveToDatabase = (fileDate) => async (dispatch, getState) => {
  try {
    dispatch(setLoading(true));
    const gatheringReportState = getState()[gatheringReportModule];
    const colMap = gatheringReportState.colMap;
    const wells = gatheringReportState.wells;
    const fileName = gatheringReportState.reportData.fileName;

    const saveObj = {
      gathering_report: {
        file_date: fileDate,
        file_name: fileName,
      },
      gathering_report_wells: {},
    };
    Object.values(wells).forEach((well) => {
      if (well.selected) {
        saveObj.gathering_report_wells[well.wcfg.id] = {};
        Object.entries(colMap).forEach(([key, val]) => {
          if (val.save) {
            saveObj.gathering_report_wells[well.wcfg.id][val.col] = well[`tag_${key}`];
          }
        });
      }
    });

    const { data } = await GatheringReportApi.saveGatheringReportData(saveObj);

    if (data.error === undefined) {
      const results = {};
      Object.entries(wells).forEach(([key, well]) => {
        const newWellColumns = { unit: {}, rms: {}, tl: {}, mp_lp: {} };
        if (well.status === 'found' && well.selected) {
          let saveText = 'Error updating value';
          let saveColor = 'red';
          if (well.id in data.gathering_report_wells) {
            const saveVal = data.gathering_report_wells[well.id].saveVal;
            if (saveVal) {
              saveText = `${saveVal} in database`;
              saveColor = 'green';
            }
          }
          ['unit', 'rms', 'tl', 'mp_lp'].forEach((val) => {
            newWellColumns[val].color = saveColor;
            newWellColumns[val].title = saveText;
          });
          results[key] = newWellColumns;
        }
      });

      const today = new Date();

      dispatch(getGatheringReportDates(today));
      dispatch(updateColumns(results));
      Notice.success('Saved to database');
    }
  } catch (e) {
    Notice.error('Failed to save gathering report');
  } finally {
    dispatch(setLoading(false));
  }
};

export const compareToDBValues = (fileDate) => async (dispatch, getState) => {
  try {
    dispatch(setLoading(true));

    const compareObj = {
      before: fileDate,
      include: true,
      compareOnly: true,
    };
    const { data } = await GatheringReportApi.getGatheringReportData(compareObj);

    const wells = getState()[gatheringReportModule].wells;
    const results = {};

    Object.entries(wells).forEach(([key, well]) => {
      if (well?.status === 'found' && well?.selected) {
        const newWellColumns = { unit: {}, rms: {}, tl: {}, mp_lp: {} };
        ['unit', 'rms', 'tl', 'mp_lp'].forEach((colKey) => {
          let txtVal = '';
          if (key in data.wells && 'tag_' + colKey in data.wells[key]) {
            newWellColumns[colKey].color = 'green';
            txtVal = data.wells[key]['tag_' + colKey];
          } else {
            newWellColumns[colKey].color = 'red';
            txtVal = 'Missing';
          }
          const modTime = moment(data.file_date).format('YYYY/MM/DD HH:mm:ss');
          newWellColumns[colKey].title = `Database\nCurrent\nVal:${txtVal}\nTS:${modTime}`;
        });
        results[key] = newWellColumns;
      }
    });

    dispatch(updateColumns(results));
    Notice.success('Compared with database values');
  } catch (e) {
    Notice.error('Failed to compare with database values');
  } finally {
    dispatch(setLoading(false));
  }
};

export const getGatheringReportDates = (date) => async (dispatch) => {
  try {
    const dd = String(moment(date, DATE_FORMAT).date()).padStart(2, '0');
    const mm = String(moment(date, DATE_FORMAT).month() + 1).padStart(2, '0');
    const yyyy = moment(date, DATE_FORMAT).year();
    const dateObj = { startDate: yyyy + '-' + mm + '-' + dd + 'T23:59:59', range: 42 };

    const { data } = await GatheringReportApi.getGatheringReportDates(dateObj);
    const dates = data;
    const reports = { day: [], night: [] };
    const two_weeks_before = moment(date, DATE_FORMAT).subtract(14, 'days');
    if (dates.length > 0) {
      let d_found = false;
      let n_found = false;
      for (let i = 0; i < 14; i++) {
        two_weeks_before.add(1, 'days');

        d_found = false;
        n_found = false;

        const title = two_weeks_before.format('YYYY-MM-DD');
        const dd = two_weeks_before.format('DD');
        const ddBefore = moment(two_weeks_before).subtract(1, 'days').format('DD');

        const d_cell = {
          title,
          value: dd,
          selected: false,
          isDayCell: true,
          time: '12:00:00',
        };
        const n_cell = {
          title,
          value: `${ddBefore}-${dd}`,
          selected: false,
          isDayCell: false,
          time: '00:00:00',
        };

        dates.forEach((date) => {
          const compDay = moment(date);

          if (compDay.isSame(two_weeks_before, 'day')) {
            if (compDay.hours() >= 7 && compDay.hours() < 19) {
              d_cell.selected = true;
              d_found = true;
            } else {
              n_cell.selected = true;
              n_found = true;
            }
            if (d_found && n_found) {
              return;
            }
          }
        });
        reports.day.push(d_cell);
        reports.night.push(n_cell);
      }
      dispatch(setDatabaseDates(reports));
    }
  } catch (e) {
    Notice.error('Failed to get gathering report dates');
  }
};

export const getGatheringReportData = (selectedItem) => async (dispatch, getState) => {
  try {
    dispatch(setLoadingReport(true));
    dispatch({ type: SET_WELLS, payload: null });
    dispatch({ type: SET_GATHERING_REPORT_DATA, payload: null });

    const gathRepDataObj = {
      before: selectedItem.title + 'T' + selectedItem.time,
      include: true,
      compareOnly: false,
    };
    const { data } = await GatheringReportApi.getGatheringReportData(gathRepDataObj);

    const state = getState();
    const wellCfg = state[gatheringReportModule].caseConfig.wellCfg;
    const colMap = state[gatheringReportModule].colMap;
    const afServer = state[loginModule].appConfig['AF:AFServer'];
    const preparedData = await prepareData(wellCfg, data, afServer, colMap);

    dispatch({ type: SET_WELLS, payload: preparedData.wells });
    dispatch({ type: SET_GATHERING_REPORT_DATA, payload: lodash.omit(preparedData, 'wells') });
  } catch (e) {
    Notice.error('Failed to get gathering report data');
  } finally {
    dispatch(setLoadingReport(false));
  }
};
