import { createConnectionMappings, updateSeperatorGrouping } from './utils';

export const handleCaseConfig = (configData, userCfg) => {
  const caseConfig = { userCfg: { ...userCfg }, units: {} };
  if (caseConfig.userCfg) {
    if (!caseConfig?.userCfg['ALT_UNIT_FIELD']) {
      caseConfig.userCfg['ALT_UNIT_FIELD'] = {};
    }
    if (!caseConfig?.userCfg['ALT_UNIT_WELL']) {
      caseConfig.userCfg['ALT_UNIT_WELL'] = {};
    }
    if (!caseConfig?.userCfg['OPTION_LIMIT_SETTINGS']) {
      caseConfig.userCfg['OPTION_LIMIT_SETTINGS'] = {};
    }

    caseConfig.unitCfg = {};
    for (let unit of JSON.parse(configData.units)) {
      caseConfig.unitCfg[unit.unit] = unit;
    }

    updateSeperatorGrouping(
      'MP_LP_TABLE_SPLIT',
      caseConfig.units,
      caseConfig.unitCfg,
      caseConfig.userCfg
    );
    updateSeperatorGrouping(
      'MP_LP_CHART_SPLIT',
      caseConfig.units,
      caseConfig.unitCfg,
      caseConfig.userCfg
    );

    caseConfig.wellColumns = {};
    for (let wellConf of configData.wellConf) {
      caseConfig.wellColumns[wellConf.id] = wellConf;
      caseConfig.wellColumns[wellConf.id].displayUom =
        caseConfig.userCfg['ALT_UNIT_WELL'][wellConf.id];
    }
  }

  caseConfig.wellCfg = {};
  for (let wellItem of configData.wells) {
    caseConfig.wellCfg[wellItem.id] = wellItem;
  }

  caseConfig.fieldCfg = {};
  for (let fieldItem of configData.field) {
    caseConfig.fieldCfg[fieldItem.id] = fieldItem;
  }
  caseConfig.fieldShape = configData.fieldShape;
  caseConfig.fieldConnection = configData.fieldConnection;

  caseConfig.connection = { mapping: {} };
  for (let conn of configData.connectionMappings) {
    caseConfig.connection.mapping[conn.id] = conn;
  }
  createConnectionMappings(caseConfig);

  return { ...configData, ...caseConfig };
};
