import moment from 'moment';
import { PIData } from '../../../_helpers/piData';

export const colNames = {
  'WLU Trunkline': 'tl',
  'WLU MP_LP': 'mp_lp',
  'WLU Routing': 'rms',
  'WLU Flow to': 'unit',
  'Gathering Status': 'gath_status',
};

export const getWellConn = (well, config) => {
  if (well.tag_unit && well.tag_rms && well.tag_tl && well.tag_mp_lp) {
    var tagKey = well.tag_unit + well.tag_rms + well.tag_tl + well.tag_mp_lp;
    tagKey = tagKey.toUpperCase();
    return config.connection.tagMap[tagKey];
  }
  return null;
};

export const buildConnStr = (well, config) => {
  let connStr = '';

  let connKey = getWellConn(well, config);
  if (connKey) {
    connStr = connKey.unit ? connKey.unit : '';
    connStr += connKey.rms ? '--' + connKey.rms : '';
    connStr += connKey.tl ? '--' + connKey.tl : '';
    connStr += connKey.mp_lp ? '--' + connKey.mp_lp : '';
  } else {
    connStr = 'No matching Dino connection';
  }
  return connStr;
};

export const updateSeperatorGrouping = function (variable, units, unitCfg, userCfg) {
  let refName = null;
  if (variable == 'MP_LP_TABLE_SPLIT') {
    refName = 'table';
  } else {
    refName = 'chart';
  }
  const bSplit = userCfg[variable] && userCfg[variable] == '1';
  units[refName] = {};

  for (let unit of Object.values(unitCfg)) {
    if (bSplit) {
      for (let sep of unit.separators) {
        let tblLabel = unit.unit;
        tblLabel += sep.mp_lp ? ' - ' + sep.mp_lp : '';
        let tblKey = tblLabel.replace(/\s/g, '');
        units[refName][tblKey] = { lbl: tblLabel, sep: sep };
      }
    } else {
      units[refName][unit.unit] = { lbl: unit.unit, sep: unit.separators[0] };
    }
  }
};

export const createConnectionMappings = function (caseConfig) {
  caseConfig.connection.tagMap = {};
  for (let conn_map of Object.values(caseConfig.connection.mapping)) {
    if (conn_map.tag_unit && conn_map.tag_rms && conn_map.tag_mp_lp && conn_map.tag_tl) {
      const rmsKeys = conn_map.tag_rms.split(',');
      const mplpKeys = conn_map.tag_mp_lp.split(',');
      const tlKeys = conn_map.tag_tl.split(',');
      for (let rmsKey of rmsKeys) {
        for (let mplpKey of mplpKeys) {
          for (let tlKey of tlKeys) {
            let tagKey = conn_map.tag_unit + rmsKey + tlKey + mplpKey;
            tagKey = tagKey.toUpperCase();
            caseConfig.connection.tagMap[tagKey] = conn_map;
          }
        }
      }
    }
  }
};

const updateWithPreviousPiValues = (well, globalDate, piFetch, colMap, hierarchy) => {
  const defArray = [];
  ['unit', 'rms', 'tl', 'mp_lp'].forEach(async (val) => {
    const sTag = well.wcfg?.configs[colMap[val]?.id]?.source_tag;
    defArray.push(
      piFetch.getAFData(sTag, globalDate).then((piVal) => {
        const txtVal = piVal.data.Value.Name ? piVal.data.Value.Name : piVal.data.Value;
        if (piVal.data.Good) {
          well[`tag_${val}`] = txtVal;
          well.selected = true;
          well.backgroundColor = 'lightblue';
          const modTime = moment(piVal.data.Timestamp).format('YYYY/MM/DD HH:mm:ss');
          well.columns[val].title = `${sTag}\nTS:${modTime}`;
        }
      })
    );
  });
  return defArray;
};

const getPIStatusValue = (well, globalDate, piFetch, colMap, hierarchy) => {
  const val = 'gath_status';
  const sTag = well.wcfg?.configs[colMap[val].id]?.source_tag;
  return piFetch.getAFData(sTag, globalDate).then(async (piVal) => {
    const txtVal = piVal.data.Value?.Name ? piVal.data.Value?.Name : piVal.data?.Value;
    if (piVal.data.Good) {
      well.gathering_status = txtVal;
      // if the well is missing get the previous value from PI and use that
      if (well.status.toUpperCase() === 'MISSING' && txtVal.toUpperCase() === 'CLOSED') {
        const defArray = updateWithPreviousPiValues(well, globalDate, piFetch, colMap, hierarchy);
        await Promise.any(defArray);
      }
    }
    const modTime = moment(piVal.data.Timestamp).format('YYYY/MM/DD HH:mm:ss');
    well.columns[val].title = `${sTag}\nTS:${modTime}`;

    return well;
  });
};

export const prepareData = async (wellCfg, gapData, afServer, colMap) => {
  const preparedData = { ...gapData };
  const piFetch = new PIData(afServer);
  const globalDate = gapData?.dt;
  const hierarchy = gapData?.hierarchy;
  const wellNameDict = {};

  for (const [wId, wcfg] of Object.entries(wellCfg)) {
    const paName = wcfg.pa_name;

    if (paName in wellNameDict) {
      continue;
    }
    wellNameDict[paName] = wId;

    if (!(paName in preparedData.wells)) {
      preparedData.wells[paName] = { status: 'missing', excel: paName, id: paName };
    }

    const well = {
      ...gapData?.wells[paName],
      excel: gapData?.wells[paName]?.excel || paName,
      wcfg,
      columns: {
        unit: {},
        rms: {},
        tl: {},
        mp_lp: {},
        gath_status: {},
        status: {},
      },
      selected: false,
    };

    let excelDetail = '';

    if (well.status === 'found') {
      well.selected = true;
      well.backgroundColor = 'lightblue';
      excelDetail = `Row(${well.excelRow + 1}) - ${well.excelRms} : ${well.excelTxt}`;
    }

    well.columns.status.title = excelDetail;

    if (wcfg.disabled) {
      well.backgroundColor = 'lightgray';
    }

    ['unit', 'rms', 'tl', 'mp_lp'].forEach((val) => {
      well.columns[val].title = well.wcfg.configs[colMap[val].id].source_tag;
      if (!hierarchy[val].includes(well[`tag_${val}`])) {
        well.columns[val].color = 'red';
      }
    });

    preparedData.wells[paName] = well;

    try {
      const result = await getPIStatusValue(well, globalDate, piFetch, colMap, hierarchy);
      if (result.status === 'fulfilled' && result.value) {
        const { excel, id } = result.value;
        preparedData.wells[excel] = result.value;
        wellNameDict[excel] = id;
      }
    } catch (error) {
      console.error(error);
    }
  }

  return preparedData;
};
