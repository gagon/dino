export default function (param, decimals) {
  const num = parseFloat(param);
  if (param == null || isNaN(num)) {
    return '';
  }
  return num
    .toFixed(decimals)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
    .replace(',', '');
}
