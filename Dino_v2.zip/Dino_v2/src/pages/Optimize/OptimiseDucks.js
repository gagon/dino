import { createReducer } from '@reduxjs/toolkit';
import moment from 'moment';
import lodash from 'lodash';

import { handleError } from '../../common/utils/handleError';
import Notice from '../../common/utils/Notice';
import { CaseApi, OptimiseApi, ScheduledApi } from '../../_helpers/service';
import { loginModule } from '../Login/LoginDucks';
import {
  loadScheduled,
  openScheduledModal,
  setSelectedCase,
} from '../../common/ScheduledCases/ScheduledCasesDucks';
import { changeActiveMenu } from './SideBar/OptimseMenuDucks';
import {
  buildCalcDict,
  evaluateCalcDict,
  getTotalFromOption,
} from '../../common/calculationUtils/calculation';
import { handleCaseConfig } from '../../common/calculationUtils/caseConfigSettings';
import { unitConversionObj } from '../../common/calculationUtils/units';
import { buildRuleList, getCaseWells, getHandledFields, getRuleChanges } from './OptimiseUtils';
import { GAS_OPTIMIZATION_FIELDS_COPY } from '../../_helpers/constants';

/**
 * Constants
 */

export const optimiseModule = 'optimise';
const SET_CASE_DATA = `${optimiseModule}/SET_CASE_DATA`;
const SET_CASE_CONFIG = `${optimiseModule}/SET_CASE_CONFIG`;
const LOAD_UNITS = `${optimiseModule}/LOAD_UNITS`;
const SET_UNITS = `${optimiseModule}/SET_UNITS`;
const HOVER_UNIT = `${optimiseModule}/HOVER_UNIT`;
const SET_CALCULATIONS = `${optimiseModule}/SET_CALCULATIONS`;
const SET_CASE_OPTIONS = `${optimiseModule}/SET_CASE_OPTIONS`;
const FIELDS = `${optimiseModule}/FIELDS`;
const FIELD_BALANCE = `${optimiseModule}/FIELD_BALANCE`;
const CLEAR = `${optimiseModule}/CLEAR`;
const LOADING_CASE_OPTIONS = `${optimiseModule}/LOADING_CASE_OPTIONS`;
const LOADING = `${optimiseModule}/LOADING`;
const SET_RULE_OPTIONS = `${optimiseModule}/SET_RULE_OPTIONS`;
const ADD_RULE = `${optimiseModule}/ADD_RULE`;
const REMOVE_RULE = `${optimiseModule}/REMOVE_RULE`;
const CHANGE_RULE_CELL_VALUE = `${optimiseModule}/CHANGE_RULE_CELL_VALUE`;
const LOADING_SAVE_CASE = `${optimiseModule}/LOADING_SAVE_CASE`;
const CHANGE_FIELD_FOR_SAVE = `${optimiseModule}/CHANGE_FIELD_FOR_SAVE`;
const CHANGE_WELL_CELL_VALUE = `${optimiseModule}/CHANGE_WELL_CELL_VALUE`;
const LOADING_SAVE = `${optimiseModule}/LOADING_SAVE`;
const UPDATE_CASE_OPTIONS = `${optimiseModule}/UPDATE_CASE_OPTIONS`;
const UPDATE_CALC_DICT = `${optimiseModule}/UPDATE_CALC_DICT`;

/**
 * Reducer
 */

const initialState = {
  caseForm: {
    name: '',
    timestamp: null,
    description: '',
  },
  changesData: { CaseWell: {}, CaseWellConfigItem: {}, CaseFieldConfigItem: {} },
  caseData: {},
  caseConfig: {},
  unitClasses: {},
  units: [],
  classByUnits: {},
  unitsByClass: {},
  calculation: {},
  fields: {},
  fieldBalance: {},
  options: { caseOpts: [], caseOptsTotal: 0, connRules: [], optRules: [] },
  loading: false,
  loadingOptions: false,
  loadingSaveCase: false,
  loadingSave: false,
  ruleOptions: [],
  rulesTableData: {},
  ruleList: {},
  wellChanges: {},
  optsTotal: {},
};

export default createReducer(initialState, {
  [FIELDS]: (state, { payload }) => {
    state.fields = payload;
  },
  [FIELD_BALANCE]: (state, { payload }) => {
    state.fieldBalance = payload;
  },
  [SET_CASE_DATA]: (state, { payload }) => {
    state.caseData = payload;
    state.caseForm.name = payload.name;
    state.caseForm.timestamp = payload.timestamp
      ? moment.utc(payload.timestamp).local().format('DD-MM-YYYY HH:mm:ss')
      : payload.timestamp;
    state.caseForm.description = payload.description;
  },
  [SET_CASE_CONFIG]: (state, { payload }) => {
    state.caseConfig = payload;
  },
  [LOAD_UNITS]: (state, { payload }) => {
    state.unitClasses = payload?.unitClasses;
    state.units = payload?.units;
  },
  [SET_UNITS]: (state, { payload }) => {
    state.unitsByClass = payload?.unitsByClass;
    state.classByUnits = payload?.classByUnits;
  },
  [HOVER_UNIT]: (state, { payload }) => {
    state.hoveredUnit = payload;
  },
  [SET_CALCULATIONS]: (state, { payload }) => {
    state.calculation = payload;
  },
  [SET_CASE_OPTIONS]: (state, { payload, rulesTableData, optsTotal }) => {
    state.options = payload;
    state.rulesTableData = rulesTableData;
    state.optsTotal = optsTotal;
  },
  [UPDATE_CASE_OPTIONS]: (state, { payload, optsTotal }) => {
    state.options = payload;
    state.optsTotal = optsTotal;
  },
  [UPDATE_CALC_DICT]: (state, { payload }) => {
    state.options.caseOpts = state.options.caseOpts.map((opt) =>
      opt.id === payload.id ? payload : opt
    );

    evaluateCalcDict(
      payload.id,
      state.calculation.calcDict,
      state.optsTotal,
      state.fields,
      state.caseConfig?.units
    );
  },
  [LOADING_CASE_OPTIONS]: (state, { payload }) => {
    state.loadingOptions = payload;
  },
  [LOADING_SAVE_CASE]: (state, { payload }) => {
    state.loadingSaveCase = payload;
  },
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [LOADING_SAVE]: (state, { payload }) => {
    state.loadingSave = payload;
  },
  [SET_RULE_OPTIONS]: (state, { payload, ruleList }) => {
    state.ruleOptions = payload;
    state.ruleList = ruleList;
    state.wellChanges = {};
  },
  [ADD_RULE]: (state) => {
    let id =
      (Object.keys(state.rulesTableData).length
        ? Math.max(...Object.keys(state.rulesTableData))
        : 0) + 1;
    for (const row of state.options.optRules) {
      if (id <= row.id) id = row.id + 1;
    }
    const rmsList = Object.keys(state.ruleList).filter(
      (key) => !Object.values(state.rulesTableData).some((i) => key === i.rmsKey)
    );
    if (rmsList.length > 0) {
      state.rulesTableData[id] = {
        id,
        case_id: state.caseData.id,
        gap_id: state.caseData.gap_file.id,
        rms: state.ruleList[rmsList[0]].rms,
        tl: state.ruleList[rmsList[0]].tl,
        rmsKey: rmsList[0],
        max_wells: 5,
      };
    }
  },
  [REMOVE_RULE]: (state, { id }) => {
    delete state.rulesTableData[id];
  },
  [CHANGE_RULE_CELL_VALUE]: (state, { id, fieldName, value }) => {
    if (fieldName === 'rmsKey') {
      const rule = state.ruleList[value];
      state.rulesTableData[id][fieldName] = value;
      state.rulesTableData[id].rms = rule.rms;
      state.rulesTableData[id].tl = rule.tl;
    } else {
      state.rulesTableData[id][fieldName] = value;
    }
  },
  [CHANGE_FIELD_FOR_SAVE]: (state, { payload }) => {
    if (lodash.isEmpty(payload)) {
      state.changesData = {};
    } else if (!lodash.isEmpty(payload?.CaseWellConfigItem)) {
      state.changesData.CaseWellConfigItem = {
        ...state.changesData.CaseWellConfigItem,
        ...payload.CaseWellConfigItem,
      };
    } else if (!lodash.isEmpty(payload?.CaseWell)) {
      for (const key of Object.keys(payload.CaseWell)) {
        if (state.changesData.CaseWell.hasOwnProperty(key)) {
          state.changesData.CaseWell[key] = {
            ...state.changesData.CaseWell[key],
            ...payload.CaseWell[key],
          };
        } else {
          state.changesData.CaseWell[key] = payload.CaseWell[key];
        }
      }
    } else if (!lodash.isEmpty(payload?.CaseFieldConfigItem)) {
      state.changesData.CaseFieldConfigItem = {
        ...state.changesData.CaseFieldConfigItem,
        ...payload.CaseFieldConfigItem,
      };
    }
    if (payload?.CaseId) {
      state.changesData.CaseId = payload.CaseId;
    }
  },
  [CHANGE_WELL_CELL_VALUE]: (state, { key, data, mode }) => {
    if (mode === 'add') {
      state.wellChanges[key] = data;
    } else if (mode === 'remove') {
      delete state.wellChanges[key];
    }
  },
  [CLEAR]: () => initialState,
});

/**
 * Actions
 */

export const clear = () => ({ type: CLEAR });

export const loadCase = (caseId) => async (dispatch, getState) => {
  try {
    const state = getState();
    const stateCaseConfig = state[optimiseModule].caseConfig;
    if (Object.keys(stateCaseConfig).length === 0) {
      const userConfig = state[loginModule].userConfig;
      const { data } = await CaseApi.loadCaseConfigSetting();
      const caseConfig = handleCaseConfig(data, userConfig, true);
      dispatch({ type: SET_CASE_CONFIG, payload: { ...data, ...caseConfig } });
      dispatch(loadCaseData(caseId, caseConfig));
    } else {
      dispatch(loadCaseData(caseId, stateCaseConfig));
    }
  } catch (e) {
    handleError(e, 'Failed to load case config data');
  }
};

export const loadCaseData = (caseId, caseConfig) => async (dispatch) => {
  try {
    if (caseConfig && parseInt(caseId)) {
      dispatch({ type: LOADING, payload: true });
      let { data: caseData } = await CaseApi.loadCase(caseId);
      let fields = getHandledFields(caseConfig, caseData);
      dispatch({ type: FIELDS, payload: fields });
      dispatch(loadUnits(caseId, caseData));
      dispatch(loadOptions(caseId, caseConfig?.connectionMappings));
      dispatch(updateOptions(caseId));
    }
  } catch (e) {
    handleError(e, 'Failed to load case data');
  }
};

export const loadUnits = (caseId, caseData) => async (dispatch, getState) => {
  dispatch({ type: LOADING, payload: true });
  try {
    const { userConfig, appConfig } = getState()[loginModule];
    const { caseConfig, fields, unitClasses, units } = getState()[optimiseModule];
    const loadedUnits = { unitClasses: {}, units: [] };
    const response = await CaseApi.getUnitClasses(appConfig['AF:AFServer']);
    loadedUnits.unitClasses = response?.data;

    const getUnits = async () => {
      let requests = response?.data?.Items.map((unit) => {
        return Promise.resolve(CaseApi.getUnits(unit?.Links?.Units));
      });
      return Promise.all(requests).then((responses) => {
        responses.map((res) => {
          loadedUnits.units.push(res.data);
        });
      });
    };

    if (response?.data?.Items.length > 0) {
      await getUnits();
    }
    dispatch({ type: LOAD_UNITS, payload: loadedUnits });

    const convertedUnits = unitConversionObj(unitClasses, units);
    let fieldTotal = getTotalFromOption(undefined, {});
    dispatch({ type: SET_UNITS, payload: convertedUnits });
    const calculation = buildCalcDict(
      convertedUnits?.classByUnits,
      convertedUnits?.unitsByClass,
      caseConfig,
      userConfig
    );

    if (caseData.run_date) {
      let { data } = await CaseApi.loadFieldBalance(caseId);
      fieldTotal = getTotalFromOption(undefined, data);
      dispatch({ type: FIELD_BALANCE, payload: data });
    }

    evaluateCalcDict(undefined, calculation?.calcDict, fieldTotal, fields, caseConfig?.units);
    dispatch({ type: SET_CALCULATIONS, payload: calculation });
    const case_wells = getCaseWells(userConfig, caseConfig, caseData, fields, units);
    dispatch({ type: SET_CASE_DATA, payload: { ...caseData, case_wells } });
  } catch (e) {
    console.error(e);
    handleError(e, 'Failed to load case unit data');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const loadOptions = (caseId, connectionMappings) => async (dispatch) => {
  try {
    dispatch({ type: LOADING_CASE_OPTIONS, payload: true });
    const { ruleOptions, ruleList } = buildRuleList(connectionMappings);
    const { data } = await OptimiseApi.getCaseOptions(caseId);
    const rulesTableData = {};
    for (const row of Object.values(data.optRules)) {
      rulesTableData[row.id] = {
        ...row,
        rmsKey: row.rms.toUpperCase() + ' ' + row.tl.toUpperCase(),
      };
    }
    let optsTotal = {};
    data.caseOpts.forEach((option) => {
      optsTotal[option.id] = {};
      Object.entries(option.results).forEach(([key, obj]) => {
        if (typeof obj === 'object') {
          optsTotal[option.id][key] = {
            oil: obj?.oil_tot,
            oil_mass: obj?.oil_mas_tot,
            gas: obj?.gas_tot,
            water: obj?.water_tot,
          };
        }
      });
    });
    dispatch({ type: SET_RULE_OPTIONS, payload: ruleOptions, ruleList });
    dispatch({ type: SET_CASE_OPTIONS, payload: data, rulesTableData, optsTotal });
  } catch (error) {
    console.error(error);
    Notice.error('Failed to load case options');
    handleError(error);
  } finally {
    dispatch({ type: LOADING_CASE_OPTIONS, payload: false });
  }
};

export const updateOptions = (caseId) => async (dispatch) => {
  try {
    dispatch({ type: LOADING_CASE_OPTIONS, payload: true });

    const { data } = await OptimiseApi.getCaseOptions(caseId);

    let optsTotal = {};
    data.caseOpts.forEach((option) => {
      optsTotal[option.id] = {};
      Object.entries(option.results).forEach(([key, obj]) => {
        if (typeof obj === 'object') {
          optsTotal[option.id][key] = {
            oil: obj?.oil_tot,
            oil_mass: obj?.oil_mas_tot,
            gas: obj?.gas_tot,
            water: obj?.water_tot,
          };
        }
      });
    });
    dispatch({ type: UPDATE_CASE_OPTIONS, payload: data, optsTotal });
    dispatch(updateCalcDict(data.caseOpts));
  } catch (error) {
    console.error(error);
    Notice.error('Failed to load case options');
    handleError(error);
  } finally {
    dispatch({ type: LOADING_CASE_OPTIONS, payload: false });
  }
};

export const updateCalcDict = (caseOptions) => (dispatch) => {
  try {
    caseOptions.forEach((item) => {
      dispatch({ type: UPDATE_CALC_DICT, payload: item });
    });
  } catch (error) {
    handleError(error);
  }
};

export const addRule = () => ({ type: ADD_RULE });

export const removeRule = (id) => ({ type: REMOVE_RULE, id });

export const changeRuleCellValue = (id, fieldName, value) => ({
  type: CHANGE_RULE_CELL_VALUE,
  id,
  fieldName,
  value,
});

export const runOptimization = (params, user_id) => (dispatch) => {
  dispatch(
    saveChangesCase(null, () => {
      ScheduledApi.runOptimization(params)
        .then(() => {
          Notice.success('Data sent to run optimizations');
          dispatch(openScheduledModal(true));
          dispatch(changeActiveMenu(null));
          dispatch(setSelectedCase(params.caseId));
          setTimeout(Notice.clearAll, 5000);
        })
        .catch((e) => handleError(e, 'Failed to run optimizations'));
    })
  );
};

export const saveChangesCase = (closeModal, runOptimization) => async (dispatch, getState) => {
  dispatch({ type: LOADING_SAVE_CASE, payload: true });
  try {
    const { changesData, fields, caseForm, caseData } = getState()[optimiseModule];
    const dataToSave = {};
    if (changesData.CaseWell && Object.keys(changesData.CaseWell).length > 0) {
      dataToSave.CaseWell = changesData.CaseWell;
    }
    if (changesData.CaseWellConfigItem && Object.keys(changesData.CaseWellConfigItem).length > 0) {
      dataToSave.CaseWellConfigItem = changesData.CaseWellConfigItem;
    }
    if (
      changesData.CaseFieldConfigItem &&
      Object.keys(changesData.CaseFieldConfigItem).length > 0
    ) {
      dataToSave.CaseFieldConfigItem = changesData.CaseFieldConfigItem;
    }
    const timestamp = moment(caseForm.timestamp, 'DD-MM-YYYY HH:mm:ss')
      .utc()
      .format()
      .replace('Z', '');
    if (
      caseForm.name !== caseData.name ||
      caseForm.description !== caseData.description ||
      timestamp !== caseData.timestamp
    ) {
      dataToSave.Case = {
        [caseData.id]: { ...caseForm, timestamp },
      };
    }
    if (Object.keys(dataToSave).length > 0) {
      const { data } = await CaseApi.updateCase({ ...dataToSave, CaseId: caseData.id });

      if (data.CaseFieldConfigItem) {
        const newFields = JSON.parse(JSON.stringify(fields));
        for (let [group, groupValues] of Object.entries(fields)) {
          for (let [itemKey, item] of Object.entries(groupValues)) {
            if (data?.CaseFieldConfigItem && item.id in data?.CaseFieldConfigItem) {
              const savedValues = data?.CaseFieldConfigItem[item.id];
              newFields[group][itemKey] = {
                ...item,
                ...savedValues,
                savedValue: savedValues.value,
              };
            }
          }
        }
        dispatch({ type: FIELDS, payload: newFields });
      }
      if (data.Case && data.Case[caseData.id]) {
        dispatch({ type: SET_CASE_DATA, payload: { ...caseData, ...data.Case[caseData.id] } });
      }
      dispatch({ type: CHANGE_FIELD_FOR_SAVE, payload: {} });

      Notice.success('Save case data success');
      closeModal && closeModal();
    }
    runOptimization && runOptimization();
  } catch (error) {
    handleError(error, 'Failed to save case data');
  } finally {
    dispatch({ type: LOADING_SAVE_CASE, payload: false });
  }
};

export const updateResults = (colUpdate) => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_SAVE_CASE, payload: true });
    const caseOpts = getState()[optimiseModule].options.caseOpts;
    const isOpts = caseOpts.find((opt) => opt.id === colUpdate.id) !== -1;

    if (isOpts) {
      dispatch({
        type: UPDATE_CALC_DICT,
        payload: colUpdate,
      });
    }
  } catch (error) {
    console.error(error);
  } finally {
    dispatch({ type: LOADING_SAVE_CASE, payload: false });
  }
};

export const changeWellCellValue = (key, mode, data) => ({
  type: CHANGE_WELL_CELL_VALUE,
  key,
  data,
  mode,
});

export const saveAndRegenerate = () => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_SAVE, payload: true });
    const optimise = getState()[optimiseModule];
    const rulesTableData = optimise.rulesTableData;
    const optRules = optimise.options.optRules;
    const CaseWellConnRule = optimise.wellChanges;
    const CaseOptRule = getRuleChanges(optRules, rulesTableData);
    await OptimiseApi.saveDinoData({ CaseOptRule, CaseWellConnRule });
    dispatch(loadOptions(optimise.caseData.id, optimise.caseConfig?.connectionMappings));
  } catch (error) {
    handleError(error, 'Failed to save and regenerate routes');
  } finally {
    dispatch({ type: LOADING_SAVE, payload: false });
  }
};
