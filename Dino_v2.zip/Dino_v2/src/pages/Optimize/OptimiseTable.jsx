import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import React, { useMemo, useState } from 'react';
import ColumnsFilter from '../../common/Table/ColumnsFilter';
import { useTheme } from '@mui/styles';
import { useSelector } from 'react-redux';
import useColumnsFilter from '../../common/Table/useColumnsFilter';
import { optimiseModule } from './OptimiseDucks';
import { wellColumns } from './WellColums';
import Table from '../../common/Table/Table';
import Select from '../../common/Select/Select';
import useStep from './useStep';

export default function OptimiseTable() {
  const { palette } = useTheme();
  const { disabled } = useStep();
  const [selectedRms, setSelectedRms] = useState('RMSM');
  const loading = useSelector((state) => state[optimiseModule].loading);
  const loadingOptions = useSelector((state) => state[optimiseModule].loadingOptions);
  const caseConfig = useSelector((state) => state[optimiseModule].caseConfig);
  const caseWells = useSelector((state) => state[optimiseModule].caseData.case_wells);
  const ruleOptions = useSelector((state) => state[optimiseModule].ruleOptions);
  const { columnFilter, changeFilter } = useColumnsFilter();
  const columns = wellColumns(caseConfig, selectedRms).filter(
    ({ field }) => !columnFilter.includes(field)
  );
  const tableData = useMemo(() => {
    if (caseWells) {
      return caseWells.filter((item) => {
        const connMap = Object.values(item.gap_well.connectionMap);
        return connMap.some(({ rms }) => rms === selectedRms);
      });
    }
    return [];
  }, [selectedRms, caseWells]);

  return (
    <div>
      <div className="flex items-center mb2 mt1">
        <Typography
          variant={'h5'}
          children={'Optimise Wells'}
          style={{ color: palette.action.active }}
        />
        <ColumnsFilter
          columns={wellColumns(caseConfig, selectedRms)}
          changeFilter={changeFilter}
          columnFilter={columnFilter}
        />
      </div>
      <Select
        withoutForm
        disabled={disabled}
        value={selectedRms}
        options={ruleOptions}
        onChange={(e) => setSelectedRms(e.target.value)}
        style={{ width: 250, marginBottom: 8 }}
      />
      <Box>
        <Table
          rows={tableData}
          columns={columns}
          loading={loading || loadingOptions}
          pageSize={tableData.length < 100 ? tableData.length : 100}
          getRowHeight={({ model }) =>
            model?.connections ? Object.values(model?.connections).length * 21 : 44
          }
          autoHeight
          hideFooterPagination
          hideFooter
          disableColumnMenu
          disableSelectionOnClick
          disableMultipleColumnsSorting
          disableExtendRowFullWidth={false}
        />
      </Box>
    </div>
  );
}
