import { setMapConnections } from '../../common/calculationUtils/utils';
import {
  CHOKE_POSITION_CONFIG_ID,
  FL_PRESSURE_CONFIG_ID,
  GATHERING_STATUS_CONFIG_ID,
  ONLINE_STATUS_CONFIG_ID,
  SLOT_PRESSURE_CONFIG_ID,
  SLOT_TEMPERATURE_CONFIG_ID,
  WH_PRESSURE_CONFIG_ID,
} from '../../_helpers/constants';
import { checkError } from '../../common/calculationUtils/checkError';

export function getHandledFields(caseConfig, caseData) {
  const fieldValues = caseData?.field_config_values;

  //Групируем поля согласно параметру config_group
  const fields = Object.values(caseConfig?.fieldCfg).reduce((group, field) => {
    const dependants = [];
    if (!group[field?.config_group]) {
      group[field?.config_group] = {};
    }
    let values = fieldValues[field.id];
    let value = '';
    if (values?.value) {
      value = parseFloat(values?.value).toFixed(2);
    }

    group[field?.config_group][field.name] = {
      ...field,
      ...values,
      value,
      dependants,
      savedValue: value,
    };
    return group;
  }, {});

  //записываем зависимых полей которые меняются по формуле при изменений данного поля
  const setDependants = () => {
    Object.values(caseConfig?.fieldCfg).map((field) => {
      const fieldValue = function (group, item) {
        fields[group][item].dependants.push({
          group: field.config_group,
          name: field.name,
          source_tag: field?.source_tag,
        });
      };
      if (!field?.is_constraint && field?.source_type === 'calc') {
        try {
          eval(field?.source_tag);
        } catch (err) {
          console.error(err);
        }
      }
    });
  };

  setDependants();

  return fields;
}

export function getCaseWells(userConfig, caseConfig, caseData, fields, units) {
  return Object.values(caseData.case_wells).map((well) => {
    const gap_well = setMapConnections(well?.gap_well, userConfig, caseConfig?.wellCfg);

    const gapName = caseConfig?.wellCfg[well.well_id].gap_name;
    const whPressur = well?.well_config_values[WH_PRESSURE_CONFIG_ID];
    const flPressur = well?.well_config_values[FL_PRESSURE_CONFIG_ID];
    const slotPressur = well?.well_config_values[SLOT_PRESSURE_CONFIG_ID];
    const slotTemperature = well?.well_config_values[SLOT_TEMPERATURE_CONFIG_ID];
    const chokePosition = well?.well_config_values[CHOKE_POSITION_CONFIG_ID];
    const onlineStatus = well?.well_config_values[ONLINE_STATUS_CONFIG_ID];
    const gatheringStatus = well?.well_config_values[GATHERING_STATUS_CONFIG_ID];

    const values = {
      ...well,
      gap_well,
      id: well?.well_id,
      gapName,
      whPressur,
      flPressur,
      slotPressur,
      slotTemperature,
      chokePosition,
      onlineStatus,
      gatheringStatus,
    };

    const validate = checkError(
      values,
      caseConfig?.unitCfg,
      fields['Process'],
      units.classByUnits,
      units.unitsByClass
    );
    return { ...values, initValues: values, validate };
  });
}

export const buildRuleList = (connectionMappings) => {
  if (connectionMappings) {
    const ruleList = {};
    for (const conn_map of Object.values(connectionMappings)) {
      const ruleKey = conn_map?.rms?.toUpperCase() + ' ' + conn_map?.tl?.toUpperCase();
      if (!(ruleKey in ruleList)) {
        ruleList[ruleKey] = { rms: conn_map.rms, tl: conn_map.tl, used: false };
      }
    }

    const ruleOptions = Object.values(ruleList).reduce((group, conn) => {
      const { rms } = conn;
      group[rms] = group[rms] ?? [];
      group[rms].push(conn);
      return group;
    }, {});

    return { ruleOptions: Object.keys(ruleOptions).map((i) => ({ name: i, value: i })), ruleList };
  }
};

export function getRuleChanges(optRules, rulesTableData) {
  const changes = {};
  for (const savedRule of optRules) {
    if (savedRule.id in rulesTableData) {
      const max_wells = rulesTableData[savedRule.id].max_wells;
      const rms = rulesTableData[savedRule.id].rms;
      const tl = rulesTableData[savedRule.id].tl;
      if (savedRule.max_wells !== max_wells || savedRule.rms !== rms || savedRule.tl !== tl) {
        changes[savedRule.id] = {
          ds: 'update',
          keys: { id: savedRule.id, case_id: savedRule.case_id, gap_id: savedRule.gap_id },
          values: { rms, tl, max_wells },
        };
      }
    } else {
      changes[savedRule.id] = {
        ds: 'delete',
        keys: { id: savedRule.id, case_id: savedRule.case_id, gap_id: savedRule.gap_id },
        values: { rms: savedRule.rms, tl: savedRule.tl, max_wells: savedRule.max_wells },
      };
    }
  }
  for (const rule of Object.values(rulesTableData)) {
    if (!optRules.some((i) => i.id === rule.id)) {
      changes[rule.id] = {
        ds: 'new',
        keys: { id: rule.id, case_id: rule.case_id, gap_id: rule.gap_id },
        values: { rms: rule.rms, tl: rule.tl, max_wells: rule.max_wells },
      };
    }
  }
  return changes;
}
