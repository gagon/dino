import React from 'react';
import { menuItems } from './OptimiseMenuItems';
import { StyledSideBar } from './OptimiseSideBarStyle';

export default function OptimiseSideBar({ children }) {
  return (
    <div className="flex">
      <StyledSideBar>
        <div className="sidebar">
          {menuItems.map((item, index) => (
            <div key={index} className="mb2">
              {item.component()}
            </div>
          ))}
        </div>
      </StyledSideBar>
      {children}
    </div>
  );
}
