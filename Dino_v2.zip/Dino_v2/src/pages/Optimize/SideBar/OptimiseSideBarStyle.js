import styled from 'styled-components';

export const StyledSideBar = styled.div`
  background: #fbfaff;
  padding-top: 20px;
  width: 94px;
  text-align: center;
  border: none;
  z-index: 2;
  padding-left: 6px;
  min-height: calc(100vh - 114px);

  p {
    margin: 0;
  }

  .sidebar {
    .sticky {
      position: sticky;
      top: 0;
    }

    .active {
      background-color: ${(props) => props.theme.palette.action.selected};
      div {
        color: ${(props) => props.theme.palette.primary.main};
      }
    }
  }
`;
