import { LoadingButton } from '@mui/lab';
import { Checkbox, Typography } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import { useTheme } from '@mui/styles';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import SideMenuItemModal from '../../../../common/SideMenuItemModal/SideMenuItemModal';
import { RUN_OPT_DEFAULT_TIME, CONTINUE_UNFINISHED_ROUTES } from '../../../../_helpers/constants';
import FieldDataIcon from '../../../../_media/sideBar/FieldDataIcon';
import { loginModule, setParamToUserConfig } from '../../../Login/LoginDucks';
import { optimiseModule, saveAndRegenerate } from '../../OptimiseDucks';
import { optimizeMenuModule, changeActiveMenu } from '../OptimseMenuDucks';
import { REGENERATE_ROUTES } from '../OptimiseMenuItems';
import SideButton from '../SideButton';
import useStep from '../../useStep';
import DesktopTimePicker from '../../../../common/_MuiHookForm/DesktopTimePicker';

export default function RegenerateRoutes() {
  const { palette } = useTheme();
  const { disabled } = useStep();
  const dispatch = useDispatch();
  const activeMenu = useSelector((state) => state[optimizeMenuModule].activeMenu);
  const isActive = activeMenu === REGENERATE_ROUTES;
  const loading = useSelector((state) => state[optimiseModule].loadingSave);
  const caseOptsTotal = useSelector((state) => state[optimiseModule].options.caseOptsTotal);
  const runTime = useSelector((state) => state[loginModule].userConfig[RUN_OPT_DEFAULT_TIME]);
  const fill = isActive ? palette.common.white : palette.action.active;
  const style = { fill: disabled ? palette.action.disabled : fill };
  const unFinished = useSelector(
    (state) => state[loginModule].userConfig[CONTINUE_UNFINISHED_ROUTES]
  );

  const onChange = (value, paramName) => {
    dispatch(setParamToUserConfig(paramName, value));
  };
  const onOpen = () => {
    dispatch(changeActiveMenu(REGENERATE_ROUTES));
  };

  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton disabled={disabled} onClick={onOpen}>
            <FieldDataIcon style={style} />
          </IconButton>
        }
      />

      <p
        className="fs-10"
        style={{ marginTop: 0, color: disabled ? palette.action.disabled : 'inherit' }}
        children={'Regenerate Routes'}
      />
      {isActive && (
        <SideMenuItemModal isOpen={isActive} close={() => dispatch(changeActiveMenu(null))}>
          <div style={{ width: 250 }}>
            <Typography style={{ marginBottom: 20 }}>Regenerate Routes</Typography>
            <div className="flex items-center justify-between" style={{ marginTop: 12 }}>
              <Typography color="textSecondary" children="Continue unfinished routes" />
              <Checkbox
                sx={{ padding: 0 }}
                checked={!!unFinished}
                onChange={({ target: { checked } }) =>
                  onChange(checked, CONTINUE_UNFINISHED_ROUTES)
                }
              />
            </div>
            <div className="flex items-center justify-between" style={{ marginTop: 12 }}>
              <Typography color="textSecondary" children="Schedule Optimise Offset" />
              <Checkbox
                sx={{ padding: 0 }}
                checked={runTime === null}
                onChange={({ target: { checked } }) =>
                  onChange(checked ? null : '23:55', RUN_OPT_DEFAULT_TIME)
                }
              />
            </div>
            <DesktopTimePicker
              disabled={runTime === null}
              value={runTime === null ? '23:55' : runTime}
              onChange={(value) => onChange(value, RUN_OPT_DEFAULT_TIME)}
            />
            <div className="flex items-center justify-between" style={{ marginTop: 12 }}>
              <Typography color="textSecondary" children="Total combinations" />
              <Typography
                color="textSecondary"
                fontWeight="bold"
                style={{ marginRight: 6 }}
                children={caseOptsTotal}
              />
            </div>
            <div className="flex justify-center" style={{ marginTop: 15 }}>
              <LoadingButton
                loading={loading}
                children={'Save / Regenerate routes'}
                onClick={() => dispatch(saveAndRegenerate())}
                variant={'contained'}
                color={'primary'}
                sx={{ borderRadius: 23, marginRight: 2 }}
              />
            </div>
          </div>
        </SideMenuItemModal>
      )}
    </>
  );
}
