import IconButton from '@mui/material/IconButton';
import { useTheme } from '@mui/styles';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import ViewResultsIcon from '../../../../_media/ViewResultsIcon';
import { optimizeMenuModule, setViewRoutes } from '../OptimseMenuDucks';
import SideButton from '../SideButton';
import useStep from '../../useStep';

export default function ViewResults() {
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const viewRoutes = useSelector((state) => state[optimizeMenuModule].viewRoutes);
  const { noResult } = useStep();
  const stroke = viewRoutes ? palette.common.white : '#5F6388';

  return (
    <>
      <SideButton
        isOpen={viewRoutes}
        icon={
          <IconButton disabled={noResult} onClick={() => dispatch(setViewRoutes(!viewRoutes))}>
            <ViewResultsIcon
              style={{
                fill: viewRoutes ? palette.common.white : '#5F6388',
                stroke: noResult ? palette.action.disabled : stroke,
              }}
            />
          </IconButton>
        }
      />
      <p
        className="fs-10"
        style={{ marginTop: 0, color: noResult ? palette.action.disabled : 'inherit' }}
        children={'View Routes'}
      />
    </>
  );
}
