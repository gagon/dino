import { LoadingButton } from '@mui/lab';
import IconButton from '@mui/material/IconButton';
import { useTheme } from '@mui/styles';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import SideMenuItemModal from '../../../../common/SideMenuItemModal/SideMenuItemModal';
import OptimizationIcon from '../../../../_media/OptimizationIcon';
import { optimiseModule } from '../../OptimiseDucks';
import useStep from '../../useStep';
import { ROUTE_OPTIMIZATION } from '../OptimiseMenuItems';
import { changeActiveMenu, optimizeMenuModule } from '../OptimseMenuDucks';
import SideButton from '../SideButton';
import useRun from './useRun';

export default function Optimization() {
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const { activeMenu } = useSelector((state) => state[optimizeMenuModule]);
  const isActive = activeMenu === ROUTE_OPTIMIZATION;
  const { running: disabled } = useStep();
  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton
            disabled={disabled}
            onClick={() => {
              dispatch(changeActiveMenu(ROUTE_OPTIMIZATION));
            }}
          >
            <OptimizationIcon
              style={{
                fill: isActive ? palette.common.white : '#5F6388',
                stroke: isActive
                  ? palette.common.white
                  : disabled
                  ? palette.action.disabled
                  : '#5F6388',
              }}
            />
          </IconButton>
        }
      />
      <p
        className="fs-10"
        style={{ marginTop: 0, color: disabled ? palette.action.disabled : 'inherit' }}
        children={'Route Optimisation'}
      />

      {isActive && <OptimisationRunModal onClose={() => dispatch(changeActiveMenu(null))} />}
    </>
  );
}

function OptimisationRunModal({ onClose }) {
  const runCase = useRun();
  const { running } = useStep();
  const loading = useSelector((state) => state[optimiseModule].loading);
  const loadingSave = useSelector((state) => state[optimiseModule].loadingSave);

  return (
    <SideMenuItemModal isOpen boxStyle={{ width: 310 }} close={onClose}>
      <span className="fs-12 bold" children={'Route optimisation'} />
      <div className="mt2">You want to run route optimisation ?</div>
      <div className="flex justify-center mt2">
        <LoadingButton
          loading={loading || loadingSave}
          children={running ? 'this case is runned' : 'RUN OPTIMISATION'}
          disabled={running || loading || loadingSave}
          variant={'contained'}
          color={'primary'}
          sx={{ borderRadius: 23 }}
          onClick={runCase}
        />
      </div>
    </SideMenuItemModal>
  );
}
