import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import moment from 'moment';
import React from 'react';

const DATE_FORMAT = 'DD/MM/yyyy HH:mm:ss';

export const caseColumns = (palette, onSelectCase) => {
  return [
    {
      field: 'id',
      headerName: 'Case id',
      width: 100,
    },
    {
      field: 'timestamp',
      headerName: 'Date',
      width: 160,
      renderCell: ({ row }) => {
        return moment(row.timestamp).format(DATE_FORMAT);
      },
    },
    { field: 'name', headerName: 'Name', flex: 0.5, minWidth: 160 },
    { field: 'description', headerName: 'Description', flex: 0.3, minWidth: 100 },
    { field: 'user', headerName: 'Creator', width: 160 },
    { field: 'gap_file', headerName: 'Gap File', flex: 0.3, minWidth: 100 },
    {
      field: 'gas_opt',
      headerName: 'Gas Opt',
      minWidth: 50,
      flex: 0.3,
      renderCell: ({ row }) => {
        return <Checkbox checked={row.gas_opt} disabled />;
      },
    },
    {
      field: 'edit_date',
      headerName: 'Last Edit',
      width: 180,
      renderCell: ({ row }) => {
        return row.edit_date ? moment.utc(row.edit_date).format(DATE_FORMAT) : '';
      },
    },
    {
      field: 'run_date',
      headerName: 'Last Run',
      width: 180,
      renderCell: ({ row }) => {
        return row.run_date ? moment.utc(row.run_date).format(DATE_FORMAT) : '';
      },
    },
    {
      field: 'action',
      headerName: 'action',
      width: 100,
      renderCell: ({ row }) => {
        return (
          <Button
            size={'small'}
            style={{ background: palette.action.selected, color: palette.text.primary }}
            children={'open'}
            onClick={() => onSelectCase(row.id)}
          />
        );
      },
    },
  ];
};
