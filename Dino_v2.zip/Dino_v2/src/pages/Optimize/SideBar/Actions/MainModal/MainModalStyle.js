import MuiToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import { styled } from '@mui/material/styles';
import { makeStyles } from '@mui/styles';

export const useStyles = makeStyles((theme) => ({
  btn: {
    height: 34,
    borderRadius: 8,
    background: theme.palette.action.selected,
    color: theme.palette.text.primary,
    fontSize: 12,
    textTransform: 'none',
    whiteSpace: 'nowrap',
  },
}));

export const buttonStyle = (palette) => ({
  width: 100,
  textTransform: 'none',
  border: 'none',
  whiteSpace: 'nowrap',
  height: 32,
  margin: '0 -16px 0 0',
  background: palette.action.selected,
  display: 'flex',
  justifyContent: 'center',
});

export const ToggleButtonGroup = styled(MuiToggleButtonGroup)(({ theme }) => ({
  textTransform: 'none !important',
  marginBottom: 14,
  '& .MuiToggleButtonGroup-grouped': {
    margin: theme.spacing(0.5),
    border: 0,
    '&.Mui-disabled': {
      border: 0,
    },
    '&:not(:first-of-type)': {
      // borderRadius: theme.shape.borderRadius,
      textTransform: 'none',
      whiteSpace: 'nowrap',
      height: 34,
      background: theme.palette.action.focus,
      margin: 0,
    },
    '&:first-of-type': {
      textTransform: 'none',
      // borderRadius: theme.shape.borderRadius,
      whiteSpace: 'nowrap',
      height: 34,
      margin: 0,
      // width: 87,
      background: theme.palette.action.selected,
    },
  },
}));

export const dialogPaperSx = {
  borderTopRightRadius: 20,
  borderTopLeftRadius: 20,
  borderBottomLeftRadius: 20,
  borderBottomRightRadius: 20,
  padding: '30px 30px 20px 30px',
};