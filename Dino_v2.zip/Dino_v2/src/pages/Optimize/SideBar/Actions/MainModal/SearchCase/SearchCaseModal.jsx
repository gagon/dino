import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Pagination,
  PaginationItem,
  useTheme,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import Input from '../../../../../../common/Input/Input';
import Table from '../../../../../../common/Table/Table';
import paths from '../../../../../../_helpers/paths';
import { CaseApi } from '../../../../../../_helpers/service';
import { caseColumns } from './columns';

const defaultSortRule = { param: 'edit_date', asc: false };
const rowsPerPage = 25;

export default function SearchCaseModal({ close, onSelect }) {
  const { palette } = useTheme();
  const [caseListData, setCaseListData] = useState({ count: 0, data: [] });
  const [page, setPage] = useState(1);
  const [searchStr, setSearchStr] = useState('');
  const [filter, setFilter] = useState({
    searchStr: '',
    limit: 25,
    offset: 0,
    sort: defaultSortRule,
  });

  const loadData = () => {
    CaseApi.loadAllCase(filter)
      .then(({ data }) => {
        setCaseListData(data);
      })
      .catch((e) => console.error(e));
  };

  const handleChangePage = (event, value) => {
    setPage(value);
    setFilter((prev) => ({ ...prev, offset: (value - 1) * rowsPerPage }));
  };

  const onSearch = () => {
    setFilter((prev) => ({ ...prev, searchStr }));
  };

  const onSelectCase = (id) => {
    window.open(paths.optimize.replaceAll(':caseId', id), '_self');
  };

  const onSortHandler = (params) => {
    if (params.length < 1) {
      setFilter((prev) => ({ ...prev, sort: defaultSortRule }));
      return;
    }
    setFilter((prev) => ({
      ...prev,
      sort: { param: params[0]?.field, asc: params[0]?.sort === 'asc' ? true : false },
    }));
  };

  useEffect(() => {
    loadData();
  }, [filter]);

  return (
    <>
      <Dialog
        fullWidth
        maxWidth={'xl'}
        sx={{ background: '#5051F935', zIndex: 2 }}
        PaperProps={{
          sx: {
            borderTopRightRadius: 20,
            borderTopLeftRadius: 20,
            borderBottomLeftRadius: 20,
            borderBottomRightRadius: 20,
            padding: '0px 20px 20px 20px',
          },
        }}
        onClose={close}
        open
      >
        <DialogTitle>
          <h5>Search Cases</h5>
          <div className="flex justify-between items-center">
            <Input
              value={searchStr}
              onChange={(value) => setSearchStr(value)}
              withoutForm
              placeholder={'Search for ...'}
            />
            <Button
              variant="contained"
              children={'Search'}
              onClick={onSearch}
              style={{ marginLeft: 10 }}
            />
          </div>
        </DialogTitle>
        <DialogContent>
          <Table
            headerHeight={46}
            rows={caseListData?.data}
            columns={caseColumns(palette, onSelect ? onSelect : onSelectCase)}
            rowsPerPage={rowsPerPage}
            hideFooter
            autoHeight
            disableColumnMenu
            disableSelectionOnClick
            disableMultipleColumnsSorting
            disableExtendRowFullWidth={false}
            sortingMode="server"
            onSortModelChange={onSortHandler}
          />
        </DialogContent>
        <DialogActions>
          <Pagination
            sx={{ margin: '0px 40px' }}
            color="primary"
            shape="rounded"
            count={Math.ceil(caseListData?.count / rowsPerPage)}
            page={page}
            onChange={handleChangePage}
            renderItem={(item) => (
              <PaginationItem
                color="primary"
                components={{ previous: ArrowBackIcon, next: ArrowForwardIcon }}
                {...item}
              />
            )}
          />
          <Button
            children={'close'}
            style={{ background: palette.action.selected, marginRight: 24 }}
            onClick={close}
          />
        </DialogActions>
      </Dialog>
    </>
  );
}
