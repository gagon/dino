import { Button, Dialog, useTheme } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import moment from 'moment';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import useSimpleModal from '../../../../../common/_hooks/useSimpleModal';
import MenuInfoIcon from '../../../../../_media/sideBar/MenuInfoIcon';
import { optimiseModule } from '../../../OptimiseDucks';
import { optimizeMenuModule, changeActiveMenu } from '../../OptimseMenuDucks';
import { MAIN_MODAL } from '../../OptimiseMenuItems';
import SideButton from '../../SideButton';
import SearchCaseModal from './SearchCase/SearchCaseModal';
import Checkbox from '@mui/material/Checkbox';
import { useParams } from 'react-router';

export default function CaseActionModal() {
  const searchModal = useSimpleModal();
  const dispatch = useDispatch();
  const { caseId } = useParams();
  const { palette } = useTheme();
  const [closed, setClosed] = useState(false);
  const activeMenu = useSelector((state) => state[optimizeMenuModule].activeMenu);
  const selected = useSelector((state) => state[optimiseModule].caseData?.selected);
  const description = useSelector((state) => state[optimiseModule].caseData?.description);
  const timestamp = useSelector((state) => state[optimiseModule].caseData?.timestamp);
  const caseName = useSelector((state) => state[optimiseModule].caseData?.name);
  const creator = useSelector((state) => state[optimiseModule].caseData?.creator?.name);
  const gapFileName = useSelector((state) => state[optimiseModule].caseData?.gap_file?.name);
  const isActive = activeMenu === MAIN_MODAL || (!parseInt(caseId) && !closed);

  return (
    <>
      <SideButton
        isOpen={isActive}
        icon={
          <IconButton onClick={() => dispatch(changeActiveMenu(MAIN_MODAL))}>
            <MenuInfoIcon
              style={{ fill: 'none', stroke: isActive ? palette.common.white : '#059DB5' }}
            />
          </IconButton>
        }
      />
      {isActive && (
        <Dialog
          sx={{ background: '#5051F935', zIndex: 2 }}
          PaperProps={{
            sx: {
              borderTopRightRadius: 20,
              borderTopLeftRadius: 20,
              borderBottomLeftRadius: 20,
              borderBottomRightRadius: 20,
            },
          }}
          onClose={() => {
            dispatch(changeActiveMenu(null));
            setClosed(true);
          }}
          open={true}
        >
          <div style={{ padding: '33px 28px 25px 28px' }}>
            <div className="flex ">
              <div style={{ width: 500 }}>
                <div className="fullWidth" style={{ marginBottom: 20 }}>
                  <div className="mb1 flex">
                    <div style={{ marginRight: 15, width: 125 }}></div>
                    <Button
                      variant="outlined"
                      children={'select case'}
                      onClick={() => searchModal.open({})}
                    />
                  </div>
                  <div className="mb1 flex">
                    <Typography
                      color={'textSecondary'}
                      children={'Gap file'}
                      style={{ marginRight: 15, width: 125 }}
                    />
                    <Typography
                      color={'textSecondary'}
                      children={gapFileName}
                      style={{ fontWeight: 'bold' }}
                    />
                  </div>
                  <div className="mb1 flex">
                    <Typography
                      color={'textSecondary'}
                      children={'Created by'}
                      style={{ marginRight: 15, width: 125 }}
                    />
                    <Typography
                      color={'textSecondary'}
                      children={creator}
                      style={{ fontWeight: 'bold' }}
                    />
                  </div>
                  <div className="mb1 flex">
                    <Typography
                      color={'textSecondary'}
                      children={'Case name'}
                      style={{ marginRight: 15, width: 125 }}
                    />
                    <Typography
                      color={'textSecondary'}
                      children={caseName}
                      style={{ fontWeight: 'bold' }}
                    />
                  </div>
                  <div className="mb1 flex">
                    <Typography
                      color={'textSecondary'}
                      children={'Date'}
                      style={{ marginRight: 15, width: 125 }}
                    />
                    <Typography
                      color={'textSecondary'}
                      children={
                        timestamp ? moment.utc(timestamp).local().format('DD-MM-YYYY HH:mm:ss') : ''
                      }
                      style={{ fontWeight: 'bold' }}
                    />
                  </div>
                  <div className="mb1 flex">
                    <Typography
                      color={'textSecondary'}
                      children={'Case description'}
                      style={{ marginRight: 15, width: 125 }}
                    />
                    <Typography
                      color={'textSecondary'}
                      children={description}
                      style={{ fontWeight: 'bold' }}
                    />
                  </div>
                  <div className="mb1 flex">
                    <Typography
                      color={'textSecondary'}
                      children={'Implemented Case'}
                      style={{ marginRight: 12, width: 125 }}
                    />
                    <Checkbox checked={!!selected} size="small" disabled style={{ padding: 0 }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
          {searchModal.isOpen && <SearchCaseModal {...searchModal} />}
        </Dialog>
      )}
    </>
  );
}
