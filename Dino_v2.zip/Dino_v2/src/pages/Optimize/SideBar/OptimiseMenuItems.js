import React from 'react';
import MainModal from './Actions/MainModal/MainModal';
import RegenerateRoutes from './Actions/RegenerateRoutes';
import RouteOptimization from './Actions/RouteOptimisation';
import ViewRoutes from './Actions/ViewRoutes';

export const MAIN_MODAL = 'mainModal';
export const REGENERATE_ROUTES = 'regenerateRoutes';
export const ROUTE_OPTIMIZATION = 'routeOptimization';
export const VIEW_ROUTES = 'viewRoutes';

export const menuItems = [
  {
    key: MAIN_MODAL,
    onClick: (modal) => modal.open(),
    component: (props) => <MainModal {...props} />,
  },
  {
    key: REGENERATE_ROUTES,
    component: (props) => <RegenerateRoutes {...props} />,
  },
  {
    key: ROUTE_OPTIMIZATION,
    component: (props) => <RouteOptimization {...props} />,
  },
  {
    key: VIEW_ROUTES,
    component: (props) => <ViewRoutes {...props} />,
  }
];
