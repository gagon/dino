import { createReducer } from '@reduxjs/toolkit';
import { REGENERATE_ROUTES } from './OptimiseMenuItems';

/**
 * Constants
 */

export const optimizeMenuModule = 'optimizeMenu';
export const activeMenu = `${optimizeMenuModule}/activeMenu`;
const CHANGE_ACTIVE_MENU = `${optimizeMenuModule}/CHANGE_ACTIVE_MENU`;
const SET_VIEW_ROUTES = `${optimizeMenuModule}/SET_VIEW_ROUTES`;
const CLEAR = `${optimizeMenuModule}/CLEAR`;

/**
 * Reducer
 */

const initialState = {
  activeMenu: null,
  viewRoutes: false,
  loading: false,
};

export default createReducer(initialState, {
  [CHANGE_ACTIVE_MENU]: (state, { payload }) => {
    if (state.activeMenu === payload) {
      state.activeMenu = null;
    } else {
      state.activeMenu = payload;
      if (payload === REGENERATE_ROUTES) {
        state.viewRoutes = false;
      }
    }
  },
  [SET_VIEW_ROUTES]: (state, { payload }) => {
    state.viewRoutes = payload;
  },
  [CLEAR]: () => initialState,
});

/**
 * Actions
 */

export const clear = () => ({ type: CLEAR });

export const setViewRoutes = (isView) => ({ type: SET_VIEW_ROUTES, payload: isView });

export const changeActiveMenu = (menuItem) => ({ type: CHANGE_ACTIVE_MENU, payload: menuItem });
