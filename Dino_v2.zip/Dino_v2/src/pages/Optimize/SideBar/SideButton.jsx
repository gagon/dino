import { useTheme } from '@mui/styles';
import React from 'react';

export default function SideButton({ isOpen, icon }) {
  const { palette } = useTheme();
  return (
    <>
      <div className="flex justify-center">
        <div
          style={{
            width: 36,
            height: 36,
            borderRadius: 14,
            background: isOpen ? palette.primary.main : 'transparent',
          }}
        >
          {icon}
        </div>
      </div>
    </>
  );
}
