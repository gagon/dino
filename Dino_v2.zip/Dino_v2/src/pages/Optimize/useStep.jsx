import { useSelector } from 'react-redux';

import { scheduledModule } from '../../common/ScheduledCases/ScheduledCasesDucks';
import { optimiseModule } from './OptimiseDucks';

export default function useStep() {
  const currentCaseId = useSelector((state) => state[optimiseModule].caseData?.id);
  const caseOptsTotal = useSelector((state) => state[optimiseModule].options.caseOptsTotal);
  const scheduledData = useSelector((state) => state[scheduledModule].scheduledData);
  const caseId = isNaN(parseInt(currentCaseId)) ? false : parseInt(currentCaseId);
  const running = scheduledData.some(
    (item) => !['completed', 'error'].includes(item.status) && item.case_id === caseId
  );

  return {
    disabled: !caseId,
    noResult: parseInt(caseOptsTotal) < 1 || !caseId,
    running: running || !caseId,
  };
}
