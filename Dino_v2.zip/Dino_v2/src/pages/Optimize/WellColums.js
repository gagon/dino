import React from 'react';
import { Checkbox, TextField } from '@mui/material';
import Button from '@mui/material/Button';
import Select from '../../common/Select/Select';
import { useDispatch, useSelector } from 'react-redux';
import { changeWellCellValue, optimiseModule } from './OptimiseDucks';

export const wellColumns = (caseConfig, rmsm) => {
  const columns = [
    {
      field: 'unit',
      headerName: 'Unit',
      minWidth: 90,
      valueGetter: ({ row }) => row.gap_well.connectionMap[row.gap_conn_id]?.unit,
    },
    {
      field: 'id',
      headerName: 'Well Name',
      minWidth: 90,
      flex: 1,
      valueGetter: ({ row }) => caseConfig.wellCfg[row.well_id].gap_name,
    },
  ];

  const connOptions = caseConfig?.connectionMappings
    ? Object.values(caseConfig.connectionMappings).reduce((group, conn) => {
        const { rms } = conn;
        group[rms] = group[rms] ?? [];
        group[rms].push(conn);
        return group;
      }, {})
    : {};

  const options = connOptions[rmsm || 'RMSM'];
  if (options) {
    options.map((opt) => {
      const key = `${opt?.tag_tl}_${opt?.tag_mp_lp}`;
      if (!columns.some((i) => i.field === key)) {
        columns.push({
          field: key,
          headerName: key.replaceAll('-', '').replace(',', '').replace('_', '') || '__',
          sortable: false,
          renderCell: function ({ row }) {
            return <ColumnCheckBox opt={opt} row={row} />;
          },
        });
      }
    });
  }

  const lasColumns = [
    {
      field: 'gor',
      headerName: 'GOR',
      minWidth: 90,
      valueGetter: ({ row }) => row.gap_well.gor.toFixed(0),
    },
    {
      field: 'watercut',
      headerName: 'Watercut',
      minWidth: 90,
      valueGetter: ({ row }) => (row.gap_well.wct * 100).toFixed(0),
    },
    {
      field: 'maskWell',
      headerName: 'Mask Well',
      minWidth: 90,
      valueGetter: ({ row }) => (row.mask_well === true ? 'Masked' : 'Unmasked'),
    },
    {
      field: 'belowMap',
      headerName: 'Let below MAP',
      title:
        'In certain cases FWHP is allowed to be below MAP.&#013;' +
        'For instance, wells under test/monitoring',
      minWidth: 110,
      valueGetter: ({ row }) => (row.below_map === true ? 'True' : 'False'),
    },
    {
      field: 'fixFWHPTarget',
      headerName: 'Fix well Target FWHP?',
      minWidth: 150,
      title:
        'If this box is checked then well target FWHP will &#013;' +
        'be fixed and excluded from optimization algorithm.',
      valueGetter: ({ row }) => (row.fixed === true ? 'True' : 'False'),
    },
    {
      field: 'connection',
      headerName: 'Case Connection',
      minWidth: 250,
      flex: 1,
      valueGetter: ({ row }) => row.gap_well.connectionMap[row.gap_conn_id]?.name,
    },
  ];

  return [...columns, ...lasColumns];
};

export const ruleColumns = (tableData, ruleList, onChange, removeRule) => {
  const rmsOptions = [];
  const rmsList = tableData.map((i) => i.rmsKey);
  for (const rule of Object.keys(ruleList)) {
    if (!rmsList.includes(rule)) {
      rmsOptions.push({ name: rule, value: rule });
    }
  }

  return [
    {
      field: 'rms',
      headerName: 'Rule Connection',
      flex: 1,
      renderCell: ({ row }) => {
        return (
          <Select
            withoutForm
            placeholder="Select rms"
            value={row.rmsKey}
            options={[...rmsOptions, { name: row.rmsKey, value: row.rmsKey }]}
            onChange={(e) => onChange(row.id, 'rmsKey', e.target.value)}
          />
        );
      },
    },
    {
      field: 'max_wells',
      headerName: 'Max Wells',
      flex: 1,
      renderCell: ({ row }) => {
        return (
          <TextField
            type="number"
            value={row.max_wells}
            style={{ maxHeight: 34, marginTop: 4 }}
            InputProps={{ style: { padding: '8px 12px' } }}
            size="small"
            onChange={(e) => onChange(row.id, 'max_wells', e.target.value)}
          />
        );
      },
    },
    {
      field: 'remove',
      headerName: 'Remove',
      flex: 1,
      renderCell: ({ row }) => {
        return (
          <Button variant="outlined" onClick={() => removeRule(row.id)} children="Remove Rule" />
        );
      },
    },
  ];
};

function ColumnCheckBox({ row, opt }) {
  const dispatch = useDispatch();
  const well_id = row?.well_id;
  const caseOptions = useSelector((state) => state[optimiseModule].options);
  const case_id = useSelector((state) => state[optimiseModule].caseData?.id);
  const gap_id = useSelector((state) => state[optimiseModule].caseData?.gap_file?.id);
  const { disabled, savedChecked, visible, conn_map_id } = getChecked(caseOptions, row, opt);
  const wellChange = useSelector(
    (state) => state[optimiseModule].wellChanges[`${well_id}-${conn_map_id}`]
  );

  if (visible) {
    const onChange = () => {
      const mode = !!wellChange ? 'remove' : 'add';
      dispatch(
        changeWellCellValue(`${well_id}-${conn_map_id}`, mode, {
          ds: savedChecked ? 'delete' : 'new',
          keys: { well_id, conn_map_id: conn_map_id, case_id, gap_id },
          values: {},
        })
      );
      if (row.gap_well?.comingledWells.length > 0) {
        row.gap_well?.comingledWells.forEach((comingledId) => {
          dispatch(
            changeWellCellValue(`${comingledId}-${conn_map_id}`, mode, {
              ds: savedChecked ? 'delete' : 'new',
              keys: { well_id: comingledId, conn_map_id: conn_map_id, case_id, gap_id },
              values: {},
            })
          );
        });
      }
    };
    return (
      <Checkbox
        checked={savedChecked ? !wellChange : !!wellChange}
        disabled={disabled}
        onChange={onChange}
      />
    );
  } else {
    return null;
  }
}

function getChecked(caseOptions, row, opt) {
  const data = caseOptions?.connRules || [];
  const connectionMap = row.gap_well?.connectionMap;
  let disabled = false;
  let savedChecked = row.gap_well?.connections.some((item) => {
    const tag = item?.conn_map?.tl;
    const tag_mp_lp = item?.conn_map?.tag_mp_lp;
    const isTest =
      tag.toLowerCase() === opt?.tag_tl.toLowerCase() &&
      tag_mp_lp.toLowerCase() === opt?.tag_mp_lp.toLowerCase();
    return isTest
      ? data.some((i) => i.well_id === item.well_id && i.conn_map_id === item.conn_map_id)
      : false;
  });

  let conn = {};
  for (let item of Object.values(connectionMap)) {
    if (item.tl.toLowerCase() === opt?.tl.toLowerCase()) {
      if (item.mp_lp.toLowerCase() === opt?.mp_lp.toLowerCase()) {
        conn = item;
      }
    }
  }

  if (Object.keys(conn).length) {
    if (row.gap_conn_id == conn.conn_map_id) {
      disabled = true;
      savedChecked = true;
    }
    return { visible: true, disabled, savedChecked, conn_map_id: conn.conn_map_id };
  }

  return { visible: false, disabled, savedChecked, conn_map_id: null };
}
