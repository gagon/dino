import React, { useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router';

import { loadCase, clear, updateResults, updateOptions } from './OptimiseDucks';
import OptimiseSideBar from './SideBar/OptimiseSideBar';
import { optimizeMenuModule } from './SideBar/OptimseMenuDucks';
import OptimiseTable from './OptimiseTable';
import OptimiseRules from './OptimiseRules';
import OptimiseResultsTable from './OptimiseResultsTable';
import useSocketMessage from '../../common/_hooks/useSocketMessage';
import paths from '../../_helpers/paths';

export default function Optimise() {
  const dispatch = useDispatch();
  const { caseId } = useParams();
  const viewRoutes = useSelector((state) => state[optimizeMenuModule].viewRoutes);

  useEffect(() => {
    dispatch(loadCase(caseId));
    return () => {
      dispatch(clear());
    };
  }, [caseId, dispatch]);

  const handleOptRoutingSingleUpdate = useCallback(
    (res) => {
      dispatch(updateOptions(caseId));
      dispatch(updateResults(res));
    },
    [dispatch, updateResults, updateOptions, caseId]
  );
  const handleCreateCaseFromOption = useCallback(
    (res) => {
      const url = paths.case.replace(':caseId', res);
      window.open(url, '_blank');
    },
    [paths]
  );
  const handleDeleteCaseOption = useCallback(
    (res) => {
      if (res === 'Option was deleted successfully') {
        dispatch(updateOptions(caseId));
      }
    },
    [caseId, dispatch, updateOptions]
  );

  useSocketMessage('opt_routing_single_update', handleOptRoutingSingleUpdate);
  useSocketMessage('create_case_from_option_reply', handleCreateCaseFromOption);
  useSocketMessage('delete_case_option_reply', handleDeleteCaseOption);

  return (
    <OptimiseSideBar>
      <div style={{ width: 'calc(100% - 94px)' }}>
        <div className="flex items-center">
          <div className="content fullWidth pb2">
            <div style={{ height: 'calc(100% - 380px)', overflow: 'hidden' }}>
              {!viewRoutes && (
                <>
                  <OptimiseRules />
                  <OptimiseTable />
                </>
              )}
              {viewRoutes && <OptimiseResultsTable />}
            </div>
          </div>
        </div>
      </div>
    </OptimiseSideBar>
  );
}
