import React, { useCallback, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import { useTheme } from '@mui/styles';
import { Box, Button, Pagination, PaginationItem, Typography } from '@mui/material';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

import Table from '../../common/Table/Table';
import nullOrFixed from '../utils/nullOrFixed';
import { optimiseModule, updateResults } from './OptimiseDucks';
import DinoSocket from '../../_helpers/socket';

const rowsPerPage = 25;
const generateColumns = (calcDict, caseConfig, caseData) => {
  const socket = DinoSocket.socket;

  const createCaseFromOption = (optId) => {
    if (socket) socket.emit('create_case_from_option', optId);
  };

  const deleteCaseOption = (optId) => {
    if (socket) socket.emit('delete_case_option', optId);
  };

  const calcCaseValue = (id, calcName) => {
    if (!(id in calcDict[calcName].results)) {
      return '';
    }
    return calcDict[calcName].results[id].value;
  };

  return [
    {
      flex: 0.4,
      minWidth: 60,
      field: 'id',
      headerName: 'ID',
      valueGetter: ({ row }) => (row.id === 'default' ? 'Base' : row.id),
    },
    {
      flex: 1,
      minWidth: 120,
      field: 'qWater',
      headerName: 'Total Qwater (sm3/d)',
      valueGetter: ({ row }) => {
        let resTot = 0;
        resTot = calcCaseValue(row.id, 'u2_wat_tot');
        resTot += calcCaseValue(row.id, 'u3_wat_tot');
        resTot += calcCaseValue(row.id, 'kpc_wat_tot');
        return nullOrFixed(resTot, 0);
      },
    },
    {
      flex: 1,
      minWidth: 120,
      field: 'qGas',
      headerName: 'Total Qgas (ksm3/d)',
      valueGetter: ({ row }) => {
        let resTot = 0;
        return nullOrFixed(calcCaseValue(row.id, 'field_tot_gas'), 0);
      },
    },
    {
      flex: 1,
      minWidth: 120,
      field: 'gasInjection',
      headerName: 'Gas Injection (ksm3/d)',
      valueGetter: ({ row }) => nullOrFixed(calcCaseValue(row.id, 'gas_inj'), 0),
    },
    {
      flex: 1,
      minWidth: 120,
      field: 'gasSales',
      headerName: 'Gas Sales (ksm3/d)',
      valueGetter: ({ row }) => nullOrFixed(calcCaseValue(row.id, 'ogp_gas'), 0),
    },
    {
      flex: 1,
      minWidth: 120,
      field: 'qOil',
      headerName: 'Total Qoil (sm3/d)',
      valueGetter: ({ row }) => nullOrFixed(calcCaseValue(row.id, 'field_tot_oil'), 0),
    },
    {
      flex: 1,
      minWidth: 190,
      field: 'cpcOil',
      headerName: 'CPC Oil Production (ksm3/d)',
      valueGetter: ({ row }) => nullOrFixed(calcCaseValue(row.id, 'cpc_oil'), 0),
    },
    {
      flex: 1,
      minWidth: 120,
      field: 'incrementalOil',
      headerName: 'Incremental Oil',
      valueGetter: ({ row }) => {
        if (row.id === 'default') {
          return 0;
        } else {
          if (!(row.id in calcDict['field_tot_oil'].results)) {
            return '';
          }
          const newTotOil = calcCaseValue(row.id, 'field_tot_oil');
          const fieldDiff = newTotOil - calcCaseValue('default', 'field_tot_oil');
          return nullOrFixed(fieldDiff, 0);
        }
      },
    },
    {
      flex: 2,
      minWidth: 200,
      field: 'routeChanges',
      headerName: 'Route Changes',
      renderCell: ({ row }) => {
        let routeChanges = <div></div>;
        if (row.id == 'default') {
          routeChanges = <div>'N/A'</div>;
        } else {
          routeChanges = (
            <div className="fs-12">
              {Object.values(row.connections).map((val) => {
                const wellId = val.well_id;
                const connMapId = val.conn_map_id;
                const caseWell = caseData.case_wells.find((item) => item.well_id === wellId);
                const name = caseConfig.wellCfg[wellId].gap_name;
                const connName = caseWell?.gap_well.connectionMap[connMapId]?.name;
                return (
                  <div key={name}>
                    {name} : {connName}
                  </div>
                );
              })}
            </div>
          );
        }
        return routeChanges;
      },
    },
    {
      flex: 0.7,
      minWidth: 100,
      field: 'newCase',
      headerName: 'New Case',
      renderCell: ({ row }) => {
        return (
          <>
            {row.id !== 'default' && (
              <Button
                variant="contained"
                size="small"
                sx={{ textTransform: 'none', width: 100 }}
                onClick={() => createCaseFromOption(row.id)}
              >
                Create Case
              </Button>
            )}
          </>
        );
      },
    },
    {
      flex: 0.8,
      minWidth: 100,
      field: 'removeOption',
      headerName: 'Remove Option',
      renderCell: ({ row }) => {
        return (
          <>
            {row.id !== 'default' && (
              <Button
                variant="contained"
                size="small"
                sx={{ textTransform: 'none', width: 100 }}
                onClick={() => deleteCaseOption(row.id)}
              >
                Remove
              </Button>
            )}
          </>
        );
      },
    },
  ];
};

const OptimiseResultsTable = () => {
  const [page, setPage] = useState(0);
  const { options, caseConfig, caseData, loading, loadingOptions } = useSelector(
    (state) => state[optimiseModule]
  );
  const { calcDict } = useSelector((state) => state[optimiseModule].calculation);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { palette } = useTheme();

  const handleChangePage = (event, value) => {
    setPage(value - 1);
  };

  const initialRows = [{ id: 'default' }];

  const rows = useMemo(() => {
    if (options.caseOpts.length > 0) {
      return [...initialRows, ...options.caseOpts];
    }
    return initialRows;
  }, [initialRows, options.caseOpts]);

  const columns = useMemo(() => {
    if (calcDict && caseConfig && caseData) {
      return generateColumns(calcDict, caseConfig, caseData);
    }
    return [];
  }, [calcDict, caseConfig, caseData, generateColumns]);

  return (
    <div className="mb4">
      <div className="mt1 mb2">
        <Typography
          variant={'h5'}
          children={'Optimisation Results'}
          style={{ color: palette.action.active }}
        />
      </div>
      <Box>
        <Table
          rows={rows}
          columns={columns}
          loading={loading || loadingOptions}
          sx={{
            '& .super-app-theme--default': {
              bgcolor: 'orange',
            },
          }}
          getRowClassName={(params) => {
            if (params.row.id === 'default') return 'super-app-theme--default';
          }}
          getRowHeight={({ model }) =>
            model?.connections ? Object.values(model?.connections).length * 21 : 40
          }
          autoHeight
          page={page}
          pageSize={rowsPerPage}
          disableExtendRowFullWidth={false}
          disableColumnMenu
          disableSelectionOnClick
          disableMultipleColumnsSorting
          hideFooter
          hideFooterPagination
        />
      </Box>

      <div
        style={{
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'center',
          marginTop: 10,
        }}
      >
        <Pagination
          color="primary"
          shape="rounded"
          count={Math.ceil(rows.length / rowsPerPage)}
          page={page + 1}
          onChange={handleChangePage}
          renderItem={(item) => (
            <PaginationItem
              color="primary"
              components={{ previous: ArrowBackIosNewIcon, next: ArrowForwardIosIcon }}
              {...item}
            />
          )}
        />
      </div>
    </div>
  );
};

export default OptimiseResultsTable;
