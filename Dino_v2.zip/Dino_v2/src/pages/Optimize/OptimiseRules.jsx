import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import React from 'react';
import { useTheme } from '@mui/styles';
import { useDispatch, useSelector } from 'react-redux';
import { addRule, changeRuleCellValue, optimiseModule, removeRule } from './OptimiseDucks';
import { ruleColumns } from './WellColums';
import Table from '../../common/Table/Table';
import { Button } from '@mui/material';
import useStep from './useStep';

export default function OptimiseRules() {
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const loading = useSelector((state) => state[optimiseModule].loading);
  const loadingOptions = useSelector((state) => state[optimiseModule].loadingOptions);
  const ruleList = useSelector((state) => state[optimiseModule].ruleList);
  const rulesTableData = useSelector((state) => state[optimiseModule].rulesTableData);
  const tableData = Object.values(rulesTableData);
  const onChange = (id, name, value) => dispatch(changeRuleCellValue(id, name, value));
  const columns = ruleColumns(tableData, ruleList, onChange, (id) => dispatch(removeRule(id)));
  const { disabled } = useStep();

  return (
    <div className="mb4">
      <div className="mb2 mt1">
        <Typography
          variant={'h5'}
          children={'Optimisation Rules'}
          style={{ color: palette.action.active }}
        />
      </div>
      <Button
        variant="outlined"
        disabled={disabled}
        onClick={() => dispatch(addRule())}
        children="Add optimization Rule"
        style={{ marginBottom: 8 }}
      />
      <Box>
        <Table
          rows={tableData}
          columns={columns}
          loading={loading || loadingOptions}
          pageSize={tableData.length < 100 ? tableData.length : 100}
          getRowHeight={({ model }) =>
            model?.connections ? Object.values(model?.connections).length * 21 : 44
          }
          autoHeight
          hideFooterPagination
          hideFooter
          disableColumnMenu
          disableSelectionOnClick
          disableMultipleColumnsSorting
          disableExtendRowFullWidth={false}
        />
      </Box>
    </div>
  );
}
