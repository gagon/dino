import i18next, { t } from 'i18next';
import { DeleteOutline } from '@mui/icons-material';
import { IconButton } from '@mui/material';

export const VehicleColumn = (deleteData) =>
  [
    { field: 'id', headerName: 'ID', witch: 70 },
    { field: 'number', headerName: t('colum_table_number'), flex: 0.8 },
    { field: 'mark', headerName: t('colum_table_mark'), flex: 0.8 },
    {
      field: 'color',
      headerName: t('colum_table_color'),
      flex: 0.8,
    },
    {
      field: '_id',
      headerName: i18next.t('colum_table_delete'),
      flex: 0.5,
      renderCell: (params) => {
        return (
          <div className={'mx-auto'}>
            <IconButton
              className="center"
              onClick={(e) => {
                e.stopPropagation();
                deleteData(params.row.id);
              }}
            >
              <DeleteOutline />
            </IconButton>
          </div>
        );
      },
    },
  ].map((column) => ({ ...column, sortable: false }));
