import React from 'react';
import HeadTitle from '../../common/HeadTitle';
import { useTranslation } from 'react-i18next';
import './vehiclePageTranslate';
import Paper from '@mui/material/Paper';
import { DataGrid } from '@mui/x-data-grid';
import { useDispatch, useSelector } from 'react-redux';
import {
  vehicleModule,
  loadDataVehicle,
  deleteData,
  createData,
  updateData,
} from './vehiclePageDucks';
import useTableFilter from '../../common/TableFilter/useTableFilter';
import { VehicleColumn } from './vehicleColumn';
import AddIcon from '@mui/icons-material/Add';
import useModal from '../../common/_hooks/useModal';
import DeleteModal from './modals/deleteModal';
import { LoadingButton } from '@mui/lab';
import AddModal from './modals/addModal';
import ViewModal from './modals/ViewModal';

export default function VehiclePage() {
  const { t } = useTranslation();
  const rows = useSelector((state) => state[vehicleModule].data);
  const totalCount = useSelector((state) => state[vehicleModule].totalCount);
  const loading = useSelector((state) => state[vehicleModule].loading);
  const dispatch = useDispatch();
  const loadData = (filter) => dispatch(loadDataVehicle(filter));
  const filter = useTableFilter(loadData);
  const addModal = useModal('addModal');
  const deleteModal = useModal('deleteModal');
  const viewModal = useModal('viewModal');
  const deleteObject = () => {
    dispatch(deleteData(deleteModal.data, filter.filter, deleteModal.close));
  };
  const addObject = (values) => {
    dispatch(createData(values, filter.filter, addModal.close));
  };
  const saveObject = (values) => {
    dispatch(updateData(values.id, values, filter.filter, viewModal.close));
  };
  return (
    <div>
      <HeadTitle title={t('vehicle_title')} />
      <div className="flex justify-between items-center mb2">
        <div className="bold fs-18">{t('vehicle_title')}</div>
        <LoadingButton
          loading={loading}
          variant="outlined"
          color="primary"
          onClick={() => addModal.open()}
          startIcon={<AddIcon />}
          children={t('add_drive')}
        />
      </div>
      <Paper className="p3">
        <DataGrid
          rows={rows}
          columns={VehicleColumn(deleteModal.open)}
          rowCount={totalCount}
          pageSize={20}
          rowsPerPageOptions={[20]}
          autoHeight
          paginationMode="server"
          onPageChange={(page) => filter.toPage(page + 1)}
          loading={loading}
          disableColumnMenu
          disableMultipleColumnsSorting
          disableSelectionOnClick
          onRowClick={(data) => viewModal.open(data.row)}
        />
      </Paper>
      <DeleteModal
        open={deleteModal.isOpen}
        deleteObject={deleteObject}
        handleClose={deleteModal.close}
        load={loading}
      />
      <AddModal
        load={loading}
        open={addModal.isOpen}
        handleClose={addModal.close}
        addObject={addObject}
      />
      <ViewModal
        data={viewModal.data ?? {}}
        load={loading}
        open={viewModal.isOpen}
        handleClose={viewModal.close}
        save={saveObject}
      />
    </div>
  );
}
