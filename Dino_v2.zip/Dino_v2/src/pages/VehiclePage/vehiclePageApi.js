import axios from "axios";

export const VehicleApi = {
  create: (data) => axios.post("api/eve/vehicle/passport", data),
  update: (data, id) => axios.put(`api/eve/vehicle/passport/${id}`, data),
  getOne: (id) => axios.get(`api/eve/vehicle/passport/${id}`),
  delete: (id) => axios.delete(`api/eve/vehicle/passport/${id}`),
  getData: (filter) => axios.get(`api/eve/vehicle/paging?filter=${filter}`),
  listOfFreeCars: () => axios.get("api/eve/vehicle/listOfFreeCars"),
};
