import { addTranslation } from '../../_helpers/translate';

addTranslation({
  ru: {
    vehicle_title: 'Управление транспортом',
    colum_table_color: 'Цвет',
    colum_table_number: 'Номер',
    colum_table_mark: 'Марка',
    colum_table_delete: 'Удалить',
    add_drive: 'Добавить',
    deleteModalTitle: 'Вы действительно хотите удалить элемент?',
    deleteModalButtonYes: 'Да',
    deleteModalButtonNo: 'Нет',
    addModalTitle: 'Добавление нового транспорта',
    addModalButtonYes: 'Добавить',
    addModalButtonNo: 'Отменить',
    fieldRequired: 'Обязательное поле',
    addError: 'Не удалось добавить транспорт',
    saveError: 'Не удалось сохранить транспорт',
    deleteError: 'Не удалось удалить транспорт',
    gerError: 'Не удалось загрузить список',
    saveModalButtonYes: 'Сохранить',
    saveModalButtonNo: 'Отменить',
  },
  kk: {},
});
