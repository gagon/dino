import React from 'react';
import { LoadingButton } from '@mui/lab';
import { t } from 'i18next';
import { useForm, Controller } from 'react-hook-form';
import { TextField } from '@mui/material';
import { fieldToProps } from '../../../common/utils/fieldToProps';
export default function ModalForm({
  onClickSaveAction,
  data,
  handleClose,
  load,
  buttonYes,
  buttonNo,
}) {
  const form = useForm({
    defaultValues: data,
    shouldUnregister: false,
  });
  return (
    <form onSubmit={form.handleSubmit(onClickSaveAction)}>
      <div className={'flex flex-column'}>
        <Controller
          control={form.control}
          name="number"
          rules={{
            required: t('fieldRequired'),
          }}
          render={(fieldProps) => (
            <TextField
              label={t('colum_table_number')}
              size="medium"
              margin="normal"
              fullWidth
              {...fieldToProps(fieldProps)}
            />
          )}
        />
        <Controller
          control={form.control}
          name="mark"
          rules={{
            required: t('fieldRequired'),
          }}
          render={(fieldProps) => (
            <TextField
              label={t('colum_table_mark')}
              size="medium"
              margin="normal"
              fullWidth
              {...fieldToProps(fieldProps)}
            />
          )}
        />
        <Controller
          control={form.control}
          name="color"
          rules={{
            required: t('fieldRequired'),
          }}
          render={(fieldProps) => (
            <TextField
              label={t('colum_table_color')}
              size="medium"
              margin="normal"
              fullWidth
              {...fieldToProps(fieldProps)}
            />
          )}
        />
      </div>
      <div className={'flex justify-end mt2'}>
        <LoadingButton loading={load} color="primary" type="submit">
          {t(buttonYes)}
        </LoadingButton>
      </div>
    </form>
  );
}
