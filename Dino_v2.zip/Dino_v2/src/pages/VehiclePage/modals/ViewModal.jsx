import React from 'react';
import { Dialog, DialogContent, DialogTitle } from '@mui/material';
import ModalForm from './ModalForm';
export default function ViewModal({ open, handleClose, save, load, data }) {
  return (
    <Dialog maxWidth="sm" fullWidth open={open} onClose={handleClose}>
      <DialogTitle>
        {data.mark ?? ''} {data.number ?? ''} {data.color ?? ''}
      </DialogTitle>
      <DialogContent>
        <ModalForm
          handleClose={handleClose}
          data={data}
          buttonYes={'saveModalButtonYes'}
          buttonNo={'saveModalButtonNo'}
          onClickSaveAction={save}
          load={load}
        />
      </DialogContent>
    </Dialog>
  );
}
