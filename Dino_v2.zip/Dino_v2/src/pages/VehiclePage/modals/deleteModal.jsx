import React from 'react';
import { Dialog, DialogActions, DialogTitle } from '@mui/material';
import { t } from 'i18next';
import { LoadingButton } from '@mui/lab';

export default function DeleteModal({ open, handleClose, deleteObject, load }) {
  return (
    <Dialog open={open} maxWidth="sm" fullWidth onClose={handleClose}>
      <DialogTitle>{t('deleteModalTitle')}</DialogTitle>
      <DialogActions>
        <LoadingButton loading={load} color="inherit" onClick={() => deleteObject()}>
          {t('deleteModalButtonYes')}
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
}
