import React from 'react';
import { Dialog, DialogContent, DialogTitle } from '@mui/material';
import { t } from 'i18next';
import ModalForm from './ModalForm';

export default function AddModal({ open, handleClose, addObject, load }) {
  return (
    <Dialog maxWidth="sm" fullWidth open={open} onClose={handleClose}>
      <DialogTitle>{t('addModalTitle')}</DialogTitle>
      <DialogContent>
        <ModalForm
          handleClose={handleClose}
          data={{}}
          buttonYes={'addModalButtonYes'}
          buttonNo={'addModalButtonNo'}
          onClickSaveAction={addObject}
          load={load}
        />
      </DialogContent>
    </Dialog>
  );
}
