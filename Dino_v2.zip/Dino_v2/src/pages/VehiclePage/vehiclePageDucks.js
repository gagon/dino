import { createReducer } from "@reduxjs/toolkit";
import { VehicleApi } from "./vehiclePageApi";
import { handleError } from "../../common/utils/handleError";
import i18next from "i18next";
import "./vehiclePageTranslate";

/**
 * Constants
 */

export const vehicleModule = "vehicle";
const SET_DATA = `${vehicleModule}/SET_DATA`;
const LOADING = `${vehicleModule}/LOADING`;
const CLEAR_STATE = `${vehicleModule}/CLEAR_STATE`;
const SET_TOTAL_COUNT = `${vehicleModule}/SET_TOTAL_COUNT`;

/**
 * Reducer
 */

const initialState = {
  loading: true,
  data: [],
  totalCount: 0,
};

export default createReducer(initialState, {
  [SET_DATA]: (state, action) => {
    state.data = action.payload;
    state.loading = false;
  },
  [SET_TOTAL_COUNT]: (state, action) => {
    state.totalCount = action.payload;
  },
  [LOADING]: (state, action) => {
    state.loading = !!action.payload;
  },
  [CLEAR_STATE]: () => initialState,
});

/**
 * Actions
 */
export const loadDataVehicle = (filter) => async (dispatch) => {
  try {
    const fiter = {
      _type: "vehicle",
      sortField: "id",
      sortOrder: "desc",
      ...filter,
    };
    dispatch({ type: LOADING, payload: true });
    let { data } = await VehicleApi.getData(JSON.stringify(fiter));
    let dataResponse = data.result;
    dispatch({ type: SET_DATA, payload: dataResponse.items });
    dispatch({ type: SET_TOTAL_COUNT, payload: dataResponse.totalCount });
  } catch (error) {
    handleError(error, i18next.t("gerError"));
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};
export const createData = (data, filter, closeModal) => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    data.isActive = true;
    await VehicleApi.create(data);
    dispatch(loadDataVehicle(filter));
  } catch (error) {
    handleError(error, i18next.t("addError"));
  } finally {
    dispatch({ type: LOADING, payload: false });
    closeModal();
  }
};
export const updateData =
  (id, dataUpdate, filter, closeModal) => async (dispatch) => {
    try {
      dispatch({ type: LOADING, payload: true });
      delete dataUpdate._id;
      delete dataUpdate._type;
      await VehicleApi.update(dataUpdate, id);
      dispatch(loadDataVehicle(filter));
    } catch (error) {
      handleError(error, i18next.t("saveError"));
    } finally {
      dispatch({ type: LOADING, payload: false });
      closeModal();
    }
  };
export const deleteData = (id, filter, closeModal) => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    await VehicleApi.delete(id);
    dispatch(loadDataVehicle(filter));
  } catch (error) {
    handleError(error, i18next.t("deleteError"));
  } finally {
    dispatch({ type: LOADING, payload: false });
    closeModal();
  }
};
