import { createReducer } from '@reduxjs/toolkit';
import { handleError } from '../../common/utils/handleError';
import Notice from '../../common/utils/Notice';
import paths from '../../_helpers/paths';
import { LoginApi } from '../../_helpers/service';

/**
 * Constants
 */

export const loginModule = 'login';
const SET_PARAM_TO_USER_CONFIG = `${loginModule}/SET_PARAM_TO_USER_CONFIG`;
const SET_CONFIG = `${loginModule}/SET_CONFIG`;
const SET_APP_CONFIG = `${loginModule}/SET_APP_CONFIG`;
const SET_IS_HOUR_UNITS = `${loginModule}/SET_IS_HOUR_UNITS`;
const CLEAR = `${loginModule}/CLEAR`;
const LOADING = `${loginModule}/LOADING`;
const LOADING_LOGIN = `${loginModule}/LOADING_LOGIN`;

/**
 * Reducer
 */

const initialState = {
  userConfig: {},
  user: null,
  appConfig: {},
  loading: true,
  loadingLogin: false,
};

export default createReducer(initialState, {
  [SET_CONFIG]: (state, { appConfig, userConfig, user }) => {
    state.appConfig = appConfig;
    state.userConfig = userConfig;
    state.user = user;
  },
  [SET_APP_CONFIG]: (state, { payload }) => {
    state.appConfig = payload;
  },
  [SET_PARAM_TO_USER_CONFIG]: (state, { paramName, payload }) => {
    state.userConfig[paramName] = payload;
  },
  [SET_IS_HOUR_UNITS]: (state, { payload }) => {
    state.userConfig.isHourUnits = payload;
  },
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [LOADING_LOGIN]: (state, { payload }) => {
    state.loadingLogin = payload;
  },
  [CLEAR]: () => initialState,
});

/**
 * Actions
 */

export const clear = () => ({ type: CLEAR });

export const login = (formValues, navigate) => async (dispatch) => {
  dispatch({ type: LOADING_LOGIN, payload: true });
  try {
    let pathname = window.location.pathname;
    if (navigate && (pathname.includes('case/') || pathname === '/')) {
      navigate(paths.case.replace(':caseId', '0'));
    }
    let formData = new FormData();
    formData.append('username', formValues.username);
    formData.append('password', formValues.password);
    await LoginApi.login(formData);
    dispatch(checkAuth());
  } catch (e) {
    handleError(e, 'Failed to sign in');
  } finally {
    dispatch({ type: LOADING_LOGIN, payload: false });
  }
};

export const logout = () => async (dispatch) => {
  dispatch({ type: LOADING_LOGIN, payload: true });
  try {
    await LoginApi.logout();
    dispatch(clear());
  } catch (e) {
    handleError(e, 'Failed to logout');
  } finally {
    dispatch({ type: LOADING, payload: false });
    dispatch({ type: LOADING_LOGIN, payload: false });
  }
};

export const checkAuth = () => async (dispatch) => {
  dispatch({ type: LOADING, payload: true });
  try {
    let { data } = await LoginApi.loadUserSetting();
    const userConfig = {};
    data.settings.forEach((item) => {
      userConfig[item.name] = item.value;
    });
    userConfig['user_id'] = data.user['user_id'];
    userConfig['user_name'] = data.user['user_name'];
    userConfig['user_role'] = data.user['user_role'];
    userConfig.isHourUnits = false;

    // app settings
    let { data: settingArr } = await LoginApi.loadAppSetting();
    const appConfig = {};
    for (let val of settingArr) {
      appConfig[val.group + ':' + val.name] = val.value;
    }
    dispatch({ type: SET_CONFIG, appConfig, userConfig, user: data.user });
  } catch (e) {
    handleError(e);
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const setAppConfig = (data) => ({ type: SET_APP_CONFIG, payload: data });

export const setParamToUserConfig = (paramName, settings) => async (dispatch) => {
  try {
    if (settings || settings === false || settings === null) {
      dispatch({ type: SET_PARAM_TO_USER_CONFIG, paramName, payload: settings });
      const paramSettings = { [paramName]: settings };
      await LoginApi.saveUserSettings(paramSettings);
    }
  } catch (e) {
    handleError(e);
    Notice.error(`Failed to save param "${paramName}" to user config`);
  }
};

export const setIsHourUnits = (isHour) => ({ type: SET_IS_HOUR_UNITS, payload: isHour });
