import styled from 'styled-components';

export const Wrapper = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;

  .login-header {
    background-color: ${(props) => props.theme.palette.primary.main};
    opacity: ${(props) => (props.theme.isDark ? 0.3 : 1)};
    height: 40vh;
  }

  .login-container {
    display: flex;
    flex-wrap: wrap;
    background-color: ${(props) => props.theme.palette.background.paper};
    max-width: 750px;
    height: 320px;
    overflow: auto;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    padding: 30px;
    transform: translateY(-30px);

    .left-block {
      flex: 5;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: flex-end;
      text-align: right;
      padding-right: 30px;
      font-size: 17px;
    }

    .right-block {
      padding-left: 30px;
      flex: 6;
      display: flex;
      align-items: center;
    }
  }

  input:-webkit-autofill,
  input:-webkit-autofill:hover,
  input:-webkit-autofill:focus,
  input:-webkit-autofill:active {
    z-index: 999;
    -webkit-box-shadow: 0 0 0 1000px transparent inset;
    -webkit-text-fill-color: ${(props) => props.theme.palette.text.primary};
    transition: background-color 5000s ease-in-out 0s;
    -webkit-transition-delay: 9999999s;
    border-radius: 4px;
  }
  @media screen and (max-width: 386px) {
    .login-container {
      height: initial;
    }
  }
`;
