import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { IconButton, TextField } from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { Wrapper } from './LoginStyle';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import Card from '@mui/material/Card';
import Divider from '@mui/material/Divider';
import LoadingButton from '@mui/lab/LoadingButton';
import {checkAuth, loadUserConfig, login, loginModule} from "./LoginDucks";
import PageLoader from '../../common/PageLoader/PageLoader';
import { useNavigate } from 'react-router';

export default function LoginPage({ children }) {
  const dispatch = useDispatch();
  const { register, handleSubmit } = useForm();
  const [showPass, setShowPass] = useState(false);
  const loading = useSelector((state) => state[loginModule].loading);
  const loadingLogin = useSelector((state) => state[loginModule].loadingLogin);
  const user = useSelector((state) => state[loginModule].user);
  const navigate = useNavigate();

  useEffect(() => {
    dispatch(checkAuth());
  }, []);

  if (loading) return <PageLoader />;
  if (user) return children;

  return (
    <Wrapper>
      <div className="login-header" />
      <Card className="login-container">
        <div className="left-block">
          {/*<img src={LogoImage} alt="" width={180} />*/}
          <div className="fs-23 mr3">{'Data Integration and Network Optimization solution'}</div>
        </div>
        <Divider orientation="vertical" />
        <div className="right-block">
          <div className="login-form">
            <form onSubmit={handleSubmit(values => dispatch(login(values, navigate)))}>
              <TextField label="username" margin="normal" {...register('username')} />
              <TextField
                type={showPass ? 'text' : 'password'}
                label="password"
                margin="normal"
                {...register('password')}
                InputProps={{
                  endAdornment: (
                    <IconButton
                      style={{ padding: 2 }}
                      onClick={() => setShowPass(!showPass)}
                      children={showPass ? <VisibilityOff /> : <Visibility />}
                    />
                  ),
                }}
              />
              <LoadingButton
                loading={loadingLogin}
                type="submit"
                style={{ padding: '15px', marginTop: 14 }}
                variant="contained"
                children="login"
                fullWidth
              />
            </form>
          </div>
        </div>
      </Card>
    </Wrapper>
  );
}
