import React from 'react';
import TabPanel from '../../common/TabPanel';
import TabsButton from './TabsButton';
import Connections from './Connections/Connections';
import FieldConfig from './FieldConfig/FieldConfig';
import ResultCalculations from './ResultCalculations/ResultCalculations';
import ResultLabels from './ResultLabels/ResultLabels';
import { useLocation, useNavigate } from 'react-router-dom';
import AppSettings from './AppSettings/AppSettings';
import UserRoles from './UserRoles/UserRoles';
import GapFiles from './GapFiles/GapFiles';
import Wells from './Wells/Wells';

export default function Config() {
  const { pathname, search } = useLocation();
  const searchParam = new URLSearchParams(search);
  const tabName = searchParam.get('tabName');
  const navigate = useNavigate();

  return (
    <div className="flex items-center">
      <div className="content fullWidth pb2">
        <div style={{ marginBottom: 20 }}>
          <TabsButton
            page={tabName}
            setPage={(tabName) => {
              searchParam.set('tabName', tabName);
              navigate(`${pathname}?${searchParam.toString()}`, { replace: true });
            }}
          />
        </div>
        <div style={{ height: 'calc(100% - 380px)', overflow: 'hidden' }}>
          <TabPanel value={tabName} index={'configuredGapFiles'} children={<GapFiles />} />
          <TabPanel value={tabName} index={'applicationSettings'} children={<AppSettings />} />
          <TabPanel value={tabName} index={'userRoles'} children={<UserRoles />} />
          <TabPanel value={tabName} index={'fieldConfig'} children={<FieldConfig />} />
          <TabPanel value={tabName} index={'connections'} children={<Connections />} />
          <TabPanel
            value={tabName}
            index={'resultCalculations'}
            children={<ResultCalculations />}
          />
          <TabPanel value={tabName} index={'resultLabels'} children={<ResultLabels />} />
          <TabPanel value={tabName} index={'wells'} children={<Wells />} />
        </div>
      </div>
    </div>
  );
}
