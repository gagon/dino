import React from 'react';
import { Button, Dialog } from '@mui/material';

const ConfirmModal = ({ isOpen, text, onProceed, onClose, disallowed }) => {
  return (
    <Dialog
      sx={{ background: '#5051F935', zIndex: 2 }}
      PaperProps={{
        sx: {
          borderTopRightRadius: 20,
          borderTopLeftRadius: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        },
      }}
      onClose={onClose}
      open={isOpen}
    >
      <div style={{ padding: '33px 28px 25px 28px' }}>
        <div
          style={{
            width: 500,
            display: 'flex',
            flexDirection: 'column',
            gap: 26,
          }}
        >
          <div>{text}</div>
          <div
            className="fullWidth"
            style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}
          >
            {!disallowed && (
              <Button variant="contained" onClick={onProceed}>
                Ok
              </Button>
            )}

            <Button variant="contained" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </div>
      </div>
    </Dialog>
  );
};

export default ConfirmModal;
