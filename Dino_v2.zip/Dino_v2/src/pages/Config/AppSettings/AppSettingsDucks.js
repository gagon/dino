import { createReducer } from '@reduxjs/toolkit';

import { handleError } from '../../../common/utils/handleError';
import Notice from '../../../common/utils/Notice';
import { AppSettingsApi, LoginApi } from '../../../_helpers/service';
import { setAppConfig } from '../../Login/LoginDucks';

/**
 * Constants
 */
export const appSettingsModule = 'appSettingsModule';
const SET_APP_CONFIG = `${appSettingsModule}/SET_APP_CONFIG`;
const LOADING = `${appSettingsModule}/LOADING`;
const LOADING_SAVE = `${appSettingsModule}/LOADING_SAVE`;
const ON_CELL_CHANGE = `${appSettingsModule}/ON_CELL_CHANGE`;
const CLEAR_CHANGES_DATA = `${appSettingsModule}/CLEAR_CHANGES_DATA`;

/**
 * Reducer
 */
const initialState = {
  appConfig: [],
  changesData: {},
  loading: true,
  loadingSave: false,
};

export default createReducer(initialState, {
  [SET_APP_CONFIG]: (state, { payload }) => {
    state.appConfig = payload;
  },
  [ON_CELL_CHANGE]: (state, { id, value }) => {
    if (state.changesData[id]) {
      state.changesData[id].value = value;
    } else {
      state.changesData[id] = { value };
    }
  },
  [CLEAR_CHANGES_DATA]: (state) => {
    state.changesData = {};
  },
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [LOADING_SAVE]: (state, { payload }) => {
    state.loadingSave = payload;
  },
});

/**
 * Actions
 */
export const loadAppSettings = () => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    const { data: settingArr } = await LoginApi.loadAppSetting();
    dispatch({ type: SET_APP_CONFIG, payload: settingArr });
  } catch (e) {
    handleError(e, 'Failed to load application settings');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const saveChanges = () => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_SAVE, payload: true });
    const changesData = getState()[appSettingsModule].changesData;
    const { data } = await AppSettingsApi.saveAppSettings({ AppSetting: changesData });
    dispatch({ type: SET_APP_CONFIG, payload: data }); // Updating app settings in appSettings module
    const appConfig = {};
    for (let val of data) {
      appConfig[val.group + ':' + val.name] = val.value;
    }
    dispatch(setAppConfig(appConfig)); // Updating app settings in login module
    dispatch({ type: CLEAR_CHANGES_DATA });
    Notice.success('Application settings have been saved');
  } catch (e) {
    handleError(e, 'Failed to save application settings');
  } finally {
    dispatch({ type: LOADING_SAVE, payload: false });
  }
};

export const onCellChange = (id, value) => ({
  type: ON_CELL_CHANGE,
  id,
  value,
});
