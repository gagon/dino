import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { TextField } from '@mui/material';

import { appSettingsModule, onCellChange } from './AppSettingsDucks';

export const appSettingsColumns = () => [
  {
    width: 260,
    field: 'group',
    headerName: 'Group',
    valueGetter: ({ row }) => row.group,
    renderCell: ({ row }) => <TableData data={row.group} />,
  },
  {
    width: 270,
    field: 'name',
    headerName: 'Name',
    valueGetter: ({ row }) => row.name,
    renderCell: ({ row }) => <TableData data={row.name} />,
  },
  {
    width: 470,
    field: 'description',
    headerName: 'Description',
    valueGetter: ({ row }) => row.description,
    renderCell: ({ row }) => <TableData data={row.description} />,
  },
  {
    field: 'value',
    headerName: 'Value',
    renderCell: ({ row }) => <InputText data={row} />,
  },
];

const InputText = ({ data }) => {
  const dispatch = useDispatch();
  const value = useSelector((state) => {
    if (state[appSettingsModule].changesData[data.id]) {
      return state[appSettingsModule].changesData[data.id].value;
    }
  });
  const onChange = (event) => dispatch(onCellChange(data.id, event.target.value));

  return (
    <TextField
      value={value !== undefined ? value : data.value || ''}
      onChange={onChange}
      sx={{ paddingLeft: '8px', margin: 0 }}
      InputProps={{
        style: {
          padding: '4px 8px',
          backgroundColor: value !== undefined ? 'rgb(227,174,115)' : 'transparent',
          fontSize: '14px',
        },
      }}
    />
  );
};

const TableData = ({ data }) => <div style={{ paddingLeft: 8 }}>{data}</div>;
