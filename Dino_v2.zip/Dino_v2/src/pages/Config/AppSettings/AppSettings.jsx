import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTheme } from '@mui/styles';
import { Typography } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import SaveIcon from '@mui/icons-material/SaveOutlined';

import { appSettingsColumns } from './AppSettingsColumns';
import { appSettingsModule, loadAppSettings, saveChanges } from './AppSettingsDucks';
import ConfigTable from '../ConfigTable';

const AppSettings = () => {
  const appConfig = useSelector((state) => state[appSettingsModule].appConfig);
  const loading = useSelector((state) => state[appSettingsModule].loading);
  const loadingSave = useSelector((state) => state[appSettingsModule].loadingSave);
  const saveDisabled = useSelector(
    (state) => Object.keys(state[appSettingsModule].changesData).length === 0
  );
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const columns = appSettingsColumns();
  const onSave = () => dispatch(saveChanges());

  useEffect(() => {
    dispatch(loadAppSettings());
  }, []);

  return (
    <div className="mb4">
      <div className="mb1 mt1 flex align-bottom justify-between">
        <Typography
          variant={'h5'}
          children="Application Settings"
          style={{ color: palette.action.active }}
        />
        <div className="right-align mb1">
          <LoadingButton
            loading={loadingSave}
            disabled={saveDisabled}
            variant="contained"
            startIcon={<SaveIcon />}
            children="Save changes"
            onClick={onSave}
          />
        </div>
      </div>

      <ConfigTable rows={appConfig} columns={columns} loading={loading} />
    </div>
  );
};

export default AppSettings;
