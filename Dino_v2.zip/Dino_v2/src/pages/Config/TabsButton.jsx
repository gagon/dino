import React from 'react';
import { styled as muiStyled } from '@mui/material/styles';
import { ToggleButton, ToggleButtonGroup } from '@mui/material';

const MuiToggleButtonGroup = muiStyled(ToggleButtonGroup)(({ theme }) => ({
  '& .MuiToggleButtonGroup-grouped': {
    margin: theme.spacing(0.5),
    border: 0,
    borderRadius: 6,
    fontSize: 12,
    backgroundColor: theme.palette.background.paper,
    '&.Mui-disabled': {
      border: 0,
    },
    '&:not(:first-of-type)': {
      borderRadius: 6,
      color: theme.palette.primary.main,
    },
    '&:first-of-type': {
      borderRadius: 6,
      color: theme.palette.primary.main,
    },
  },

  '& .Mui-selected': {
    backgroundColor: `${theme.palette.primary.main} !important`,
    color: `${theme.palette.common.white} !important`,
  },
}));

const MuiToggleButton = muiStyled(ToggleButton)(() => ({
  textTransform: 'none',
  height: 25,
}));

export default function TabsButton({ page, setPage }) {
  return (
    <>
      <MuiToggleButtonGroup
        exclusive
        color="primary"
        value={page}
        onChange={(e, path) => {
          setPage(path);
        }}
      >
        <MuiToggleButton value={'configuredGapFiles'} children={'Configured Gap Files'} />;
        <MuiToggleButton value={'applicationSettings'} children={'Application Settings'} />;
        <MuiToggleButton value={'userRoles'} children={'User Roles'} />;
        <MuiToggleButton value={'fieldConfig'} children={'Field Config'} />;
        <MuiToggleButton value={'connections'} children={'Connections'} />;
        <MuiToggleButton value={'resultCalculations'} children={'Result Calculations'} />;
        <MuiToggleButton value={'resultLabels'} children={'Result Labels'} />;
        <MuiToggleButton value={'wells'} children={'Wells'} />;
      </MuiToggleButtonGroup>
    </>
  );
}
