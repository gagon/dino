import { createReducer } from '@reduxjs/toolkit';

import { handleError } from '../../../common/utils/handleError';
import Notice from '../../../common/utils/Notice';
import { UserRolesApi } from '../../../_helpers/service';

/**
 * Constants
 */
export const userRolesModule = 'userRolesModule';
const SET_USER_ROLES = `${userRolesModule}/SET_USER_ROLES`;
const LOADING = `${userRolesModule}/LOADING`;
const LOADING_SAVE = `${userRolesModule}/LOADING_SAVE`;
const ON_CELL_CHANGE = `${userRolesModule}/ON_CELL_CHANGE`;
const CLEAR_CHANGES_DATA = `${userRolesModule}/CLEAR_CHANGES_DATA`;

/**
 * Reducer
 */
const initialState = {
  userRoles: [],
  changesData: {},
  loading: true,
  loadingSave: false,
};

export default createReducer(initialState, {
  [SET_USER_ROLES]: (state, { payload }) => {
    state.userRoles = payload;
  },
  [ON_CELL_CHANGE]: (state, { id, value }) => {
    if (state.changesData[id]) {
      state.changesData[id].roles = value;
    } else {
      state.changesData[id] = { roles: value };
    }
  },
  [CLEAR_CHANGES_DATA]: (state) => {
    state.changesData = {};
  },
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [LOADING_SAVE]: (state, { payload }) => {
    state.loadingSave = payload;
  },
});

/**
 * Actions
 */
export const loadUserRoles = () => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    const { data } = await UserRolesApi.loadUserRoles();
    dispatch({ type: SET_USER_ROLES, payload: data });
  } catch (e) {
    handleError(e, 'Failed to load user roles');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const saveChanges = () => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_SAVE, payload: true });
    const changesData = getState()[userRolesModule].changesData;
    const { data } = await UserRolesApi.saveUserRoles({ User: changesData });
    dispatch({ type: SET_USER_ROLES, payload: data });
    dispatch({ type: CLEAR_CHANGES_DATA });
    Notice.success('User roles have been saved');
  } catch (e) {
    handleError(e, 'Failed to save user roles');
  } finally {
    dispatch({ type: LOADING_SAVE, payload: false });
  }
};

export const onCellChange = (id, value) => ({
  type: ON_CELL_CHANGE,
  id,
  value,
});
