import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Select, MenuItem } from '@mui/material';

import { userRolesModule, onCellChange } from './UserRolesDucks';

export const userRolesColumns = () => [
  {
    field: 'name',
    headerName: 'Name',
    valueGetter: ({ row }) => row.name,
    renderCell: ({ row }) => <div style={{ paddingLeft: 8 }}>{row.name}</div>,
  },
  {
    field: 'userRole',
    headerName: 'User Role',
    renderCell: ({ row }) => <RoleSelect row={row} />,
  },
];

const RoleSelect = ({ row }) => {
  const menuItemStyle = { height: 20, px: 1, py: 1.5, fontSize: 14 };
  const dispatch = useDispatch();
  const value = useSelector((state) => {
    if (state[userRolesModule].changesData[row.id]) {
      return state[userRolesModule].changesData[row.id].roles;
    }
  });
  const handleChange = (event) => dispatch(onCellChange(row.id, event.target.value));

  return (
    <div style={{ paddingLeft: 8 }}>
      <Select
        sx={{
          padding: '4px 8px',
          width: '100%',
          backgroundColor: value !== undefined ? 'rgb(227,174,115)' : 'transparent',
          fontSize: '14px',
        }}
        value={value !== undefined ? value : row.roles}
        onChange={handleChange}
      >
        <MenuItem value={1} sx={menuItemStyle}>
          Administrator
        </MenuItem>
        <MenuItem value={2} sx={menuItemStyle}>
          Regular Account
        </MenuItem>
      </Select>
    </div>
  );
};
