import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTheme } from '@mui/styles';
import { Typography } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import SaveIcon from '@mui/icons-material/SaveOutlined';

import { userRolesColumns } from './UserRolesColumns';
import { loadUserRoles, userRolesModule, saveChanges } from './UserRolesDucks';
import ConfigTable from '../ConfigTable';

const UserRoles = () => {
  const userRoles = useSelector((state) => state[userRolesModule].userRoles);
  const loading = useSelector((state) => state[userRolesModule].loading);
  const loadingSave = useSelector((state) => state[userRolesModule].loadingSave);
  const saveDisabled = useSelector(
    (state) => Object.keys(state[userRolesModule].changesData).length === 0
  );
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const columns = userRolesColumns();
  const onSave = () => dispatch(saveChanges());

  useEffect(() => {
    dispatch(loadUserRoles());
  }, []);

  return (
    <div className="mb4">
      <div className="mb1 mt1 flex align-bottom justify-between">
        <Typography variant={'h5'} children="User Roles" style={{ color: palette.action.active }} />
        <div className="right-align mb1">
          <LoadingButton
            loading={loadingSave}
            disabled={saveDisabled}
            variant="contained"
            startIcon={<SaveIcon />}
            children="Save changes"
            onClick={onSave}
          />
        </div>
      </div>

      <ConfigTable rows={userRoles} columns={columns} loading={loading} />
    </div>
  );
};

export default UserRoles;
