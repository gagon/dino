import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  addConfiguration,
  resultLabelsModule,
  loadResultLabels,
  saveChanges,
} from './ResultLabelsDucks';
import { resultLabelsColumns } from './ResultLabelsColumns';
import Typography from '@mui/material/Typography';
import { useTheme } from '@mui/styles';
import AddIcon from '@mui/icons-material/Add';
import SaveIcon from '@mui/icons-material/SaveOutlined';
import { LoadingButton } from '@mui/lab';
import {
  loadResultCalculations,
  resultCalculationsModule,
} from '../ResultCalculations/ResultCalculationsDucks';
import ConfigTable from '../ConfigTable';

export default function ResultLabels() {
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const loading = useSelector((state) => state[resultLabelsModule].loading);
  const tableData = useSelector((state) => state[resultLabelsModule].tableData);
  const saveDisabled = useSelector(
    (state) => Object.keys(state[resultLabelsModule].changesData).length === 0
  );
  const loadingAdd = useSelector((state) => state[resultLabelsModule].loadingAdd);
  const loadingSave = useSelector((state) => state[resultLabelsModule].loadingSave);
  const resultCalculations = useSelector((state) => state[resultCalculationsModule].tableData);

  useEffect(() => {
    if (tableData.length === 0) {
      dispatch(loadResultLabels());
    }
  }, []);

  useEffect(() => {
    if (resultCalculations.length === 0) {
      dispatch(loadResultCalculations());
    }
  }, []);

  return (
    <div className="mb4">
      <div className="mb1 mt1 flex align-bottom justify-between">
        <Typography
          variant={'h5'}
          children="Result Labels"
          style={{ color: palette.action.active }}
        />
        <div className="right-align mb1">
          <LoadingButton
            loading={loadingSave}
            disabled={saveDisabled}
            variant="contained"
            startIcon={<SaveIcon />}
            children="Save changes"
            onClick={() => dispatch(saveChanges())}
          />
        </div>
      </div>
      <ConfigTable rows={tableData} columns={resultLabelsColumns()} loading={loading} />
      <div className="right-align mt1">
        <LoadingButton
          loading={loadingAdd}
          variant="outlined"
          startIcon={<AddIcon />}
          children="Add configuration"
          onClick={() => dispatch(addConfiguration())}
        />
      </div>
    </div>
  );
}
