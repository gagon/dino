import React, { useEffect } from 'react';
import { LoadingButton } from '@mui/lab';
import { useDispatch, useSelector } from 'react-redux';
import { resultLabelsModule, deleteConfiguration, onCellChange } from './ResultLabelsDucks';
import { resultCalculationsModule } from '../ResultCalculations/ResultCalculationsDucks';
import Select from '../../../common/Select/Select';

export function resultLabelsColumns() {
  return [
    {
      field: 'group',
      flex: 1,
      headerName: 'Group',
      renderCell: ({ row }) => <InputText field="group" data={row} />,
    },
    {
      field: 'text',
      flex: 1,
      headerName: 'Text',
      renderCell: ({ row }) => <InputText field="text" data={row} />,
    },
    {
      field: 'calc_id',
      flex: 1,
      headerName: 'Calc',
      renderCell: ({ row }) => <DropDown field="calc_id" data={row} />,
    },
    {
      field: 'label_ref',
      flex: 1,
      headerName: 'Label Ref',
      renderCell: ({ row }) => <InputText field="label_ref" data={row} />,
    },
    {
      field: 'order',
      flex: 1,
      headerName: 'Order',
      renderCell: ({ row }) => <InputText field="order" data={row} />,
    },
    {
      field: 'action',
      flex: 1,
      headerName: 'Delete',
      maxWidth: 100,
      align: 'center',
      renderCell: ({ row }) => <DeleteRow data={row} />,
    },
  ];
}

function InputText({ field, data }) {
  const dispatch = useDispatch();
  const savedValue = data[field] === null || data[field] === undefined ? '' : data[field];
  const value = useSelector((state) => {
    if (state[resultLabelsModule].changesData[data.id]) {
      return state[resultLabelsModule].changesData[data.id][field];
    }
  });
  const onChange = (event) => {
    dispatch(onCellChange(data.id, field, event.target.value));
  };

  return (
    <div className="overflow-hidden fullwidth">
      <input
        name={field}
        value={value !== undefined ? value : savedValue}
        onChange={onChange}
        style={{
          border: 'none',
          outline: 'none',
          background: value !== undefined ? 'rgb(255 229 203)' : 'transparent',
          height: 28,
          width: '100%',
          paddingLeft: 8,
        }}
      />
    </div>
  );
}

function DropDown({ field, data }) {
  const dispatch = useDispatch();
  const savedValue = data[field] === null || data[field] === undefined ? '' : data[field];
  const resultCalculations = useSelector((state) => state[resultCalculationsModule].tableData);
  const value = useSelector((state) => {
    if (state[resultLabelsModule].changesData[data.id]) {
      return state[resultLabelsModule].changesData[data.id][field];
    }
  });
  const onChange = (event) => dispatch(onCellChange(data.id, field, event.target.value));
  const background = value !== undefined ? 'rgb(255 229 203)' : 'transparent';
  const options = resultCalculations.map((i) => ({ name: i.name, value: i.id }));
  options.unshift({ name: '[NO CALC]', value: '' });

  return (
    <div className="overflow-hidden fullwidth">
      <Select
        selectStyle={{
          height: 28,
          padding: 5,
          borderRadius: 0,
          border: 'none',
          width: '100%',
          background,
        }}
        style={{ background, borderRadius: 0 }}
        value={value !== undefined ? value : savedValue}
        withoutForm
        sx={{ border: 'none' }}
        options={options}
        onChange={onChange}
      />
    </div>
  );
}

function DeleteRow({ data }) {
  const dispatch = useDispatch();
  const loading = useSelector((state) => state[resultLabelsModule].loadingDelete);
  const deleteRow = (id) => {
    dispatch(deleteConfiguration(id));
  };
  return (
    <LoadingButton
      loading={loading === data.id}
      size="small"
      children="Delete"
      onClick={() => deleteRow(data.id)}
    />
  );
}
