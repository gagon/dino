import React from 'react';
import { LoadingButton } from '@mui/lab';
import { useDispatch, useSelector } from 'react-redux';
import {
  resultCalculationsModule,
  deleteConfiguration,
  onCellChange,
} from './ResultCalculationsDucks';

export function resultCalculationsColumns() {
  return [
    {
      field: 'name',
      flex: 1,
      headerName: 'Name',
      renderCell: ({ row }) => <InputText field="name" data={row} />,
    },
    {
      field: 'calc',
      flex: 1,
      headerName: 'Calculation',
      renderCell: ({ row }) => <InputText field="calc" data={row} />,
    },
    {
      field: 'uom',
      flex: 1,
      headerName: 'Base Unit Of Measure',
      renderCell: ({ row }) => <InputText field="uom" data={row} />,
    },
    {
      field: 'type',
      flex: 1,
      headerName: 'Type',
      renderCell: ({ row }) => <InputText field="type" data={row} />,
    },
    {
      field: 'action',
      flex: 1,
      headerName: 'Delete',
      maxWidth: 100,
      align: 'center',
      renderCell: ({ row }) => <DeleteRow data={row} />,
    },
  ];
}

function InputText({ field, data }) {
  const dispatch = useDispatch();
  const value = useSelector((state) => {
    if (state[resultCalculationsModule].changesData[data.id]) {
      return state[resultCalculationsModule].changesData[data.id][field];
    }
  });
  const onChange = (event) => {
    dispatch(onCellChange(data.id, field, event.target.value));
  };

  return (
    <div className="overflow-hidden fullwidth">
      <input
        name={field}
        value={value !== undefined ? value : data[field] || ''}
        onChange={onChange}
        style={{
          border: 'none',
          outline: 'none',
          background: value !== undefined ? 'rgb(255 229 203)' : 'transparent',
          height: 28,
          width: '100%',
          paddingLeft: 8,
        }}
      />
    </div>
  );
}

function DeleteRow({ data }) {
  const dispatch = useDispatch();
  const loading = useSelector((state) => state[resultCalculationsModule].loadingDelete);
  const deleteRow = (id) => {
    dispatch(deleteConfiguration(id));
  };
  return (
    <LoadingButton
      loading={loading === data.id}
      size="small"
      children="Delete"
      onClick={() => deleteRow(data.id)}
    />
  );
}
