import { createReducer } from '@reduxjs/toolkit';
import { handleError } from '../../../common/utils/handleError';
import { ResultCalculationsApi } from '../../../_helpers/service';

/**
 * Constants
 */
export const resultCalculationsModule = 'resultCalculations';
const LOADING = `${resultCalculationsModule}/LOADING`;
const SET_TABLE_DATA = `${resultCalculationsModule}/SET_TABLE_DATA`;
const ADD_CONFIGURATION = `${resultCalculationsModule}/ADD_CONFIGURATION`;
const DELETE_CONFIGURATION = `${resultCalculationsModule}/DELETE_CONFIGURATION`;
const LOADING_ADD = `${resultCalculationsModule}/LOADING_ADD`;
const LOADING_DELETE = `${resultCalculationsModule}/LOADING_DELETE`;
const LOADING_SAVE = `${resultCalculationsModule}/LOADING_SAVE`;
const ON_CELL_CHANGE = `${resultCalculationsModule}/ON_CELL_CHANGE`;
const CLEAR_CHANGES_DATA = `${resultCalculationsModule}/CLEAR_CHANGES_DATA`;

/**
 * Reducer
 */
const initialState = {
  loading: true,
  tableData: [],
  loadingAdd: false,
  loadingDelete: false,
  loadingSave: false,
  changesData: {},
};

export default createReducer(initialState, {
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [SET_TABLE_DATA]: (state, { payload }) => {
    state.tableData = payload;
  },
  [LOADING_ADD]: (state, { payload }) => {
    state.loadingAdd = payload;
  },
  [ADD_CONFIGURATION]: (state, { payload }) => {
    state.tableData.push(payload);
  },
  [DELETE_CONFIGURATION]: (state, { payload }) => {
    state.tableData = state.tableData.filter((row) => row.id !== payload);
  },
  [ON_CELL_CHANGE]: (state, { id, field, value }) => {
    if (state.changesData[id]) {
      state.changesData[id][field] = value;
    } else {
      state.changesData[id] = { [field]: value };
    }
  },
  [LOADING_DELETE]: (state, { payload }) => {
    state.loadingDelete = payload;
  },
  [LOADING_SAVE]: (state, { payload }) => {
    state.loadingSave = payload;
  },
  [CLEAR_CHANGES_DATA]: (state) => {
    state.changesData = {};
  },
});

/**
 * Actions
 */
export const loadResultCalculations = () => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    let { data } = await ResultCalculationsApi.getData();
    dispatch({ type: SET_TABLE_DATA, payload: data });
  } catch (e) {
    handleError(e, 'Failed to load result calculations data');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const addConfiguration = () => async (dispatch) => {
  try {
    dispatch({ type: LOADING_ADD, payload: true });
    let { data } = await ResultCalculationsApi.addConfig();
    dispatch({ type: ADD_CONFIGURATION, payload: data });
  } catch (e) {
    handleError(e, 'Failed to add result calculations row configuration');
  } finally {
    dispatch({ type: LOADING_ADD, payload: false });
  }
};

export const deleteConfiguration = (id) => async (dispatch) => {
  try {
    dispatch({ type: LOADING_DELETE, payload: id });
    await ResultCalculationsApi.removeConfig(id);
    dispatch({ type: DELETE_CONFIGURATION, payload: id });
  } catch (e) {
    handleError(e, 'Failed to delete result calculations row configuration');
  } finally {
    dispatch({ type: LOADING_DELETE, payload: false });
  }
};

export const saveChanges = () => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_SAVE, payload: true });
    const changesData = getState()[resultCalculationsModule].changesData;
    await ResultCalculationsApi.saveData({ ResultCalculation: changesData });
    dispatch(loadResultCalculations());
    dispatch({ type: CLEAR_CHANGES_DATA });
  } catch (e) {
    handleError(e, 'Failed to save result calculations changes data');
  } finally {
    dispatch({ type: LOADING_SAVE, payload: false });
  }
};

export const onCellChange = (id, field, value) => ({
  type: ON_CELL_CHANGE,
  id,
  field,
  value,
});
