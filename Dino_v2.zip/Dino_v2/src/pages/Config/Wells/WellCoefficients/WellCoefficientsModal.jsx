import React, { useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Button, Dialog } from '@mui/material';
import { useTheme } from '@mui/styles';

import { WellCoefficientsColumns } from './columns';
import { addLogMessage, saveCoefficientsReply, setCurrentWellId, wellsModule } from '../WellsDucks';
import ConfigTable from '../../ConfigTable';
import WellCoefficientsPanel from './WellCoefficientsPanel';
import WellCoefficientsHeader from './ModalHeader';
import WellCoefficientsLogsModal from './WellCoefficientsLogsModal';
import useSocketMessage from '../../../../common/_hooks/useSocketMessage';

const WellCoefficientsModal = ({ wells, isOpen, onClose }) => {
  const currentGapData = useSelector((state) => state[wellsModule].currentGapData);
  const currentWellId = useSelector((state) => state[wellsModule].currentWellId);
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const columns = WellCoefficientsColumns();
  const isRowSelected = (id) => id === currentWellId;

  const handleRowClick = useCallback(
    (row) => dispatch(setCurrentWellId(row.id)),
    [dispatch, setCurrentWellId]
  );

  const handleNewLogMessage = useCallback(
    (msg) => dispatch(addLogMessage(msg.data)),
    [dispatch, addLogMessage]
  );

  useSocketMessage('show_loading_message_well_psg', handleNewLogMessage);

  return (
    <>
      <WellCoefficientsLogsModal />

      <Dialog
        sx={{ background: '#5051F935', zIndex: 2 }}
        PaperProps={{
          sx: {
            padding: '25px 28px',
            borderTopRightRadius: 20,
            borderTopLeftRadius: 20,
            borderBottomLeftRadius: 20,
            borderBottomRightRadius: 20,
            maxWidth: 1536,
            maxHeight: 'calc(100% - 64px)',
            width: 'calc(100% - 64px)',
          },
        }}
        onClose={onClose}
        open={isOpen}
      >
        <div
          style={{
            width: '100%',
            height: 722,
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <div className="mb2">
            <span
              children={`Well PC Data: ${currentGapData.name}`}
              style={{ color: palette.action.active, fontSize: '20px' }}
            />
            <WellCoefficientsHeader wells={wells} />
          </div>

          <div style={{ overflow: 'auto' }}>
            <div
              style={{
                float: 'left',
                width: '74.5%',
                minHeight: '200px',
                height: '100%',
                overflow: 'auto',
              }}
            >
              <ConfigTable
                rows={wells}
                columns={columns}
                isSelected={isRowSelected}
                maxHeight={588}
                onRowClick={handleRowClick}
                withoutTitle
              />
            </div>
            <div
              style={{
                float: 'right',
                width: '25%',
                minHeight: '200px',
                height: '100%',
              }}
            >
              <WellCoefficientsPanel wells={wells} />
            </div>
          </div>

          <div
            style={{ display: 'flex', justifyContent: 'flex-end', width: '100%', marginTop: 16 }}
          >
            <Button
              children="close"
              style={{ background: palette.action.selected, width: 100 }}
              onClick={onClose}
            />
          </div>
        </div>
      </Dialog>
    </>
  );
};

export default WellCoefficientsModal;
