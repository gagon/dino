import React, { useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Typography, TextField } from '@mui/material';

import { wellsModule, onCellChange } from '../WellsDucks';
import ConfigTable from '../../ConfigTable';
import { StyledInput } from '../Components/StyledInput';

const coeffKeys = ['oC', 'o1', 'o2', 'o3', 'bC', 'b1', 'b2', 'b3'];

const coefficientsColumns = () => [
  {
    width: '10px',
    field: '#',
    headerName: '#',
    renderCell: ({ row }) => <div style={{ paddingLeft: 8 }}>{row.id}</div>,
  },
  {
    flex: 1,
    field: 'thps',
    headerName: 'thps',
    renderCell: ({ row }) => <InputText data={row} field={'thps'} />,
  },
  {
    flex: 1,
    field: 'qoil',
    headerName: 'qoil',
    renderCell: ({ row }) => <InputText data={row} field={'qoil'} />,
  },
  {
    flex: 1,
    field: 'fbhps',
    headerName: 'fbhps',
    renderCell: ({ row }) => <InputText data={row} field={'fbhps'} />,
  },
];

const InputText = ({ data, field }) => {
  const key = data[field].key;
  const currentValue = data[field].value;
  const currentWellId = useSelector((state) => state[wellsModule].currentWellId);
  const value = useSelector((state) => {
    if (state[wellsModule].changesData[currentWellId]) {
      return state[wellsModule].changesData[currentWellId][key];
    }
  });

  const dispatch = useDispatch();
  const onChange = (event) => dispatch(onCellChange(currentWellId, key, event.target.value));

  return (
    <StyledInput
      value={value !== undefined ? value : currentValue}
      currentValue={currentValue}
      onChange={onChange}
    />
  );
};

const PanelWrapper = ({ children }) => (
  <Box
    sx={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      backgroundColor: 'rgba(80, 81, 249, 0.1)',
      borderRadius: '8px',
      fontSize: '12px',
    }}
  >
    {children}
  </Box>
);

const WellCoefficientsPanel = ({ wells }) => {
  const currentWellId = useSelector((state) => state[wellsModule].currentWellId);
  const currentWell = useSelector((state) => state[wellsModule].wells[currentWellId]);
  const changesData = useSelector((state) => state[wellsModule].changesData);
  const dispatch = useDispatch();
  const columns = coefficientsColumns();
  const isGapValues =
    changesData?.[currentWellId]?.use_coeff !== undefined
      ? changesData?.[currentWellId]?.use_coeff
      : currentWell?.use_coeff;

  const rows = useMemo(() => {
    if (currentWell) {
      return [
        {
          id: 1,
          thps: { value: currentWell.o1, key: 'o1' },
          qoil: { value: currentWell.o3, key: 'o3' },
          fbhps: { value: currentWell.o2, key: 'o2' },
        },
        {
          id: 2,
          thps: { value: currentWell.b1, key: 'b1' },
          qoil: { value: currentWell.b3, key: 'b3' },
          fbhps: { value: currentWell.b2, key: 'b2' },
        },
      ];
    }
    return [];
  }, [currentWell]);

  if (!currentWellId) return <PanelWrapper />;

  return (
    <PanelWrapper>
      {isGapValues ? (
        <ConfigTable rows={rows} columns={columns} />
      ) : (
        <Box sx={{ padding: '10px 15px' }}>
          {coeffKeys.map((coeff) => {
            const value = changesData?.[currentWellId]?.[coeff];
            return (
              <Box
                key={coeff}
                sx={{
                  display: 'flex',
                  gap: 1,
                  alignItems: 'center',
                  paddingY: '4px',
                  borderBottom: '1px solid #EEF0F9',
                }}
              >
                <Typography sx={{ fontWeight: 'bold' }}>{coeff}</Typography>
                <StyledInput
                  value={value !== undefined ? value : currentWell?.[coeff]}
                  currentValue={currentWell?.[coeff]}
                  onChange={(e) => dispatch(onCellChange(currentWell.id, coeff, e.target.value))}
                  padding={'4px 8px'}
                />
              </Box>
            );
          })}
        </Box>
      )}
    </PanelWrapper>
  );
};

export default WellCoefficientsPanel;
