import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Button } from '@mui/material';

import WellCoefficientsModal from './WellCoefficientsModal';
import { wellsModule } from '../WellsDucks';

const WellCoefficients = () => {
  const [isOpen, setIsOpen] = useState(false);
  const wells = useSelector((state) => state[wellsModule].wells);
  const wellsArray = Object.values(wells);

  return (
    <>
      <WellCoefficientsModal wells={wellsArray} isOpen={isOpen} onClose={() => setIsOpen(false)} />

      <Button variant="contained" onClick={() => setIsOpen(true)} disabled={wellsArray.length < 1}>
        Load Well Coefficients
      </Button>
    </>
  );
};

export default WellCoefficients;
