import React, { useCallback, useState, useMemo } from 'react';
import { useSelector } from 'react-redux';
import { Popover, Box, ToggleButtonGroup, ToggleButton, Divider } from '@mui/material';
import Highcharts from 'highcharts/highstock';

import { initialOptions, sections } from './constants';
import { generateDataFromEqn, generateDataFromLinear, solveCubic } from './utils';
import { wellsModule } from '../WellsDucks';

const ReactHighcharts = require('react-highcharts');

const WellCoefficientsCharts = ({
  well,
  wellName,
  currentTargetPressure,
  anchorEl,
  isOpen,
  onClose,
}) => {
  const [tab, setTab] = useState(sections.oil);
  const changesData = useSelector((state) => state[wellsModule].changesData);
  const wellId = well.well_id;

  const handleChangeTab = useCallback((e) => {
    e.stopPropagation();
    setTab(e.target.value);
  }, []);

  const getChartsDataFromWell = useCallback(() => {
    const newWell = changesData[wellId];
    const gor = well.gor;
    const wct = well.wct;
    const oldMap = well.map;
    let newGor;
    let newWct;
    let newMap;
    let oldOilData;
    let oldFBHPSData;
    let newOilData;
    let newFBHPSData;

    let xEnd = null;
    let xStart = 50;

    const roots = solveCubic(well.o3, well.o2, well.o1, well.oC);

    roots.forEach((val) => {
      if (xEnd === null || (val < xEnd && val > 0)) xEnd = val;
    });

    if (!xEnd) xEnd = 500;
    if (xEnd < 50) {
      xStart = 20;
    }

    if (well.use_coeff || newWell?.use_coeff) {
      oldOilData = generateDataFromLinear(well.o1, well.b1, well.o3, well.b3);
      oldFBHPSData = generateDataFromLinear(well.o1, well.b1, well.o2, well.b2);
    } else {
      oldOilData = generateDataFromEqn(well.o3, well.o2, well.o1, well.oC, xStart, xEnd);
      oldFBHPSData = generateDataFromEqn(well.b3, well.b2, well.b1, well.bC, xStart, xEnd);
    }

    if (newWell) {
      if (newWell.map !== undefined) {
        newMap = parseFloat(newWell.map);
      }
      if (newWell.wct !== undefined) {
        newWct = parseFloat(newWell.wct);
      }
      if (newWell.gor !== undefined) {
        newGor = parseFloat(newWell.gor);
      }

      const roots = solveCubic(
        parseFloat(newWell.o3),
        parseFloat(newWell.o2),
        parseFloat(newWell.o1),
        parseFloat(newWell.oC)
      );

      xStart = 50;
      xEnd = null;

      roots.forEach((val) => {
        if (xEnd === null || (val < xEnd && val > 0)) xEnd = val;
      });

      if (!xEnd) xEnd = 500;
      if (xEnd < 50) {
        xStart = 20;
      }

      if (newWell.use_coeff) {
        newOilData = generateDataFromLinear(
          parseFloat(newWell.o1),
          parseFloat(newWell.b1),
          parseFloat(newWell.o3),
          parseFloat(newWell.b3)
        );
        newFBHPSData = generateDataFromLinear(
          parseFloat(newWell.o1),
          parseFloat(newWell.b1),
          parseFloat(newWell.o2),
          parseFloat(newWell.b2)
        );
      } else {
        newOilData = generateDataFromEqn(
          parseFloat(newWell.o3),
          parseFloat(newWell.o2),
          parseFloat(newWell.o1),
          parseFloat(newWell.oC),
          xStart,
          xEnd
        );
        newFBHPSData = generateDataFromEqn(
          parseFloat(newWell.b3),
          parseFloat(newWell.b2),
          parseFloat(newWell.b1),
          parseFloat(newWell.bC),
          xStart,
          xEnd
        );
      }
    }

    return {
      oldOilData,
      newOilData,
      oldFBHPSData,
      newFBHPSData,
      oldMap,
      newMap,
      wct,
      newWct,
      gor,
      newGor,
    };
  }, [well, changesData]);

  const chartsData = useMemo(() => {
    const {
      oldOilData,
      newOilData,
      oldFBHPSData,
      newFBHPSData,
      oldMap,
      newMap,
      wct,
      newWct,
      gor,
      newGor,
    } = getChartsDataFromWell();

    switch (tab) {
      case sections.oil:
        return {
          title: 'Oil vs THP',
          oldData: oldOilData,
          newData: newOilData,
          oldMap,
          newMap,
        };

      case sections.fbhps:
        return {
          title: 'FBHP vs THP',
          oldData: oldFBHPSData,
          newData: newFBHPSData,
          oldMap,
          newMap,
        };

      case sections.gas:
        const oldGasData = [];
        const newGasData = [];

        oldOilData.forEach((val, idx) => {
          oldGasData.push([Math.floor((gor * oldOilData[idx][0]) / 1000), oldOilData[idx][1]]);

          if (newOilData?.length) {
            newGasData.push([Math.floor((newGor * newOilData[idx][0]) / 1000), newOilData[idx][1]]);
          }
        });

        return {
          title: 'Gas vs THP',
          oldData: oldGasData,
          newData: newGasData,
          oldMap,
          newMap,
        };

      case sections.liquid:
        let oldLiquidData = [];
        let newLiquidData = [];
        oldOilData.forEach((val, idx) => {
          oldLiquidData.push([oldOilData[idx][0] / (1.0 - wct), oldOilData[idx][1]]);

          if (newOilData?.length) {
            newLiquidData.push([newOilData[idx][0] / (1.0 - newWct), newOilData[idx][1]]);
          }
        });

        return {
          title: 'Liquid vs THP',
          oldData: oldLiquidData,
          newData: newLiquidData,
          oldMap,
          newMap,
        };

      case sections.temp:
        let oldTempData = [];
        let newTempData = [];

        oldOilData.forEach((val, idx) => {
          oldTempData.push([
            Math.floor((oldOilData[idx][0] / (1.0 - wct)) * 0.01842105263 + 13.15789473684),
            oldOilData[idx][1],
          ]);

          if (newOilData?.length) {
            newTempData.push([
              Math.floor((newOilData[idx][0] / (1.0 - newWct)) * 0.01842105263 + 13.15789473684),
              newOilData[idx][1],
            ]);
          }
        });

        return {
          title: 'THP vs Temperature',
          oldData: oldTempData,
          newData: newTempData,
          oldMap,
          newMap,
        };

      default:
        return { title: '', oldData: [], newData: [], oldMap, newMap };
    }
  }, [tab, getChartsDataFromWell]);

  const chartsConfig = useMemo(() => {
    const oldData = chartsData.oldData;
    let lastPoint;

    if (currentTargetPressure) {
      const lastIndex = oldData.findIndex((point) => point[1] >= currentTargetPressure);
      lastPoint = oldData[lastIndex];
      if (lastPoint) {
        oldData.splice(lastIndex + 1, 0, [lastPoint[0], currentTargetPressure]);
      }
    }

    return {
      ...initialOptions,
      title: { text: chartsData.title },
      series: [
        {
          color: '#0000FFCC',
          data: oldData,
          type: 'line',
          name: 'Old',
          states: { hover: { enabled: true } },
          marker: {
            enabled: false,
          },
        },
        {
          color: '#FF0000CC',
          data: chartsData.newData,
          type: 'line',
          name: 'New',
          states: { hover: { enabled: true } },
          marker: {
            enabled: false,
          },
        },
        {
          color: '#3457D5',
          data: [
            { x: lastPoint ? lastPoint[0] : null, y: lastPoint ? currentTargetPressure : null },
          ],
          type: 'scatter',
          marker: {
            symbol: 'circle',
            radius: 6,
            lineWidth: 1,
          },
          name: 'Target Pressure',
        },
      ],
      yAxis: {
        title: {
          text: null,
        },
        plotLines: [
          {
            color: 'orange',
            width: 1,
            value: chartsData.oldMap,
          },
          {
            color: 'brown',
            width: 1,
            value: chartsData.newMap,
          },
        ],
      },
      tooltip: {
        formatter: function () {
          if (this.series.name === 'Target Pressure') {
            return `<span style="color:#3457D5">●</span> ${this.series.name}: <b>${this.y}</b><br/>`;
          } else {
            return `${this.x}<br/><span style="color:blue">●</span> ${this.series.name}: <b>${this.y}</b><br/>`;
          }
        },
      },
    };
  }, [chartsData, currentTargetPressure]);

  return (
    <Popover
      open={isOpen}
      anchorEl={anchorEl}
      onClose={onClose}
      anchorOrigin={{
        vertical: 'center',
        horizontal: 'right',
      }}
      transformOrigin={{
        vertical: 'center',
        horizontal: 'left',
      }}
    >
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          width: 580,
          height: 490,
        }}
      >
        <span
          style={{
            padding: '15px 25px',
            backgroundColor: '#efefef',
            fontSize: 18,
          }}
        >
          Well {wellName}
        </span>

        <Divider />

        <Box
          sx={{
            padding: '20px 15px',
            display: 'flex',
            flexDirection: 'column',
            gap: '20px',
          }}
        >
          <ToggleButtonGroup
            color="primary"
            variant="contained"
            aria-label="outlined primary button group"
            size="small"
            sx={{ width: '80%', alignSelf: 'center' }}
            value={tab}
            exclusive
            onChange={handleChangeTab}
          >
            {Object.values(sections).map((section) => (
              <ToggleButton
                key={section}
                sx={{ width: '100%', textTransform: 'none' }}
                value={section}
              >
                {section}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>

          <ReactHighcharts highcharts={Highcharts} config={chartsConfig} />
        </Box>
      </Box>
    </Popover>
  );
};

export default WellCoefficientsCharts;
