import React, { useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Checkbox, Tooltip, IconButton } from '@mui/material';
import ArrowCircleLeftOutlinedIcon from '@mui/icons-material/ArrowCircleLeftOutlined';

import { StyledInput } from '../Components/StyledInput';
import { onCellChange, wellsModule } from '../WellsDucks';
import WellCoefficientsCharts from './WellCoefficientsCharts';

export const WellCoefficientsColumns = () => [
  {
    minWidth: 60,
    field: 'well',
    headerName: 'Well',
    renderCell: ({ row }) => <Well row={row} />,
  },
  {
    minWidth: 100,
    field: 'sbhp',
    headerName: 'SBHP',
    renderCell: ({ row }) => <CoefficientCell row={row} field="sbhp" />,
  },
  {
    minWidth: 100,
    field: 'gor',
    headerName: 'GOR',
    renderCell: ({ row }) => <CoefficientCell row={row} field="gor" />,
  },
  {
    minWidth: 100,
    field: 'wct',
    headerName: 'WCT',
    renderCell: ({ row }) => <CoefficientCell row={row} field="wct" />,
  },
  {
    minWidth: 100,
    field: 'map',
    headerName: 'MAP',
    renderCell: ({ row }) => <CoefficientCell row={row} field="map" />,
  },
  {
    minWidth: 100,
    field: 'wgr',
    headerName: 'WGR',
    renderCell: ({ row }) => <CoefficientCell row={row} field="wgr" />,
  },
  {
    minWidth: 100,
    field: 'oilSG',
    headerName: 'Oil SG',
    renderCell: ({ row }) => <CoefficientCell row={row} field="oil_sg" />,
  },
  {
    minWidth: 60,
    field: 'use_coeff',
    headerName: 'GAP Values?',
    renderCell: ({ row }) => <GapValuesCheckbox row={row} />,
  },
];

const Well = ({ row }) => {
  const id = row.id;
  const gapName = row.well.gap_name;
  const checked = useSelector((state) => {
    if (state[wellsModule].changesData?.[id]) {
      return state[wellsModule].changesData?.[id]?.selected;
    }
  });
  const [anchorEl, setAnchorEl] = useState(null);
  const isOpen = Boolean(anchorEl);

  const handleOpen = useCallback((e) => {
    e.stopPropagation();
    setAnchorEl(e.currentTarget);
  }, []);
  const handleClose = useCallback((e) => {
    e.stopPropagation();
    setAnchorEl(null);
  }, []);

  const dispatch = useDispatch();
  const handleChange = useCallback(
    (e) => {
      e.stopPropagation();
      dispatch(onCellChange(id, 'selected', e.target.checked));
    },
    [id]
  );

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        paddingLeft: 8,
        fontSize: '14px',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <span>{gapName}</span>
        <Checkbox
          sx={{ padding: '0px 5px' }}
          checked={checked !== undefined ? checked : false}
          onClick={handleChange}
        />
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <span>{gapName}</span>
        <IconButton onClick={handleOpen} children={<ArrowCircleLeftOutlinedIcon />} />

        {isOpen && (
          <WellCoefficientsCharts
            well={row}
            wellName={row?.well?.gap_name}
            anchorEl={anchorEl}
            onClose={handleClose}
            isOpen={isOpen}
          />
        )}
      </div>
    </div>
  );
};

const CoefficientCell = ({ row, field }) => {
  const id = row.id;
  const currentValue = row?.[field] || 0;
  const value = useSelector((state) => {
    if (state[wellsModule].changesData?.[id]) {
      return state[wellsModule].changesData?.[id]?.[field];
    }
  });
  const error = useSelector((state) => {
    if (state[wellsModule].changesData?.[id]) {
      return state[wellsModule].changesData?.[id]?.columnsError?.[field];
    }
  });
  const currentValueColor = row?.saved ? 'green' : row?.saved !== undefined ? 'red' : '';

  const dispatch = useDispatch();
  const handleChange = useCallback(
    (e) => dispatch(onCellChange(id, field, e.target.value)),
    [id, field]
  );

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        paddingLeft: 4,
        fontSize: '14px',
        justifyContent: 'space-between',
        height: '100%',
      }}
    >
      <span
        style={{
          paddingLeft: 8,
          paddingTop: 1,
          height: 20,
          lineHeight: '20px',
          color: currentValueColor,
        }}
      >
        {currentValue.toFixed(2)}
      </span>
      <Tooltip title={error || ''} enterDelay={1000}>
        <div style={{ marginTop: 5 }}>
          <StyledInput
            value={value !== undefined ? value : currentValue}
            errorMessage={error || ''}
            currentValue={currentValue}
            onChange={handleChange}
          />
        </div>
      </Tooltip>
    </div>
  );
};

const GapValuesCheckbox = ({ row }) => {
  const id = row.id;
  const currentValue = row.use_coeff;
  const value = useSelector((state) => {
    if (state[wellsModule].changesData?.[id]) {
      return state[wellsModule].changesData?.[id]?.['use_coeff'];
    }
  });

  const dispatch = useDispatch();
  const handleChange = useCallback(
    (e) => {
      e.stopPropagation();
      dispatch(onCellChange(id, 'use_coeff', e.target.checked));
    },
    [id]
  );

  return (
    <div
      style={{
        display: 'flex',
        height: '54px',
        flexDirection: 'column',
        justifyContent: 'flex-end',
      }}
    >
      <Checkbox
        sx={{
          alignSelf: 'flex-start',
          justifySelf: 'flex-end',
          paddingY: '4px',
        }}
        checked={value !== undefined ? value : currentValue}
        onClick={handleChange}
      />
    </div>
  );
};
