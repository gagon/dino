export const sections = {
  oil: 'Oil',
  fbhps: 'FBHPS',
  gas: 'Gas',
  liquid: 'Liquid',
  temp: 'Temp',
};

export const initialOptions = {
  chart: {
    height: 300,
  },
  legend: { enabled: false },
  xAxis: {
    title: {
      text: null,
    },
  },
};
