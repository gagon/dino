import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ButtonGroup, Button, TextField, Select, MenuItem } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import moment from 'moment';

import DateTimePicker, { DATE_FORMAT } from '../../../../common/_MuiHookForm/DesktopDatePicker';
import { loadCoefficients, saveCoefficients, uploadPcReport, wellsModule } from '../WellsDucks';

const WellCoefficientsHeader = () => {
  const [loadDate, setLoadDate] = useState(moment().format(DATE_FORMAT));
  const [uploadParams, setUploadParams] = useState({
    file: null,
  });
  const loadingAll = useSelector((state) => state[wellsModule].loadingAllCoefs);
  const loadingSelected = useSelector((state) => state[wellsModule].loadingSelectedCoefs);
  const loadingSaveCoefs = useSelector((state) => state[wellsModule].loadingSaveCoefs);
  const sheetOptions = useSelector((state) => state[wellsModule].sheetOptions);
  const changesData = useSelector((state) => state[wellsModule].changesData);
  const dispatch = useDispatch();

  const selectedFileNameLength = uploadParams.file?.name.length || 0;
  const selectedFileName = uploadParams.file?.name
    ? `${uploadParams.file?.name.substring(0, 12)}... ${uploadParams.file?.name.substring(
        selectedFileNameLength - 18,
        selectedFileNameLength
      )}`
    : 'No file chosen';

  const onSelectFile = (e) => {
    if (!e.target.files || e.target.files.length === 0) {
      setUploadParams((prev) => ({ ...prev, file: null }));
      return;
    }
    setUploadParams((prev) => ({ ...prev, file: e.target.files[0] }));
  };

  useEffect(() => {
    if (!uploadParams.file) return;

    const uploadData = new FormData();
    uploadData.append('file', uploadParams.file);
    dispatch(uploadPcReport(uploadData));
  }, [uploadParams]);

  const handleLoadAll = () => dispatch(loadCoefficients(loadDate, true));
  const handleLoadSelected = () => dispatch(loadCoefficients(loadDate));
  const handleUpdateCoefficients = () => dispatch(saveCoefficients());

  const notSelected = Object.values(changesData).filter((w) => w.selected).length < 1;
  const saveIsDisabled = notSelected || loadingAll || loadingSelected;

  return (
    <div
      style={{
        width: '100%',
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 10,
      }}
    >
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <DateTimePicker
          onChange={setLoadDate}
          value={loadDate}
          sx={{ margin: 0, width: 294, fontWeight: 500 }}
        />

        <ButtonGroup
          variant="contained"
          aria-label="outlined primary button group"
          sx={{ width: 200, boxShadow: notSelected ? 'none' : '' }}
          size="small"
        >
          <LoadingButton
            loading={loadingAll}
            variant="contained"
            sx={{ textTransform: 'none', width: '80%' }}
            onClick={handleLoadAll}
          >
            Load All
          </LoadingButton>
          <LoadingButton
            loading={loadingSelected}
            variant="contained"
            sx={{
              textTransform: 'none',
              width: '100%',
            }}
            disabled={notSelected}
            onClick={handleLoadSelected}
          >
            Load Checked
          </LoadingButton>
        </ButtonGroup>
      </div>

      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <div>
          <TextField
            disabled
            value={selectedFileName}
            title={uploadParams.file?.name || ''}
            sx={{
              width: 314,
              margin: 0,
            }}
            InputProps={{
              startAdornment: (
                <Button
                  disabled
                  variant="contained"
                  component="label"
                  color="primary"
                  sx={{
                    width: 156,
                    fontSize: '12px',
                    padding: 0,
                    textTransform: 'none',
                    marginRight: '5px',
                    borderRadius: '6px',
                    mr: 1,
                  }}
                >
                  Choose File
                  <input type="file" hidden onChange={onSelectFile} />
                </Button>
              ),
              sx: { padding: '4px' },
            }}
          />
          <Select
            sx={{
              padding: '4px 8px',
              fontSize: '14px',
              marginLeft: '4px',
              width: 100,
            }}
            value={''}
            disabled={sheetOptions.length < 1}
          >
            {sheetOptions.length > 0 &&
              sheetOptions.map((option) => (
                <MenuItem
                  key={option}
                  value={option}
                  sx={{ height: 20, px: 1, py: 1.5, fontSize: 14 }}
                >
                  {option}
                </MenuItem>
              ))}
          </Select>
        </div>
      </div>

      <LoadingButton
        variant="contained"
        loading={loadingSaveCoefs}
        size="small"
        sx={{ textTransform: 'none', width: 200 }}
        onClick={handleUpdateCoefficients}
        disabled={saveIsDisabled}
      >
        Update Saved Coefficients
      </LoadingButton>
    </div>
  );
};

export default WellCoefficientsHeader;
