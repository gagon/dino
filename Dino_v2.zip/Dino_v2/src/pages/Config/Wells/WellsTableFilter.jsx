import React, { useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { debounce } from 'lodash';
import { FormControlLabel, Checkbox, TextField, Box, Typography, Divider } from '@mui/material';
import styled from '@emotion/styled';

import { findWellByMaskPipe, setSearchStr, toggleFilterNoErrors, wellsModule } from './WellsDucks';

const StyledWrapper = styled.div`
  width: 100%;
  height: fit-content;
  border: 1px solid;
  border-color: #ddd;
  border-radius: 8px;
  margin: 8px 0 16px 0;
  overflow: hidden;

  .title {
    background-color: #efefef;
    padding: 15px 20px;
  }

  .children {
    display: flex;
    gap: 65px;
    padding: 20px 20px;
    background-color: #fff;
  }
`;

const labelStyle = { fontWeight: 'bold', fontSize: '12px' };
const inputContainerStyle = {
  display: 'flex',
  gap: 1,
  alignItems: 'center',
};
const inputStyle = { px: '16px', py: '5.5px' };

const WellsTableFilter = () => {
  const isNoErrors = useSelector((state) => state[wellsModule].filterNoErrors);
  const dispatch = useDispatch();

  const handleFindWell = (e) => {
    dispatch(setSearchStr(e.target.value));
  };
  const handleFindByMaskPipe = (e) => {
    dispatch(findWellByMaskPipe(e.target.value));
  };

  const debouncedFindWell = useMemo(() => {
    return debounce(handleFindWell, 200);
  }, []);
  const debouncedFindByMaskPipe = useMemo(() => {
    return debounce(handleFindByMaskPipe, 200);
  }, []);

  useEffect(() => {
    return () => {
      debouncedFindWell.cancel();
    };
  });
  useEffect(() => {
    return () => {
      debouncedFindByMaskPipe.cancel();
    };
  });

  return (
    <StyledWrapper>
      <div className="title">Search / Filter Wells</div>

      <Divider />

      <div className="children">
        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
          <FormControlLabel
            sx={{ margin: 0, fontWeight: 'bold' }}
            control={
              <Checkbox
                size="small"
                checked={isNoErrors}
                sx={{ paddingLeft: '6px' }}
                onChange={() => dispatch(toggleFilterNoErrors())}
              />
            }
            label={<Typography sx={labelStyle}>Filter No Errors</Typography>}
            labelPlacement="start"
          />
        </Box>

        <Box sx={{ display: 'flex', gap: 4 }}>
          <Box sx={inputContainerStyle}>
            <Typography sx={labelStyle}>Find Well</Typography>
            <TextField
              sx={{ width: 254, margin: 0 }}
              InputProps={{ sx: inputStyle }}
              onChange={debouncedFindWell}
            />
          </Box>

          <Box sx={inputContainerStyle}>
            <Typography sx={labelStyle}>Find Mask Pipe</Typography>
            <TextField
              sx={{ width: 254, margin: 0 }}
              InputProps={{ sx: inputStyle }}
              onChange={debouncedFindByMaskPipe}
            />
          </Box>
        </Box>
      </div>
    </StyledWrapper>
  );
};

export default WellsTableFilter;
