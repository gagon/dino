import React, { useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTheme } from '@mui/styles';
import { Typography } from '@mui/material';

import { wellsColumns } from './WellsColumns';
import {
  loadCurrentGapFileData,
  wellsModule,
  getConfiguredTags,
  loadConnections,
} from './WellsDucks';
import WellsTableFilter from './WellsTableFilter';
import WellsCoefficients from './WellCoefficients/WellCoefficients';
import WellsTable from './WellsTable';

const Wells = () => {
  const wells = useSelector((state) => state[wellsModule].wells);
  const searchStr = useSelector((state) => state[wellsModule].searchStr);
  const findByMaskPipe = useSelector((state) => state[wellsModule].findByMaskPipe);
  const loading = useSelector((state) => state[wellsModule].loading);
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const columns = wellsColumns();
  const wellsArray = Object.values(wells);

  const rows = useMemo(() => {
    if (findByMaskPipe === null) {
      return [];
    }
    if (findByMaskPipe.length > 0 && searchStr === '') {
      return wellsArray.filter((well) => findByMaskPipe.includes(well.id));
    }
    if (findByMaskPipe.length > 0 && searchStr !== '') {
      return wellsArray
        .filter((well) => findByMaskPipe.includes(well.id))
        .filter(
          ({ well }) => well.gap_name.includes(searchStr) || well.pa_name.includes(searchStr)
        );
    }
    if (searchStr !== '') {
      return wellsArray.filter(
        ({ well }) => well.gap_name.includes(searchStr) || well.pa_name.includes(searchStr)
      );
    }

    return wellsArray;
  }, [wellsArray, searchStr, findByMaskPipe]);

  useEffect(() => {
    if (wellsArray.length < 1) {
      dispatch(loadCurrentGapFileData());
    }
  }, [wellsArray.length, dispatch, loadCurrentGapFileData]);

  useEffect(() => {
    if (wellsArray.length) {
      dispatch(getConfiguredTags());
      dispatch(loadConnections());
    }
  }, [wellsArray.length]);

  return (
    <div className="mb4">
      <div className="my1 flex align-bottom justify-between">
        <Typography variant={'h5'} children="Wells" style={{ color: palette.action.active }} />
        <div className="right-align mb1">
          <WellsCoefficients />
        </div>
      </div>

      <WellsTableFilter />

      <WellsTable rows={rows} columns={columns} loading={loading} />
    </div>
  );
};

export default Wells;
