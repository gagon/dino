import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IconButton } from '@mui/material';
import AfIcon from '@mui/icons-material/PendingOutlined';

import ConfigTable from '../../../ConfigTable';
import { StyledInput } from '../../Components/StyledInput';
import { onTagCellChange, wellsModule } from '../../WellsDucks';
import ConfiguredTagsModal from '../../../../../common/ConfiguredTagsModal/ConfiguredTagsModal';

const columns = () => [
  {
    field: 'name',
    headerName: 'Name',
    renderCell: ({ row }) => <div style={{ paddingLeft: 8 }}>{row.name}</div>,
  },
  {
    field: 'sourceTag',
    headerName: 'Source Tag',
    renderCell: ({ row }) => (
      <SourceTagCell wellId={row.wellId} id={row.id} currentValue={row.source_tag} />
    ),
  },
  {
    field: 'gapString',
    headerName: 'GAP String',
    renderCell: ({ row }) => {
      const wellId = row.wellId;
      const id = row.id;
      const value = useSelector((state) => {
        if (state[wellsModule].tagsChangesData?.[wellId]?.[id]) {
          return state[wellsModule].tagsChangesData?.[wellId]?.[id]?.gap_string;
        }
      });
      const currentValue = row.gap_string;
      const dispatch = useDispatch();

      const handleChange = useCallback(
        (e) => {
          dispatch(onTagCellChange(wellId, id, 'gap_string', e.target.value));
        },
        [dispatch, onTagCellChange, wellId, id]
      );

      return (
        <StyledInput
          value={value !== undefined ? value : currentValue || ''}
          currentValue={currentValue || ''}
          onChange={handleChange}
        />
      );
    },
  },
];

const SourceTagCell = ({ wellId, id, currentValue }) => {
  const [isOpen, setIsOpen] = useState(false);
  const value = useSelector((state) => {
    if (state[wellsModule].tagsChangesData?.[wellId]?.[id]) {
      return state[wellsModule].tagsChangesData?.[wellId]?.[id]?.source_tag;
    }
  });
  const dispatch = useDispatch();

  const handleChange = useCallback(
    (e) => {
      dispatch(onTagCellChange(wellId, id, 'source_tag', e.target.value));
    },
    [dispatch, onTagCellChange, wellId, id]
  );

  return (
    <div style={{ display: 'flex', gap: 4 }}>
      <ConfiguredTagsModal
        isOpen={isOpen}
        close={() => setIsOpen(false)}
        onSelect={(value) => dispatch(onTagCellChange(wellId, id, 'source_tag', value))}
      />

      <StyledInput
        value={value !== undefined ? value : currentValue}
        currentValue={currentValue}
        width="95%"
        onChange={handleChange}
      />

      <IconButton sx={{ padding: 0 }} children={<AfIcon />} onClick={() => setIsOpen(true)} />
    </div>
  );
};

const ConfiguredTags = ({ well }) => {
  const configuredTags = useSelector((state) => state[wellsModule].configuredTags);
  const loading = useSelector((state) => state[wellsModule].loadingConfiguredTags);
  const dispatch = useDispatch();

  const rows = useMemo(() => {
    return configuredTags?.[well.id].map((tag) => ({ ...tag, wellId: well.id })) || [];
  }, [configuredTags, well.id]);

  return (
    <div>
      <h3>Configured Tags</h3>

      <div style={{ paddingLeft: 28 }}>
        <ConfigTable rows={rows} columns={columns()} loading={loading} />
      </div>
    </div>
  );
};

export default ConfiguredTags;
