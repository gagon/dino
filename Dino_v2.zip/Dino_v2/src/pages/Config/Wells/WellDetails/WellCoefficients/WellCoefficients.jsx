import React, { useState, useCallback } from 'react';
import { Checkbox, IconButton } from '@mui/material';
import ArrowCircleLeftOutlinedIcon from '@mui/icons-material/ArrowCircleLeftOutlined';

import { StyledDisabledInput } from '../../Components/StyledInput';
import WellCoefficientsCharts from '../../WellCoefficients/WellCoefficientsCharts';

const coefficients = {
  oC: 'oC',
  SBHP: 'sbhp',
  o1: 'o1',
  GOR: 'gor',
  o2: 'o2',
  WCT: 'wct',
  o3: 'o3',
  MAP: 'map',
  bC: 'bC',
  WGR: 'wgr',
  b1: 'b1',
  'Oil SG': 'oil_sg',
  b2: 'b2',
  'Gap Values': 'use_coeff',
  b3: 'b3',
};

const WellCoefficients = ({ well }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const isOpen = Boolean(anchorEl);

  const handleOpen = useCallback((e) => {
    setAnchorEl(e.currentTarget);
  }, []);
  const handleClose = useCallback((e) => {
    setAnchorEl(null);
  }, []);

  return (
    <div>
      <div style={{ display: 'flex' }}>
        <h3>Well Coefficients</h3>
        <IconButton
          onClick={handleOpen}
          children={<ArrowCircleLeftOutlinedIcon sx={{ color: 'black' }} />}
        />
      </div>

      {isOpen && (
        <WellCoefficientsCharts
          well={well}
          anchorEl={anchorEl}
          onClose={handleClose}
          isOpen={isOpen}
        />
      )}

      <ul
        style={{
          display: 'grid',
          gridTemplateColumns: '380px 380px',
          columnGap: 50,
          marginTop: 0,
          marginBottom: 30,
        }}
      >
        <li
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '6px',
          }}
        >
          <label style={{ fontWeight: 'bold' }}>Load Time</label>
          <span style={{ width: '70%' }}>From gap file</span>
        </li>

        {Object.entries(coefficients).map(([key, value]) => (
          <li
            key={key}
            style={{
              display: 'flex',
              justifyContent: key.length > 2 ? 'space-between' : 'space-evenly',
              alignItems: 'center',
              marginBottom: '6px',
            }}
          >
            <label style={{ fontWeight: 'bold' }}>{key}</label>
            {key === 'Gap Values' ? (
              <div style={{ width: '70%', marginRight: '3px' }}>
                <Checkbox
                  size="small"
                  sx={{
                    padding: 0,
                    cursor: 'not-allowed',
                    color: 'rgba(0, 0, 0, 0.23)',
                  }}
                  checked={well[value]}
                />
              </div>
            ) : (
              <StyledDisabledInput value={well[value]} disabled width="70%" />
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default WellCoefficients;
