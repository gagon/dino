import React from 'react';

import ConfiguredTags from './ConfiguredTags/ConfiguredTags';
import WellCoefficients from './WellCoefficients/WellCoefficients';
import WellConnections from './WellConnections/WellConnections';

const WellDetails = ({ well }) => {
  return (
    <section style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <ConfiguredTags well={well} />
      <WellConnections well={well} />
      <WellCoefficients well={well} />
    </section>
  );
};

export default WellDetails;
