import React, { useState, useCallback, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '@mui/material';
import { LoadingButton } from '@mui/lab';

import { columns } from './columns';
import { WellsApi } from '../../../../../_helpers/service';
import { loadCurrentGapFileData, wellsModule } from '../../WellsDucks';
import ConfigTable from '../../../ConfigTable';
import WellConnectionsModal from '../../../../../common/WellConnectionsModal/WellConnectionsModal';

const WellConnections = ({ well }) => {
  const [isOpen, setIsOpen] = useState(false);
  const loading = useSelector((state) => state[wellsModule].loading);
  const dispatch = useDispatch();

  const rows = useMemo(() => {
    if (well) {
      return well?.connections.map((c) => ({ ...c, id: c.conn_map_id }));
    } else {
      return [];
    }
  }, [well]);

  const handleAddWellConnection = useCallback(async () => {
    try {
      const data = { well_id: well.well_id, gap_id: well.gap_id };
      await WellsApi.addWellConnection(data);
      dispatch(loadCurrentGapFileData());
    } catch (e) {
      console.error('Failed to add new connection');
    }
  }, [well]);

  return (
    <div>
      {isOpen && (
        <WellConnectionsModal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          wellId={well.well_id}
          gapId={well.gap_id}
          isEditMode={true}
        />
      )}

      <h3>Connections</h3>

      <div style={{ paddingLeft: 28 }}>
        <LoadingButton
          loading={loading}
          variant="contained"
          sx={{ textTransform: 'none' }}
          children="New Well Connection"
          onClick={handleAddWellConnection}
        />
        <Button
          variant="contained"
          sx={{ textTransform: 'none', ml: 1 }}
          children="Connection Diagram"
          onClick={() => setIsOpen(true)}
        />

        <div style={{ marginTop: '0.8em' }}>
          <ConfigTable rows={rows} columns={columns()} />
        </div>
      </div>
    </div>
  );
};

export default WellConnections;
