import { useCallback, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Radio, Select, MenuItem } from '@mui/material';
import { LoadingButton } from '@mui/lab';

import { StyledInput } from '../../Components/StyledInput';
import { loadCurrentGapFileData, onConnectionsCellChange, wellsModule } from '../../WellsDucks';
import { WellsApi } from '../../../../../_helpers/service';
import ConfirmModal from '../../../ConfirmModal';

export const columns = () => [
  {
    field: 'connection',
    headerName: 'Connection',
    renderCell: ({ row }) => <ConnectionSelect row={row} field="conn_map_id" />,
  },
  {
    field: 'slot',
    headerName: 'Slot',
    renderCell: ({ row }) => <InputText row={row} field="slot" />,
  },
  {
    field: 'openSvrMask',
    headerName: 'Open Svr Mask',
    renderCell: ({ row }) => <InputText row={row} field="opensvr_mask" />,
  },
  {
    field: 'routeJoints',
    headerName: 'Route Joints',
    renderCell: ({ row }) => <InputText row={row} field="branch_joints" />,
  },
  {
    field: 'default',
    headerName: 'Default',
    align: 'center',
    renderCell: ({ row }) => <InputRadio row={row} />,
  },
  {
    field: 'slotPressPipe',
    headerName: 'Slot Press Pipe',
    renderCell: ({ row }) => <InputText row={row} field="fl_pipe_os" />,
  },
  {
    field: 'comingled1',
    headerName: 'Comingled',
    renderCell: ({ row }) => <ComingledSelect row={row} field="comingled1" />,
  },
  {
    field: 'comingled2',
    headerName: 'Comingled',
    renderCell: ({ row }) => <ComingledSelect row={row} field="comingled2" />,
  },
  {
    field: 'delete',
    align: 'center',
    headerName: 'Delete',
    renderCell: ({ row }) => <DeleteButton row={row} />,
  },
];

const InputText = ({ row, field }) => {
  const wellId = row.well_id;
  const id = row.id;
  const value = useSelector((state) => {
    if (state[wellsModule].connectionsChangesData?.[wellId]?.[id]) {
      return state[wellsModule].connectionsChangesData?.[wellId]?.[id]?.[field];
    }
  });
  const currentValue = row[field];
  const dispatch = useDispatch();

  const handleChange = useCallback(
    (e) => {
      dispatch(onConnectionsCellChange(wellId, id, field, e.target.value));
    },
    [dispatch, onConnectionsCellChange, wellId, id, field]
  );

  return (
    <div style={{ paddingLeft: 8 }}>
      <StyledInput
        value={value ? value : currentValue}
        currentValue={currentValue}
        onChange={handleChange}
      />
    </div>
  );
};

const DeleteButton = ({ row }) => {
  const [isOpen, setIsOpen] = useState(false);
  const loading = useSelector((state) => state[wellsModule].loading);
  const dispatch = useDispatch();
  const onClose = () => setIsOpen(false);

  const handleDelete = useCallback(async () => {
    try {
      const data = { conn_map_id: row.conn_map_id, well_id: row.well_id, gap_id: row.gap_id };
      await WellsApi.removeWellConnection(data);
      dispatch(loadCurrentGapFileData());
      onClose();
    } catch (e) {
      console.error('Error while deleting well connection');
    }
  }, [row]);

  return (
    <>
      <ConfirmModal
        isOpen={isOpen}
        text="This will remove the gap connection item for all gap files and cases. Are you sure?"
        onClose={onClose}
        onProceed={handleDelete}
      />
      <LoadingButton
        loading={loading}
        sx={{ padding: 0 }}
        size="small"
        children="Delete"
        onClick={() => setIsOpen(true)}
      />
    </>
  );
};

const InputRadio = ({ row }) => {
  const wellId = row.well_id;
  const id = row.id;
  const value = useSelector((state) => {
    if (state[wellsModule].connectionsChangesData?.[wellId]?.[id]) {
      return Boolean(state[wellsModule].connectionsChangesData?.[wellId]?.[id]?.default);
    }
  });
  const dispatch = useDispatch();

  const handleChange = useCallback(
    (e) => {
      dispatch(onConnectionsCellChange(wellId, id, 'default', e.target.checked));
    },
    [dispatch, onConnectionsCellChange, wellId, id]
  );

  return <Radio size="small" sx={{ padding: 0 }} checked={value} onChange={handleChange} />;
};

const ComingledSelect = ({ row, field }) => {
  const wellId = row.well_id;
  const id = row.id;
  const value = useSelector((state) => {
    if (state[wellsModule].connectionsChangesData?.[wellId]?.[id]) {
      return state[wellsModule].connectionsChangesData?.[wellId]?.[id]?.[field];
    }
  });
  const wells = useSelector((state) => state[wellsModule].wells);
  const comingledOptions = Object.values(wells).map((w) => ({
    value: w.well_id,
    key: w.well.gap_name,
  }));
  const dispatch = useDispatch();

  const handleChange = useCallback(
    (e) => {
      dispatch(onConnectionsCellChange(wellId, id, field, e.target.value));
    },
    [dispatch, onConnectionsCellChange, wellId, id, field]
  );

  return (
    <div style={{ paddingLeft: 8 }}>
      <Select
        sx={{
          padding: '4px 8px',
          width: '100%',
          backgroundColor: value && value !== row[field] ? 'rgb(227,174,115)' : 'transparent',
          fontSize: '14px',
        }}
        value={value ? value : ''}
        onChange={handleChange}
      >
        {comingledOptions.map(({ key, value }) => (
          <MenuItem
            key={key}
            value={value}
            sx={{ height: 20, px: 1, py: 1.5, fontSize: 14 }}
            children={key}
          />
        ))}
      </Select>
    </div>
  );
};

const ConnectionSelect = ({ row, field }) => {
  const wellId = row.well_id;
  const id = row.id;
  const value = useSelector((state) => {
    if (state[wellsModule].connectionsChangesData?.[wellId]?.[id]) {
      return state[wellsModule].connectionsChangesData?.[wellId]?.[id]?.[field];
    }
  });
  const dispatch = useDispatch();

  const connections = useSelector((state) => state[wellsModule].connections);
  const connMapCfg = {};
  connections.forEach((val) => {
    let key = val.unit + ' ' + val.rms;
    if (val.tl) key = key + ' ' + val.tl;
    if (val.mp_lp) key = key + ' ' + val.mp_lp;
    connMapCfg[key] = val.id;
  });

  const handleChange = useCallback(
    (e) => {
      dispatch(onConnectionsCellChange(wellId, id, field, e.target.value));
    },
    [dispatch, onConnectionsCellChange, wellId, id, field]
  );

  return (
    <div style={{ paddingLeft: 8 }}>
      <Select
        sx={{
          padding: '4px 8px',
          width: '100%',
          backgroundColor: value && value !== row[field] ? 'rgb(227,174,115)' : 'transparent',
          fontSize: '14px',
        }}
        value={value ? value : Object.values(connMapCfg).find((item) => item === id) || ''}
        onChange={handleChange}
      >
        {Object.entries(connMapCfg).map(([key, val]) => (
          <MenuItem
            key={val}
            value={val}
            sx={{ height: 20, px: 1, py: 1.5, fontSize: 14 }}
            children={key}
          />
        ))}
      </Select>
    </div>
  );
};
