import styled from 'styled-components';

export const StyledInput = styled.input`
  padding: ${(props) => (props.padding ? props.padding : '4px 8px')};
  border-radius: 8px;
  border-color: ${(props) => (props.errorMessage ? 'red' : 'rgba(0, 0, 0, 0.23)')};
  border-width: 1px;
  border-style: solid;
  font-size: 14px;
  width: ${(props) => (props.width ? props.width : '100%')};
  background-color: ${(props) =>
    props.value !== undefined && props.value !== props.currentValue ? 'rgb(227,174,115)' : 'white'};
  &:hover {
    border-color: black;
  }
  &:focus {
    outline: none;
    border-color: blue;
  }
`;

export const StyledDisabledInput = styled.input`
  padding: ${(props) => (props.padding ? props.padding : '4px 8px')};
  border-radius: 8px;
  border-color: 'rgba(0, 0, 0, 0.23)';
  border-width: 1px;
  border-style: solid;
  font-size: 14px;
  cursor: not-allowed;
  width: ${(props) => (props.width ? props.width : '100%')};
  background-color: 'white';
  &:hover {
    border-color: black;
  }
`;
