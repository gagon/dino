import React, { useCallback, useState } from 'react';
import { useDispatch } from 'react-redux';
import { IconButton, Button } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import CircularProgress from '@mui/material/CircularProgress';
import KeyboardArrowDownOutlinedIcon from '@mui/icons-material/KeyboardArrowDownOutlined';
import KeyboardArrowUpOutlinedIcon from '@mui/icons-material/KeyboardArrowUpOutlined';

import { saveWell } from './WellsDucks';
import WellDetails from './WellDetails/WellDetails';

const SaveButton = ({ wellId }) => {
  const dispatch = useDispatch();

  const handleSave = useCallback(() => {
    dispatch(saveWell(wellId));
  }, [dispatch, saveWell, wellId]);

  return <Button sx={{ padding: 0 }} size="small" children="Save" onClick={handleSave} />;
};

const ExpandableTableRow = ({ wellId, children, expandComponent, ...otherProps }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <>
      <TableRow {...otherProps}>
        {children}

        <TableCell
          align="center"
          sx={{
            width: 140,
            borderBottom: '1px solid #EEF0F9',
            borderRight: '1px solid #EEF0F9',
            maxHeight: 40,
            padding: '4px',
          }}
        >
          <IconButton onClick={() => setIsExpanded(!isExpanded)} sx={{ padding: 0 }}>
            {isExpanded ? <KeyboardArrowUpOutlinedIcon /> : <KeyboardArrowDownOutlinedIcon />}
          </IconButton>
        </TableCell>

        <TableCell
          align="center"
          sx={{
            width: 160,
            borderBottom: '1px solid #EEF0F9',
            borderRight: '1px solid #EEF0F9',
            maxHeight: 40,
            padding: '4px',
          }}
        >
          <SaveButton wellId={wellId} />
        </TableCell>
      </TableRow>

      {isExpanded && <TableRow>{expandComponent}</TableRow>}
    </>
  );
};

const WellsTable = ({ loading, columns, rows }) => {
  return (
    <div style={{ background: 'white', borderRadius: 8, overflow: 'hidden' }}>
      <TableContainer sx={{ maxHeight: '100%' }}>
        <Table stickyHeader>
          <TableHead sx={{ background: '#EEF0F9', height: 56 }}>
            <TableRow>
              {columns.map((column, index) => (
                <TableCell
                  key={column.field}
                  align={column.align || 'left'}
                  children={
                    <div
                      style={{
                        borderRight: '2px solid rgb(214 215 217)',
                        paddingRight: 16,
                      }}
                    >
                      {column.headerName}
                    </div>
                  }
                  sx={{
                    lineHeight: 1,
                    fontWeight: 600,
                    fontSize: 12,
                    padding: '12px 0 12px 16px',
                  }}
                />
              ))}

              <TableCell
                align={'center'}
                children={
                  <div
                    style={{
                      borderRight: '2px solid rgb(214 215 217)',
                      paddingRight: 16,
                    }}
                  >
                    Show Details
                  </div>
                }
                sx={{
                  lineHeight: 1,
                  fontWeight: 600,
                  fontSize: 12,
                  padding: '12px 0 12px 16px',
                }}
              />

              <TableCell
                align={'center'}
                children={
                  <div
                    style={{
                      paddingRight: 16,
                    }}
                  >
                    Save
                  </div>
                }
                sx={{
                  lineHeight: 1,
                  fontWeight: 600,
                  fontSize: 12,
                  padding: '12px 0 12px 16px',
                }}
              />
            </TableRow>
          </TableHead>

          <TableBody>
            {rows.map((row) => (
              <ExpandableTableRow
                hover
                tabIndex={-1}
                key={row.id}
                wellId={row.id}
                expandComponent={
                  <TableCell colSpan="7">
                    <WellDetails well={row} />
                  </TableCell>
                }
              >
                {columns.map((column) => (
                  <TableCell
                    key={column.headerName + row.id}
                    align={column.align || 'left'}
                    title={column.headerName}
                    children={column.renderCell({ row })}
                    sx={{
                      width: column.width,
                      minWidth: column.minWidth,
                      borderBottom: '1px solid #EEF0F9',
                      borderRight: '1px solid #EEF0F9',
                      maxHeight: 40,
                      padding: '4px',
                    }}
                  />
                ))}
              </ExpandableTableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      {rows.length === 0 && !loading && (
        <div className="flex items-center justify-center" style={{ height: 80 }}>
          no rows
        </div>
      )}
      {rows.length === 0 && loading && (
        <div className="flex items-center justify-center" style={{ height: 80 }}>
          <CircularProgress />
        </div>
      )}
    </div>
  );
};

export default WellsTable;
