import React, { useCallback, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Checkbox } from '@mui/material';

import { onWellCellChange, wellsModule } from './WellsDucks';
import { StyledInput } from './Components/StyledInput';

export const wellsColumns = () => [
  {
    minWidth: 150,
    field: 'errors',
    headerName: 'Errors',
    renderCell: ({ row }) => <div style={{ paddingLeft: 8 }}></div>,
  },
  {
    minWidth: 250,
    field: 'paName',
    headerName: 'PA Name',
    renderCell: ({ row }) => <InputText data={row} field={'pa_name'} />,
  },
  {
    minWidth: 250,
    field: 'gapName',
    headerName: 'GAP Name',
    renderCell: ({ row }) => <InputText data={row} field={'gap_name'} />,
  },
  {
    minWidth: 250,
    field: 'regex',
    headerName: 'Gathering Report Regex',
    renderCell: ({ row }) => <InputText data={row} field={'gathering_name'} />,
  },
  {
    width: 130,
    align: 'center',
    field: 'disabled',
    headerName: 'Disabled',
    renderCell: ({ row }) => <InputCheckbox data={row} />,
  },
];

const InputText = ({ data, field }) => {
  const wellId = data.id;
  const dispatch = useDispatch();
  const value = useSelector((state) => {
    if (state[wellsModule].wellChangesData[wellId]) {
      return state[wellsModule].wellChangesData[wellId][field];
    }
  });
  const currentValue = data.well[field];
  const handleChange = useCallback(
    (event) => dispatch(onWellCellChange(wellId, field, event.target.value)),
    [dispatch, onWellCellChange, wellId, field]
  );

  return (
    <div style={{ width: '100%', paddingLeft: '8px' }}>
      <StyledInput
        width="95%"
        value={value !== undefined ? value : currentValue || ''}
        currentValue={currentValue}
        onChange={handleChange}
      />
    </div>
  );
};

const InputCheckbox = ({ data }) => {
  const wellId = data.id;
  const value = useSelector((state) => {
    if (state[wellsModule].wellChangesData[wellId]) {
      return state[wellsModule].wellChangesData[wellId].disabled;
    }
  });
  const dispatch = useDispatch();
  const handleChange = (e) => dispatch(onWellCellChange(data.id, 'disabled', e.target.checked));

  return (
    <Checkbox
      checked={value !== undefined ? value : data.well.disabled}
      sx={{ paddingY: 0, paddingLeft: '8px' }}
      onChange={handleChange}
    />
  );
};
