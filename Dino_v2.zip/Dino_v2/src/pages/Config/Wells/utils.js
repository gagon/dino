export function diffObjects(obj1, obj2) {
  const result = {};

  for (let key in obj2) {
    if (obj1.hasOwnProperty(key)) {
      const value1 = obj1[key];
      const value2 = obj2[key];

      if (value1 === null && value2 === null) {
        continue;
      }

      if (typeof value2 !== 'object' && typeof value1 !== 'object') {
        if (value1 !== value2) {
          result[key] = value2;
        }
      } else if (value1 === null || value2 === null) {
        result[key] = value2;
      } else {
        const diff = diffObjects(value1, value2);
        if (Object.keys(diff).length > 0) {
          result[key] = diff;
        }
      }
    } else {
      result[key] = obj2[key];
    }
  }

  return result;
}
