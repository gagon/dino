import { createReducer } from '@reduxjs/toolkit';
import lodash from 'lodash';
import moment from 'moment';

import { handleError } from '../../../common/utils/handleError';
import Notice from '../../../common/utils/Notice';
import { PIData } from '../../../_helpers/piData';
import { GapFilesApi, WellsApi, PIDataApi, ConnectionsApi } from '../../../_helpers/service';
import DinoSocket from '../../../_helpers/socket';
import { loginModule } from '../../Login/LoginDucks';
import { diffObjects } from './utils';

/**
 * Constants
 */
export const wellsModule = 'wellsModule';
const SET_CURRENT_GAP_DATA = `${wellsModule}/SET_CURRENT_GAP_DATA`;
const SET_WELLS = `${wellsModule}/SET_WELLS`;
const SET_CONFIGURED_TAGS = `${wellsModule}/SET_CONFIGURED_TAGS`;
const LOADING = `${wellsModule}/LOADING`;
const LOADING_CONFIGURED_TAGS = `${wellsModule}/LOADING_CONFIGURED_TAGS`;
const LOADING_ALL_COEFS = `${wellsModule}/LOADING_ALL_COEFS`;
const LOADING_SELECTED_COEFS = `${wellsModule}/LOADING_SELECTED_COEFS`;
const LOADING_SAVE_COEFFICIENTS = `${wellsModule}/LOADING_SAVE_COEFFICIENTS`;
const ON_CELL_CHANGE = `${wellsModule}/ON_CELL_CHANGE`;
const ON_WELL_CELL_CHANGE = `${wellsModule}/ON_WELL_CELL_CHANGE`;
const ON_TAG_CELL_CHANGE = `${wellsModule}/ON_TAG_CELL_CHANGE`;
const ON_CONNECTIONS_CELL_CHANGE = `${wellsModule}/ON_CONNECTIONS_CELL_CHANGE`;
const UPDATE_CHANGES_DATA = `${wellsModule}/UPDATE_CHANGES_DATA`;
const CLEAR_CHANGES_DATA = `${wellsModule}/CLEAR_CHANGES_DATA`;
const CLEAR_TAGS_CHANGES_DATA = `${wellsModule}/CLEAR_TAG_CHANGES_DATA`;
const CLEAR_CONNECTIONS_CHANGES_DATA = `${wellsModule}/CLEAR_CONNECTIONS_CHANGES_DATA`;
const TOGGLE_FILTER_NO_ERRORS = `${wellsModule}/TOGGLE_FILTER_NO_ERRORS`;
const SET_SEARCH_STR = `${wellsModule}/SET_SEARCH_STR`;
const SET_FIND_BY_MASK_PIPE = `${wellsModule}/SET_FIND_BY_MASK_PIPE`;
const SET_SHEET_OPTIONS = `${wellsModule}/SET_SHEET_OPTIONS`;
const SET_CURRENT_WELL_ID = `${wellsModule}/SET_CURRENT_WELL_ID`;
const SET_CONNECTIONS_CHANGES_DATA = `${wellsModule}/SET_CONNECTIONS_CHANGES_DATA`;
const SET_CONNECTIONS = `${wellsModule}/SET_CONNECTIONS`;
const ADD_LOG_MESSAGE = `${wellsModule}/ADD_LOG_MESSAGE`;
const OPEN_LOGS_MODAL = `${wellsModule}/OPEN_LOGS_MODAL`;

/**
 * Reducer
 */
const initialState = {
  connections: [],
  currentGapData: {},
  wells: {},
  configuredTags: {},
  sheetOptions: [],
  changesData: {},
  wellChangesData: {},
  tagsChangesData: {},
  connectionsChangesData: {},
  currentWellId: '',
  loading: true,
  loadingConfiguredTags: false,
  loadingAllCoefs: false,
  loadingSelectedCoefs: false,
  loadingSaveCoefs: false,
  filterNoErrors: false,
  searchStr: '',
  findByMaskPipe: [],
  logMessages: [],
  isLogsOpen: false,
};

export default createReducer(initialState, {
  [SET_CONNECTIONS]: (state, { payload }) => {
    state.connections = payload;
  },
  [SET_CURRENT_GAP_DATA]: (state, { payload }) => {
    state.currentGapData = payload;
  },
  [SET_WELLS]: (state, { payload }) => {
    state.wells = payload;
  },
  [SET_CONFIGURED_TAGS]: (state, { payload }) => {
    state.configuredTags = payload;
  },
  [SET_CURRENT_WELL_ID]: (state, { payload }) => {
    state.currentWellId = payload;
  },
  [SET_SHEET_OPTIONS]: (state, { payload }) => {
    state.sheetOptions = payload;
  },
  [ON_CELL_CHANGE]: (state, { id, field, value }) => {
    if (state.changesData[id]) {
      state.changesData[id][field] = value;
    } else {
      state.changesData[id] = { [field]: value };
    }
  },
  [ON_WELL_CELL_CHANGE]: (state, { id, field, value }) => {
    if (state.wellChangesData[id]) {
      state.wellChangesData[id][field] = value;
    } else {
      state.wellChangesData[id] = { [field]: value };
    }
  },
  [ON_TAG_CELL_CHANGE]: (state, { wellId, id, field, value }) => {
    if (state.tagsChangesData?.[wellId]?.[id]?.[field]) {
      state.tagsChangesData[wellId][id][field] = value;
    } else {
      state.tagsChangesData[wellId] = { ...state.tagsChangesData[wellId] };
      state.tagsChangesData[wellId][id] = { ...state.tagsChangesData[wellId][id], [field]: value };
    }
  },
  [ON_CONNECTIONS_CELL_CHANGE]: (state, { wellId, id, field, value }) => {
    if (field === 'default') {
      state.connectionsChangesData[wellId] = Object.fromEntries(
        Object.entries(state.connectionsChangesData[wellId]).map(([key, conn]) =>
          key == id ? [key, { ...conn, default: true }] : [key, { ...conn, default: false }]
        )
      );
      return;
    }
    state.connectionsChangesData[wellId][id][field] = value;
  },
  [SET_CONNECTIONS_CHANGES_DATA]: (state, { payload }) => {
    state.connectionsChangesData = payload;
  },
  [UPDATE_CHANGES_DATA]: (state, { payload }) => {
    state.changesData = { ...state.changesData, ...payload };
  },
  [CLEAR_CHANGES_DATA]: (state) => {
    state.changesData = {};
  },

  [CLEAR_TAGS_CHANGES_DATA]: (state) => {
    state.tagsChangesData = {};
  },
  [CLEAR_CONNECTIONS_CHANGES_DATA]: (state) => {
    state.connectionsChangesData = {};
  },
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [LOADING_CONFIGURED_TAGS]: (state, { payload }) => {
    state.loadingConfiguredTags = payload;
  },
  [LOADING_ALL_COEFS]: (state, { payload }) => {
    state.loadingAllCoefs = payload;
  },
  [LOADING_SELECTED_COEFS]: (state, { payload }) => {
    state.loadingSelectedCoefs = payload;
  },
  [LOADING_SAVE_COEFFICIENTS]: (state, { payload }) => {
    state.loadingSaveCoefs = payload;
  },
  [TOGGLE_FILTER_NO_ERRORS]: (state) => {
    state.filterNoErrors = !state.filterNoErrors;
  },
  [SET_SEARCH_STR]: (state, { payload }) => {
    state.searchStr = payload;
  },
  [SET_FIND_BY_MASK_PIPE]: (state, { payload }) => {
    state.findByMaskPipe = payload;
  },
  [ADD_LOG_MESSAGE]: (state, { payload }) => {
    state.logMessages.push(payload);
  },
  [OPEN_LOGS_MODAL]: (state, { payload }) => {
    state.isLogsOpen = payload;
  },
});

/**
 * Actions
 */
export const loadConnections = () => async (dispatch) => {
  try {
    const { data } = await ConnectionsApi.getConnections();
    dispatch({ type: SET_CONNECTIONS, payload: data });
  } catch (e) {
    console.error('Error while loading case config settings');
  }
};

export const loadCurrentGapFileData = () => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING, payload: true });
    const { data } = await WellsApi.getCurrentGapFileData();
    dispatch(setCurrentGapData(data));
    const wells = {};
    Object.keys(data.gap_wells).forEach((item) => {
      wells[item] = {
        ...data.gap_wells[item],
        id: item,
        selected: false,
      };
    });
    dispatch(setWells(wells));

    const connectionsChangesData = getState()[wellsModule].connectionsChangesData;
    const connDict = {};
    Object.values(wells).forEach(
      (w) =>
        (connDict[w.id] = w.connections.reduce(
          (a, v) => ({
            ...a,
            [v.conn_map_id]: { ...v, ...connectionsChangesData?.[w.id]?.[v.conn_map_id] },
          }),
          {}
        ))
    );

    dispatch({
      type: SET_CONNECTIONS_CHANGES_DATA,
      payload: connDict,
    });
  } catch (e) {
    handleError(e, 'Failed to load gap wells');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const setCurrentGapData = (data) => ({ type: SET_CURRENT_GAP_DATA, payload: data });
export const setWells = (wells) => ({ type: SET_WELLS, payload: wells });

export const onCellChange = (id, field, value) => ({
  type: ON_CELL_CHANGE,
  id,
  field,
  value,
});

export const onWellCellChange = (id, field, value) => ({
  type: ON_WELL_CELL_CHANGE,
  id,
  field,
  value,
});

export const onTagCellChange = (wellId, id, field, value) => ({
  type: ON_TAG_CELL_CHANGE,
  wellId,
  id,
  field,
  value,
});

export const onConnectionsCellChange = (wellId, id, field, value) => ({
  type: ON_CONNECTIONS_CELL_CHANGE,
  wellId,
  id,
  field,
  value,
});

export const saveWell = (wellId) => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING, payload: true });
    const gapId = getState()[wellsModule].currentGapData.id;
    const wells = getState()[wellsModule].wells;
    const wellChangesData = getState()[wellsModule].wellChangesData;
    const tagsChangesData = getState()[wellsModule].tagsChangesData;
    const connectionsChangesData = getState()[wellsModule].connectionsChangesData;
    const saveObj = { wellId, gapId };
    if (wellChangesData?.[wellId]) {
      const well = {};
      well[wellId] = wellChangesData[wellId];
      saveObj.Well = well;
    }
    if (tagsChangesData?.[wellId]) {
      const wellConfigItem = {};
      Object.entries(tagsChangesData[wellId]).forEach(
        ([key, value]) => (wellConfigItem[`${wellId}-${key}`] = value)
      );
      saveObj.WellConfigItem = wellConfigItem;
    }
    if (connectionsChangesData?.[wellId]) {
      const connDict = {};
      wells[wellId].connections.forEach((conn) => {
        connDict[conn.conn_map_id] = conn;
      });
      const diff = diffObjects(connDict, connectionsChangesData[wellId]);
      saveObj.WellConnection = diff;
    }
    await WellsApi.saveWell(saveObj);
    dispatch(loadCurrentGapFileData());
    Notice.success('Well has been saved');
  } catch (e) {
    Notice.error('Failed to save changes');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const toggleFilterNoErrors = () => ({ type: TOGGLE_FILTER_NO_ERRORS });
export const setSearchStr = (searchStr) => ({ type: SET_SEARCH_STR, payload: searchStr });
export const findWellByMaskPipe = (searchStr) => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING, payload: true });
    const gapId = getState()[wellsModule].currentGapData.id;
    const params = { gapId, search: searchStr };
    const { data } = await WellsApi.getWellIdByMaskPipe(params);
    const filteredWells = Object.keys(data).length ? Object.keys(data) : null;
    dispatch({ type: SET_FIND_BY_MASK_PIPE, payload: filteredWells });
  } catch (e) {
    Notice.error('Failed to filter by mask pipe');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const setCurrentWellId = (id) => ({ type: SET_CURRENT_WELL_ID, payload: id });

export const uploadPcReport = (uploadData) => async (dispatch) => {
  try {
    dispatch({ type: SET_SHEET_OPTIONS, payload: [] });
    const { data } = await WellsApi.uploadPcReport(uploadData);
    data.sheets && dispatch({ type: SET_SHEET_OPTIONS, payload: data.sheets });
  } catch (e) {
    Notice.error('Failed to upload file');
  } finally {
  }
};

export const loadCoefficients = (loadDate, loadAll) => async (dispatch, getState) => {
  try {
    loadAll
      ? dispatch({ type: LOADING_ALL_COEFS, payload: true })
      : dispatch({ type: LOADING_SELECTED_COEFS, payload: true });

    const wells = getState()[wellsModule].wells;
    const oldChangesData = getState()[wellsModule].changesData;
    const appSettings = getState()[loginModule].appConfig;
    const piFetch = new PIData(appSettings['AF:AFServer']);
    const timestamp = moment(loadDate, 'DD-MM-YYYY HH:mm:ss').format('YYYY-MM-DD HH:mm:ssZ');
    let changesData = {};
    const fetchList = loadAll
      ? Object.keys(wells)
      : Object.entries(oldChangesData)
          .filter(([key, value]) => value.selected)
          .map(([key, value]) => key);

    const fetchPCsInBatches = async () => {
      const batchSize = 10;
      let startIndex = 0;
      while (startIndex < fetchList.length) {
        const endIndex = Math.min(startIndex + batchSize, fetchList.length);
        const batch = fetchList.slice(startIndex, endIndex);
        const promises = batch.map((wKey) => {
          const coefficients = [
            'sbhp',
            'gor',
            'wct',
            'map',
            'oil_sg',
            'oC',
            'o1',
            'o2',
            'o3',
            'bC',
            'b1',
            'b2',
            'b3',
          ];
          const newWell = {};
          newWell.pc_load_ts = timestamp;
          newWell.id = wells[wKey].well_id;
          newWell.columnsError = {};
          newWell.selected = true;
          return coefficients.map((key) =>
            fetchPCsFromPI(newWell, key, wells[wKey], piFetch, appSettings, timestamp)
          );
        });

        await Promise.allSettled(promises.flat()).then((data) => {
          data.forEach(({ status, value }) => {
            if (status === 'fulfilled' && value) {
              changesData[value.id] = value;
            }
          });
          dispatch({ type: UPDATE_CHANGES_DATA, payload: changesData });
          changesData = {};
        });
        startIndex = endIndex;
      }
    };

    await fetchPCsInBatches();
  } catch (e) {
    Notice.error('Failed to load coefficients from PI');
  } finally {
    loadAll
      ? dispatch({ type: LOADING_ALL_COEFS, payload: false })
      : dispatch({ type: LOADING_SELECTED_COEFS, payload: false });
  }
};

const fetchPCsFromPI = (newWell, key, well, piObj, settings, timestamp) => {
  const tagPath = settings['PC_Source:GAPFileWell.' + key].replace('***', well.well.pa_name);

  return piObj.getAFData(tagPath, timestamp).then(({ data }) => {
    if (!data.Good) {
      newWell.columnsError[key] = `Error: ${data.Value.Name}`;
    } else {
      if (key === 'wct') {
        newWell[key] = data.Value / 100;
      } else {
        newWell[key] = data.Value;
      }
    }
    return newWell;
  });
};

export const saveCoefficients = () => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_SAVE_COEFFICIENTS, payload: true });
    const socket = DinoSocket.socket;
    const wellsModuleState = getState()[wellsModule];
    const wells = wellsModuleState.wells;
    const changesData = wellsModuleState.changesData;
    const gapId = wellsModuleState.currentGapData.id;
    const changesDataArray = Object.entries(changesData);
    const updateData = { wells: {}, gapId };

    changesDataArray.forEach(([wKey, well]) => {
      if (well.selected) {
        const wellChanges = {};
        Object.entries(changesData[wKey]).forEach(
          ([key, value]) => (wellChanges[key] = parseFloat(value))
        );

        if (well.use_coeff) {
          Object.entries(changesData[wKey]).forEach(
            ([key, value]) => (wellChanges[key] = Number(value))
          );
        }

        updateData.wells[wells[wKey].well.gap_name] = {
          ...lodash.omit(wells[wKey], [
            'id',
            'connections',
            'gap_id',
            'pc_load_ts',
            'well',
            'well_id',
            'timestamp',
            'selected',
            'saved',
          ]),
          ...wellChanges,
        };
      }
    });

    if (Object.keys(updateData.wells).length > 0) {
      dispatch({ type: OPEN_LOGS_MODAL, payload: true });
      const { data } = await WellsApi.saveAllWellPcs(updateData);
      const saveDict = JSON.parse(data);
      dispatch(saveCoefficientsReply(saveDict));
    }
  } catch (e) {
    Notice.error('Failed to update saved coefficients');
  } finally {
    dispatch({ type: LOADING_SAVE_COEFFICIENTS, payload: false });
  }
};

export const saveCoefficientsReply = (res) => async (dispatch) => {
  try {
    const { data } = await WellsApi.getCurrentGapFileData();
    dispatch(setCurrentGapData(data));
    const wells = {};
    Object.keys(data.gap_wells).forEach((item) => {
      wells[item] = {
        ...data.gap_wells[item],
        id: item,
      };
    });

    Object.entries(res).forEach(([gapName, isSaved]) => {
      const wellId = Object.values(wells).find((w) => w.well.gap_name === gapName).id;
      wells[wellId].saved = isSaved;
    });

    dispatch({ type: CLEAR_CHANGES_DATA });
    dispatch(setWells(wells));
    Notice.success('Coefficients have been updated');
  } catch (e) {
    Notice.error('Failed to update saved coefficients');
  }
};

export const getConfiguredTags = () => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_CONFIGURED_TAGS, payload: true });
    const afServer = getState()[loginModule].appConfig['AF:AFServer'];
    const wells = getState()[wellsModule].wells;
    const configuredTags = {};
    const wellColumns = {};

    const { data: wellCols } = await GapFilesApi.getGapFiles();
    wellCols.wellCols.forEach((col) => {
      wellColumns[col.id] = col;
    });

    Object.entries(wells).forEach(([key, well]) => {
      const tags = Object.values(well.well.configs).map((config) => {
        const confItem = wellColumns[config.config_id];
        return {
          id: config.config_id,
          name: confItem.name,
          source_tag: config.source_tag,
          gap_string: config.gap_string,
        };
      });
      configuredTags[key] = tags;
    });
    dispatch({ type: SET_CONFIGURED_TAGS, payload: configuredTags });
  } catch (e) {
    Notice.error('Failed to load configured tags');
  } finally {
    dispatch({ type: LOADING_CONFIGURED_TAGS, payload: false });
  }
};

export const openLogsModal = (isOpen) => ({ type: OPEN_LOGS_MODAL, payload: isOpen });
export const addLogMessage = (msg) => ({ type: ADD_LOG_MESSAGE, payload: msg });
