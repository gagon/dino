import { createReducer } from '@reduxjs/toolkit';
import { handleError } from '../../../common/utils/handleError';
import { FieldConfigApi } from '../../../_helpers/service';
import ParamsModel from '../../../common/FieldSchema/VisualizationBoard/Params/Model';
import React from 'react';
import { engine, model } from './FieldConfig';
import InputField from './FieldItem/InputField';
import Notice from '../../../common/utils/Notice';

/**
 * Constants
 */
export const configFieldsModule = 'configFields';
const LOADING = `${configFieldsModule}/LOADING`;
const LOADING_SAVE = `${configFieldsModule}/LOADING_SAVE`;
const CLEAR_CHANGES_DATA = `${configFieldsModule}/CLEAR_CHANGES_DATA`;
const SET_CASE_CONFIG = `${configFieldsModule}/SET_CASE_CONFIG`;
const DELETE_FIELD = `${configFieldsModule}/DELETE_FIELD`;
const ADD_NEW_FIELD = `${configFieldsModule}/ADD_NEW_FIELD`;
const HIDE_FIELDS = `${configFieldsModule}/HIDE_FIELDS`;
const HIDE_RESULT_FIELDS = `${configFieldsModule}/HIDE_RESULT_FIELDS`;
const ON_CHANGE_FIELD = `${configFieldsModule}/ON_CHANGE_FIELD`;
const ON_CHANGE_RESULT_FIELD = `${configFieldsModule}/ON_CHANGE_RESULT_FIELD`;

/**
 * Reducer
 */
const FieldsModels = {};
const ResultFieldModels = {};
const initialState = {
  loading: true,
  loadingSave: false,
  calcMap: [],
  fields: null,
  resultFields: null,
  hideFields: false,
  hideResultFields: false,
  deletedFieldsIds: [],
  deletedResultIds: [],
};

export default createReducer(initialState, {
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [LOADING_SAVE]: (state, { payload }) => {
    state.loadingSave = payload;
  },
  [SET_CASE_CONFIG]: (state, { payload }) => {
    const { fields, resultFields, calcMap } = payload;
    state.calcMap = calcMap;
    state.fields = fields;
    state.resultFields = resultFields;
  },
  [CLEAR_CHANGES_DATA]: (state) => {
    state.deletedFieldsIds = [];
    state.deletedResultIds = [];
  },
  [DELETE_FIELD]: (state, { id, isResult }) => {
    if (isResult) {
      delete state.resultFields[id];
      state.deletedResultIds.push(id);
    } else {
      delete state.fields[id];
      state.deletedFieldsIds.push(id);
    }
  },
  [ADD_NEW_FIELD]: (state, { fieldData, isResult }) => {
    if (isResult) {
      state.resultFields[fieldData.id] = fieldData;
    } else {
      state.fields[fieldData.id] = fieldData;
    }
  },
  [HIDE_FIELDS]: (state, { payload }) => {
    state.hideFields = payload;
  },
  [HIDE_RESULT_FIELDS]: (state, { payload }) => {
    state.hideResultFields = payload;
  },
  [ON_CHANGE_FIELD]: (state, { field }) => {
    state.fields[field.id] = { ...field, status: 'update' };
  },
  [ON_CHANGE_RESULT_FIELD]: (state, { field }) => {
    state.resultFields[field.id] = { ...field, status: 'update' };
  },
});

/**
 * Actions
 */

export const onHideFields = (checked) => ({ type: HIDE_FIELDS, payload: checked });

export const onHideResultFields = (checked) => ({ type: HIDE_RESULT_FIELDS, payload: checked });

export const loadConfig = (isUpdate) => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    const { data } = await FieldConfigApi.loadCaseConfigSetting();
    data.resultLabel = data.resultLabel.filter((i) => i.group === 'Diagram');
    const calcMap = data.resultCalculation.map((i) => ({ name: i.name, value: i.id }));
    const fields = listToObject(data.field);
    const resultFields = listToObject(data.resultLabel);
    dispatch({ type: SET_CASE_CONFIG, payload: { fields, resultFields, calcMap } });

    if (isUpdate) {
      for (const id of Object.keys(FieldsModels)) {
        if (!fields.hasOwnProperty(id)) {
          model.removeNode(FieldsModels[id]);
          delete FieldsModels[id];
        }
      }
      for (const id of Object.keys(ResultFieldModels)) {
        if (!fields.hasOwnProperty(id)) {
          model.removeNode(ResultFieldModels[id]);
          delete ResultFieldModels[id];
        }
      }
    }

    for (const field of Object.values(fields)) {
      if (!FieldsModels.hasOwnProperty(field.id)) {
        const fieldItem = new ParamsModel(engine, {
          children: <InputField key={field.id} data={field} />,
        });
        fieldItem.setPosition(field.xpos2, field.ypos2);
        FieldsModels[field.id] = fieldItem;
        model.addNode(fieldItem);
      }
    }
    for (const field of Object.values(resultFields)) {
      if (field.group === 'Diagram' && !ResultFieldModels.hasOwnProperty(field.id)) {
        const fieldItem = new ParamsModel(engine, {
          children: <InputField key={field.id + 'res'} data={field} isResult />,
        });
        fieldItem.setPosition(field.xpos2, field.ypos2);
        ResultFieldModels[field.id] = fieldItem;
        model.addNode(fieldItem);
      }
    }
  } catch (e) {
    handleError(e, 'Failed to load data');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const deleteField = (fieldData, isResult, onClose) => async (dispatch) => {
  dispatch({ type: DELETE_FIELD, id: fieldData.id, isResult });
  if (isResult) {
    model.removeNode(ResultFieldModels[fieldData.id]);
    onClose && onClose();
  } else {
    model.removeNode(FieldsModels[fieldData.id]);
    onClose && onClose();
  }
};

export const addField = (fieldData) => async (dispatch, getState) => {
  // checking field
  const fields = getState()[configFieldsModule].fields;
  for (const field of Object.values(fields)) {
    if (field.config_group === fieldData.config_group && field.name === fieldData.name) {
      Notice.error(`Field with name ${field.name} and group ${field.config_group} already exists`);
      return;
    }
  }
  // adding field
  dispatch({ type: ADD_NEW_FIELD, fieldData });
  const fieldItem = new ParamsModel(engine, {
    children: <InputField key={fieldData.id} data={fieldData} />,
  });
  fieldItem.setPosition(fieldData.xpos / 1.4 + 1400, fieldData.ypos / 1.6 + 60);
  FieldsModels[fieldData.id] = fieldItem;
  model.addNode(fieldItem);
};

export const addResultField = (fieldData) => async (dispatch, getState) => {
  // checking field
  const fields = getState()[configFieldsModule].resultFields;
  for (const field of Object.values(fields)) {
    if (field.config_group === fieldData.config_group && field.name === fieldData.name) {
      Notice.error(`Field with name ${field.name} and group ${field.config_group} already exists`);
      return;
    }
  }
  // adding field
  dispatch({ type: ADD_NEW_FIELD, fieldData, isResult: true });
  const fieldItem = new ParamsModel(engine, {
    children: <InputField key={fieldData.id + 'res'} data={fieldData} isResult />,
  });
  fieldItem.setPosition(fieldData.xpos / 1.4 + 1400, fieldData.ypos / 1.6 + 60);
  ResultFieldModels[fieldData.id] = fieldItem;
  model.addNode(fieldItem);
};

export const onChangeField = (field) => ({ type: ON_CHANGE_FIELD, field });

export const onChangeResultField = (field) => ({ type: ON_CHANGE_RESULT_FIELD, field });

function listToObject(list) {
  const obj = {};
  for (const item of list) {
    obj[item.id] = item;
  }
  return obj;
}

export const saveChanges = () => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_SAVE, payload: true });
    const fieldsForSave = {};
    const resultFieldsForSave = {};
    const state = getState()[configFieldsModule];

    for (const fieldId of Object.keys(state.fields)) {
      const field = { ...state.fields[fieldId] };
      const position = FieldsModels[field.id].getPosition();
      if (
        field.status === 'new' ||
        field.status === 'update' ||
        field.xpos2 !== position.x ||
        field.ypos2 !== position.y
      ) {
        delete field.id;
        delete field.timestamp;
        delete field.option_rule;
        delete field.config_order;
        delete field.status;
        field.xpos2 = position.x;
        field.ypos2 = position.y;
        fieldsForSave[fieldId] = field;
      }
    }

    for (const fieldId of Object.keys(state.resultFields)) {
      const field = { ...state.resultFields[fieldId] };
      const position = ResultFieldModels[field.id].getPosition();
      if (
        field.status === 'new' ||
        field.status === 'update' ||
        field.xpos2 !== position.x ||
        field.ypos2 !== position.y
      ) {
        delete field.id;
        delete field.calc;
        delete field.order;
        delete field.status;
        field.xpos2 = position.x;
        field.ypos2 = position.y;
        resultFieldsForSave[fieldId] = field;
      }
    }

    await FieldConfigApi.saveData({
      FieldConfigItem: fieldsForSave,
      ResultItem: resultFieldsForSave,
      DelFieldConfigItem: state.deletedFieldsIds,
      DelResultItem: state.deletedResultIds,
      Version: 1,
    });
    dispatch({ type: CLEAR_CHANGES_DATA });
    dispatch(loadConfig(true));
  } catch (e) {
    handleError(e, 'Failed to save changes data');
  } finally {
    dispatch({ type: LOADING_SAVE, payload: false });
  }
};
