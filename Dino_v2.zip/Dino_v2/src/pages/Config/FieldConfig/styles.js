import styled from '@emotion/styled';
import { makeStyles } from '@mui/styles';

export const rootStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  content: {
    // backgroundColor: `${BACKGROUND_CONTENT}`,
    backgroundSize: '50px 50px',
    flexGrow: 1,
    minHeight: 'calc(100vh - 200px)',
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    '& > *': {
      height: '100%',
      minHeight: 'calc(100vh - 220px)',
      width: '100%',
    },
  },
}));

export const InputContainerStyle = styled.div`
  display: ${(props) => (props.hideField ? 'none' : 'flex')};
  border: ${(props) => (props.isConstraint ? '2px solid #F12BA8' : 'none')};
  border-radius: 6px;
  margin-bottom: 4px;
  justify-content: center;
  align-items: center;

  .input-field {
    overflow: hidden;
    white-space: nowrap;
    color: black;
    background: rgb(255, 243, 169);
    font-size: 12px;
    padding: 0 4px;
    width: 60px;
    height: 18px;
  }

  .title {
    position: absolute;
    white-space: nowrap;
    font-size: 12px;
  }
  .position-left {
    right: 120px;
    top: -2px;
  }
  .position-right {
    left: 120px;
    top: -2px;
    text-align: right;
  }
  .position-top {
    bottom: 22px;
  }
  .position-bottom {
    top: 22px;
  }
`;

export const inputFieldBtnStyle = (buttonBg, hoveredUnit, isConstraint) => ({
  background: hoveredUnit ? 'green' : buttonBg,
  height: 18,
  width: 50,
  minWidth: 50,
  padding: '2px 4px 2px 4px',
  margin: 0,
  borderBottomLeftRadius: 0,
  borderTopLeftRadius: 0,
  borderBottomRightRadius: 5,
  borderTopRightRadius: 5,
  marginLeft: '-1px',
  textTransform: 'none',
  border: isConstraint ? '2px solid #F12BA8' : 'none',
  '&:hover': {
    background: (hoveredUnit ? 'green' : buttonBg) + '90',
  },
});
