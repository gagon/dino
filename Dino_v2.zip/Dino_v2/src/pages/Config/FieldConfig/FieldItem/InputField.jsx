import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import React, { useMemo, useState } from 'react';
import FieldArrowIcon from '../../../../_media/FieldArrowIcon';
import { InputContainerStyle, inputFieldBtnStyle } from '../styles';
import FieldPopover from './FieldPopover';
import FieldResultPopover from './FieldResultPopover';
import { useSelector } from 'react-redux';
import { configFieldsModule } from '../FieldConfigDucks';

export default function InputField({ data: { id }, isResult }) {
  const fieldBg = isResult ? 'rgb(157 247 212)' : '#FFF3A9';
  const newButtonBg = isResult ? '#10d58b' : '#ff9900';
  const buttonBg = isResult ? '#1d9868' : '#EDB901';
  const [anchorEl, setAnchorEl] = useState(null);
  const data = useSelector((state) =>
    isResult ? state[configFieldsModule].resultFields[id] : state[configFieldsModule].fields[id]
  );
  const hideField = useSelector((state) =>
    isResult ? state[configFieldsModule].hideResultFields : state[configFieldsModule].hideFields
  );
  const sxBtn = useMemo(
    () => inputFieldBtnStyle(data.status === 'new' ? newButtonBg : buttonBg),
    [buttonBg, newButtonBg]
  );

  return (
    <InputContainerStyle isConstraint={data.is_constraint} hideField={hideField}>
      {['left', 'top'].includes(data.label_pos) && (
        <div className={'title position-' + data.label_pos}>{data.name}</div>
      )}
      <div
        className="input-field"
        style={{ backgroundColor: fieldBg, borderRadius: 6 }}
        title={data.name}
        children={data.name}
      />
      <Button onClick={(e) => setAnchorEl(e.currentTarget)} sx={sxBtn}>
        <div className="fullWidth flex justify-between items-center">
          <Typography
            sx={{
              fontSize: 9,
              color: data.config_group === 'Export' && !data.is_constraint ? 'black' : 'white',
            }}
            children={data.uom}
          />
          <FieldArrowIcon
            stroke={data.config_group === 'Export' && !data.is_constraint ? 'black' : 'white'}
            style={{ fontSize: 9, marginRight: 3, marginLeft: 3 }}
          />
        </div>
      </Button>
      {isResult && anchorEl && (
        <FieldResultPopover anchorEl={anchorEl} setAnchorEl={setAnchorEl} data={data} />
      )}
      {!isResult && anchorEl && (
        <FieldPopover anchorEl={anchorEl} setAnchorEl={setAnchorEl} data={data} />
      )}
    </InputContainerStyle>
  );
}
