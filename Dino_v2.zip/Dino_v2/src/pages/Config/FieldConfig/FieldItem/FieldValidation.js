import { object, string, number, date } from 'yup';
export const fieldValidation = object({
  config_group: string().required(),
});
