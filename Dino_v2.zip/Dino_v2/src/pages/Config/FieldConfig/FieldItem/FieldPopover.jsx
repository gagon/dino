import Button from '@mui/material/Button';
import React from 'react';
import PopoverWindow from '../../../../common/Popover/Popover';
import { FormControlLabel, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import Input from '../../../../common/Input/Input';
import useForm from '../../../../common/_hooks/useForm';
import { fieldValidation } from './FieldValidation';
import Field from '../../../../common/Form/Field';
import Checkbox from '@mui/material/Checkbox';
import Select from '../../../../common/Select/Select';
import { deleteField, onChangeField } from '../FieldConfigDucks';
import { useDispatch } from 'react-redux';
import AfIcon from '@mui/icons-material/PendingOutlined';
import useSimpleModal from '../../../../common/_hooks/useSimpleModal';
import ConfiguredTagsModal from '../../../../common/ConfiguredTagsModal/ConfiguredTagsModal';

const dataTypeOptions = [
  { name: 'float', value: 'float' },
  { name: 'string', value: 'string' },
];
const sourceTypeOptions = [
  { name: 'none', value: '' },
  { name: 'Attributes', value: 'Attributes' },
  { name: 'url', value: 'url' },
  { name: 'calc', value: 'calc' },
  { name: 'pipoint', value: 'pipoint' },
];
const labelPosOptions = [
  { name: 'none', value: 'none' },
  { name: 'top', value: 'top' },
  { name: 'left', value: 'left' },
];
const popupPosOptions = [
  { name: 'top', value: 'top' },
  { name: 'left', value: 'left' },
  { name: 'right', value: 'right' },
  { name: 'bottom', value: 'bottom' },
];

const fields = [
  { title: 'Group', name: 'config_group' },
  { title: 'Name', name: 'name' },
  { title: 'Description', name: 'description' },
  { title: 'Data Type', name: 'data_type', type: 'select', options: dataTypeOptions },
  { title: 'Default', name: 'default_val' },
  { title: 'Source Type', name: 'source_type', type: 'select', options: sourceTypeOptions },
  { title: 'Source', name: 'source_tag', withAfModal: true },
  { title: 'Gap String', name: 'gap_string' },
  { title: 'Unit Of Measure', name: 'uom' },
  { title: 'Alt Unit Of Measure', name: 'alt_uom' },
  { title: 'Min Constraint', name: 'min' },
  { title: 'Max Constraint', name: 'max' },
  {
    type: 'checkbox',
    checkboxList: [
      { title: 'Is Constraint', name: 'is_constraint', type: 'checkbox' },
      { title: 'Is Required', name: 'is_required', type: 'checkbox' },
      { title: 'Used In Optimize', name: 'used_in_opt', type: 'checkbox' },
      { title: 'Show Time Picker', name: 'time_picker', type: 'checkbox' },
      { title: 'Prevent Fetch', name: 'no_auto_fetch', type: 'checkbox' },
    ],
  },
  { title: 'Default Chart Period', name: 'chart_days' },
  { title: 'Decimal Points', name: 'display_dp' },
  { title: 'Label Position', name: 'label_pos', type: 'select', options: labelPosOptions },
  { title: 'Popup Position', name: 'popup_pos', type: 'select', options: popupPosOptions },
  { title: 'X Pos', name: 'xpos' },
  { title: 'Y Pos', name: 'ypos' },
];

export default function FieldPopover({ anchorEl, setAnchorEl, data, onAdd }) {
  const dispatch = useDispatch();
  const tagModal = useSimpleModal();
  const form = useForm(fieldValidation, data);
  const onSubmit = (data) => console.log(data);
  const onChange = () => {
    dispatch(onChangeField(form.getValues()));
    setAnchorEl(null);
  };

  return (
    <PopoverWindow open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={onChange}>
      <div className="pt2" style={{ minWidth: 800 }}>
        <div
          className="if-header flex items-center justify-between pl3 pr2 pb2"
          style={{ borderBottom: '1px solid lightgray' }}
        >
          <div className="bold">Edit Field Item</div>
          <IconButton size="small" onClick={onChange}>
            <CloseIcon />
          </IconButton>
        </div>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="px3 pb3 pt2 overflow-auto" style={{ maxHeight: 500 }}>
            {fields.map((field, index) => (
              <div key={index} className="clearfix">
                <div className="col col-5 pt1">{field.title}</div>
                <div className="col col-7">
                  {!field.type && (
                    <Input
                      name={field.name}
                      control={form.control}
                      inputStyle={{ padding: field.withAfModal ? '15px 2px 15px 15' : undefined }}
                      savedValue={data[field.name]}
                      editedBg={true}
                      endAdornment={
                        field.withAfModal && (
                          <IconButton
                            size="small"
                            color="default"
                            onClick={tagModal.open}
                            children={<AfIcon />}
                          />
                        )
                      }
                    />
                  )}
                  {field.type === 'select' && (
                    <Select
                      name={field.name}
                      options={field.options}
                      control={form.control}
                      savedValue={data[field.name]}
                      editedBg={true}
                    />
                  )}
                  {field.type === 'checkbox' &&
                    field.checkboxList.map((item) => (
                      <Field key={item.name} name={item.name} control={form.control}>
                        {({ value, onChange }) => (
                          <FormControlLabel
                            sx={{ marginRight: 3 }}
                            label={<span className="fs-12">{item.title}</span>}
                            control={
                              <Checkbox
                                size="small"
                                title={item.title}
                                checked={!!value}
                                onChange={onChange}
                              />
                            }
                          />
                        )}
                      </Field>
                    ))}
                </div>
              </div>
            ))}
            <div className="mt3">
              {!onAdd && (
                <Button
                  startIcon={<DeleteIcon />}
                  variant="outlined"
                  fullWidth
                  color="error"
                  children="Delete field"
                  onClick={() => dispatch(deleteField(data, false, () => setAnchorEl(null)))}
                />
              )}
              {onAdd && (
                <Button
                  startIcon={<AddIcon />}
                  variant="contained"
                  fullWidth
                  children="add field"
                  onClick={() => onAdd(form.getValues())}
                />
              )}
            </div>
          </div>
        </form>
      </div>
      {tagModal.isOpen && (
        <ConfiguredTagsModal
          {...tagModal}
          onSelect={(value) => form.setValue('source_tag', value)}
        />
      )}
    </PopoverWindow>
  );
}
