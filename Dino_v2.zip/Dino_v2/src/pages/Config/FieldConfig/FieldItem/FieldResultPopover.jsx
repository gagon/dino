import React from 'react';
import Button from '@mui/material/Button';
import PopoverWindow from '../../../../common/Popover/Popover';
import { FormControlLabel, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import Input from '../../../../common/Input/Input';
import useForm from '../../../../common/_hooks/useForm';
import { fieldValidation } from './FieldValidation';
import Field from '../../../../common/Form/Field';
import Checkbox from '@mui/material/Checkbox';
import Select from '../../../../common/Select/Select';
import { useDispatch, useSelector } from 'react-redux';
import { configFieldsModule, deleteField, onChangeResultField } from '../FieldConfigDucks';
import AddIcon from '@mui/icons-material/Add';

const labelPosOptions = [
  { name: 'none', value: 'none' },
  { name: 'top', value: 'top' },
  { name: 'left', value: 'left' },
];
const popupPosOptions = [
  { name: 'top', value: 'top' },
  { name: 'left', value: 'left' },
  { name: 'right', value: 'right' },
  { name: 'bottom', value: 'bottom' },
];

const fields = [
  { title: 'Group', name: 'config_group' },
  { title: 'Name', name: 'name' },
  { title: 'Calculation', name: 'calc_id', type: 'select' },
  { title: 'Alt Unit Of Measure', name: 'alt_uom' },
  { title: 'Decimal Points', name: 'display_dp' },
  { title: 'Label Position', name: 'label_pos', type: 'select', options: labelPosOptions },
  { title: 'Popup Position', name: 'popup_pos', type: 'select', options: popupPosOptions },
  { title: 'X Pos', name: 'xpos' },
  { title: 'Y Pos', name: 'ypos' },
];

export default function FieldResultPopover({ anchorEl, setAnchorEl, data, onAdd }) {
  const dispatch = useDispatch();
  const form = useForm(fieldValidation, data);
  const calcMap = useSelector((state) => state[configFieldsModule].calcMap);
  const onSubmit = (data) => console.log(data);
  const onChange = () => {
    dispatch(onChangeResultField(form.getValues()));
    setAnchorEl(null);
  };

  return (
    <PopoverWindow open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={onChange}>
      <div className="pt2" style={{ minWidth: 800 }}>
        <div
          className="if-header flex items-center justify-between pl3 pr2 pb2"
          style={{ borderBottom: '1px solid lightgray' }}
        >
          <div className="bold">Edit Result Calculation</div>
          <IconButton size="small" onClick={onChange}>
            <CloseIcon />
          </IconButton>
        </div>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="px3 pb3 pt2 overflow-auto" style={{ maxHeight: 500 }}>
            {fields.map((field, index) => (
              <div key={index} className="clearfix">
                <div className="col col-5 pt1">{field.title}</div>
                <div className="col col-7">
                  {!field.type && (
                    <Input
                      name={field.name}
                      control={form.control}
                      savedValue={data[field.name]}
                      editedBg={true}
                    />
                  )}
                  {field.type === 'select' && (
                    <Select
                      withoutEmptyOption
                      name={field.name}
                      options={field.name === 'calc_id' ? calcMap : field.options}
                      control={form.control}
                      savedValue={data[field.name]}
                      editedBg={true}
                    />
                  )}
                  {field.type === 'checkbox' &&
                    field.checkboxList.map((item) => (
                      <Field key={item.name} name={item.name} control={form.control}>
                        {({ value, onChange }) => (
                          <FormControlLabel
                            sx={{ marginRight: 3 }}
                            label={item.title}
                            control={
                              <Checkbox
                                size="small"
                                title={item.title}
                                checked={!!value}
                                onChange={onChange}
                              />
                            }
                          />
                        )}
                      </Field>
                    ))}
                </div>
              </div>
            ))}
            <div className="mt3">
              {!onAdd && (
                <Button
                  startIcon={<DeleteIcon />}
                  variant="outlined"
                  fullWidth
                  color="error"
                  children="Delete field"
                  onClick={() => dispatch(deleteField(data, true, () => setAnchorEl(null)))}
                />
              )}
              {onAdd && (
                <Button
                  startIcon={<AddIcon />}
                  variant="contained"
                  fullWidth
                  children="add field"
                  onClick={() => onAdd(form.getValues())}
                />
              )}
            </div>
          </div>
        </form>
      </div>
    </PopoverWindow>
  );
}
