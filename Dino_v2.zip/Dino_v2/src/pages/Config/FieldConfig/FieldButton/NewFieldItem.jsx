import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Button } from '@mui/material';
import { v4 as uuidv4 } from 'uuid';
import { addField } from '../FieldConfigDucks';
import FieldPopover from '../FieldItem/FieldPopover';

export default function NewFieldItem() {
  const dispatch = useDispatch();
  const [data, setData] = useState();
  const [anchorEl, setAnchorEl] = useState(null);
  const onOpen = (anchorEl) => {
    setData({
      config_group: 'New',
      name: 'NewName',
      description: '',
      chart_days: 1,
      is_required: false,
      default_val: null,
      source_type: null,
      source_tag: null,
      gap_string: null,
      uom: null,
      alt_uom: null,
      display_dp: 2,
      data_type: 'float',
      xpos: -1213,
      ypos: -237,
      status: 'new',
      id: uuidv4(),
      min: null,
      max: null,
      is_constraint: null,
      used_in_opt: null,
      time_picker: null,
      no_auto_fetch: null,
      label_pos: null,
      popup_pos: null,
    });
    setAnchorEl(anchorEl);
  };

  return (
    <>
      <Button
        sx={{ marginRight: 1 }}
        onClick={(e) => onOpen(e.currentTarget)}
        variant="outlined"
        children="new Field item"
      />
      {data && (
        <FieldPopover
          anchorEl={anchorEl}
          setAnchorEl={() => {
            setData(null);
            setAnchorEl(null);
          }}
          data={data}
          onAdd={(data) => {
            setData(null);
            dispatch(addField(data));
          }}
        />
      )}
    </>
  );
}
