import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Button } from '@mui/material';
import { v4 as uuidv4 } from 'uuid';
import { addResultField } from '../FieldConfigDucks';
import FieldResultPopover from '../FieldItem/FieldResultPopover';

export default function NewResultItem() {
  const dispatch = useDispatch();
  const [data, setData] = useState();
  const [anchorEl, setAnchorEl] = useState(null);
  const onOpen = (anchorEl) => {
    setData({
      id: uuidv4(),
      group: 'Diagram',
      config_group: 'New',
      name: 'NewName',
      calc_id: 1,
      alt_uom: null,
      display_dp: 2,
      label_pos: null,
      popup_pos: null,
      xpos: -890,
      ypos: -237,
      status: 'new',
    });
    setAnchorEl(anchorEl);
  };

  return (
    <>
      <Button
        sx={{ marginRight: 1 }}
        variant="outlined"
        onClick={(e) => onOpen(e.currentTarget)}
        children="new Result item"
      />
      {data && (
        <FieldResultPopover
          anchorEl={anchorEl}
          setAnchorEl={() => {
            setData(null);
            setAnchorEl(null);
          }}
          data={data}
          onAdd={(data) => {
            setData(null);
            dispatch(addResultField(data));
          }}
        />
      )}
    </>
  );
}
