import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  configFieldsModule,
  loadConfig,
  onHideFields,
  onHideResultFields,
  saveChanges,
} from './FieldConfigDucks';
import Typography from '@mui/material/Typography';
import { useTheme } from '@mui/styles';
import SaveIcon from '@mui/icons-material/SaveOutlined';
import { LoadingButton } from '@mui/lab';
import Slider from '@mui/material/Slider';
import { getModel } from '../../../common/FieldSchema/FieldSchemaObjects';
import { CanvasWidget } from '@projectstorm/react-canvas-core';
import { rootStyles } from './styles';
import FieldLegend from '../../../common/FieldLegend/FieldLegend';
import NewFieldItem from './FieldButton/NewFieldItem';
import NewResultItem from './FieldButton/NewResultItem';
import Switch from '../../../common/Switch/Switch';
import PageLoader from '../../../common/PageLoader/PageLoader';

export const { engine, model } = getModel();
export default function FieldConfig() {
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const classes = rootStyles();
  const loading = useSelector((state) => state[configFieldsModule].loading);
  const fields = useSelector((state) => state[configFieldsModule].fields);
  const resultFields = useSelector((state) => state[configFieldsModule].resultFields);
  const hideFields = useSelector((state) => state[configFieldsModule].hideFields);
  const hideResultFields = useSelector((state) => state[configFieldsModule].hideResultFields);
  const loadingSave = useSelector((state) => state[configFieldsModule].loadingSave);

  useEffect(() => {
    if (fields === null && resultFields === null) {
      dispatch(loadConfig());
    }
  }, [fields, resultFields]);

  return (
    <div className="mb4">
      <div className="mb3">
        <Typography
          variant={'h5'}
          children="FieldConfig"
          style={{ color: palette.action.active }}
        />
        <div className="flex justify-between">
          <div className="flex">
            <div
              className="flex mr2 items-center pointer"
              onClick={() => dispatch(onHideFields(!hideFields))}
            >
              <Switch
                size="small"
                checked={hideFields}
                onClick={() => dispatch(onHideFields(!hideFields))}
              />
              <span className="ml1">Hide Edit Controls</span>
            </div>
            <div
              className="flex items-center pointer"
              onClick={() => dispatch(onHideResultFields(!hideResultFields))}
            >
              <Switch size="small" checked={hideResultFields} />
              <span className="ml1">Hide Result Controls</span>
            </div>
          </div>
          <div className="right-align mb1">
            <NewFieldItem />
            <NewResultItem />
            <LoadingButton
              loading={loadingSave}
              variant="contained"
              startIcon={<SaveIcon />}
              children="Save changes"
              onClick={() => dispatch(saveChanges())}
            />
          </div>
        </div>
      </div>
      <div
        className="flex pb2 pl2"
        style={{ position: 'absolute', right: 0, backgroundColor: '#E8E8F0', zIndex: 99 }}
        children={<FieldLegend />}
      />
      <div className="flex" style={{ height: 800 }}>
        <div style={{ marginTop: 90 }}>
          <div style={{ height: 200 }}>
            <Slider
              size="small"
              defaultValue={window.innerWidth < 1600 ? 16 : 30}
              valueLabelDisplay="auto"
              orientation="vertical"
              onChange={(ev, zoom) => {
                model.setZoomLevel(zoom + 60);
                engine.repaintCanvas();
              }}
            />
          </div>
        </div>
        <div className={classes.content}>
          {loading && <PageLoader opacity={70} position="absolute" height="70vh" />}
          <CanvasWidget engine={engine} />
        </div>
      </div>
    </div>
  );
}
