import React, { useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import CircularProgress from '@mui/material/CircularProgress';
import IconButton from '@mui/material/IconButton';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';

export default function ConfigTable({
  loading,
  columns,
  rows,
  isSelected,
  maxHeight,
  onRowClick,
  withoutTitle,
  sortingTable = true,
}) {
  const [sortable, setSortable] = useState({});
  const setColumnSorting = (column) => {
    if (sortable.column === column && sortable.sort === 'desc') {
      setSortable({ column, sort: 'asc' });
    } else if (sortable.column === column && sortable.sort === 'asc') {
      setSortable({});
    } else {
      setSortable({ column, sort: 'desc' });
    }
  };

  return (
    <div
      style={{ background: 'white', borderRadius: 8, overflow: 'hidden', border: '1px solid #ddd' }}
    >
      <TableContainer sx={{ maxHeight: maxHeight || '100%' }}>
        <Table stickyHeader>
          <TableHead sx={{ background: '#efefef', height: 56 }}>
            <TableRow>
              {columns.map((column, index) => (
                <TableCell
                  key={column.field}
                  align={column.align || 'left'}
                  onClick={() =>
                    sortingTable && column.valueGetter && setColumnSorting(column.headerName)
                  }
                  children={
                    <div
                      style={{
                        borderRight:
                          columns.length - 1 !== index ? '2px solid rgb(214 215 217)' : 'none',
                        paddingRight: 16,
                      }}
                    >
                      {column.headerName}
                      {sortable.column === column.headerName &&
                        sortable.sort === 'desc' &&
                        column.valueGetter && (
                          <IconButton size="small">
                            <ArrowDownwardIcon fontSize="small" />
                          </IconButton>
                        )}
                      {sortable.column === column.headerName &&
                        sortable.sort === 'asc' &&
                        column.valueGetter && (
                          <IconButton size="small">
                            <ArrowUpwardIcon fontSize="small" />
                          </IconButton>
                        )}
                    </div>
                  }
                  sx={{
                    background: '#efefef',
                    lineHeight: 1,
                    fontWeight: 600,
                    fontSize: 12,
                    padding: '12px 0 12px 16px',
                    cursor: column.valueGetter ? 'pointer' : 'inherit',
                  }}
                />
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {[...rows]
              .sort((a, b) => compare(a, b, sortable, columns))
              .map((row) => (
                <TableRow
                  hover
                  tabIndex={-1}
                  key={row.id}
                  {...(isSelected && { selected: isSelected(row.id) })}
                  {...(onRowClick && { onClick: () => onRowClick(row) })}
                >
                  {columns.map((column) => (
                    <TableCell
                      key={column.field + row.id}
                      align={column.align || 'left'}
                      {...(!withoutTitle && { title: column.headerName })}
                      children={column.renderCell({ row })}
                      sx={{
                        width: column.width,
                        minWidth: column.minWidth,
                        borderBottom: '1px solid #EEF0F9',
                        borderRight: '1px solid #EEF0F9',
                        maxHeight: 40,
                        padding: '4px',
                      }}
                    />
                  ))}
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </TableContainer>
      {rows.length === 0 && !loading && (
        <div className="flex items-center justify-center" style={{ height: 80 }}>
          no rows
        </div>
      )}
      {rows.length === 0 && loading && (
        <div className="flex items-center justify-center" style={{ height: 80 }}>
          <CircularProgress />
        </div>
      )}
    </div>
  );
}

function compare(rowA, rowB, sortableObj, columns) {
  try {
    const sortable =
      Object.keys(sortableObj).length > 0
        ? sortableObj
        : { sort: 'desc', column: (columns.find((i) => i.defaultSort) || columns[0]).headerName };
    const column = columns.find((c) => c.headerName === sortable.column);
    if (column && sortable.sort && column.valueGetter) {
      let a = column.valueGetter({ row: rowA });
      let b = column.valueGetter({ row: rowB });

      if (column.type === 'number') {
        a = parseFloat(a) || 0;
        b = parseFloat(b) || 0;
      }
      if (a < b && sortable.sort === 'desc') {
        return -1;
      }
      if (a > b && sortable.sort === 'desc') {
        return 1;
      }
      if (a < b && sortable.sort === 'asc') {
        return 1;
      }
      if (a > b && sortable.sort === 'asc') {
        return -1;
      }
    }
  } catch (e) {
    console.error(e.message);
  }

  return 0;
}
