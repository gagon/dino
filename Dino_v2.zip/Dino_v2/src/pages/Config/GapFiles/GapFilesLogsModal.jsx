import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Dialog, Typography } from '@mui/material';
import { useTheme } from '@mui/styles';

import { gapFilesModule, openLogsModal } from './GapFilesDucks';

const GapFilesLogsModal = () => {
  const logMessages = useSelector((state) => state[gapFilesModule].logMessages);
  const isOpen = useSelector((state) => state[gapFilesModule].isLogsOpen);
  const dispatch = useDispatch();
  const { palette } = useTheme();

  const onClose = () => {
    dispatch(openLogsModal(false));
  };

  useEffect(() => {
    const elem = document.querySelector('#log-messages');
    if (elem) {
      elem.scrollTop = elem.scrollHeight;
    }
  });

  return (
    <Dialog
      sx={{ background: '#5051F935', zIndex: 2 }}
      PaperProps={{
        sx: {
          borderTopRightRadius: 20,
          borderTopLeftRadius: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
          maxWidth: 800,
        },
      }}
      onClose={onClose}
      open={isOpen}
    >
      <div style={{ padding: '33px 28px 25px 28px' }}>
        <div
          style={{
            width: 700,
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}
        >
          <Typography variant={'h5'} children="Progress" style={{ color: palette.action.active }} />
          <div
            id="log-messages"
            style={{
              border: '2px solid #F3F5F9',
              borderRadius: 6,
              marginTop: 16,
              padding: '11px 15px 9px 15px',
              height: '300px',
              overflowY: 'auto',
            }}
          >
            {logMessages.map((msg, index) => (
              <div key={index}>{msg}</div>
            ))}
          </div>
          <div
            className="fullWidth"
            style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}
          >
            <Button
              children="close"
              style={{ background: palette.action.selected, width: 100 }}
              onClick={onClose}
            />
          </div>
        </div>
      </div>
    </Dialog>
  );
};

export default GapFilesLogsModal;
