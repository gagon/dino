import { createReducer } from '@reduxjs/toolkit';

import { handleError } from '../../../common/utils/handleError';
import Notice from '../../../common/utils/Notice';
import { GapFilesApi } from '../../../_helpers/service';
import { setWells } from '../Wells/WellsDucks';

/**
 * Constants
 */
export const gapFilesModule = 'gapFilesModule';
const SET_GAP_FILES = `${gapFilesModule}/SET_GAP_FILES`;
const CHANGE_DEFAULT_GAP_FILE = `${gapFilesModule}/CHANGE_DEFAULT_GAP_FILE`;
const REMOVE_GAP_FILE = `${gapFilesModule}/REMOVE_GAP_FILE`;
const LOADING = `${gapFilesModule}/LOADING`;
const OPEN_LOGS = `${gapFilesModule}/OPEN_LOGS`;
const ADD_LOG_MESSAGE = `${gapFilesModule}/ADD_LOG_MESSAGE`;

/**
 * Reducer
 */
const initialState = {
  gapFiles: [],
  logMessages: [],
  isLogsOpen: false,
  loading: true,
};

export default createReducer(initialState, {
  [SET_GAP_FILES]: (state, { payload }) => {
    state.gapFiles = payload;
  },
  [CHANGE_DEFAULT_GAP_FILE]: (state, { payload }) => {
    state.gapFiles = state.gapFiles.map((gap) =>
      gap.id === payload ? { ...gap, current: true } : gap
    );
  },
  [REMOVE_GAP_FILE]: (state, { payload }) => {
    state.gapFiles = state.gapFiles.filter((gap) => gap.id !== payload);
  },
  [ADD_LOG_MESSAGE]: (state, { payload }) => {
    state.logMessages.push(payload);
  },
  [OPEN_LOGS]: (state, { payload }) => {
    state.isLogsOpen = payload;
  },
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
});

/**
 * Actions
 */
export const loadGapFiles = () => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    const {
      data: { gapfiles },
    } = await GapFilesApi.getGapFiles();
    dispatch({ type: SET_GAP_FILES, payload: gapfiles });
  } catch (e) {
    handleError(e, 'Failed to load the gap files');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const changeDefaultGap = (id) => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    await GapFilesApi.changeDefaultGap(id);
    dispatch(loadGapFiles());
    Notice.success('The default gap file has been changed');
  } catch (e) {
    handleError(e, 'Failed to change the default gap file');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const uploadGapFile = (uploadData) => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    dispatch(openLogsModal(true));
    await GapFilesApi.uploadGapFile(uploadData);
  } catch (e) {
    handleError(e, 'Failed to upload the gap file');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const removeGapFile = (id) => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    await GapFilesApi.removeGapFile(id);
    dispatch({ type: REMOVE_GAP_FILE, payload: id });
    Notice.success('The gap file has been deleted');
  } catch (e) {
    handleError(e, 'Failed to remove the gap file');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const loadWellConfig = (id) => async (dispatch) => {
  try {
    dispatch({ type: LOADING, payload: true });
    const { data: gap_wells } = await GapFilesApi.getGapFileData(id);
    dispatch(setWells(gap_wells));
  } catch (e) {
    handleError(e, 'Failed to load the well config');
  } finally {
    dispatch({ type: LOADING, payload: false });
  }
};

export const openLogsModal = (isOpen) => ({ type: OPEN_LOGS, payload: isOpen });

export const addLogMessage = (msg) => ({ type: ADD_LOG_MESSAGE, payload: msg });
