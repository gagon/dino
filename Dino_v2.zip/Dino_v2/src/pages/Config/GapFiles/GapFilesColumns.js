import React, { useState, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Radio } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import moment from 'moment';

import {
  changeDefaultGap,
  gapFilesModule,
  loadWellConfig,
  openModal,
  removeGapFile,
} from './GapFilesDucks';
import ConfirmModal from '../ConfirmModal';

const REMOVE_GAP_TEXT =
  'This will remove the gap file and all the wells and cases configured for it. Are you sure?';
const REMOVE_CURRENT_GAP_TEXT = 'You cant remove the file that is currently in use.';
const SET_CURRENT_GAP_TEXT =
  'This will change the gap file used to create and configure new cases. Are you sure?';

export const gapFilesColumns = () => [
  {
    minWidth: 60,
    field: 'name',
    headerName: 'Gap File Name',
    valueGetter: ({ row }) => row.name,
    renderCell: ({ row }) => <TableData data={row.name} />,
  },
  {
    minWidth: 120,
    field: 'configuredStartDate',
    align: 'center',
    headerName: 'Configured Start Date',
    defaultSort: true,
    valueGetter: ({ row }) => moment(row.timestamp).format('YYYY MMM DD'),
    renderCell: ({ row }) => <TableData data={moment(row.timestamp).format('YYYY MMM DD')} />,
  },
  {
    field: 'current',
    align: 'center',
    headerName: 'Currently Selected',
    valueGetter: ({ row }) => row.current,
    renderCell: ({ row }) => <DefaultGapRadio data={row} />,
  },
  {
    minWidth: 120,
    field: 'cases',
    align: 'center',
    headerName: 'Associated Cases',
    valueGetter: ({ row }) => row.cases,
    renderCell: ({ row }) => <TableData data={row.cases} />,
  },
  {
    minWidth: 120,
    field: 'wells',
    align: 'center',
    headerName: 'Associated Wells',
    valueGetter: ({ row }) => row.wells,
    renderCell: ({ row }) => <TableData data={row.wells} />,
  },
  {
    align: 'center',
    field: 'loadWellConfig',
    headerName: 'Load Well Config',
    valueGetter: ({ row }) => row.wells,
    renderCell: ({ row }) => <LoadWellConfigButton data={row} />,
  },
  {
    align: 'center',
    field: 'delete',
    headerName: 'Delete',
    renderCell: ({ row }) => <DeleteButton row={row} />,
  },
];

const DefaultGapRadio = ({ data }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dispatch = useDispatch();
  const onClose = () => setIsOpen(false);
  const onProceed = () => {
    dispatch(changeDefaultGap(data.id));
    onClose();
  };

  return (
    <WithModal isOpen={isOpen} text={SET_CURRENT_GAP_TEXT} onProceed={onProceed} onClose={onClose}>
      <Radio
        size="small"
        sx={{ paddingY: '4px' }}
        checked={data.current}
        onChange={() => setIsOpen(true)}
      />
    </WithModal>
  );
};

const LoadWellConfigButton = ({ data }) => {
  const dispatch = useDispatch();
  const loadConfig = () => dispatch(loadWellConfig(data.id));

  return (
    <LoadingButton
      size="small"
      children="Load Well Config"
      onClick={loadConfig}
      sx={{ paddingLeft: '8px' }}
    />
  );
};

const DeleteButton = ({ row }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dispatch = useDispatch();
  const isCurrent = row.current;
  const onClose = () => setIsOpen(false);
  const onDelete = () => {
    dispatch(removeGapFile(row.id));
    onClose();
  };

  const modalData = useMemo(() => {
    return isCurrent
      ? { text: REMOVE_CURRENT_GAP_TEXT, onProceed: onClose }
      : { text: REMOVE_GAP_TEXT, onProceed: onDelete };
  }, [isCurrent]);

  return (
    <WithModal
      isOpen={isOpen}
      text={modalData.text}
      onProceed={modalData.onProceed}
      onClose={onClose}
      disallowed={isCurrent}
    >
      <LoadingButton size="small" children="Delete" onClick={() => setIsOpen(true)} />
    </WithModal>
  );
};

const WithModal = ({ isOpen, text, onProceed, onClose, disallowed, children }) => {
  return (
    <>
      {isOpen && (
        <ConfirmModal
          isOpen={isOpen}
          text={text}
          onProceed={onProceed}
          onClose={onClose}
          disallowed={disallowed}
        />
      )}
      {children}
    </>
  );
};

const TableData = ({ data }) => <div style={{ paddingLeft: 8 }}>{data}</div>;
