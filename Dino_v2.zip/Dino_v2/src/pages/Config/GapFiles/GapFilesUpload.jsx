import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import styled from '@emotion/styled';
import { Divider, Box, TextField, Button, FormControlLabel, Checkbox } from '@mui/material';

import { uploadGapFile } from './GapFilesDucks';
import GapFilesLogsModal from './GapFilesLogsModal';

const StyledWrapper = styled.div`
  min-width: 420px;
  width: 35%;
  height: fit-content;
  border: 1px solid;
  border-color: #ddd;
  border-radius: 8px;
  margin-bottom: 2rem;
  overflow: hidden;

  .title {
    background-color: #efefef;
    padding: 15px 20px;
  }

  .children {
    padding: 20px 20px;
  }
`;

const GapFilesUpload = () => {
  const [uploadParams, setUploadParams] = useState({
    file: null,
    checkConnections: false,
  });
  const dispatch = useDispatch();

  const selectedFileNameLength = uploadParams.file?.name.length || 0;
  const selectedFileName = uploadParams.file?.name
    ? `${uploadParams.file?.name.substring(0, 13)}... ${uploadParams.file?.name.substring(
        selectedFileNameLength - 20,
        selectedFileNameLength
      )}`
    : 'No file chosen';

  const onSelectFile = (e) => {
    if (!e.target.files || e.target.files.length === 0) {
      setUploadParams((prev) => ({ ...prev, file: null }));
      return;
    }
    setUploadParams((prev) => ({ ...prev, file: e.target.files[0] }));
  };

  const toggleCheckConnections = () => {
    setUploadParams((prev) => ({ ...prev, checkConnections: !prev.checkConnections }));
  };

  const uploadFile = () => {
    const uploadData = new FormData();
    uploadData.append('file', uploadParams.file);
    if (uploadParams.checkConnections) {
      uploadData.append('checkConnections', 'on');
    }
    dispatch(uploadGapFile(uploadData));
  };

  return (
    <>
      <GapFilesLogsModal />

      <StyledWrapper>
        <div className="title">Add new GAP Model</div>
        <Divider />
        <div className="children" style={{ backgroundColor: '#fff' }}>
          <Box
            sx={{
              display: 'flex',
              gap: 1,
              alignItems: 'center',
            }}
          >
            <TextField
              disabled
              value={selectedFileName}
              title={uploadParams.file?.name || ''}
              sx={{
                width: '360px',
                margin: 0,
              }}
              InputProps={{
                startAdornment: (
                  <Button
                    variant="contained"
                    component="label"
                    color="primary"
                    sx={{
                      width: 156,
                      fontSize: '12px',
                      padding: 0,
                      textTransform: 'none',
                      marginRight: '5px',
                      borderRadius: '6px',
                      mr: 1,
                    }}
                  >
                    Choose File
                    <input type="file" hidden onChange={onSelectFile} />
                  </Button>
                ),
                sx: { padding: '4px' },
              }}
            />

            <Button
              variant="contained"
              size="small"
              sx={{ minWidth: '70px', textTransform: 'none' }}
              onClick={uploadFile}
            >
              Upload
            </Button>
          </Box>

          <FormControlLabel
            control={
              <Checkbox
                size="small"
                value={uploadParams.checkConnections}
                onChange={toggleCheckConnections}
              />
            }
            sx={{ fontSize: '12px', marginLeft: '0px' }}
            label="Check and update well connections on load"
            labelPlacement="start"
          />
        </div>
      </StyledWrapper>
    </>
  );
};

export default GapFilesUpload;
