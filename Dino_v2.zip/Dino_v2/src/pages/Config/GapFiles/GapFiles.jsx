import React, { useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTheme } from '@mui/styles';
import { Typography } from '@mui/material';

import { gapFilesModule, loadGapFiles, addLogMessage } from './GapFilesDucks';
import { gapFilesColumns } from './GapFilesColumns';
import GapFilesUpload from './GapFilesUpload';
import useSocketMessage from '../../../common/_hooks/useSocketMessage';
import ConfigTable from '../ConfigTable';

const GapFiles = () => {
  const gapFiles = useSelector((state) => state[gapFilesModule].gapFiles);
  const loading = useSelector((state) => state[gapFilesModule].loading);
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const columns = gapFilesColumns();

  const handleNewLogMessage = useCallback(
    (msg) => dispatch(addLogMessage(msg.data)),
    [dispatch, addLogMessage]
  );

  useSocketMessage('show_loading_message', handleNewLogMessage);

  useEffect(() => {
    dispatch(loadGapFiles());
  }, []);

  return (
    <>
      <div className="mb4">
        <div className="mb2 mt1 flex align-bottom justify-between">
          <Typography
            variant={'h5'}
            children="Currently Configured Files"
            style={{ color: palette.action.active }}
          />
        </div>
        <GapFilesUpload />
        <ConfigTable rows={gapFiles} columns={columns} loading={loading} />
      </div>
    </>
  );
};

export default GapFiles;
