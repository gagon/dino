import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  addConfiguration,
  configConnections,
  loadConnections,
  saveChanges,
} from './ConnectionsDucks';
import { connectionColumns } from './ConnectionsColumns';
import Typography from '@mui/material/Typography';
import { useTheme } from '@mui/styles';
import AddIcon from '@mui/icons-material/Add';
import SaveIcon from '@mui/icons-material/SaveOutlined';
import { LoadingButton } from '@mui/lab';
import ConfigTable from '../ConfigTable';

export default function Connections() {
  const { palette } = useTheme();
  const dispatch = useDispatch();
  const loading = useSelector((state) => state[configConnections].loading);
  const tableData = useSelector((state) => state[configConnections].tableData);
  const loadingAdd = useSelector((state) => state[configConnections].loadingAdd);
  const loadingSave = useSelector((state) => state[configConnections].loadingSave);
  const saveDisabled = useSelector(
    (state) => Object.keys(state[configConnections].changesData).length === 0
  );

  useEffect(() => {
    if (tableData.length === 0) {
      dispatch(loadConnections());
    }
  }, []);

  return (
    <div className="mb4">
      <div className="mb1 mt1 flex align-bottom justify-between">
        <Typography
          variant={'h5'}
          children="Connections"
          style={{ color: palette.action.active }}
        />
        <div className="right-align mb1">
          <LoadingButton
            loading={loadingSave}
            disabled={saveDisabled}
            variant="contained"
            startIcon={<SaveIcon />}
            children="Save changes"
            onClick={() => dispatch(saveChanges())}
          />
        </div>
      </div>
      <ConfigTable rows={tableData} columns={connectionColumns()} loading={loading} />
      <div className="right-align mt1">
        <LoadingButton
          loading={loadingAdd}
          variant="outlined"
          startIcon={<AddIcon />}
          children="Add configuration"
          onClick={() => dispatch(addConfiguration())}
        />
      </div>
    </div>
  );
}
