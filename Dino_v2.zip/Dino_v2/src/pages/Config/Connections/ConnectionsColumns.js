import React from 'react';
import { LoadingButton } from '@mui/lab';
import { useDispatch, useSelector } from 'react-redux';
import { configConnections, deleteConfiguration, onCellChange } from './ConnectionsDucks';

export function connectionColumns() {
  return [
    {
      field: 'unit',
      flex: 1,
      headerName: 'Unit',
      renderCell: ({ row }) => <InputText field="unit" data={row} />,
    },
    {
      field: 'tag_unit',
      flex: 1,
      headerName: 'Tag Unit',
      renderCell: ({ row }) => <InputText field="tag_unit" data={row} />,
    },
    {
      field: 'rms',
      flex: 1,
      headerName: 'RMS',
      renderCell: ({ row }) => <InputText field="rms" data={row} />,
    },
    {
      field: 'tag_rms',
      flex: 1,
      headerName: 'Tag RMS',
      renderCell: ({ row }) => <InputText field="tag_rms" data={row} />,
    },
    {
      field: 'gath_rms',
      flex: 1,
      headerName: 'Gathering RMS Regex',
      renderCell: ({ row }) => <InputText field="gath_rms" data={row} />,
    },
    {
      field: 'tl',
      flex: 1,
      headerName: 'Trunk Line',
      renderCell: ({ row }) => <InputText field="tl" data={row} />,
    },
    {
      field: 'tag_tl',
      flex: 1,
      headerName: 'Tag Trunk Line',
      renderCell: ({ row }) => <InputText field="tag_tl" data={row} />,
    },
    {
      field: 'gath_tl',
      flex: 1,
      headerName: 'Gathering Trunk Line Regex',
      renderCell: ({ row }) => <InputText field="gath_tl" data={row} />,
    },
    {
      field: 'mp_lp',
      flex: 1,
      headerName: 'MP/LP',
      renderCell: ({ row }) => <InputText field="mp_lp" data={row} />,
    },
    {
      field: 'tag_mp_lp',
      flex: 1,
      headerName: 'Tag MP/LP',
      renderCell: ({ row }) => <InputText field="tag_mp_lp" data={row} />,
    },
    {
      field: 'action',
      flex: 1,
      headerName: 'Delete',
      maxWidth: 100,
      align: 'center',
      renderCell: ({ row }) => <DeleteRow data={row} />,
    },
  ];
}

function InputText({ field, data }) {
  const dispatch = useDispatch();
  const value = useSelector((state) => {
    if (state[configConnections].changesData[data.id]) {
      return state[configConnections].changesData[data.id][field];
    }
  });
  const onChange = (event) => {
    dispatch(onCellChange(data.id, field, event.target.value));
  };

  return (
    <div className="overflow-hidden fullwidth">
      <input
        name={field}
        value={value !== undefined ? value : data[field] || ''}
        onChange={onChange}
        style={{
          border: 'none',
          outline: 'none',
          background: value !== undefined ? 'rgb(255 229 203)' : 'transparent',
          height: 28,
          width: '100%',
          paddingLeft: 8,
        }}
      />
    </div>
  );
}

function DeleteRow({ data }) {
  const dispatch = useDispatch();
  const loading = useSelector((state) => state[configConnections].loadingDelete);
  const deleteRow = (id) => {
    dispatch(deleteConfiguration(id));
  };
  return (
    <LoadingButton
      loading={loading === data.id}
      size="small"
      children="Delete"
      onClick={() => deleteRow(data.id)}
    />
  );
}
