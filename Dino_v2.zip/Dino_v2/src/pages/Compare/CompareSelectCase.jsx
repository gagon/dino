import { Button, Divider } from '@mui/material';
import React from 'react';
import { useSelector } from 'react-redux';
import { compareModule } from './CompareDucks';
import styled from 'styled-components';
import Checkbox from '@mui/material/Checkbox';
import SearchCaseModal from '../Case/CaseActions/SearchCase/SearchCaseModal';
import useSimpleModal from '../../common/_hooks/useSimpleModal';
import { useNavigate } from 'react-router';
import LinearProgress from '@mui/material/LinearProgress';
import moment from 'moment';

const Styled = styled.div`
  margin-bottom: 20px;
  color: ${(props) => props.theme.palette.grey[700]};
  .title {
    text-transform: uppercase;
  }
  .left-case {
    border-right: 1px solid ${(props) => props.theme.palette.divider};
  }
  .case-row {
    margin-bottom: 3px;
    display: flex;
  }
  .case-block {
    width: 500px;
  }
  span {
    margin-left: 3px;
    font-size: 13px;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  .label {
    width: 150px;
    min-width: 150px;
    margin-right: 12px;
    text-align: right;
    font-size: 13px;
  }
`;

export default function CompareSeelectCase({ caseId1, caseId2 }) {
  const loading = useSelector((state) => state[compareModule].loading);
  const case1 = useSelector((state) => state[compareModule].caseData);
  const case2 = useSelector((state) => state[compareModule].caseData2);
  const searchModal = useSimpleModal();
  const navigate = useNavigate();
  const onSelectCase = (caseId) => {
    const notSelected = String(searchModal.data).includes('case');
    const qp = window.location.search.includes('?') ? '&' : '?';
    const replacement = notSelected ? `${qp}${searchModal.data}=${caseId}` : caseId;
    const url = notSelected
      ? window.location.search + replacement
      : window.location.search.replace(String(searchModal.data), replacement);
    navigate(window.location.pathname + url);
    searchModal.close();
  };
  return (
    <Styled>
      <div className="flex justify-center mb3 mt2">
        <div className="case-block flex1 left-case pr3">
          <div className="case-row mb1 bold">
            <div className="label"></div>
            <div className="flex items-center justify-between fullWidth">
              <span className="title">Case 1 {case1.id && `(${case1.id})`}</span>
              <Button
                size="small"
                className="right"
                variant="outlined"
                children="select case"
                onClick={() => searchModal.open(case1.id || 'case1')}
              />
            </div>
          </div>
          {case1.id && (
            <>
              <div className="case-row">
                <div className="label">Gap File :</div>
                <span>{case1.gap_file?.name}</span>
              </div>
              <div className="case-row">
                <div className="label">Created By :</div>
                <span>{case1.creator?.name}</span>
              </div>
              <div className="case-row">
                <div className="label">Case Name :</div>
                <span>{case1?.name}</span>
              </div>
              <div className="case-row">
                <div className="label">Date :</div>
                <span>
                  {case1?.timestamp ? moment(case1?.timestamp).format('DD/MM/YYYY HH:mm') : ''}
                </span>
              </div>
              <div className="case-row">
                <div className="label">Case Description :</div>
                <span>{case1?.description}</span>
              </div>
              <div className="case-row">
                <div className="label">Implemented Case :</div>
                <Checkbox checked={!!case1.selected} size="small" disabled style={{ padding: 0 }} />
              </div>
            </>
          )}
        </div>
        <div className="case-block flex1 pl3">
          <div className="case-row mb1 bold">
            <div className="label"></div>
            <div className="flex items-center justify-between fullWidth">
              <span className="title">Case 2 {case2.id && `(${case2.id})`}</span>
              <Button
                size="small"
                className="right"
                variant="outlined"
                children="select case"
                onClick={() => searchModal.open(case2.id || 'case2')}
              />
            </div>
          </div>
          {case2.id && (
            <>
              <div className="case-row">
                <div className="label">Gap File :</div>
                <span>{case2.gap_file?.name}</span>
              </div>
              <div className="case-row">
                <div className="label">Created By:</div>
                <span>{case2.creator?.name}</span>
              </div>
              <div className="case-row">
                <div className="label">Case Name:</div>
                <span>{case2?.name}</span>
              </div>
              <div className="case-row">
                <div className="label">Date:</div>
                <span>
                  {case2?.timestamp ? moment(case2?.timestamp).format('DD/MM/YYYY HH:mm') : ''}
                </span>
              </div>
              <div className="case-row">
                <div className="label">Case Description:</div>
                <span>{case2?.description}</span>
              </div>
              <div className="case-row">
                <div className="label">Implemented Case:</div>
                <Checkbox checked={!!case2.selected} size="small" disabled style={{ padding: 0 }} />
              </div>
            </>
          )}
        </div>
      </div>
      <Divider />
      {loading && (caseId1 || caseId2) && <LinearProgress />}
      {searchModal.isOpen && <SearchCaseModal {...searchModal} onSelect={onSelectCase} />}
    </Styled>
  );
}
