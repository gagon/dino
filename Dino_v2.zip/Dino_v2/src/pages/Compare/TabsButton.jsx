import { ToggleButton, ToggleButtonGroup } from '@mui/material';
import { styled as muiStyled } from '@mui/material/styles';
import React from 'react';

const MuiToggleButtonGroup = muiStyled(ToggleButtonGroup)(({ theme }) => ({
  '& .MuiToggleButtonGroup-grouped': {
    margin: theme.spacing(0.5),
    border: 0,
    borderRadius: 6,
    fontSize: 12,
    backgroundColor: theme.palette.background.paper,

    '&.Mui-disabled': {
      border: 0,
    },
    '&:not(:first-of-type)': {
      borderRadius: 6,
      color: theme.palette.primary.main,
    },
    '&:first-of-type': {
      borderRadius: 6,
      color: theme.palette.primary.main,
    },
  },

  '& .Mui-selected': {
    backgroundColor: `${theme.palette.primary.main} !important`,
    color: `${theme.palette.common.white} !important`,
  },
}));

const MuiToggleButton = muiStyled(ToggleButton)(() => ({
  textTransform: 'none',
  height: 25,
}));

export default function TabsButton({ page, setPage }) {
  const handleChange = (e, path) => {
    setPage(path);
  };

  return (
    <>
      <MuiToggleButtonGroup exclusive color="primary" value={page} onChange={handleChange}>
        <MuiToggleButton value={1} children={'FIELD'} />
        <MuiToggleButton value={2} children={'KPC'} />
        <MuiToggleButton value={3} children={'U2'} />
        <MuiToggleButton value={4} children={'U3'} />
        <MuiToggleButton value={5} children={'TABLE'} />
      </MuiToggleButtonGroup>
    </>
  );
}
