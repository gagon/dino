import React, { Fragment, useMemo } from 'react';
import Paper from '@mui/material/Paper';
import Divider from '@mui/material/Divider';
import { useSelector } from 'react-redux';
import { compareModule } from '../../../CompareDucks';

export default function Kpls() {
  const calculation1 = useSelector((state) => state[compareModule].calculation);
  const calculation2 = useSelector((state) => state[compareModule].calculation2);

  const data = useMemo(() => {
    let case1, case2;

    if (calculation1) {
      const tableData = calculation1?.labelDict['KPI Table'];
      case1 = tableData
        ? Object.entries(tableData).map(([key, item]) => {
            const calcValue = calculation1?.calcDict[key].results?.default?.value;
            const value = parseFloat(calcValue).toFixed(3);
            return { ...item, value: value || '' };
          })
        : [];
    }

    if (calculation2) {
      const tableData = calculation2?.labelDict['KPI Table'];
      case2 = tableData
        ? Object.entries(tableData).map(([key, item]) => {
            const calcValue = calculation2?.calcDict[key].results?.default?.value;
            const value = parseFloat(calcValue).toFixed(3);
            return { ...item, value: value || '' };
          })
        : [];
    }

    return (case1 ?? case2).map((item) => ({
      id: item.id,
      case1: case1 ? case1.find((i) => i.id === item.id) : null,
      case2: case2 ? case2.find((i) => i.id === item.id) : null,
    }));
  });

  return (
    <Paper
      sx={{
        borderTopRightRadius: 20,
        borderBottomRightRadius: 20,
        borderBottomLeftRadius: 20,
        borderTopLeftRadius: 20,
        padding: '25px 30px 20px 30px',
      }}
    >
      <div className="fs-12 bold mb2 flex justify-between">
        <div children={'KPLs'} />
        <div className="flex">
          <div style={{ width: 100 }} children={'Case 1'} />
          <div style={{ width: 100 }} children={'Case 2'} />
        </div>
      </div>
      <div>
        {data.map((item, index) => {
          return (
            <Fragment key={index}>
              <div
                className="flex items-center justify-between"
                style={{
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                <div className="fs-12" children={(item.case1 ?? item.case2).name} />
                <div className="flex">
                  <div
                    className="fs-12"
                    style={{ width: 100 }}
                    children={item.case1 ? `${item.case1.value} %` : ''}
                  />
                  <div
                    className="fs-12"
                    style={{ width: 100 }}
                    children={item.case2 ? `${item.case2.value} %` : ''}
                  />
                </div>
              </div>
              {index !== data.length - 1 ? (
                <Divider
                  sx={{ border: '1px solid #EEF0F9' }}
                  variant={'fullWidth'}
                  orientation={'horizontal'}
                />
              ) : null}
            </Fragment>
          );
        })}
      </div>
    </Paper>
  );
}
