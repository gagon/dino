import React from 'react';
import { useSelector } from 'react-redux';
import { compareModule } from '../../../CompareDucks';
import { generateChart } from './generateChart';
import { getUnitSeries, setPCData } from './ChartsUtils';
const ReactHighcharts = require('react-highcharts');

export default function Charts({ calcGroup }) {
  const caseConfig = useSelector((state) => state[compareModule].caseConfig);
  const fieldBalance1 = useSelector((state) => state[compareModule].fieldBalance);
  const fieldBalance2 = useSelector((state) => state[compareModule].fieldBalance2);

  const charts = [];
  for (let [uKey, uObj] of Object.entries(caseConfig.units.chart)) {
    try {
      let series = [];
      let PCData = {};
      if (fieldBalance1) {
        const { pcArr, pointArr } = setPCData(fieldBalance1, 1, caseConfig.units);
        series = getUnitSeries(uKey, calcGroup, 1, pcArr, pointArr);
        PCData[1] = pcArr[1][calcGroup][uKey];
      }
      if (fieldBalance2) {
        const { pcArr, pointArr } = setPCData(fieldBalance2, 2, caseConfig.units);
        let series2 = getUnitSeries(uKey, calcGroup, 2, pcArr, pointArr);
        PCData[2] = pcArr[2][calcGroup][uKey];
        series = [...series, ...series2];
      }
      const chartConfig = generateChart(uObj.lbl + ' performance curve', series, PCData);
      charts.push(chartConfig);
    } catch (e) {
      console.error(e);
    }
  }

  return (
    <>
      <div className="fullWidth flex items-center ">
        {charts.map((item, index) => {
          const style = { marginRight: index !== charts.length - 1 ? 20 : 0 };
          const style2 = { padding: 10, borderRadius: 20, background: 'white' };
          return (
            <div key={index} className="flex-1" style={style}>
              <div style={style2}>
                <ReactHighcharts config={item} />
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
