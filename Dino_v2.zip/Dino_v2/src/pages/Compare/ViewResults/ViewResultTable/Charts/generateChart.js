export const generateChart = function (text, series, PCData) {
  //var self = this;
  return {
    chart: {
      backgroundColor: 'white',
      style: { fontSize: 8 },
      spacing: [5, 5, 5, 0],
    },
    title: {
      text: text,
      style: { fontSize: 10 },
      margin: 0,
    },
    xAxis: {
      title: { text: 'Qgas,ksm3/d' },
      labels: { style: { fontSize: 8 }, padding: 0 },
      gridLineWidth: 1,
      tickPixelInterval: 60,
    },
    yAxis: {
      title: { text: 'Qoil,sm3/d' },
      labels: { style: { fontSize: 8 } },
      tickPixelInterval: 50,
      min: 0,
    },
    tooltip: {
      hideDelay: 0,
      outside: true,
      //shared: true,
      formatter: function (a, b, c) {
        if (
          this.point.name &&
          (this.series.name == 'GOR Ascending' || this.series.name == 'GOR Descending')
        ) {
          var line = this.series.name == 'GOR Ascending' ? 'lineAsc' : 'lineDesc';
          var lookupData = PCData[this.point.caseNum][line][this.point.name];

          if (!lookupData) return false;

          var tooltipHead = '<b>' + this.series.name + '</b><br/>';
          //if (self.compare) tooltipHead = '<b>Case ' + caseNum + ': </b>';
          var tooltip =
            '● Well: ' +
            this.point.name +
            '<br/>● GOR: ' +
            formatFixed(lookupData.gor, 2) +
            '<br/>● Gas: ' +
            formatFixed(lookupData.gas, 2) +
            '<br/>● Cumulative Gas: ' +
            formatFixed(this.point.x, 2) +
            '<br/>● Oil: ' +
            formatFixed(lookupData.oil, 2) +
            '<br/>● Cumulative Oil: ' +
            formatFixed(this.point.y, 2);
          return [tooltipHead, tooltip];
        } else return false;
      },
    },

    legend: { enabled: false },
    series: series,
    plotOptions: { series: { animation: false } },
  };
};

function formatFixed(num, fix) {
  return num.toFixed(fix).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}
