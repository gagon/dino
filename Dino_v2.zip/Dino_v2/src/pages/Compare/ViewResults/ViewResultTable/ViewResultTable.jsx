import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Grid, Switch, Paper } from '@mui/material';

import Kpls from './KPLS/Kpls';
import AllocationFactors from './AllocationFactors/AllocationFactors';
import Charts from './Charts/Charts';

export default function ViewResultTable() {
  const [calcGroup, setCalcGroup] = useState('calc');

  const switchCalcGroup = () => {
    setCalcGroup((prev) => (prev === 'calc' ? 'orig' : 'calc'));
  };

  return (
    <>
      <div className="flex">
        <div className="col-6 " style={{ paddingRight: 10 }}>
          <Kpls />
        </div>
        <div className="col-6" style={{ paddingLeft: 10 }}>
          <AllocationFactors />
        </div>
      </div>

      <div className="flex items-center ml3 my1">
        <span children={'Unit performance curves'} className="fs-14 bold mr2" />
        <Grid
          component="label"
          container
          alignItems="center"
          spacing={0}
          sx={{ cursor: 'pointer', width: '50%', marginLeft: 8 }}
        >
          <Grid item>Raw Data</Grid>
          <Grid item>
            <Switch color="primary" onChange={switchCalcGroup} checked={calcGroup === 'calc'} />
          </Grid>
          <Grid item>AF Adjusted</Grid>
        </Grid>
      </div>

      <Charts calcGroup={calcGroup} />
    </>
  );
}
