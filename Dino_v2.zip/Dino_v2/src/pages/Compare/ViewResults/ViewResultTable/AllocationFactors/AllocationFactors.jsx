import React, { Fragment, useMemo } from 'react';
import Paper from '@mui/material/Paper';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import { useSelector, useDispatch } from 'react-redux';
import { compareModule, copyAllocationFactory } from '../../../CompareDucks';

export default function AllocationFactors() {
  const dispatch = useDispatch();
  const calculation1 = useSelector((state) => state[compareModule].calculation);
  const calculation2 = useSelector((state) => state[compareModule].calculation2);
  const style = { marginLeft: 20, width: 80 };

  const data = useMemo(() => {
    let case1, case2;

    if (calculation1) {
      const currentData = calculation1?.labelDict['AF Table:Current'];
      const newData = calculation1?.labelDict['AF Table:New'];
      case1 = currentData
        ? Object.entries(currentData).map(([key, item]) => {
            const calcValue = calculation1?.calcDict[key].results?.default?.value;
            const value = parseFloat(calcValue).toFixed(2);

            const newValueObj = Object.values(newData).find(({ name }) => name === item?.name);
            const newCalcName = calculation1?.calcNameLookup[newValueObj.calc_id];
            const newCalcValue = calculation1?.calcDict[newCalcName].results?.default?.value;
            const newValue = parseFloat(newCalcValue).toFixed(2);
            return { ...item, value: value || '', newValue: newValue || '' };
          })
        : [];
    }

    if (calculation2) {
      const currentData = calculation2?.labelDict['AF Table:Current'];
      const newData = calculation2?.labelDict['AF Table:New'];
      case2 = currentData
        ? Object.entries(currentData).map(([key, item]) => {
            const calcValue = calculation2?.calcDict[key].results?.default?.value;
            const value = parseFloat(calcValue).toFixed(2);

            const newValueObj = Object.values(newData).find(({ name }) => name === item?.name);
            const newCalcName = calculation2?.calcNameLookup[newValueObj.calc_id];
            const newCalcValue = calculation2?.calcDict[newCalcName].results?.default?.value;
            const newValue = parseFloat(newCalcValue).toFixed(2);
            return { ...item, value: value || '', newValue: newValue || '' };
          })
        : [];
    }

    return (case1 ?? case2).map((item) => ({
      id: item.id,
      case1: case1 ? case1.find((i) => i.id === item.id) : null,
      case2: case2 ? case2.find((i) => i.id === item.id) : null,
    }));
  });

  return (
    <Paper
      sx={{
        borderTopRightRadius: 20,
        borderBottomRightRadius: 20,
        borderBottomLeftRadius: 20,
        borderTopLeftRadius: 20,
        padding: '25px 30px 20px 30px',
      }}
    >
      <div className="fs-12 bold mb2" children={'Allocation factors'} />
      <div>
        <div className="flex justify-end mb1">
          <div className="fs-12 bold" children={'Current'} style={{ width: 200 }} />
          <div className="fs-12 bold" children={'New'} style={{ width: 180 }} />
        </div>
        <div className="flex justify-end mb2">
          <div className="fs-12 bold flex">
            <div className="flex-1" style={style} children="Case 1" />
            <div className="flex-1" style={style} children="Case 2" />
          </div>
          <div className="fs-12 bold">
            <div className="fs-12 bold flex">
              <div className="flex-1" style={style} children="Case 1" />
              <div className="flex-1" style={style} children="Case 2" />
            </div>
          </div>
        </div>
        {data.map((dataItem, index) => {
          const item = dataItem.case1 ?? dataItem.case2;
          return (
            <Fragment key={index}>
              <div
                className="flex items-center justify-between "
                style={{
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                <div className="fs-12" children={item.name} />
                <div className="flex">
                  <div className="fs-12 flex">
                    <div className="flex1" style={style}>
                      {dataItem.case1.value}
                    </div>
                    <div className="flex1" style={style}>
                      {dataItem.case2.value}
                    </div>
                  </div>
                  <div className="fs-12 flex">
                    <div className="flex1" style={style}>
                      {dataItem.case1.newValue}
                    </div>
                    <div className="flex1" style={style}>
                      {dataItem.case2.newValue}
                    </div>
                  </div>
                </div>
              </div>
              {index !== data.length - 1 ? (
                <Divider
                  sx={{ border: '1px solid #EEF0F9' }}
                  variant={'fullWidth'}
                  orientation={'horizontal'}
                />
              ) : null}
            </Fragment>
          );
        })}
      </div>
      <div className="flex justify-end">
        <div style={{ marginRight: 34 }}>
          <Button
            children={'Copy'}
            onClick={() => dispatch(copyAllocationFactory(true))}
            style={{
              background: '#D9D9D9',
              color: 'black',
              textTransform: 'none',
              padding: '6px 18px ',
            }}
          />
          <Button
            children={'Copy'}
            onClick={() => dispatch(copyAllocationFactory(true, true))}
            style={{
              background: '#D9D9D9',
              color: 'black',
              textTransform: 'none',
              marginLeft: 40,
              padding: '6px 18px ',
            }}
          />
        </div>
        <div style={{ marginRight: 16 }}>
          <Button
            children={'Copy'}
            onClick={() => dispatch(copyAllocationFactory())}
            style={{
              background: '#D9D9D9',
              color: 'black',
              textTransform: 'none',
              padding: '6px 18px ',
            }}
          />
          <Button
            children={'Copy'}
            onClick={() => dispatch(copyAllocationFactory(false, true))}
            style={{
              background: '#D9D9D9',
              color: 'black',
              textTransform: 'none',
              marginLeft: 40,
              padding: '6px 18px ',
            }}
          />
        </div>
      </div>
    </Paper>
  );
}
