import Typography from '@mui/material/Typography';
import React, { useMemo } from 'react';
import ColumnsFilter from '../../../../common/Table/ColumnsFilter';
import { useTheme } from '@mui/styles';
import { useSelector } from 'react-redux';
import useColumnsFilter from '../../../../common/Table/useColumnsFilter';
import { compareModule } from '../../CompareDucks';
import { wellColumns } from './WellColums';
import Table from './WellCommonTable';

export default function UnitTable({ tab }) {
  const caseData = useSelector((state) => state[compareModule].caseData);
  const caseData2 = useSelector((state) => state[compareModule].caseData2);
  const caseConfig = useSelector((state) => state[compareModule].caseConfig);
  const classByUnits = useSelector((state) => state[compareModule].classByUnits);
  const unitsByClass = useSelector((state) => state[compareModule].unitsByClass);
  const { columnFilter, changeFilter } = useColumnsFilter();
  const { palette } = useTheme();

  const list = useMemo(() => {
    let case1 = null;
    let case2 = null;
    if (caseData?.case_wells) {
      case1 = caseData?.case_wells.filter((caseWell) => {
        const currentConnId = caseWell.gap_conn_id;
        let unitName = caseWell.gap_well.connectionMap[currentConnId]?.unit;
        return unitName === tab;
      });
    }

    if (caseData2?.case_wells) {
      case2 = caseData2?.case_wells.filter((caseWell) => {
        const currentConnId = caseWell.gap_conn_id;
        let unitName = caseWell.gap_well.connectionMap[currentConnId]?.unit;
        return unitName === tab;
      });
    }

    if (case1 && case2) {
      return case1.map((item) => {
        return {
          code: item.code,
          case1: item,
          case2: case2.find((i) => i.id === item.id),
          getPercentDiff: getPercentDiff,
        };
      });
    } else if (case1) {
      return case1.map((item) => ({ code: item.code, case1: item }));
    } else if (case2) {
      return case2.map((item) => ({ code: item.code, case2: item }));
    } else return [];
  }, [caseData, caseData2]);

  const columns = wellColumns(
    caseConfig?.wellCfg,
    caseConfig?.wellColumns,
    classByUnits,
    unitsByClass
  ).filter(({ field }) => !columnFilter.includes(field));

  return (
    <div>
      <div className="flex items-center mb2 mt1">
        <Typography
          variant={'h5'}
          children={'Wells'}
          style={{
            color: palette.action.active,
          }}
        />
        <ColumnsFilter
          columns={wellColumns()}
          changeFilter={changeFilter}
          columnFilter={columnFilter}
        />
      </div>
      <Typography variant={'h6'} children={tab} style={{ marginBottom: 15 }} />
      <Table columns={columns} list={list} stickyHeader tab={tab} sortable />
    </div>
  );
}

function getPercentDiff(row, column) {
  let num1 = parseFloat(
    row.case1
      ? column.valueGetter
        ? column.valueGetter({ row: { ...row, ...row.case1 } })
        : column.renderCell({ row: { ...row, ...row.case1 } })
      : ''
  ).toFixed(1);
  let num2 = parseFloat(
    row.case2
      ? column.valueGetter
        ? column.valueGetter({ row: { ...row, ...row.case2 } })
        : column.renderCell({ row: { ...row, ...row.case2 } })
      : ''
  ).toFixed(1);

  if (num1 == num2 || typeof num1 === 'object' || typeof num1 === 'function') {
    return null;
  }

  let percent = '';
  if (Number(num1) == num1 && Number(num2) == num2 && num1 !== '' && num2 !== '') {
    num1 = Number(num1);
    num2 = Number(num2);
    percent = Math.abs(num1 - num2) / ((num1 + num2) / 2);
  }

  const color = new window.ColorTranslator('#EDB901');
  const title = !percent ? '' : (percent * 100).toFixed(2) + '%';
  if (percent > 1 || !percent) percent = 1;
  percent = 95 - percent * 40;
  color.setL(percent);

  return {
    color: color.HEX,
    title: title,
  };
}
