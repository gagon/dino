import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import React, { Fragment, useState } from 'react';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import IconButton from '@mui/material/IconButton';

export default function WellCommonTable({ columns, list, stickyHeader, sortable: sortingTable }) {
  const [sortable, setSortable] = useState({});
  const setColumnsorting = (column, caseName) => {
    if (sortable.column === column && sortable.case === caseName && sortable.sort === 'desc') {
      setSortable({ column, case: caseName, sort: 'asc' });
    } else if (
      sortable.column === column &&
      sortable.case === caseName &&
      sortable.sort === 'asc'
    ) {
      setSortable({});
    } else {
      setSortable({ column, case: caseName, sort: 'desc' });
    }
  };

  return (
    <div
      style={{
        padding: 30,
        background: 'white',
        borderRadius: 20,
        marginBottom: 30,
      }}
    >
      <Box
        sx={{
          borderRadius: '12px',
          overflow: 'hidden',
          width: 1,
          '& .super-app-theme--cell': {
            background: '#D4EEFF80',
          },
        }}
      >
        <TableContainer>
          <Table stickyHeader={stickyHeader}>
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell
                    key={column.field}
                    align={column.align || 'left'}
                    colSpan={column.onlyOneCase ? 1 : 2}
                    sx={{
                      lineHeight: 1,
                      fontWeight: 600,
                      padding: '12px 16px',
                    }}
                  >
                    {column.headerName}
                  </TableCell>
                ))}
              </TableRow>

              <TableRow>
                {columns.map((column, index) => (
                  <Fragment key={column.headerName}>
                    <TableCell
                      align={column.align || 'left'}
                      onClick={() => sortingTable && setColumnsorting(column.headerName, 'case1')}
                      sx={{
                        lineHeight: 1,
                        fontWeight: 600,
                        top: 49,
                        whiteSpace: 'nowrap',
                        padding: '9px 16px',
                        height: 50,
                        cursor: 'pointer',
                      }}
                    >
                      {!column.onlyOneCase && 'case 1'}
                      {sortable.column === column.headerName &&
                        sortable.sort === 'desc' &&
                        sortable.case === 'case1' && (
                          <IconButton size="small">
                            <ArrowDownwardIcon fontSize="small" />
                          </IconButton>
                        )}
                      {sortable.column === column.headerName &&
                        sortable.sort === 'asc' &&
                        sortable.case === 'case1' && (
                          <IconButton size="small">
                            <ArrowUpwardIcon fontSize="small" />
                          </IconButton>
                        )}
                    </TableCell>
                    {!column.onlyOneCase && (
                      <TableCell
                        align={column.align || 'left'}
                        onClick={() => sortingTable && setColumnsorting(column.headerName, 'case2')}
                        sx={{
                          lineHeight: 1,
                          fontWeight: 600,
                          top: 49,
                          whiteSpace: 'nowrap',
                          padding: '9px 16px',
                          height: 50,
                          cursor: 'pointer',
                        }}
                      >
                        case 2
                        {sortable.column === column.headerName &&
                          sortable.sort === 'desc' &&
                          sortable.case === 'case2' && (
                            <IconButton size="small">
                              <ArrowDownwardIcon fontSize="small" />
                            </IconButton>
                          )}
                        {sortable.column === column.headerName &&
                          sortable.sort === 'asc' &&
                          sortable.case === 'case2' && (
                            <IconButton size="small">
                              <ArrowUpwardIcon fontSize="small" />
                            </IconButton>
                          )}
                      </TableCell>
                    )}
                  </Fragment>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {list
                .sort((a, b) => compare(a, b, sortable, columns))
                .map((row, index) => {
                  return (
                    <TableRow hover role="checkbox" tabIndex={-1} key={`row` + index}>
                      {columns.map((column) => {
                        const case1Value = row.case1
                          ? column.renderCell
                            ? column.renderCell({ row: { ...row, ...row.case1 } })
                            : column.valueGetter({ row: { ...row, ...row.case1 } })
                          : '';
                        const case2Value = row.case2
                          ? column.renderCell
                            ? column.renderCell({ row: { ...row, ...row.case2 } })
                            : column.valueGetter({ row: { ...row, ...row.case2 } })
                          : '';
                        const persent = row.getPercentDiff && row.getPercentDiff(row, column);
                        return (
                          <Fragment key={column.headerName + `column` + index}>
                            <TableCell
                              align={column.align || 'left'}
                              className={column.cellClassName}
                              title={persent ? persent.title : undefined}
                              sx={{
                                backgroundColor: persent ? persent.color : 'transparent',
                                width: column.width,
                                minWidth: column.minWidth,
                                lineHeight: 1,
                                padding: '12px 16px',
                              }}
                              children={case1Value}
                            />
                            {!column.onlyOneCase && (
                              <TableCell
                                align={column.align || 'left'}
                                className={column.cellClassName}
                                title={persent ? persent.title : undefined}
                                sx={{
                                  backgroundColor: persent ? persent.color : 'transparent',
                                  width: column.width,
                                  minWidth: column.minWidth,
                                  lineHeight: 1,
                                  padding: '12px 16px',
                                }}
                                children={case2Value}
                              />
                            )}
                          </Fragment>
                        );
                      })}
                    </TableRow>
                  );
                })}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </div>
  );
}

function compare(rowA, rowB, sortableObj, columns) {
  const sortable =
    Object.keys(sortableObj).length > 0
      ? sortableObj
      : {
          sort: 'desc',
          case: 'case1',
          column: 'Well Name',
        };
  const column = columns.find((c) => c.headerName === sortable.column);
  if (column && sortable.sort && column.valueGetter) {
    const a = rowA[sortable.case]
      ? column.valueGetter({ row: { ...rowA, ...rowA[sortable.case] } })
      : '';
    const b = rowB[sortable.case]
      ? column.valueGetter({ row: { ...rowB, ...rowB[sortable.case] } })
      : '';

    if (a < b && sortable.sort === 'desc') {
      return -1;
    }
    if (a > b && sortable.sort === 'desc') {
      return 1;
    }
    if (a < b && sortable.sort === 'asc') {
      return 1;
    }
    if (a > b && sortable.sort === 'asc') {
      return -1;
    }
  }

  return 0;
}
