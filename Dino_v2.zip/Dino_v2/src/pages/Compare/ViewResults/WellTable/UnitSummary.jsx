import Box from '@mui/material/Box';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { compareModule } from '../../CompareDucks';
import { buildUnitSummary } from '../../../../common/calculationUtils/units';
import { unitColumns } from './WellColums';
import { MuiDataGrid } from './styles';
import WellCommonTable from './WellCommonTable';

export default function UnitSummary({ tab }) {
  const caseData = useSelector((state) => state[compareModule].caseData);
  const caseData2 = useSelector((state) => state[compareModule].caseData2);
  const [tableData, setTableData] = useState([]);

  useEffect(() => {
    let tableData = [];
    if (caseData && caseData?.case_wells) {
      const unitsTotal = buildUnitSummary(caseData?.case_wells);
      const currentSummary = unitsTotal[tab];
      tableData.push({ title: 'TOTAL', id: 'total', case1: currentSummary });
      const rms = Object.entries(currentSummary?.rms).map(([key, values]) => {
        tableData.push({ title: key, id: key, case1: values });
      });
    }
    if (caseData2 && caseData2?.case_wells) {
      const unitsTotal = buildUnitSummary(caseData2?.case_wells);
      const currentSummary = unitsTotal[tab];
      if (caseData && caseData?.case_wells) {
        const total = tableData.find((i) => i.id === 'total');
        total.case2 = currentSummary;
      } else {
        tableData.push({ title: 'TOTAL', id: 'total', case2: currentSummary });
      }

      const rms = Object.entries(currentSummary?.rms).map(([key, values]) => {
        if (caseData && caseData?.case_wells) {
          const rmsId = tableData.find((i) => i.id === key);
          rmsId.case2 = values;
        } else {
          tableData.push({ title: key, id: key, case2: values });
        }
      });
    }
    if (tableData.length > 0) {
      setTableData(tableData);
    }
  }, [caseData, caseData2]);

  return (
    <div
      style={{
        padding: 30,
        background: 'white',
        borderRadius: 20,
        marginBottom: 30,
      }}
    >
      <Box sx={{ width: '100%', overflow: 'hidden' }}>
        <WellCommonTable columns={unitColumns(tab)} list={tableData} />
      </Box>
    </div>
  );
}
