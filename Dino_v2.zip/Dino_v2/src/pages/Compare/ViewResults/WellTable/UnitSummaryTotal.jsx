import React, { useMemo } from 'react';
import { useSelector } from 'react-redux';

import Table from '../../../../common/Table/Table';
import { compareModule } from '../../CompareDucks';
import { loginModule } from '../../../Login/LoginDucks';

export default function UnitSummaryTotal() {
  const labelDict1 = useSelector((state) => state[compareModule].calculation?.labelDict);
  const labelDict2 = useSelector((state) => state[compareModule].calculation2?.labelDict);
  const calcDict1 = useSelector((state) => state[compareModule].calculation?.calcDict);
  const calcDict2 = useSelector((state) => state[compareModule].calculation2?.calcDict);
  const calcNameLookup1 = useSelector((state) => state[compareModule].calculation?.calcNameLookup);
  const calcNameLookup2 = useSelector((state) => state[compareModule].calculation2?.calcNameLookup);
  const isHourUnits = useSelector((state) => state[loginModule].userConfig.isHourUnits);

  const data = useMemo(() => {
    let field_diff_gas;
    let field_diff_oil;
    const usc1 = 'Unit Summary:case 1';
    const usc2 = 'Unit Summary:case 2';
    const labelDict = labelDict1 ?? labelDict2;
    const calcNameLookup = calcNameLookup1 ?? calcNameLookup2;
    const columnKeys = Object.values(calcNameLookup).filter((id) => {
      return Object.keys(labelDict[usc1]).includes(id) || Object.keys(labelDict[usc2]).includes(id);
    });

    if (calcDict1 && calcDict2) {
      field_diff_gas = JSON.parse(JSON.stringify(calcDict2.field_diff_gas));
      field_diff_oil = JSON.parse(JSON.stringify(calcDict2.field_diff_oil));
      const totGas1 = parseFloat(calcDict1?.field_tot_gas?.results?.default?.value);
      const totGas2 = parseFloat(calcDict2?.field_tot_gas?.results?.default?.value);

      const totOil1 = parseFloat(calcDict1?.field_tot_oil?.results?.default?.value);
      const totOil2 = parseFloat(calcDict2?.field_tot_oil?.results?.default?.value);

      field_diff_gas.results.default.value = totGas1 - totGas2;
      field_diff_oil.results.default.value = totOil1 - totOil2;
    }

    const columns = [
      {
        field: 'case',
        headerName: '',
        valueGetter: ({ row }) => 'case ' + row.id,
        width: 120,
      },
      ...columnKeys.map((id) => {
        const uom = (calcDict1 || calcDict2 || {})[id]?.uom || '';
        const displayedUom = isHourUnits ? uom.replace('/d', '/h') : uom;
        return {
          field: id,
          flex: 1,
          headerName: (
            <div>
              {(labelDict[usc1] || {})[id]?.name || (labelDict[usc2] || {})[id]?.name}
              <div className="fs-12 fw-3">{displayedUom}</div>
            </div>
          ),
          valueGetter: ({ row }) => {
            const value = parseFloat(row[id]?.results?.default?.value || '0').toFixed(2);
            return uom.includes('/d') && isHourUnits ? (value / 24).toFixed(2) : value;
          },
        };
      }),
    ];

    return {
      list: [
        calcDict1 ?? {},
        calcDict2 ? { ...calcDict2, field_diff_gas, field_diff_oil } : {},
      ].map((i, index) => ({ ...i, id: index + 1 })),
      columns,
    };
  }, [labelDict1, labelDict2, calcNameLookup1, calcNameLookup2, calcDict1, calcDict2, isHourUnits]);

  return (
    <Table
      headerHeight={46}
      rows={data.list}
      columns={data.columns}
      hideFooterPagination
      hideFooter
      autoHeight
      disableColumnMenu
      disableSelectionOnClick
      disableMultipleColumnsSorting
      disableExtendRowFullWidth={false}
      sx={{ border: 'none' }}
    />
  );
}
