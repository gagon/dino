import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import React, { useMemo } from 'react';
import ColumnsFilter from '../../../../common/Table/ColumnsFilter';
// import Table from '../../../../common/Table/Table';
import { useTheme } from '@mui/styles';
import { useSelector } from 'react-redux';
import useColumnsFilter from '../../../../common/Table/useColumnsFilter';
import { compareModule } from '../../CompareDucks';
import { wellColumns } from './WellColums';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import UnitSummary from './UnitSummary';
import UnitTable from './UnitTable';

export default function WellsTable({ tab }) {
  return (
    <>
      <UnitSummary tab={tab} />
      <UnitTable tab={tab} />
    </>
  );
}
