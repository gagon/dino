import React from 'react';
import nullOrFixed from '../../../utils/nullOrFixed';
import { unitConvert } from '../../../../common/calculationUtils/units';

export const wellColumns = (wellCfg, wellCols, classByUnits, unitsByClass) => {
  return [
    {
      field: 'id',
      headerName: 'Well Name',
      minWidth: 90,
      valueGetter: ({ row }) => wellCfg[row.well_id].gap_name,
      renderCell: ({ row }) => {
        const name = wellCfg[row.well_id].gap_name;
        const isLp = row.gap_well.connectionMap[row.gap_conn_id].mp_lp === 'LP';
        return <span children={name} style={{ color: isLp ? 'blue' : 'black' }} />;
      },
    },
    {
      field: 'gor',
      headerName: 'GOR (sm3/sm3)',
      valueGetter: ({ row }) => row.gap_well?.gor,
      renderCell: ({ row }) => {
        return nullOrFixed(row.gap_well?.gor, 0);
      },
    },
    {
      field: 'watercut',
      headerName: 'Watercut (%)',
      width: 100,
      type: 'number',
      valueGetter: ({ row }) => {
        return nullOrFixed(row.gap_well.wct * 100, 0);
      },
    },
    {
      field: 'connected',
      headerName: 'Connected',
      width: 86,
      valueGetter: ({ row }) => {
        return row.gap_well.connectionMap[row.gap_conn_id].dual_unit;
      },
    },
    {
      field: 'comingled',
      headerName: 'Comingled',
      minWidth: 140,
      valueGetter: ({ row }) => {
        return row.gap_well.connectionMap[row.gap_conn_id].comingled;
      },
    },
    {
      field: 'map',
      headerName: 'MAP (bara)',
      type: 'number',
      width: 86,
      valueGetter: ({ row }) => {
        return row.gap_well.map;
      },
    },
    {
      field: 'flowTo',
      headerName: 'Flow to',
      minWidth: 220,
      valueGetter: ({ row }) => row.gap_well.connectionMap[row.gap_conn_id].name,
      renderCell: ({ row }) => {
        const flowTo = row.gap_well.connectionMap[row.gap_conn_id].name;
        const isLp = row.gap_well.connectionMap[row.gap_conn_id].mp_lp === 'LP';
        return <span children={flowTo} style={{ color: isLp ? 'blue' : 'black' }} />;
      },
    },
    {
      field: 'targetPressure',
      headerName: 'Target FWHP (bara)',
      minWidth: 80,
      type: 'number',
      valueGetter: ({ row }) => row.target_pressure,
      renderCell: ({ row }) => nullOrFixed(row.target_pressure, 1),
    },
    {
      field: 'fwhp',
      headerName: 'GAP FWHP (bara)',
      type: 'number',
      valueGetter: ({ row }) => row.res_fwhp,
      renderCell: ({ row }) => nullOrFixed(row.res_fwhp, 1),
    },
    {
      field: 'chokePos',
      headerName: 'Choke Pos (%)',
      valueGetter: ({ row }) => {
        let measChokeDBId = null;
        for (let obj of Object.values(wellCols)) {
          if (obj.name === 'Choke Position') {
            measChokeDBId = obj.id;
          }
        }
        return measChokeDBId ? row.well_config_values[measChokeDBId].value : '';
      },
      renderCell: ({ row }) => {
        let measChokeDBId = null;
        for (let obj of Object.values(wellCols)) {
          if (obj.name === 'Choke Position') {
            measChokeDBId = obj.id;
          }
        }
        return measChokeDBId ? nullOrFixed(row.well_config_values[measChokeDBId].value, 1) : '';
      },
    },
    {
      field: 'dPChoke',
      headerName: 'dP Choke (bar)',
      valueGetter: ({ row }) => {
        if (row.res_shutin_reason && !row.res_shutin_reason.startsWith('Swing well')) {
          return row.res_shutin_reason;
        } else {
          var resDPText = nullOrFixed(row.res_dp, 1);
          if (row.res_shutin_reason && row.res_shutin_reason.startsWith('Swing well')) {
            return row.res_shutin_reason;
          }
          return resDPText;
        }
      },
      renderCell: ({ row }) => {
        if (row.res_shutin_reason && !row.res_shutin_reason.startsWith('Swing well')) {
          return <span children={row.res_shutin_reason} style={{ color: 'red' }} />;
        } else {
          var resDPText = nullOrFixed(row.res_dp, 1);
          if (row.res_shutin_reason && row.res_shutin_reason.startsWith('Swing well')) {
            return <span children={row.res_shutin_reason} style={{ color: 'red' }} />;
          }
          return <span children={resDPText} style={{ color: 'black' }} />;
        }
      },
    },
    {
      field: 'flPressure',
      headerName: 'FL pressure (barg)',
      type: 'number',
      valueGetter: ({ row }) => {
        let flp = '';
        if (row.res_fwhp && row.res_dp) {
          flp = row.res_fwhp - row.res_dp;
        }
        return flp;
      },
      renderCell: ({ row }) => {
        let flp = '';
        if (row.res_fwhp && row.res_dp) {
          flp = nullOrFixed(row.res_fwhp - row.res_dp, 1);
        }
        return flp;
      },
    },
    {
      field: 'slotPressure',
      headerName: 'Slot pressure (barg)',
      type: 'number',
      valueGetter: ({ row }) => row.res_slotpres,
      renderCell: ({ row }) => nullOrFixed(row.res_slotpres, 1),
    },
    {
      field: 'slotreachedPres',
      headerName: 'Slotreached pres',
      type: 'number',
      valueGetter: ({ row }) => row.slotreached_pres,
      renderCell: ({ row }) => nullOrFixed(row.slotreached_pres, 1),
    },
    {
      field: 'qOil(sm3/d)',
      headerName: 'Qoil (sm3/d)',
      type: 'number',
      // проверить после отладки unitConvert
      valueGetter: ({ row }) => row.res_oil_rate,
      renderCell: ({ row }) => {
        const props = { unit: 'sm3/d' };
        return unitConvert(props, row.res_oil_rate, 1, classByUnits, unitsByClass);
      },
    },
    {
      field: 'qOil(t/d)',
      headerName: 'Qoil (t/d)',
      type: 'number',
      // проверить после отладки unitConvert
      valueGetter: ({ row }) => row.res_oil_rate * row.gap_well.oil_sg,
      renderCell: ({ row }) => {
        const props = { unit: 't/d' };
        const value = row.res_oil_rate * row.gap_well.oil_sg;
        const result = unitConvert(props, value, 1, classByUnits, unitsByClass);
        return result;
      },
    },
    {
      field: 'qGas',
      headerName: 'Qgas (kscm/d)',
      type: 'number',
      // проверить после отладки unitConvert
      valueGetter: ({ row }) => row.res_gas_rate,
      renderCell: ({ row }) => {
        const props = { unit: 'kscm/d' };
        return unitConvert(props, row.res_gas_rate, 1, classByUnits, unitsByClass);
      },
    },
    {
      field: 'qWater',
      headerName: 'Qwater (sm3/d)',
      type: 'number',
      // проверить после отладки unitConvert
      valueGetter: ({ row }) => row.res_wat_rate,
      renderCell: ({ row }) => {
        const props = { unit: 'sm3/d' };
        return unitConvert(props, row.res_wat_rate, 1, classByUnits, unitsByClass);
      },
    },
    {
      field: 'sbhp',
      headerName: 'SBHP',
      type: 'number',
      // проверить после отладки unitConvert
      valueGetter: ({ row }) => row?.case_sbhp,
      renderCell: ({ row }) => {
        const props = { unit: 'sm3/d' };
        return unitConvert(props, row?.case_sbhp, 1, classByUnits, unitsByClass);
      },
    },
  ];
};

export const unitColumns = (unitName) => {
  return [
    {
      field: 'title',
      headerName: <span children={unitName} className="fs-18 bold" />,
      width: 500,
      onlyOneCase: true,
      renderCell: ({ row }) => {
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{row.title}</span>;
      },
    },
    {
      field: 'shutInOpen',
      headerName: 'Shut in / Open count',
      renderCell: ({ row }) => {
        const value = `${row.shutin}/${row.count - row.shutin}`;
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
    {
      field: 'qgas',
      headerName: 'Qgas (kscm/d)',
      renderCell: ({ row }) => {
        const unit = 'kscm/d';
        const value = unitConvert({ unit }, row['qgas'], 0);
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
    {
      field: 'qoil',
      headerName: 'Qoil (sm3/d)',
      renderCell: ({ row }) => {
        const unit = 'sm3/d';
        const value = unitConvert({ unit }, row['qoil'], 0);
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
    {
      field: 'qoiltd',
      headerName: 'Qoil (t/d)',
      renderCell: ({ row }) => {
        const unit = 't/d';
        const value = unitConvert({ unit }, row['qoiltd'], 0);
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
    {
      field: 'qwat',
      headerName: 'Qwater (sm3/d)',
      renderCell: ({ row }) => {
        const unit = 'sm3/d';
        const value = unitConvert({ unit }, row['qwat'], 0);
        const color = row.id === 'total' ? 'green' : 'black';
        return <span style={{ color }}>{value}</span>;
      },
    },
  ];
};
