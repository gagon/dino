import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useParams } from 'react-router';
import { loadGasTabData } from '../../CompareDucks';
import GasCharts from './GasCharts/GasCharts';
import GasTable from './GasTable/GasTable';

export default function GasTab() {
  const { caseId } = useParams();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(loadGasTabData(caseId));
  }, [caseId, dispatch]);

  return (
    <div>
      <GasTable />
      <GasCharts />
    </div>
  );
}
