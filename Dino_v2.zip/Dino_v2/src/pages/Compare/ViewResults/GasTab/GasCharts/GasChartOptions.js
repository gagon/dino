export const gasChartOptions = function (chartData, isHour) {
  return {
    chart: {
      type: 'line',
      zoomType: 'xy',
      backgroundColor: '#FFFFFF',
    },
    title: { text: 'Gas distribution', fontSize: 12 },
    legend: {
      layout: 'vertical',
      align: 'rigth',
      verticalAlign: 'top',
      borderWidth: 1,
    },
    xAxis: {
      min: chartData.xAxis.sort()[0] - 2,
      categories: chartData.xAxis,
      gridLineWidth: 1,
      title: { text: 'KPC TO U2' },
    },
    yAxis: [
      {
        // left y axis
        title: { text: isHour ? 'Total Qoil (sm3/h)' : 'Total Qoil (sm3/d)' },
        labels: { align: 'left', x: 3, y: 16, format: '{value:.,0f} ' },
        showFirstLabel: false,
      },
      {
        // right y axis
        linkedTo: 0,
        gridLineWidth: 0,
        opposite: true,
        title: { text: 'Total Qoil (sm3/h)' },
        labels: {
          enabled: true,
          align: 'right',
          x: -3,
          y: 16,
          formatter: () => `${parseFloat(this.value / 24).toFixed(1)}`,
        },
        showFirstLabel: false,
      },
    ],
    tooltip: {
      headerFormat: '<b>KPC to U2</b>   :  {point.x:.1f} %',
      pointFormat: ' | <b>Total Qoil </b> : {point.y} sm3/d ',
      shared: false,
    },
    plotOptions: { series: {} },
    series: chartData.series,
  };
};
