export function handleGasChartData(caseOpts, calcDict) {
  if (caseOpts && caseOpts.length > 0) {
    const qoil = { data: [], name: 'KPC TO U2', type: 'line' };
    const xAxis = [];

    const u2Base = calcDict.kpc_gas_to_u2.results['default']?.value;
    const totalBase = calcDict.kpc_tot_gas.results['default']?.value;
    const u2BaseProcentage = parseFloat((u2Base * 100) / totalBase);
    const baseOpts = calcDict.field_tot_oil.results['default']?.value;
    const baseOptsSeries = {
      data: [[u2BaseProcentage, parseFloat(parseFloat(baseOpts).toFixed(1))]],
      name: 'Base Case',
      type: 'scatter',
      color: 'red',
      marker: { radius: 5 },
    };

    const options = [];
    for (let item of Object.values(caseOpts)) {
      options.push(item?.id);
    }

    for (let opt of options) {
      if (opt === 'default') continue;
      let u2 = calcDict.kpc_gas_to_u2.results[opt]?.value || 0;
      let u3 = calcDict.kpc_gas_to_u3.results[opt]?.value || 0;
      let qoilValue = calcDict.field_tot_oil.results[opt]?.value || 0;

      if (u2 && u3) {
        const total = u2 + u3;
        const u2Procentage = parseFloat((u2 * 100) / total);
        xAxis.push(parseFloat(u2Procentage.toFixed(1)));
        qoil.data.push([
          parseFloat(u2Procentage.toFixed(1)),
          parseFloat(parseFloat(qoilValue).toFixed(1)),
        ]);
      }
    }

    let series = [baseOptsSeries, qoil];
    return { series, xAxis };
  }
  return null;
}
