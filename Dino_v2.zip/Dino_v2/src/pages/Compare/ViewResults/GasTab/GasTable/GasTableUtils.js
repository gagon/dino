import nullOrFixed from '../../../../utils/nullOrFixed';
import { buildUnitSummary } from '../../../../../common/calculationUtils/units';

export function handleGasTableData(caseData, calcDict, caseOpts) {
  const gasAllocData = [];
  const unitSummary = buildUnitSummary(caseData?.case_wells);

  const getCalcDictValue = (key, id) => {
    return nullOrFixed((calcDict[key]?.results || {})[id]?.value);
  };

  const getCalcDictNumValue = (key, id) => {
    try {
      return parseFloat((calcDict[key].results || {})[id].value).toFixed(1);
    } catch (e) {
      return '';
    }
  };

  for (const item of [{ id: 'default' }, ...caseOpts]) {
    if (!item.id) continue;
    const id = item.id;
    let u2 = calcDict.kpc_gas_to_u2.results[id]?.value;
    let total = calcDict.kpc_tot_gas.results[id]?.value;
    let u3 = calcDict.kpc_gas_to_u3.results[id]?.value;
    let percentage = '';
    let wells = '';
    let qwater = '';

    // percentage
    if (u2 && u3) {
      const total = u2 + u3;
      const u2Procentage = parseFloat((u2 * 100) / total).toFixed(1);
      const u3Procentage = parseFloat(100 - u2Procentage).toFixed(1);
      percentage = `U2(${u2Procentage}) | U3(${u3Procentage})`;
    }

    // wells
    if (id !== 'default') {
      try {
        if (item?.results) {
          const optionU2Open = item?.results.U2_open_well;
          const optionU2shutin = item?.results.U2_shut_well;
          const optionU3Open = item?.results.U3_open_well;
          const optionU3shutin = item?.results.U3_shut_well;
          const u2 = ` U2 (${optionU2shutin} | ${optionU2Open})`;
          const u3 = ` U3 (${optionU3shutin} | ${optionU3Open})`;
          wells = `${u2} \n ${u3}`;
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      var bseU2shutin = unitSummary?.['U2']?.shutin;
      const baseU2total = unitSummary?.['U2']?.count;
      const baseU2openWell = baseU2total - bseU2shutin;
      var bseU3shutin = unitSummary?.['U3']?.shutin;
      const baseU3total = unitSummary?.['U3']?.count;
      const baseU3openWell = baseU3total - bseU3shutin;
      wells = `U2 (${bseU2shutin} | ${baseU2openWell}) \n U3 (${bseU3shutin} | ${baseU3openWell})`;
    }

    //
    qwater = calcDict.u2_wat_tot.results[id]?.value || 0;
    qwater += calcDict.u3_wat_tot.results[id]?.value || 0;
    qwater += calcDict.kpc_wat_tot.results[id]?.value || 0;
    qwater = nullOrFixed(qwater, 0);

    gasAllocData.push({
      id: id === 'default' ? 'Base' : id,
      u2GasTotal: getCalcDictValue('u2_gas_tot', id),
      kpcQgasU2: getCalcDictValue('kpc_gas_to_u2', id),
      u3GasTotal: getCalcDictValue('u3_gas_tot', id),
      kpcGasToU3: getCalcDictValue('kpc_gas_to_u3', id),
      kpcTotalGas: getCalcDictValue('kpc_tot_gas', id),
      percentage: percentage,
      ogp: getCalcDictNumValue('ogp_gas', id),
      sgi: getCalcDictNumValue('gas_inj', id),
      wells: wells,
      totalQoil: getCalcDictValue('field_tot_oil', id),
      totalQgas: getCalcDictValue('field_tot_gas', id),
      totalQwater: qwater,
    });
  }
  return gasAllocData;
}
