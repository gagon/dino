import React, { Fragment } from 'react';
import Paper from '@mui/material/Paper';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import { useSelector } from 'react-redux';
import { compareModule } from '../../../CompareDucks';
import Table from '../../../../../common/Table/Table';
import { gasColumns } from './GasColumns';

export default function GasTable() {
  const tableData = useSelector((state) => state[compareModule].gasTabTable);
  const loading = useSelector((state) => state[compareModule].loadingCaseOptions);

  return (
    <div>
      <Table
        loading={loading}
        headerHeight={46}
        rows={tableData}
        columns={gasColumns(false)}
        hideFooterPagination
        hideFooter
        autoHeight
        disableColumnMenu
        disableSelectionOnClick
        disableMultipleColumnsSorting
        disableExtendRowFullWidth={false}
        sx={{ border: 'none' }}
      />
    </div>
  );
}
