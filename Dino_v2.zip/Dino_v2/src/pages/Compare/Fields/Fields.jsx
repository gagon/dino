import React from 'react';
import { Typography, useTheme } from '@mui/material';
import Slider from '@mui/material/Slider';
import { CanvasWidget } from '@projectstorm/react-canvas-core';

import DayHourSwitchButtons from '../../Case/Fields/FieldComponents/DayHourSwitchButtons';
import UnitSummaryTotal from '../ViewResults/WellTable/UnitSummaryTotal';
import FieldLegend from '../../../common/FieldLegend/FieldLegend';
import { getModel } from './FieldSchemaObjects';

import { rootStyles } from './styles';

export const { model, engine } = getModel();
export default function Fields() {
  const { palette } = useTheme();
  const classes = rootStyles('white', 'black');

  return (
    <>
      <div className="mb3">
        <UnitSummaryTotal />
      </div>
      <div className="relative" style={{ zIndex: 2 }}>
        <div className="flex pb2 pr2" style={{ position: 'absolute', backgroundColor: '#E8E8F0' }}>
          <Typography variant={'h5'} children={'Fields'} style={{ color: palette.action.active }} />
        </div>
        <div
          className="flex pb2 pl2"
          style={{ position: 'absolute', right: 0, backgroundColor: '#E8E8F0' }}
        >
          <FieldLegend />
          <DayHourSwitchButtons />
        </div>
      </div>
      <div className="flex" style={{ height: 800 }}>
        <div style={{ marginTop: 90 }}>
          <div style={{ height: 200 }}>
            <Slider
              size="small"
              defaultValue={30}
              valueLabelDisplay="auto"
              orientation="vertical"
              onChange={(ev, zoom) => {
                model.setZoomLevel(zoom + 60);
                engine.repaintCanvas();
              }}
            />
          </div>
        </div>
        <div className={classes.content}>
          <CanvasWidget engine={engine} />
        </div>
      </div>
    </>
  );
}
