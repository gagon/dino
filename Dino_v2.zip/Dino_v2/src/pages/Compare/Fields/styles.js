import styled from '@emotion/styled';
import { makeStyles } from '@mui/styles';

export const FieldWrappers = styled.div`
  background: #eef8ff;
  height: calc(100% - 23px);
  border-bottom-right-radius: 10px;
  border-bottom-left-radius: 10px;
  padding: 16px 7px 16px 7px;
`;

export const rootStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  content: {
    // backgroundColor: `${BACKGROUND_CONTENT}`,
    backgroundSize: '50px 50px',
    flexGrow: 1,
    minHeight: 'calc(100vh - 200px)',
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    '& > *': {
      height: '100%',
      minHeight: 'calc(100vh - 220px)',
      width: '100%',
    },
  },
}));

export const InputContainerStyle = styled.div`
  border: ${(props) => (props.isConstraint ? '2px solid #F12BA8' : 'none')};
  border-radius: 6px;
  margin-bottom: 4px;
  overflow: hidden;

  .fcv {
    border-right: 2px solid #bdbdbd;
    overflow: hidden;
  }

  .scv {
    padding-left: 4px;
    overflow: hidden;
  }

  .input-field {
    color: black;
    background: rgb(255, 243, 169);
    font-size: 12px;
    padding: 0 4px;
    width: 116px;
    height: 19px;
  }

  .title {
    position: absolute;
    white-space: nowrap;
    font-size: 12px;
  }
  .position-left {
    right: 170px;
    top: -2px;
  }
  .position-right {
    left: 120px;
    top: -2px;
    text-align: right;
  }
  .position-top {
    bottom: 22px;
  }
  .position-bottom {
    top: 22px;
  }
`;

export const inputFieldbtnStyle = (buttonBg, hoveredUnit, isConstraint) => ({
  background: hoveredUnit ? 'green' : buttonBg,
  height: 19,
  width: 50,
  minWidth: 50,
  padding: '2px 4px 2px 4px',
  margin: 0,
  borderBottomLeftRadius: 0,
  borderTopLeftRadius: 0,
  borderBottomRightRadius: 5,
  borderTopRightRadius: 5,
  marginLeft: '-1px',
  textTransform: 'none',
  border: isConstraint ? '2px solid #F12BA8' : 'none',
});

export const selectStyle = {
  height: 12,
  minWidth: 140,
  px: 0.5,
  py: 1.5,
  fontWeight: 'bold',
  fontSize: 14,
  ml: -0.5,
  '&.Mui-focused fieldset': {
    borderColor: '#848884 !important',
    borderWidth: '1px !important',
  },
};

export const InputPopoverStyle = styled.div`
  max-width: 580px;
  font-size: 12px;
  .title {
    background-color: #efefef;
  }

  .row {
    text-overflow: ellipsis;
    overflow: hidden;
    display: flex;
    align-items: center;
  }

  .label {
    min-width: 116px;
    text-align: right;
    margin-right: 10px;
  }

  .info {
    font-weight: bold;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .date_picker {
    margin-top: -5px;
  }

  .end {
    margin: 0 10px;
  }

  .table-wrapper {
    width: 100%;
    border: 0.5px solid rgba(0, 0, 0, 0.25);
    border-radius: 5px;
    padding: 5px 5px;
    margin: 5px 0;
    text-align: left;
  }

  .th-var {
    width: 70%;
  }

  .th-value {
    width: 15%;
  }
`;
