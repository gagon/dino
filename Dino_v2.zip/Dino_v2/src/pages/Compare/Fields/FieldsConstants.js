export const CALCULATED = 'Calculated';
export const LAB_DATA = 'labData';
export const UNIT_PRESSURE = 'unitPressure';
export const GAS = 'gas';
export const OIL = 'oil';

export const COLORS = {
  PURPLE: '#800080',
  BRICK: '#B22222',
  GREEN: '#006400',
  TEAL: '#008080',
  BLUE: '#00008B',
  OLIVE: '#808000',
  SLATEGRAY: '#2F4F4F',
  VIOLET: '#9400d3',
  BYZANTIUM: '#702963',
  GOLDEN: '#daa520',
  OCHRE: '#cc7722',
  RAISIN: '#612302',
  BLOOD: '#8a0707',
  TAWNY: '#cd5700',
  BLUSH: '#de5d83',
  INDIGO: '#4b0082',
  AZURE: '#007fff',
  EMERALD: '#50c878',
  CLEMENTINE: '#eb5e00',
  SANGRIA: '#65242e',
  NAVY: '#000080',
  ORANGE: '#FFA500',
};

export const COLOR_KEYS = Object.keys(COLORS);
