import { Divider } from '@mui/material';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import moment from 'moment';
import React, { useMemo, useState } from 'react';
import { useSelector } from 'react-redux';

import PopoverWindow from '../../../common/Popover/Popover';
import DatePicker from '../../../common/_MuiHookForm/DesktopDatePicker';
import FieldArrowIcon from '../../../_media/FieldArrowIcon';
import { convertUnit } from '../../Case/FieldWellDataModal/FieldWellDataUtils';
import { compareModule } from '../CompareDucks';
import { CALCULATED } from './FieldsConstants';
import Chart from './FieldComponents/Chart/Chart';
import useFieldData from './FieldComponents/useFieldData';
import { FieldDescription, FieldFormulaTable } from './InputFieldUtils';
import { InputContainerStyle, inputFieldbtnStyle, InputPopoverStyle } from './styles';
import { loginModule } from '../../Login/LoginDucks';

export default function InputField({
  name,
  groupName,
  isConstraint,
  isExport,
  isResult,
  ...props
}) {
  const data = useFieldData(name, groupName, isResult);
  const data2 = useFieldData(name, groupName, isResult, true);
  const value = groupName !== 'Lab' ? parseFloat(data?.value).toFixed(1) : data?.value;
  const value2 = groupName !== 'Lab' ? parseFloat(data2?.value).toFixed(1) : data2?.value;
  const fieldData = useSelector((state) => state[compareModule].fields);
  const fieldData2 = useSelector((state) => state[compareModule].fields2);
  const classByUnits = useSelector((state) => state[compareModule].classByUnits);
  const unitsByClass = useSelector((state) => state[compareModule].unitsByClass);
  const hoveredUnit = useSelector((state) => state[compareModule].hoveredUnit);
  const isHourUnits = useSelector((state) => state[loginModule].userConfig.isHourUnits);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedUnits, setSelectedUnits] = useState(null);
  const [selectedStartTime, setSelectedStartTime] = useState(null);
  const [selectedEndTime, setSelectedEndTime] = useState(null);
  const fieldBg = isResult ? 'rgb(157 247 212)' : '#FFF3A9';
  const buttonBg = isResult ? '#1d9868' : '#EDB901';
  const title = isResult
    ? `Calculations - ${data.name}`
    : groupName
    ? `${groupName} - ${name}`
    : name;

  const sxBtn = useMemo(
    () => inputFieldbtnStyle(buttonBg, hoveredUnit === title),
    [buttonBg, hoveredUnit]
  );
  const times = useMemo(() => {
    if (data?.timestamp && data?.time_picker) {
      const defaultStartTime = moment(data?.timestamp).subtract(data?.chart_days, 'day');
      const defaultEndTime = moment(data?.timestamp);
      return { defaultStartTime, defaultEndTime };
    }
    return { defaultStartTime: null, defaultEndTime: null };
  }, [data?.timestamp, data?.time_picker]);

  const displayedValue = useMemo(() => {
    if (data?.uom && isHourUnits && data?.uom.includes('/d')) {
      return (value / 24).toFixed(1);
    }
    return value;
  }, [value, isHourUnits, data?.uom]);

  const displayedValue2 = useMemo(() => {
    if (data2?.uom && isHourUnits && data2?.uom.includes('/d')) {
      return (value / 24).toFixed(1);
    }
    return value;
  }, [value, isHourUnits, data2?.uom]);

  const displayedUom = useMemo(() => {
    if (data?.uom && isHourUnits && data?.uom.includes('/d')) {
      return data?.uom.replace('/d', '/h');
    }
    return data?.uom;
  }, [data?.uom, isHourUnits]);

  return (
    <InputContainerStyle className="flex items-center justify-center" isConstraint={isConstraint}>
      {['left', 'top'].includes(data.label_pos || props.label_pos) && (
        <div className={'title position-' + (data.label_pos || props.label_pos)}>
          {isResult ? props.fieldName : data.name}
        </div>
      )}
      <div
        className="input-field flex"
        style={{ backgroundColor: hoveredUnit ? '#50C878' : fieldBg }}
      >
        <div
          className="flex-1 fcv"
          title={!(value === undefined || isNaN(value)) ? displayedValue : ''}
        >
          {!(value === undefined || isNaN(value)) && displayedValue}
        </div>
        <div
          className="flex-1 scv"
          title={!(value2 === undefined || isNaN(value2)) ? displayedValue2 : ''}
        >
          {!(value2 === undefined || isNaN(value2)) && displayedValue2}
        </div>
      </div>
      <Button onClick={(e) => setAnchorEl(e.currentTarget)} sx={sxBtn}>
        <div className="fullWidth flex justify-between items-center">
          <Typography
            sx={{
              fontSize: 9,
              color: isExport ? 'black' : 'white',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
            }}
            children={selectedUnits || displayedUom}
          />
          <FieldArrowIcon
            stroke={isExport ? 'black' : 'white'}
            style={{ fontSize: 9, marginRight: 3, marginLeft: 3 }}
          />
        </div>
      </Button>

      <PopoverWindow open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={() => setAnchorEl(null)}>
        <InputPopoverStyle>
          <div className="title py1 px2">{title}</div>
          <Divider />
          <div className="p2">
            {!isResult && (
              <FieldDescription
                data={data}
                data2={data2}
                value={value}
                value2={value2}
                selectedUnits={selectedUnits}
                setSelectedUnits={setSelectedUnits}
                unitsByClass={unitsByClass}
                classByUnits={classByUnits}
              />
            )}
            {data?.time_picker && data?.timestamp && data?.data_source !== CALCULATED && (
              <>
                <div className="row date_picker">
                  <div className="label">Start:</div>
                  <DatePicker
                    value={selectedStartTime || times.defaultStartTime}
                    onChange={setSelectedStartTime}
                  />
                  <div className="end">End:</div>
                  <DatePicker
                    value={selectedEndTime || times.defaultEndTime}
                    onChange={setSelectedEndTime}
                  />
                </div>

                <Chart
                  data={data}
                  selectedStartTime={selectedStartTime || times.defaultStartTime}
                  selectedEndTime={selectedEndTime || times.defaultEndTime}
                  title={title}
                  desiredUnits={selectedUnits || data?.uom}
                />
              </>
            )}

            {(data?.data_source === CALCULATED || isResult) && (
              <FieldFormulaTable
                isResult={isResult}
                data={data}
                data2={data2}
                value={value}
                value2={value2}
                fieldData={fieldData}
                fieldData2={fieldData2}
              />
            )}
          </div>
        </InputPopoverStyle>
      </PopoverWindow>
    </InputContainerStyle>
  );
}
