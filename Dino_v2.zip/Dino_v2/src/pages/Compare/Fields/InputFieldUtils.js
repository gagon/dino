import React, { useMemo } from 'react';
import moment from 'moment';
import { CALCULATED, COLORS, COLOR_KEYS } from './FieldsConstants';
import { selectStyle } from './styles';
import { MenuItem, Select } from '@mui/material';
import { DATE_FORMAT } from '../../../common/_MuiHookForm/DesktopDatePicker';
import { useDispatch, useSelector } from 'react-redux';
import { compareModule, setHoveredUnit } from '../CompareDucks';

export function FieldDescription({
  data,
  data2,
  value,
  value2,
  selectedUnits,
  setSelectedUnits,
  unitsByClass,
  classByUnits,
}) {
  const units = useMemo(() => {
    if (Object.keys(classByUnits).length > 0 && Object.keys(unitsByClass).length > 0 && data?.uom) {
      return Object.keys(unitsByClass[classByUnits[data?.uom].class].Units);
    }
    return [];
  }, [unitsByClass, classByUnits, data?.uom]);

  return (
    <>
      {data?.uom && (
        <div className="row nowrap">
          <div className="label">Base Unit:</div>
          <div className="info">{data?.uom}</div>
        </div>
      )}
      {data?.uom && (
        <div className="row nowrap">
          <div className="label">Display Unit:</div>
          <Select
            sx={selectStyle}
            value={selectedUnits || data?.uom}
            onChange={(e) => setSelectedUnits(e.target.value)}
          >
            {units.map((unit) => (
              <MenuItem
                key={unitsByClass[classByUnits[data?.uom].class].Units[unit].Abbreviation}
                value={unitsByClass[classByUnits[data?.uom].class].Units[unit].Abbreviation}
                sx={{ height: 20, px: 1, py: 1.5, fontSize: 14 }}
              >
                {unitsByClass[classByUnits[data?.uom].class].Units[unit].Abbreviation} -{' '}
                {unitsByClass[classByUnits[data?.uom].class].Units[unit].Name}
              </MenuItem>
            ))}
          </Select>
        </div>
      )}
      {data?.source_tag && (
        <div className="row nowrap">
          <div className="label">Source:</div>
          <div className="info" title={data?.source_tag}>
            {data?.source_tag}
          </div>
        </div>
      )}

      <div className="row mt2 bold">
        <div className="label">Case 1</div>
      </div>
      {data?.default_val && (
        <div className="row nowrap">
          <div className="label">Default Value:</div>
          <div className="info">{data?.default_val}</div>
        </div>
      )}
      {data?.data_source && (
        <div className="row nowrap">
          <div className="label">Value Source:</div>
          <div className="info">{data?.data_source}</div>
        </div>
      )}
      {value && (
        <div className="row nowrap">
          <div className="label">Current Value:</div>
          <div className="info">{value === undefined ? '' : value}</div>
        </div>
      )}
      {data?.timestamp && (
        <div className="row nowrap">
          <div className="label">Timestamp:</div>
          <div className="info">
            {data?.timestamp ? moment(data?.timestamp).format(DATE_FORMAT) : ''}
          </div>
        </div>
      )}

      <div className="row mt2 bold">
        <div className="label">Case 2</div>
      </div>
      {data2?.default_val && (
        <div className="row nowrap">
          <div className="label">Default Value:</div>
          <div className="info">{data2?.default_val}</div>
        </div>
      )}
      {data2?.data_source && (
        <div className="row nowrap">
          <div className="label">Value Source:</div>
          <div className="info">{data2?.data_source}</div>
        </div>
      )}
      {value2 && (
        <div className="row nowrap">
          <div className="label">Current Value:</div>
          <div className="info">{value2 === undefined ? '' : value2}</div>
        </div>
      )}
      {data2?.timestamp && (
        <div className="row nowrap">
          <div className="label">Timestamp:</div>
          <div className="info">
            {data2?.timestamp ? moment(data2?.timestamp).format(DATE_FORMAT) : ''}
          </div>
        </div>
      )}
    </>
  );
}

export function FieldFormulaTable({ isResult, data, data2, value, value2, fieldData, fieldData2 }) {
  const dispatch = useDispatch();
  const calcDict = useSelector((state) => state[compareModule].calculation?.calcDict);
  const calcDict2 = useSelector((state) => state[compareModule].calculation2?.calcDict);
  const fbTotal = useSelector((state) => state[compareModule].fieldBalance?.totals);
  const fbTotal2 = useSelector((state) => state[compareModule].fieldBalance2?.totals);
  const labelDict = useSelector((state) => state[compareModule].calculation?.labelDict);
  const onInputFieldHovered = (unitName) => {
    dispatch(setHoveredUnit(unitName));
  };

  const dataVariables = useMemo(() => {
    return getMatchedFieldsFromSourceType(
      data?.source_tag,
      fieldData,
      fieldData2,
      calcDict,
      calcDict2,
      fbTotal,
      fbTotal2
    );
  }, [data?.source_tag, fieldData, fieldData2, fbTotal, fbTotal2]);

  const title =
    isResult && labelDict.Diagram
      ? labelDict.Diagram[data.name]?.name + `[${data.name}]`
      : 'Variable';

  const resultFormula = useMemo(() => {
    let formula = data?.source_tag;
    for (const field of dataVariables) {
      formula = formula
        .replaceAll("'", '"')
        .replace(/",\s+"/g, '","')
        .replace(
          `fieldValue("${field.group}","${field.name}")`,
          `<span style="color: ${field.color};" title="${field.group}: ${field.name}">${field.case1}</span>`
        )
        .replace(
          `unitTotal("${field.unit}","${field.name}")`,
          `<span style="color: ${field.color};" title="${field.unit}: ${field.name}">${field.case1}</span>`
        )
        .replace(
          `calcValue("${field.name}")`,
          `<span style="color: ${field.color};" title="${field.name}">${field.case1}</span>`
        )
        .replace(
          `calcCaseValue("${field.name}")`,
          `<span style="color: ${field.color};" title="${field.name}">${field.case1}</span>`
        );
    }
    return `<span>${value} = </span>${formula}`;
  }, [data?.data_source, data?.source_tag, dataVariables, value]);

  const resultFormula2 = useMemo(() => {
    let formula = data2?.source_tag;
    for (const field of dataVariables) {
      formula = formula
        .replaceAll("'", '"')
        .replace(/",\s+"/g, '","')
        .replace(
          `fieldValue("${field.group}","${field.name}")`,
          `<span style="color: ${field.color};" title="${field.group}: ${field.name}">${field.case2}</span>`
        )
        .replace(
          `unitTotal("${field.unit}","${field.name}")`,
          `<span style="color: ${field.color};" title="${field.unit}: ${field.name}">${field.case2}</span>`
        )
        .replace(
          `calcValue("${field.name}")`,
          `<span style="color: ${field.color};" title="${field.name}">${field.case2}</span>`
        )
        .replace(
          `calcCaseValue("${field.name}")`,
          `<span style="color: ${field.color};" title="${field.name}">${field.case2}</span>`
        );
    }
    return `<span>${value2} = </span>${formula}`;
  }, [data2?.data_source, data2?.source_tag, dataVariables, value2]);

  return (
    <table className="table-wrapper">
      <thead>
        <tr className='mb2'>
          <th className="th-var border-bottom pb1">{title}</th>
          <th className="th-value border-bottom pb1">Case 1</th>
          <th className="th-value border-bottom pb1">Case 2</th>
        </tr>
      </thead>
      <tbody>
        {dataVariables.map(({ name, group, sourceName, case1, case2, color }, index) => {
          return (
            <tr key={`${group ?? sourceName} : ${index}`}>
              <td>{isResult ? sourceName : `${group} : ${name}`}</td>
              <td
                style={{ color: `${color}` }}
                onMouseEnter={() => onInputFieldHovered(`${group ?? unit} - ${name}`)}
                onMouseLeave={() => onInputFieldHovered(null)}
                children={case1}
              />
              <td
                style={{ color: `${color}` }}
                onMouseEnter={() => onInputFieldHovered(`${group ?? unit} - ${name}`)}
                onMouseLeave={() => onInputFieldHovered(null)}
                children={case2}
              />
            </tr>
          );
        })}
      </tbody>
      <tfoot>
        <tr className="info border-bottom">
          <td colSpan={3} className='border-bottom pb1 pt1'>Result</td>
        </tr>
        <tr>
          <td colSpan={3} dangerouslySetInnerHTML={{ __html: `<strong>Case 1:</strong> ${resultFormula}` }}></td>
        </tr>
        <tr>
          <td colSpan={3} dangerouslySetInnerHTML={{ __html: `<strong>Case 2:</strong> ${resultFormula2}` }}></td>
        </tr>
      </tfoot>
    </table>
  );
}

export function getMatchedFieldsFromSourceType(
  source,
  fieldData,
  fieldData2,
  calcDict,
  calcDict2,
  fbTotal,
  fbTotal2
) {
  let match;
  const sourceTag = source.replaceAll("'", '"');
  const regexMatchFields = /fieldValue\("([^"]+)+",\s?"([^"]+)+"\)/g;
  const regexMatchUnits = /unitTotal\("([^"]+)+",\s?"([^"]+)+"\)/g;
  const regexMatchCalc = /calcValue\("([^"]+)+"\)/g;
  const regexMatchCaseVals = /calcCaseValue\("([^"]+)+"\)/g;
  const matchedFields = [];
  while ((match = regexMatchFields.exec(sourceTag)) !== null) {
    if (match && match.length >= 3) {
      const [sourceName, group, name] = match;
      const case1 = fieldData[group] ? fieldData[group][name]?.value : '';
      const case2 = fieldData2[group] ? fieldData2[group][name]?.value : '';
      const color = COLORS[COLOR_KEYS[(COLOR_KEYS.length * Math.random()) << 0]];
      matchedFields.push({
        sourceName,
        group,
        name,
        case1,
        case2,
        color,
        groupError: !(group in fieldData) ? 'Invalid group name.' : '',
        nameError: !(name in fieldData[group]) ? 'Invalid field item name!' : '',
      });
    }
  }
  while ((match = regexMatchUnits.exec(sourceTag)) !== null) {
    if (match && match.length >= 3) {
      const [sourceName, unit, name] = match;
      const case1 = fbTotal && fbTotal[unit] ? fbTotal[unit][name] : '';
      const case2 = fbTotal2 && fbTotal2[unit] ? fbTotal2[unit][name] : '';
      const color = COLORS[COLOR_KEYS[(COLOR_KEYS.length * Math.random()) << 0]];
      matchedFields.push({
        sourceName,
        unit,
        name,
        case1,
        case2,
        color,
        unitError: !(unit in fbTotal) ? 'Invalid unit name.' : '',
      });
    }
  }
  while ((match = regexMatchCalc.exec(sourceTag)) !== null) {
    if (match && match.length >= 2) {
      const [sourceName, name] = match;
      const case1 = calcDict[name] ? calcDict[name].results?.default?.value : '';
      const case2 = calcDict2[name] ? calcDict2[name].results?.default?.value : '';
      const color = COLORS[COLOR_KEYS[(COLOR_KEYS.length * Math.random()) << 0]];
      matchedFields.push({
        sourceName,
        name,
        case1,
        case2,
        color,
        error: !calcDict[name] ? 'Is not a known calculation value' : '',
      });
    }
  }
  while ((match = regexMatchCaseVals.exec(sourceTag)) !== null) {
    if (match && match.length >= 2) {
      const [sourceName, name] = match;
      const case1 = calcDict[name] ? calcDict[name].results?.default?.value : '';
      const case2 = calcDict2[name] ? calcDict2[name].results?.default?.value : '';
      const color = COLORS[COLOR_KEYS[(COLOR_KEYS.length * Math.random()) << 0]];
      matchedFields.push({
        sourceName,
        name,
        case1,
        case2,
        color,
        error: !calcDict[name] ? 'Is not a known calculation value' : '',
      });
    }
  }

  return matchedFields.map((i) => ({
    ...i,
    case1: parseFloat(i.case1).toFixed(2) ?? '',
    case2: parseFloat(i.case2).toFixed(2) ?? '',
  }));
}
