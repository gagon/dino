import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import Highcharts from 'highcharts/highstock';
import moment from 'moment';

import { StreamsApi } from '../../../../../_helpers/service';
import { loginModule } from '../../../../Login/LoginDucks';
import { DATE_FORMAT } from '../../../../../common/_MuiHookForm/DesktopDatePicker';
import { initialOptions } from './ChartOptions';
import { generateWebID } from '../../../../Case/FieldWellDataModal/FieldWellDataUtils';

const ReactHighcharts = require('react-highcharts');

const Chart = ({ data, selectedStartTime, selectedEndTime, title, desiredUnits, onChange }) => {
  const afServer = useSelector((state) => state[loginModule].appConfig['AF:AFServer']);
  const [options, setOptions] = useState(initialOptions);

  const loadCharts = async (sourceTag, sourceType, desiredUnits) => {
    const webId = generateWebID(sourceTag, sourceType);

    const encStartTime = encodeURIComponent(
      moment(selectedStartTime, DATE_FORMAT).format('YYYY-MM-DDTHH:mm:ssZ')
    );
    const encEndTime = encodeURIComponent(
      moment(selectedEndTime, DATE_FORMAT).format('YYYY-MM-DDTHH:mm:ssZ')
    );
    const data = await StreamsApi.loadStreams(
      afServer,
      webId,
      encStartTime,
      encEndTime,
      desiredUnits
    );
    moment.locale('en');
    const convertedData = data?.data?.Items.map((item) => [
      moment(item.Timestamp).format('LLL'),
      item.Value,
    ]);

    setOptions((prev) => ({
      ...prev,
      series: [{ type: 'spline', data: convertedData, name: title }],
      plotOptions: {
        series: {
          point: {
            events: {
              click() {
                let point = this;
                onChange && onChange(point.y);
              },
            },
          },
        },
      },
    }));
  };

  useEffect(() => {
    if (data?.time_picker) {
      loadCharts(data?.source_tag, data?.data_source, desiredUnits);
    }
  }, [selectedStartTime, selectedEndTime, desiredUnits]);

  return <ReactHighcharts highcharts={Highcharts} config={options} />;
};

export default Chart;
