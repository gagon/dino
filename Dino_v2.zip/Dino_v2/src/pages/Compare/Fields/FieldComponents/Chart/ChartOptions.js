export const initialOptions = {
  title: {
    text: null,
  },
  legend: { enabled: false },
  xAxis: {
    labels: {
      enabled: false,
    },
  },
  yAxis: {
    title: {
      text: null,
    },
  },
  series: [{ data: [] }],
};
