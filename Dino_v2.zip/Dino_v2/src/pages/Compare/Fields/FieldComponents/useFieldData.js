import { useSelector } from 'react-redux';
import { compareModule } from '../../CompareDucks';

export default function useFieldData(name, groupName, isResult, secondCase) {
  return useSelector((state) => {
    if (isResult) {
      const key = secondCase ? 'calculation2' : 'calculation';
      const calcDict = state[compareModule][key]?.calcDict;
      if (calcDict) return calcDict[name]?.results?.default;
    } else {
      const key = secondCase ? 'fields2' : 'fields';
      const fields = state[compareModule][key];
      if (Object.keys(fields).length > 0) return fields[groupName][name];
    }
    return {};
  });
}
