import React from 'react';
import oilImg from '../../../_media/svg/oilWhite.svg';
import { GAS, LAB_DATA, OIL, UNIT_PRESSURE } from './FieldsConstants';
import GasIcon from '../../../_media/GasIcon';
import unitSvg from '../../../_media/svg/unit.svg';
import ParamsModel from '../../../common/FieldSchema//VisualizationBoard/Params/Model';
import Lines from './FieldComponents/Lines';
import WellParams from '../../../common/FieldSchema/VisualizationBoard/UnitComponents/WellParams';
import UnitComponentsModel from '../../../common/FieldSchema//VisualizationBoard/UnitComponents/Model';
import ParamsByTypeModel from '../../../common/FieldSchema//VisualizationBoard/ParamsByType/Model';
import createEngine, { DiagramModel } from '@projectstorm/react-diagrams';
import UnitComponentsFactory from '../../../common/FieldSchema//VisualizationBoard/UnitComponents/Factory';
import ParamsByTypeFactory from '../../../common/FieldSchema//VisualizationBoard/ParamsByType/Factory';
import ParamsFactory from '../../../common/FieldSchema//VisualizationBoard/Params/Factory';
import styled from '@emotion/styled';

export const FieldWrappers = styled.div`
  background: #eef8ff;
  height: calc(100% - 23px);
  border-bottom-right-radius: 10px;
  border-bottom-left-radius: 10px;
  padding: 16px 7px 16px 7px;
`;

const Unit = () => (
  <>
    <WellParams title={'Gas from wells'} large>
      <FieldWrappers />
    </WellParams>
    <WellParams title={'Oil from wells'} large>
      <FieldWrappers />
    </WellParams>
    <WellParams title={'Water from wells'} large>
      <FieldWrappers />
    </WellParams>
  </>
);

const FieldGroup = ({ height = 90, title, padding, width = 120 }) => (
  <div
    style={{ height, padding: title || padding ? 5 : 'inherit', width }}
    children={
      title && <div className="fs-12 flex justify-center mb1 center bold" children={title} />
    }
  />
);

export function getModel() {
  const engine = createEngine({
    registerDefaultDeleteItemsAction: false,
    registerDefaultPanAndZoomCanvasAction: false,
    registerDefaultZoomCanvasAction: false,
  });
  engine.getNodeFactories().registerFactory(new UnitComponentsFactory(true));
  engine.getNodeFactories().registerFactory(new ParamsByTypeFactory(true));
  engine.getNodeFactories().registerFactory(new ParamsFactory());

  const lines = new ParamsModel(engine, {
    children: <Lines />,
  });
  lines.setPosition(0, 0);
  lines.setLocked(true);

  const secondUnitNode = new UnitComponentsModel(engine, {
    title: 'U2',
    children: <Unit />,
  });
  secondUnitNode.setPosition(33, 400);
  secondUnitNode.setLocked(true);

  const thirdUnit = new UnitComponentsModel(engine, {
    title: 'U3',
    children: <Unit />,
  });
  thirdUnit.setPosition(735, 100);
  thirdUnit.setLocked(true);

  const KpcNode = new UnitComponentsModel(engine, {
    title: 'KPC',
    children: <Unit />,
  });
  KpcNode.setPosition(1433, 400);
  KpcNode.setLocked(true);

  const ogpOil = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <img src={oilImg} />
        <span children={'OGP oil'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={86} width={178} />,
    type: OIL,
  });
  ogpOil.setPosition(735, -40);
  ogpOil.setLocked(true);

  const ogpGas = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <GasIcon style={{ fontSize: 10 }} />
        <span children={'OGP gas'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={66} width={178} />,
    bgColor: '#5051F9',
    type: GAS,
  });
  ogpGas.setPosition(1144, -20);
  ogpGas.setLocked(true);

  const mtuOil = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <img src={oilImg} />
        <span children={'MTU oil'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={130} width={175} />,
    type: OIL,
  });
  mtuOil.setPosition(1366, 110);
  mtuOil.setLocked(true);

  const cpcOil = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <img src={oilImg} />
        <span children={'CPC oil'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup width={178} />,
    type: OIL,
  });
  cpcOil.setPosition(1433, 650);
  cpcOil.setLocked(true);

  const fuelGas = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <GasIcon style={{ fontSize: 10 }} />
        <span children={'Fuel gas'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={64} width={178} />,
    bgColor: '#5051F9',
    type: GAS,
  });
  fuelGas.setPosition(1845, 650);
  fuelGas.setLocked(true);

  const gasInjection = new ParamsByTypeModel(engine, {
    title: (
      <div>
        <img src={unitSvg} height={10} />
        <span children={'Gas injection'} style={{ marginLeft: 4 }} />
      </div>
    ),
    children: <FieldGroup height={70} width={178} />,
    bgColor: '#5051F9',
    type: GAS,
  });
  gasInjection.setPosition(33, 650);
  gasInjection.setLocked(true);

  const U3GasTrain = new ParamsModel(engine, {
    children: <FieldGroup title="U3 gas Trains + Degasser" height={70} width={180} />,
    style: { border: '2px dashed #F3F5F9', background: 'white' },
  });
  U3GasTrain.setPosition(480, 50);
  U3GasTrain.setLocked(true);

  const unitPressures = new ParamsModel(engine, {
    children: <FieldGroup title="Unit pressures" width={378} height={230} padding={20} />,
    style: { border: '2px solid #E1E2E5' },
    type: UNIT_PRESSURE,
  });
  unitPressures.setPosition(46, 145);
  unitPressures.setLocked(true);

  const gasOpt = new ParamsModel(engine, {
    children: <FieldGroup title="Gas optimisation" width={378} height={230} padding={20} />,
    style: { border: '2px solid #E1E2E5' },
    type: UNIT_PRESSURE,
  });
  gasOpt.setPosition(46, -103);
  gasOpt.setLocked(true);

  const labData = new ParamsModel(engine, {
    children: <FieldGroup title="Lab data" width={330} height={330} padding={20} />,
    style: { border: '2px solid #E1E2E5' },
    type: LAB_DATA,
  });
  labData.setPosition(1661, 20);
  labData.setLocked(true);

  const u2DrizoGas = new ParamsModel(engine, {
    children: <FieldGroup title="U2 Drizo Gas" height={76} width={184} />,
    style: { border: '2px dashed #F3F5F9', background: 'white' },
  });
  u2DrizoGas.setPosition(-166, 549);
  u2DrizoGas.setLocked(true);

  const kpcTotalGasTransfer = new ParamsModel(engine, {
    children: <FieldGroup title="KPC total gas transfer" height={158} width={186} />,
    style: { border: '2px dashed #F3F5F9', background: 'white' },
  });
  kpcTotalGasTransfer.setPosition(2057, 352);
  kpcTotalGasTransfer.setLocked(true);

  const secondUnitToThirdUnit = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  secondUnitToThirdUnit.setPosition(644, 350);
  secondUnitToThirdUnit.setLocked(true);

  const kpcToThirdUnit = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  kpcToThirdUnit.setPosition(830, 350);
  kpcToThirdUnit.setLocked(true);

  const thirdUnitToKpc = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  thirdUnitToKpc.setPosition(1016, 350);
  thirdUnitToKpc.setLocked(true);

  const secondUnitToKpc = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  secondUnitToKpc.setPosition(945, 480);
  secondUnitToKpc.setLocked(true);

  const kpcToSecondUnit = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  kpcToSecondUnit.setPosition(720, 600);
  kpcToSecondUnit.setLocked(true);

  const kpcToSecondUnitConstraint = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  kpcToSecondUnitConstraint.setPosition(735, 554);
  kpcToSecondUnitConstraint.setLocked(true);

  const thirdGasOilCalculate = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  thirdGasOilCalculate.setPosition(384, -60);
  thirdGasOilCalculate.setLocked(true);

  const qgasMPSep = new ParamsModel(engine, {
    children: <FieldGroup padding />,
  });
  qgasMPSep.setPosition(-160, 300);
  qgasMPSep.setLocked(true);

  const model = new DiagramModel();
  model.setZoomLevel(79);
  model.setOffsetY(100);
  model.setOffsetX(170);
  // model.setLocked();
  model.addAll(
    lines,
    secondUnitNode,
    thirdUnit,
    KpcNode,
    ogpOil,
    ogpGas,
    mtuOil,
    cpcOil,
    fuelGas,
    gasInjection,
    U3GasTrain,
    unitPressures,
    gasOpt,
    labData,
    u2DrizoGas,
    kpcTotalGasTransfer,
    secondUnitToThirdUnit,
    kpcToThirdUnit,
    thirdUnitToKpc,
    secondUnitToKpc,
    kpcToSecondUnit,
    kpcToSecondUnitConstraint,
    thirdGasOilCalculate,
    qgasMPSep
  );
  engine.setModel(model);

  return { model, engine };
}
