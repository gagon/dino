import { createReducer } from '@reduxjs/toolkit';
import { handleError } from '../../common/utils/handleError';
import Notice from '../../common/utils/Notice';
import {
  CHOKE_POSITION_CONFIG_ID,
  FL_PRESSURE_CONFIG_ID,
  GATHERING_STATUS_CONFIG_ID,
  ONLINE_STATUS_CONFIG_ID,
  SLOT_PRESSURE_CONFIG_ID,
  SLOT_TEMPERATURE_CONFIG_ID,
  WH_PRESSURE_CONFIG_ID,
} from '../../_helpers/constants';
import { CaseApi } from '../../_helpers/service';
import { loginModule } from '../Login/LoginDucks';
import { handleGasChartData } from './ViewResults/GasTab/GasCharts/GasChartsUtils';
import { handleGasTableData } from './ViewResults/GasTab/GasTable/GasTableUtils';
import {
  buildCalcDict,
  evaluateCalcDict,
  getTotalFromOption,
} from '../../common/calculationUtils/calculation';
import { handleCaseConfig } from '../../common/calculationUtils/caseConfigSettings';
import { handleCaseFields, setMapConnections } from '../../common/calculationUtils/utils';
import { checkError } from '../../common/calculationUtils/checkError';
import ParamsModel from '../../common/FieldSchema/VisualizationBoard/Params/Model';
import { engine, model } from './Fields/Fields';
import InputField from './Fields/InputField';

/**
 * Constants
 */

export const compareModule = 'compare';
const SET_CASE_DATA = `${compareModule}/SET_CASE_DATA`;
const SET_CASE_DATA2 = `${compareModule}/SET_CASE_DATA2`;
const SET_CONFIG_AND_UNITS = `${compareModule}/SET_CONFIG_AND_UNITS`;
const HOVER_UNIT = `${compareModule}/HOVER_UNIT`;
const SET_GAS_TAB_DATA = `${compareModule}/SET_GAS_TAB_DATA`;
const SET_GAS_TAB_DATA2 = `${compareModule}/SET_GAS_TAB_DATA2`;
const CLEAR = `${compareModule}/CLEAR`;
const LOADING_CASE_OPTIONS = `${compareModule}/LOADING_CASE_OPTIONS`;
const LOADING = `${compareModule}/LOADING`;
const CLEAR_CASE1 = `${compareModule}/CLEAR_CASE1`;
const CLEAR_CASE2 = `${compareModule}/CLEAR_CASE2`;

/**
 * Reducer
 */
const FieldsModels = {};
const ResultFieldModels = {};
const initialState = {
  loading: true,
  caseConfig: {},
  unitClasses: {},
  units: [],
  classByUnits: {},
  unitsByClass: {},
  hoveredUnit: null,

  // case 1
  caseData: {},
  calculation: {},
  gasTabTable: [],
  gasTabChart: null,
  fields: {},
  fieldBalance: {},
  connectionsJoinDict: {},
  connMapDict: {},

  // case 2
  caseData2: {},
  calculation2: {},
  gasTabTable2: [],
  gasTabChart2: null,
  fields2: {},
  fieldBalance2: {},
  connectionsJoinDict2: {},
  connMapDict2: {},
};

export default createReducer(initialState, {
  [SET_CONFIG_AND_UNITS]: (state, { payload }) => {
    state.caseConfig = payload?.caseConfig;
    state.unitClasses = payload?.unitClasses;
    state.units = payload?.units;
    state.unitsByClass = payload?.unitsByClass;
    state.classByUnits = payload?.classByUnits;
  },
  [SET_CASE_DATA]: (state, { payload }) => {
    state.loading = false;
    state.fields = payload.fields;
    state.caseData = payload.caseData;
    state.calculation = payload.calculation;
    state.fieldBalance = payload.fieldBalance;
    state.connMapDict = payload.connMapDict;
    state.connectionsJoinDict = payload.connectionsJoinDict;
  },
  [SET_CASE_DATA2]: (state, { payload }) => {
    state.loading = false;
    state.fields2 = payload.fields;
    state.caseData2 = payload.caseData;
    state.calculation2 = payload.calculation;
    state.fieldBalance2 = payload.fieldBalance;
    state.connMapDict2 = payload.connMapDict;
    state.connectionsJoinDict2 = payload.connectionsJoinDict;
  },
  [CLEAR_CASE1]: (state) => {
    state.caseData = {};
    state.calculation = {};
    state.gasTabTable = [];
    state.gasTabChart = null;
    state.fields = {};
    state.fieldBalance = {};
    state.connectionsJoinDict = {};
    state.connMapDict = {};
  },
  [CLEAR_CASE2]: (state) => {
    state.caseData2 = {};
    state.calculation2 = {};
    state.gasTabTable2 = [];
    state.gasTabChart2 = null;
    state.fields2 = {};
    state.fieldBalance2 = {};
    state.connectionsJoinDict2 = {};
    state.connMapDict2 = {};
  },
  [HOVER_UNIT]: (state, { payload }) => {
    state.hoveredUnit = payload;
  },
  [SET_GAS_TAB_DATA]: (state, { table, chart }) => {
    state.gasTabTable = table;
    state.gasTabChart = chart;
  },
  [SET_GAS_TAB_DATA2]: (state, { table, chart }) => {
    state.gasTabTable2 = table;
    state.gasTabChart2 = chart;
  },
  [LOADING]: (state, { payload }) => {
    state.loading = payload;
  },
  [LOADING_CASE_OPTIONS]: (state, { payload }) => {
    state.loadingCaseOptions = payload;
  },
  [CLEAR]: () => initialState,
});

/**
 * Actions
 */

export const clear = () => ({ type: CLEAR });
export const clearCase1 = () => ({ type: CLEAR_CASE1 });
export const clearCase2 = () => ({ type: CLEAR_CASE2 });

export const loadCases = (caseId, secondCase) => async (dispatch, getState) => {
  dispatch({ type: LOADING, payload: true });
  try {
    const state = getState();
    const stateCaseConfig = state[compareModule].caseConfig;
    if (Object.keys(stateCaseConfig).length === 0) {
      const configAndUnits = await loadConfigAndUnits(state);
      dispatch({ type: SET_CONFIG_AND_UNITS, payload: configAndUnits });
      dispatch(loadCaseData(caseId, secondCase));
    } else {
      dispatch(loadCaseData(caseId, secondCase));
    }
  } catch (e) {
    handleError(e, 'Failed to load case config data');
  }
};

async function loadConfigAndUnits(state) {
  const units = [];
  const unitsByClass = {};
  const classByUnits = {};
  const { userConfig, appConfig } = state[loginModule];

  // UNIT CLASSES
  const response = await CaseApi.getUnitClasses(appConfig['AF:AFServer']);
  const unitClasses = response?.data;

  // UNITS
  const getUnits = async () => {
    let requests = response?.data?.Items.map((unit) => {
      return Promise.resolve(CaseApi.getUnits(unit?.Links?.Units));
    });
    return Promise.all(requests).then((responses) => {
      responses.map((res) => {
        units.push(res.data);
      });
    });
  };
  if (response?.data?.Items.length > 0) await getUnits();

  // UNIT_BY_CLASSES, CLASS_BY_UNITS
  for (let uClassIndex in unitClasses.Items) {
    const uClass = unitClasses.Items[uClassIndex];
    unitsByClass[uClass.Name] = { ...uClass };
    const retUnits = units[uClassIndex];

    unitsByClass[uClass.Name].Units = {};
    for (let unit of retUnits.Items) {
      unitsByClass[uClass.Name].Units[unit.Abbreviation] = unit;
      classByUnits[unit.Abbreviation] = {
        class: uClass.Name,
        clash: unit.Abbreviation in classByUnits,
      };
    }
  }

  // CASE CONFIG
  const { data } = await CaseApi.loadCaseConfigSetting();
  const caseConfig = handleCaseConfig(data, userConfig);

  return { unitClasses, units, unitsByClass, classByUnits, caseConfig };
}

export const loadCaseData = (caseId, secondCase) => async (dispatch, getState) => {
  dispatch({ type: LOADING, payload: true });
  try {
    const state = getState();
    const { caseConfig } = state[compareModule];
    const { userConfig } = state[loginModule];

    if (caseConfig) {
      let fieldBalance = {};

      // CASE DATA
      let { data: caseData } = await CaseApi.loadCase(caseId);
      const fields = handleCaseFields(caseData, caseConfig);

      const connectionsJoinDict = {};
      const connMapDict = {};
      const { units, classByUnits, unitsByClass } = state[compareModule];

      // FIELD BALANCE
      let fieldTotal = getTotalFromOption(undefined, {});
      if (caseData.run_date) {
        let { data } = await CaseApi.loadFieldBalance(caseId);
        fieldTotal = getTotalFromOption(undefined, data);
        fieldBalance = data;
      }

      // CALCULATION
      const calculation = buildCalcDict(classByUnits, unitsByClass, caseConfig, userConfig);
      evaluateCalcDict(undefined, calculation?.calcDict, fieldTotal, fields, caseConfig?.units);

      // HANDLE CASE WELLS
      const case_wells = Object.values(caseData.case_wells).map((well) => {
        const gap_well = setMapConnections(
          well?.gap_well,
          userConfig,
          caseConfig?.wellCfg,
          connMapDict,
          connectionsJoinDict
        );

        const gapName = caseConfig?.wellCfg[well.well_id].gap_name;
        const whPressur = well?.well_config_values[WH_PRESSURE_CONFIG_ID];
        const flPressur = well?.well_config_values[FL_PRESSURE_CONFIG_ID];
        const slotPressur = well?.well_config_values[SLOT_PRESSURE_CONFIG_ID];
        const slotTemperature = well?.well_config_values[SLOT_TEMPERATURE_CONFIG_ID];
        const chokePosition = well?.well_config_values[CHOKE_POSITION_CONFIG_ID];
        const onlineStatus = well?.well_config_values[ONLINE_STATUS_CONFIG_ID];
        const gatheringStatus = well?.well_config_values[GATHERING_STATUS_CONFIG_ID];

        const values = {
          ...well,
          gap_well,
          id: well?.well_id,
          gapName,
          whPressur,
          flPressur,
          slotPressur,
          slotTemperature,
          chokePosition,
          onlineStatus,
          gatheringStatus,
        };

        const validate = checkError(
          values,
          caseConfig?.unitCfg,
          fields['Process'],
          units.classByUnits,
          units.unitsByClass
        );
        return { ...values, initValues: values, validate };
      });

      dispatch({
        type: secondCase ? SET_CASE_DATA2 : SET_CASE_DATA,
        payload: {
          fields,
          calculation,
          fieldBalance,
          caseData: { ...caseData, case_wells },
          connMapDict,
          connectionsJoinDict,
        },
      });
      addFieldModels(caseConfig, calculation.calcDict, calculation.calcNameLookup);
    }
  } catch (e) {
    console.error(e);
    handleError(e, 'Failed to load case data');
  }
};

function addFieldModels(data, calcDict, calcNameLookup) {
  const fields = listToObject(data.field);
  const resultLabel = data.resultLabel.filter((i) => i.group === 'Diagram');
  const resultFields = listToObject(resultLabel);

  for (const field of Object.values(fields)) {
    if (!FieldsModels.hasOwnProperty(field.id)) {
      const fieldItem = new ParamsModel(engine, {
        children: (
          <InputField
            key={field.id}
            name={field.name}
            groupName={field.config_group}
            isConstraint={field.is_constraint}
            isExport={field.config_group === 'Export' && !field.is_constraint}
          />
        ),
      });
      fieldItem.setPosition(field.xpos2 * 1.4 - 250, field.ypos2);
      FieldsModels[field.id] = fieldItem;
      model.addNode(fieldItem);
    }
  }

  for (const item of Object.values(resultFields)) {
    if (!ResultFieldModels.hasOwnProperty(item.id)) {
      const calcName = calcNameLookup[item.calc_id];
      const field = {
        ...item,
        ...calcDict[calcName].results?.default,
        fieldName: item.name,
        uom: calcDict[calcName]?.uom,
        name: calcDict[calcName]?.name,
      };
      const fieldItem = new ParamsModel(engine, {
        children: (
          <InputField
            key={field.id + 'res'}
            name={field.name}
            fieldName={field.fieldName}
            groupName={field.config_group}
            label_pos={field.label_pos}
            isExport={field.config_group === 'Export'}
            isResult
          />
        ),
      });
      fieldItem.setPosition(field.xpos2 * 1.4 - 250, field.ypos2);
      ResultFieldModels[field.id] = fieldItem;
      model.addNode(fieldItem);
    }
  }
  engine.repaintCanvas();
}

function listToObject(list) {
  const obj = {};
  for (const item of list) {
    obj[item.id] = item;
  }
  return obj;
}

export const loadGasTabData = (caseId, secondCase) => async (dispatch, getState) => {
  try {
    dispatch({ type: LOADING_CASE_OPTIONS, payload: true });
    const state = getState();
    const calculation = secondCase ? 'calculation2' : 'calculation';
    const calcDict = state[compareModule][calculation]?.calcDict || {};
    const caseData = state[compareModule][secondCase ? 'caseData2' : 'caseData'];
    const { data } = await CaseApi.getCaseOption(caseId);
    const table = handleGasTableData(caseData, calcDict, data.caseOpts);
    const chart = handleGasChartData(data.caseOpts, calcDict);
    dispatch({ type: secondCase ? SET_GAS_TAB_DATA2 : SET_GAS_TAB_DATA, table, chart });
  } catch (error) {
    console.error(error);
    Notice.error('Failed to load case option');
    handleError(error);
  } finally {
    dispatch({ type: LOADING_CASE_OPTIONS, payload: false });
  }
};

export const copyAllocationFactory = (isCurrent, secondCase) => (dispatch, getState) => {
  try {
    const state = getState();
    const caseKey = secondCase ? 'calculation2' : 'calculation';
    const calcDict = state[compareModule][caseKey]?.calcDict;
    const labelDict = state[compareModule][caseKey]?.labelDict;
    const afValues = {};
    for (let name of Object.keys(labelDict[isCurrent ? 'AF Table:Current' : 'AF Table:New'])) {
      if (typeof name == 'number') {
        afValues[name] = calcDict[name]?.results?.default?.value;
      } else {
        afValues[name] = calcDict[name]?.results?.default?.value;
      }
    }
    localStorage.setItem('afValues', JSON.stringify(afValues));
  } catch (error) {
    handleError(error, 'Failed to copy allocation factors');
  }
};

export const setHoveredUnit = (unitName) => (dispatch) => {
  dispatch({ type: HOVER_UNIT, payload: unitName });
};
