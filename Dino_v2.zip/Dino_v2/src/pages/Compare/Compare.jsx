import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useSearchParams } from 'react-router-dom';
import TabPanel from '../../common/TabPanel';
import { compareModule, loadCases, clearCase1, clearCase2 } from './CompareDucks';
import CompareSelectCase from './CompareSelectCase';
import Fields from './Fields/Fields';
import TabsButton from './TabsButton';
import GasTab from './ViewResults/GasTab/GasTab';
import WellTable from './ViewResults/WellTable/WellTable';
import ViewResultTable from './ViewResults/ViewResultTable/ViewResultTable';

export default function Compare() {
  const dispatch = useDispatch();
  const [searchParam] = useSearchParams();
  const [page, setPage] = useState(1);
  const loading = useSelector((state) => state[compareModule].loading);
  const caseId1 = searchParam.get('case1');
  const caseId2 = searchParam.get('case2');

  useEffect(() => {
    dispatch(caseId1 ? loadCases(caseId1) : clearCase1());
    return () => {
      dispatch(clearCase1());
    };
  }, [caseId1, dispatch]);

  useEffect(() => {
    dispatch(caseId2 ? loadCases(caseId2, true) : clearCase2());
    return () => {
      dispatch(clearCase2());
    };
  }, [caseId2, dispatch]);

  return (
    <div className="flex items-center">
      <div className="content fullWidth pb2">
        <CompareSelectCase caseId1={caseId1} caseId2={caseId2} />
        {!loading && (caseId1 || caseId2) && (
          <>
            <div style={{ marginBottom: 20 }}>
              <TabsButton page={page} setPage={(page) => setPage(page)} />
            </div>
            <div style={{ height: 'calc(100% - 380px)', overflow: 'hidden' }}>
              <TabPanel value={page} index={1} children={<Fields />} />
              <TabPanel value={page} index={2}>
                <WellTable tab={'KPC'} />
              </TabPanel>
              <TabPanel value={page} index={3}>
                <WellTable tab={'U2'} />
              </TabPanel>
              <TabPanel value={page} index={4}>
                <WellTable tab={'U3'} />
              </TabPanel>
              <TabPanel value={page} index={5} children={<ViewResultTable tab={'TABLE'} />} />
              <TabPanel value={page} index={6} children={<GasTab tab={'GAS'} />} />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
