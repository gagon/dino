import {Prefab} from "./Prefab";

export interface InstanceData {
    id: number,
    value: any,
}

export interface InstanceLink {
    id: number,
    instance_id: number,
    sub_instance_id: number,
    property_id: number,
    created_at?: string
    updated_at?: string
    frontend_status?: string,
    instance?: Instance,
    SubInstance?: Instance
}

export interface InstanceFiles {
    id: number,
    value: any
}

export interface BaseInstance {
    id: number,
    title: string,
    prefab_id: number,
    status?: number,
}

export interface Instance extends BaseInstance {
    instance_data?: Array<InstanceData>,
    instance_links?: Array<InstanceLink>,
    instance_files?: Array<InstanceFiles>, //не приходит с сервера, свойство только для фронта
    created_at?: string,
    updated_at?: string
    prefab?: Prefab
}

export interface InstanceForm extends Instance {
    instance_data_unsaved?: InstanceDataUnsaved
    instance_links_last?: Array<InstanceLink>
}

export interface InstanceDataUnsaved {
    [prop: string]: any
}

export interface InstanceFilter {
    product_id?: number,
    as_tree?: boolean,
    value?: string,
    title?: string,
    prefab_id?: number,
    prefab?: Prefab | null
    property_id?: number
    limit: number,
    offset: number
    page: number
    is_root: boolean
    refreshFilter: number
}

export const defaultInstanceFilter: InstanceFilter = {
    product_id: 0,
    as_tree: false,
    value: "",
    prefab_id: 0,
    property_id: 999999,
    limit: 10,
    offset: 0,
    page: 0,
    prefab: null,
    is_root: false,
    refreshFilter: Math.random()
};