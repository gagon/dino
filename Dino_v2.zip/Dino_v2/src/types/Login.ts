import {Moment} from "moment";

export interface LoginData {
    username: string,
    password: string
}

export interface Role {
    name: string,
    description: string,
    id: number,
    is_admin: boolean,
    is_active: boolean,
    access_list: string,
    created_at: Moment | null,
    updated_at: Moment | null
}

export interface User {
    username: string,
    password: string,
    full_name: string,
    email: string,
    id: number,
    is_active: boolean,
    role: Role,
    role_id: number,
    blocked_until: string,
    created_at: Moment | null,
    updated_at: Moment | null
}

export interface UserFilter {
    search_text: string,
    role_id: number | string
}

export const DefaultUserFilter: UserFilter = {
    search_text: "",
    role_id: "",
}

export interface RoleFilter {
    search_text: string,
}

export const DefaultRoleFilter: RoleFilter = {
    search_text: "",
}

