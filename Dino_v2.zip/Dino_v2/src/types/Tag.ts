export interface Tag {
    id: number,
    title: string
}