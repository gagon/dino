import {Instance} from "./Instance";

export interface Callback {
    title: string,
    type: number,
    generate_id: string,
    function: string,
    options: any
}

export interface Method {
    title: string,
    type: number,
    generate_id: string,
    function: string,
    options: any
}

export interface FormMethod extends  Method{
    on_tick_time?: string
}

export interface Property {
    id: number,
    title: string,
    type: number,
    prefab_id: number,
    sub_prefab_id?:number | null,
    constraints: any,
    created_at?: string,
    updated_at?: string,
    sub_prefab?: Prefab
    generate_id?: string
    frontend_status?: "created" | "updated" | "deleted"
    order_number?: number
}

export interface FormProperty  extends Property {
    max?: number,
    min?: number
}

export interface Event {
    id: number,
    title: string,
    description?: string,
    created_at?: string
}

export interface BasePrefab {
    id: number,
    title: string,
    description: string
    product_id: number,
    is_root: boolean
}

export interface Prefab extends BasePrefab{
    created_at?: string,
    updated_at?: string,
    callbacks?: Array<Callback>,
    methods?: Array<Method>,
    properties?: Array<Property>
    events?: Array<Event>
}

export interface BasePropertyType {
    [number: number]: string
}

export interface MethodType {
    [number: number]: string
}

export function isPrefab(pet: Prefab | Instance | null): pet is Prefab {
    return (pet as Prefab).callbacks !== undefined;
}

export interface PrefabFilter {
    product_id: number,
    title?: string,
    offset: number,
    limit: number
    as_tree?: boolean
    page:number
    refreshFilter?: number
}

export const DefaultPrefabFilter: PrefabFilter = {
    product_id: 0,
    offset: 0,
    limit: 10,
    as_tree: false,
    page: 0,
    refreshFilter: Math.random()
};
