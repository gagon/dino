import {Tag} from "./Tag";


export interface Product {
    id: number
    title: string
    version?: string
    author?: string
    description?: string
    tags?: Array<Tag>
    created_at?: string
    updated_at?: string
    is_active?: boolean
}