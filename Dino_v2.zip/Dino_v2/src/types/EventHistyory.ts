export interface EventHistory {
    id: number,
    event_id: number,
    instance_id: number,
    created_at: string | null
}