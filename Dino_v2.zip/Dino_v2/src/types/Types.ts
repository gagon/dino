export interface Paginate {
    limit: number
    offset: number
}

export interface Refreshable {
    refresh: number
}