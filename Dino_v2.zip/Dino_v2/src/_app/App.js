import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import ThemeProvider from '../common/ThemeProvider/ThemeProvider';
import DatePickerProvider from '../common/DatePickerProvider/DatePickerProvider';
import Root from './Root';
import { store } from '../_helpers/store';
import { history } from '../_helpers/history';

export const dispatch = store.dispatch;
export default function App() {
  return (
    <Provider store={store}>
      <BrowserRouter forceRefresh={true} history={history}>
        <ThemeProvider>
          <DatePickerProvider>
            <Root />
          </DatePickerProvider>
        </ThemeProvider>
      </BrowserRouter>
    </Provider>
  );
}
