import React, { useEffect } from 'react';
import { ReactNotifications } from 'react-notifications-component';
import { Routes } from 'react-router';
import { Route } from 'react-router-dom';
import BadGateway from '../common/BadGateway/BadGateway';
import Header from '../common/Header/Header';
import HeaderMenu from '../common/HeaderMenu/HeaderMenu';
import LoginPage from '../pages/Login/Login';
import routerProps from '../_helpers/routerProps';
import DinoSocket from '../_helpers/socket';

export default function Root() {
  useEffect(() => {
    DinoSocket.init();
  }, []);

  return (
    <div style={{ overflow: 'hidden' }}>
      <ReactNotifications />
      <BadGateway>
        <LoginPage>
          <Header />
          <HeaderMenu />
          <div style={{ minHeight: 'calc(100vh - 220px)', paddingLeft: 0 }}>
            <Routes>
              <Route exact {...routerProps.case} />
              <Route exact {...routerProps.login} />
              <Route exact {...routerProps.gatheringReport} />
              <Route exact {...routerProps.compare} />
              <Route exact {...routerProps.optimize} />
              <Route exact {...routerProps.config} />
              <Route {...routerProps.page404} />
            </Routes>
          </div>
        </LoginPage>
      </BadGateway>
    </div>
  );
}
