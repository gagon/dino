import io from 'socket.io-client';

export default class DinoSocket {
  static init() {
    try {
      const port = document.location.port ? ':' + document.location.port : '';
      DinoSocket.socket = io.connect('http://' + document.domain + port, {
        path: '/socket.io',
      });
    } catch (e) {
      console.error(e);
    }
  }
}
