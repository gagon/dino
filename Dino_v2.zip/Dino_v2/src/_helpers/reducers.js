import sortReducers from '../common/utils/sortReducers';
import badGatewayReducer, { badGatewayModule } from '../common/BadGateway/BadGatewayDucks';
import themeReducer, { themeModule } from '../common/ThemeProvider/ThemeDucks';
import caseMenuReducer, { caseMenuModule } from '../pages/Case/SideBar/CaseMenuDucks';
import optimizeMenuReducer, {
  optimizeMenuModule,
} from '../pages/Optimize/SideBar/OptimseMenuDucks';
import caseReducer, { caseModule } from '../pages/Case/CaseDucks/CaseDucks';
import optimizeReducer, { optimiseModule } from '../pages/Optimize/OptimiseDucks';
import compareReducer, { compareModule } from '../pages/Compare/CompareDucks';
import loginReducer, { loginModule } from '../pages/Login/LoginDucks';
import scheduledCasesReducer, {
  scheduledModule,
} from '../common/ScheduledCases/ScheduledCasesDucks';
import gatheringReportReducer, {
  gatheringReportModule,
} from '../pages/GatheringReport/GatheringReportDucks/GatheringReportDucks';
import configConnectionsReducer, {
  configConnections,
} from '../pages/Config/Connections/ConnectionsDucks';
import resultCalculationsReducer, {
  resultCalculationsModule,
} from '../pages/Config/ResultCalculations/ResultCalculationsDucks';
import resultLabelsReducer, {
  resultLabelsModule,
} from '../pages/Config/ResultLabels/ResultLabelsDucks';
import appSettingsReducer, {
  appSettingsModule,
} from '../pages/Config/AppSettings/AppSettingsDucks';
import userRolesReducer, { userRolesModule } from '../pages/Config/UserRoles/UserRolesDucks';
import gapFilesReducer, { gapFilesModule } from '../pages/Config/GapFiles/GapFilesDucks';
import wellsReducer, { wellsModule } from '../pages/Config/Wells/WellsDucks';
import configFieldsReducer, {
  configFieldsModule,
} from '../pages/Config/FieldConfig/FieldConfigDucks';
import wellConnectionsReducer, {
  wellConnectionsModule,
} from '../common/WellConnectionsModal/WellConnectionsDucks';
import commentsSidebarReducer, {
  commentsSidebarModule,
} from '../common/CommentsSidebar/CommentsSidebarDucks';

export default sortReducers({
  [badGatewayModule]: badGatewayReducer,
  [themeModule]: themeReducer,
  [caseMenuModule]: caseMenuReducer,
  [caseModule]: caseReducer,
  [optimiseModule]: optimizeReducer,
  [compareModule]: compareReducer,
  [loginModule]: loginReducer,
  [scheduledModule]: scheduledCasesReducer,
  [gatheringReportModule]: gatheringReportReducer,
  [optimizeMenuModule]: optimizeMenuReducer,
  [configConnections]: configConnectionsReducer,
  [resultCalculationsModule]: resultCalculationsReducer,
  [resultLabelsModule]: resultLabelsReducer,
  [appSettingsModule]: appSettingsReducer,
  [userRolesModule]: userRolesReducer,
  [gapFilesModule]: gapFilesReducer,
  [wellsModule]: wellsReducer,
  [configFieldsModule]: configFieldsReducer,
  [wellConnectionsModule]: wellConnectionsReducer,
  [commentsSidebarModule]: commentsSidebarReducer,
});
