import { PIDataApi } from './service';
import { generateWebID } from '../pages/Case/FieldWellDataModal/FieldWellDataUtils';
import moment from 'moment';

export class PIData {
  constructor(afServer) {
    this.valUrl = `https://${afServer}/piwebapi/streams/`;
    this.attUrl = `https://${afServer}/piwebapi/attributes/`;

    this.getAFData = function (path, ts) {
      if (!path) {
        return;
      }

      const encDate = encodeURIComponent(moment(ts).format('YYYY-MM-DDTHH:mm:ssZ'));
      const fullURL = this.valUrl + generateWebID(path) + '/value?time=' + encDate;

      return PIDataApi.get(fullURL);
    };

    this.saveAFData = function (path, ts, value, bViaPITag) {
      if (!path) {
        return;
      }
      const newValue = new Object();
      newValue.Timestamp = moment(ts).format('YYYY-MM-DDTHH:mm:ssZ');
      newValue.Value = value;
      newValue.Good = true;
      newValue.Questionable = false;
      const jsonString = JSON.stringify(newValue);

      if (bViaPITag) {
        const getPIpt = this.attUrl + generateWebID(path);

        return PIDataApi.get(getPIpt).then((attObj) => {
          const fullURL =
            attObj.data.Links.Point.replace('/points/', '/streams/') +
            '/value?updateOption=Replace';

          return PIDataApi.post(fullURL, jsonString);
        });
      } else {
        const fullURL = this.valUrl + generateWebID(path) + '/value?updateOption=Replace';

        return PIDataApi.post(fullURL, jsonString);
      }
    };
  }
}
