import axios from 'axios';
import i18next from 'i18next';

export const Api = axios.create({
  headers: {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    withCredentials: true,
  },
  withCredentials: true,
});

const interceptor = ({ headers, ...config }) => {
  // const accessToken = localStorage.getItem('accessToken');
  // headers['Content-Language'] = getContentLanguage();
  // if (!headers.Authorization && accessToken) {
  //   headers.Authorization = `Bearer ${accessToken}`;
  // }
  return { ...config, headers };
};

const unauthorized = async (error) => {
  return Promise.reject(error);
};

function getContentLanguage() {
  switch (i18next.language) {
    case 'ru':
      return 'ru,ru-RU';
    case 'kk':
      return 'kk,kk-KZ';
    default:
      return 'en,en-US';
  }
}

if (process.env.REACT_APP_BASE_URL) {
  axios.defaults.baseURL = process.env.REACT_APP_BASE_URL;
}
axios.interceptors.request.use(interceptor, (e) => Promise.reject(e));
axios.interceptors.response.use((r) => r, unauthorized);

export const CaseApi = {
  loadCase: (id) => Api.get(`/api/get_case_by_id/${id}`),
  loadFieldBalance: (id) =>
    Api.get(`/api/get_field_balance/${id}`, {
      headers: {
        params: {
          modify: true,
        },
      },
    }),
  loadCaseConfigSetting: () => Api.get('/api/get_case_config_settings'),
  loadAllCase: (params) => Api.post('/api/get_all_case_data', params),
  crateNewCase: (currentDate) => Api.get(`/api/create_case/${currentDate}`),
  cloneCase: (params) => Api.get(`/api/clone_case`, { params }),
  updateCase: (values) => Api.put(`/api/save_case_data`, values),
  deleteCase: (id) => Api.delete(`/api/delete_case/${id}`),
  getDatafromUrl: (url) => Api.get(url),
  getCaseOption: (caseId) =>
    Api.get(`/api/get_case_options_by_id`, {
      params: { opt_routing: false, case_id: caseId, size: 50, page: 1 },
    }),
  getUnitClasses: (afServer) =>
    Api.get(
      `https://${afServer}/piwebapi/assetservers/F1RSF2L2H8-86U-jM1Z2heBNdwS1BPQVBJMDM/unitclasses`
    ),
  getUnits: (unitsLink) => Api.get(unitsLink),
  loadReport: (caseId, calcDict) =>
    Api.post(
      `/download?case_id=${caseId}`,
      { calcDict },
      {
        headers: { 'Content-Type': 'application/json' },
        responseType: 'blob',
      }
    ),
};

export const LoginApi = {
  login: (user) => Api.post('/api/login', user),
  logout: () => Api.get('/logout'),
  loadUserSetting: () => Api.get('/api/get_user_settings'),
  loadAppSetting: () => Api.get('/api/get_app_settings'),
  saveUserSettings: (settings) => Api.put('/api/save_user_settings', { UserSetting: settings }),
};

export const ScheduledApi = {
  loadList: (params) => Api.post(`/api/get_case_schedule_data`, params),
  loadMessages: (caseId) => Api.get(`/api/get_case_schedule_messages/${caseId}`),
  runOptimization: (values) => Api.post(`/api/create_case_schedule`, values),
  remove: (caseId) => Api.delete(`/api/remove_case_schedule/${caseId}`),
};

export const StreamsApi = {
  loadStreams: (afServer, webId, startTime, endTime, desiredUnits) => {
    const url =
      `https://${afServer}/piwebapi/streams/${webId}/plot?startTime=${startTime}&endTime=${endTime}` +
      (desiredUnits !== undefined && desiredUnits !== null ? `&desiredUnits=${desiredUnits}` : '');
    return Api.get(url);
  },
};

export const GatheringReportApi = {
  uploadReport: (params) => Api.post('/upload_gath_rep', params),
  getGatheringReportDates: (data) => Api.post('/api/get_gathering_report_dates', data),
  getGatheringReportData: (data) => Api.post('/api/get_gath_rep_data', data),
  saveGatheringReportData: (data) => Api.post('/api/save_gath_rep_data', data),
};

export const PIDataApi = {
  get: (url) => Api.get(url),
  post: (url, params) => Api.post(url, params),
};

export const OptimiseApi = {
  getCaseOptions: (caseId) =>
    Api.get(`/api/get_case_options_by_id`, {
      params: { opt_routing: true, case_id: caseId, size: 50, page: 1 },
    }),
  saveDinoData: (params) => Api.post(`/api/save_dino_data`, params),
};

export const ConnectionsApi = {
  getConnections: () => Api.get(`/api/get_connection_mappings`),
  addConnection: () => Api.put(`/api/add_connection_mappings`),
  removeConnection: (id) => Api.delete(`/api/remove_connection_mapping/${id}`),
  saveData: (data) => Api.put(`/api/save_connection_mapping`, data),
};

export const ResultCalculationsApi = {
  getData: () => Api.get(`/api/get_result_calculations`),
  addConfig: () => Api.post(`/api/add_result_calculation`),
  removeConfig: (id) => Api.delete(`/api/remove_result_calculation/${id}`),
  saveData: (data) => Api.put(`/api/save_result_calculation`, data),
};

export const ResultLabelsApi = {
  getData: () => Api.get(`/api/get_result_labels`),
  addConfig: () => Api.post(`/api/add_result_label`),
  removeConfig: (id) => Api.delete(`/api/remove_result_label/${id}`),
  saveData: (data) => Api.put(`/api/save_result_label`, data),
};

export const AppSettingsApi = {
  saveAppSettings: (data) => Api.put(`/api/save_app_settings`, data),
};

export const UserRolesApi = {
  loadUserRoles: () => Api.get('/api/get_user_roles'),
  saveUserRoles: (data) => Api.put('/api/save_user_roles', data),
};

export const GapFilesApi = {
  getGapFiles: () => Api.get('/api/get_gap_files'),
  getGapFileData: (id) => Api.get(`/api/get_gap_file_data/${id}`),
  removeGapFile: (id) => Api.delete(`/api/remove_gap_file/${id}`),
  changeDefaultGap: (id) => Api.patch(`/api/change_default_gap/${id}`),
  uploadGapFile: (data) => Api.post('/upload_gap_file', data),
};

export const WellsApi = {
  getCurrentGapFileData: () => Api.get('/api/get_current_gap_file_data'),
  saveWell: (data) => Api.post('/api/save_well_data', data),
  getWellIdByMaskPipe: (data) => Api.post('api/get_well_id_by_mask_pipe', data),
  uploadPcReport: (data) => Api.post('/upload_pc_rep', data),
  addWellConnection: (data) => Api.post('/api/add_well_connection', data),
  removeWellConnection: (data) => Api.delete('/api/remove_well_connection', { data }),
  getConnectionsFromGap: (data) => Api.post('/api/get_connections_from_gap', data),
  saveAllWellPcs: (data) => Api.post('/api/save_all_well_pcs', data),
};

export const FieldConfigApi = {
  loadCaseConfigSetting: () => Api.get('/api/get_case_config_settings'),
  saveData: (data) => Api.post(`/api/save_field_config_diagram`, data),
};

export const CommentsApi = {
  getComments: (wellName, caseId) =>
    Api.get(`/api/get_comments_by_wellname/well_name=${wellName}/case_id=${caseId}`),
  addComment: (data) => Api.post('/api/new_comment', data),
  removeComment: (commentId) => Api.delete(`/api/remove_comment/${commentId}`),
};
