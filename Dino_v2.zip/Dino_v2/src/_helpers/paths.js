const paths = {
  trips: '/',
  case: '/case/:caseId',
  config: '/config',
  login:'/login',
  compare: '/case-compare',
  gatheringReport: '/gathering-report',
  help: '/help',
  adminUser: '/help',
  optimize: '/optimize/:caseId',
  page404: '/page404',
};

export default paths;
