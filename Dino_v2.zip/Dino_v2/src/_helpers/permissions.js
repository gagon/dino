const permissions = {
    CAN_VIEW_PROFILE: 'CAN_VIEW_PROFILE',
};

export default permissions;
