import { createBrowserHistory } from 'history';

const browserHistory = createBrowserHistory();
const intersectionObserver = new IntersectionObserver(entries => {
    let [entry] = entries;
    if (entry.isIntersecting) {
        setTimeout(() => {
            intersectionObserver.unobserve(entry.target);
            entry.target.style.backgroundColor = 'transparent';
        }, 400);
    }
});



export const history = browserHistory;
