import React from 'react';
import paths from './paths';
import Page404 from '../pages/Page404/Page404';
import Case from '../pages/Case/Case';
import Login from '../pages/Login/Login';
import GatheringReport from '../pages/GatheringReport/GatheringReport';
import Compare from '../pages/Compare/Compare';
import Optimise from '../pages/Optimize/Optimise';
import Config from '../pages/Config/Config';

const routerProps = {
  case: {
    path: paths.case,
    element: <Case />,
  },
  login: {
    path: paths.login,
    element: <Login />,
  },
  gatheringReport: {
    path: paths.gatheringReport,
    element: <GatheringReport />,
  },
  compare: {
    path: paths.compare,
    element: <Compare />,
  },
  optimize: {
    path: paths.optimize,
    element: <Optimise />,
  },
  page404: {
    path: paths.page404,
    element: <Page404 />,
  },
  config: {
    path: paths.config,
    element: <Config />,
  },
};

export default routerProps;
