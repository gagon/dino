export const FL_PRESSURE_CONFIG_ID = 1;
export const SLOT_PRESSURE_CONFIG_ID = 2;
export const SLOT_TEMPERATURE_CONFIG_ID = 3;
export const ONLINE_STATUS_CONFIG_ID = 4;
export const WH_PRESSURE_CONFIG_ID = 5;
export const GATHERING_STATUS_CONFIG_ID = 6;
export const CHOKE_POSITION_CONFIG_ID = 11;

export const NEW_CASE_DEFAULT_TIME = 'NEW_CASE_DEFAULT_TIME';
export const CLONE_CASE_GAP_SETTING = 'CLONE_CASE_GAP_SETTING';
export const FIELD_FETCH_PERIOD = 'FIELD_FETCH_PERIOD';
export const FIELD_FETCH_METHOD = 'FIELD_FETCH_METHOD';
export const FIELD_NON_NUMERIC = 'FIELD_NON_NUMERIC';
export const WELL_FETCH_PERIOD = 'WELL_FETCH_PERIOD';
export const WELL_FETCH_METHOD = 'WELL_FETCH_METHOD';
export const WELL_NON_NUMERIC = 'WELL_NON_NUMERIC';
export const OPT_MAX_ITERATIONS = 'OPT_MAX_ITERATIONS';
export const GAS_FIELD_OPTIMISATION = 'GAS_FIELD_OPTIMISATION';
export const RUN_OPT_DEFAULT_TIME = 'RUN_OPT_DEFAULT_TIME';
export const CONTINUE_UNFINISHED_ROUTES = 'CONTINUE_UNFINISHED_ROUTES';
export const LAST_VIEWED_CASE = 'LAST_VIEWED_CASE';

export const GAS_OPTIMIZATION_FIELDS_COPY = [
  { group: 'Process', field: 'New OGP', copyTo: { group: 'Export', field: 'OGP gas Max' } },
  { group: 'Process', field: 'New Fuel Gas', copyTo: { group: 'Export', field: 'Fuel gas Max' } },
  {
    group: 'Process',
    field: 'New Gas injection',
    copyTo: { group: 'Export', field: 'Gas injection Max' },
  },
  {
    group: 'Process',
    field: 'KPC Max Gas from Wells',
    copyTo: { group: 'Unit KPC', field: 'Q Gas Max' },
  },
  {
    group: 'Process',
    field: 'U2 Max Gas from Wells',
    copyTo: { group: 'Unit 2', field: 'Q Gas Max' },
  },
  {
    group: 'Process',
    field: 'U3 Max Gas from Wells',
    copyTo: { group: 'Unit 3', field: 'Q Gas Max' },
  },
  {
    group: 'Process',
    field: 'KPC Max Gas Transfer to U2',
    copyTo: { group: 'Export', field: 'KPC Qgas to Unit-2 Max' },
  },
  {
    group: 'Process',
    field: 'KPC Max Gas Transfer to U3',
    copyTo: { group: 'Export', field: 'KPC Qgas to Unit-3 Max' },
  },
];

export const currentFieldMappings = {
  kpc_af_gas: { grp: 'Unit KPC', field: 'Q Gas AF' },
  kpc_af_oil: { grp: 'Unit KPC', field: 'Q Oil AF' },
  kpc_af_wat: { grp: 'Unit KPC', field: 'Q Water AF' },
  u2_af_gas: { grp: 'Unit 2', field: 'Q Gas AF' },
  u2_af_oil: { grp: 'Unit 2', field: 'Q Oil AF' },
  u2_af_wat: { grp: 'Unit 2', field: 'Q Water AF' },
  u3_af_gas: { grp: 'Unit 3', field: 'Q Gas AF' },
  u3_af_oil: { grp: 'Unit 3', field: 'Q Oil AF' },
  u3_af_wat: { grp: 'Unit 3', field: 'Q Water AF' },
};
export const afFieldMappings = {
  af_kpc_gas: { grp: 'Unit KPC', field: 'Q Gas AF' },
  af_kpc_oil: { grp: 'Unit KPC', field: 'Q Oil AF' },
  af_kpc_wat: { grp: 'Unit KPC', field: 'Q Water AF' },
  af_u2_gas: { grp: 'Unit 2', field: 'Q Gas AF' },
  af_u2_oil: { grp: 'Unit 2', field: 'Q Oil AF' },
  af_u2_wat: { grp: 'Unit 2', field: 'Q Water AF' },
  af_u3_gas: { grp: 'Unit 3', field: 'Q Gas AF' },
  af_u3_oil: { grp: 'Unit 3', field: 'Q Oil AF' },
  af_u3_wat: { grp: 'Unit 3', field: 'Q Water AF' },
};
